/** @type {import('next-sitemap').IConfig} */

NEXT_PUBLIC_DOMAIN = process.env.NEXT_PUBLIC_DOMAIN;

module.exports = {
  siteUrl: NEXT_PUBLIC_DOMAIN,
  exclude: [
    '/api',
    '/api/*',
    '/fav',
    '/400',
    '/404',
    '/500',
    '/me',
    '/me/*',
    '/signin',
    '/checkout',
    '/checkout/*',
    '/qr',
    '/qr/*',
    '/market',
    '/market/*',
    '/ozon',
    '/ozon/*',
  ],
  generateRobotsTxt: true,
  // optional
  robotsTxtOptions: {
    policies: [
      {
        userAgent: '*',
        disallow: [
          //'/',
          '/api',
          '/api/*',
          '/me',
          '/me/*',
          '/signin',
          '/checkout',
          '/checkout/*',
          '/qr',
          '/qr/*',
          '/market',
          '/market/*',
          '/ozon',
          '/ozon/*',
        ],
      },
      {
        userAgent: 'Yandex',
        disallow: [
          //'/',
          '/api',
          '/api/*',
          '/me',
          '/me/*',
          '/signin',
          '/checkout',
          '/checkout/*',
          '/qr',
          '/qr/*',
          '/market',
          '/market/*',
          '/ozon',
          '/ozon/*',
        ],
      },
    ],
  },
};
