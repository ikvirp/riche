<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8"/>
  <meta content="IE=edge" http-equiv="X-UA-Compatible"/>
  <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0" name="viewport">
  <title><?php Core_Page::instance()->showTitle(); ?></title>
  <meta name="description" content="<?php Core_Page::instance()->showDescription(); ?>">
  <link rel="shortcut icon" href="/favicon.ico"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" referrerpolicy="no-referrer" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/css/bootstrap-select.min.css'>
  <style>
    .comment__rating {
        white-space: nowrap;
    }
    .comment__rating svg {
        display: inline-block;
        width: 16px;
    }
    .comment__rating .star {
        fill: #58B151;
    }
    .comment__rating .star-empty {
        stroke: #58B151;
    }
    .bootstrap-select:not([class*=col-]):not([class*=form-control]):not(.input-group-btn) {
        width: 100%;
    }
    .bootstrap-select>.dropdown-toggle {
        border: var(--bs-border-width) solid var(--bs-border-color);
    }
  </style>
    <?php
    Core_Page::instance()
        ->showCss();
    ?>
</head>
<body class="bg-light">
  <div class="container">
    <ul class="nav nav-tabs mt-4">
      <li class="nav-item me-5">
        <div class="logo mt-1">
          <img alt="RICHE" title="RICHE" src="/upload/logo.svg" style="height: 30px"/>
          <svg viewBox="0 0 88 20" fill="currentColor" xmlns="http://www.w3.org/2000/svg" style="height: 25px"><path d="M8.982 9.457H4.357V3.335h4.625a3.047 3.047 0 0 1 3.057 1.828c.167.39.251.81.246 1.233a3.032 3.032 0 0 1-2.053 2.907c-.401.138-.827.19-1.25.154ZM15.9 19.659l-4.712-7.565a5.412 5.412 0 0 0 3.367-1.975 5.393 5.393 0 0 0 1.158-3.723A5.838 5.838 0 0 0 13.937 2 5.86 5.86 0 0 0 9.48.362H.967v19.297h3.39V12.43H7.71l4.263 7.229H15.9ZM25.124.362h-3.39v19.272h3.39V.362ZM40.008 19.969a8.736 8.736 0 0 0 7.753-4.33l-2.892-1.468a5.68 5.68 0 0 1-4.861 2.8 6.63 6.63 0 0 1-4.838-2.048 6.605 6.605 0 0 1-1.819-4.92 6.58 6.58 0 0 1 1.82-4.916 6.609 6.609 0 0 1 4.837-2.039 5.742 5.742 0 0 1 4.86 2.8l2.893-1.481a8.738 8.738 0 0 0-7.753-4.33 9.751 9.751 0 0 0-7.23 2.783 9.714 9.714 0 0 0-2.905 7.17 9.697 9.697 0 0 0 2.904 7.171 9.738 9.738 0 0 0 7.23 2.783M69.05 19.621V.361h-3.378V8.25H55.625V.362h-3.39v19.26h3.39v-8.399h10.047v8.398h3.378ZM87.873 19.621v-2.973h-9.835V11.31h9.635V8.337h-9.635V3.335h9.835V.362H74.647v19.26h13.226Z"></path></svg>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="/manager/">Отзывы</a>
      </li>
    </ul>
  </div>
  <main>
      <div class="container-fluid">
          <div class="bg-white py-4 px-3">
              <?php
              Core_Page::instance()->execute();
              ?>
          </div>
      </div>
  </main>
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/js/bootstrap-select.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/js/i18n/defaults-ru_RU.js"></script>
  <script>
    $(function() {
      jQuery.extend({
        sendCommentAnswer: function (commentAnswerElement, commentId) {
          $.ajax({
            url: './?action=comment_answer',
            type: 'POST',
            dataType: 'json',
            data: {
              comment_id: commentId,
              text: $(commentAnswerElement).val()
            },
            success: function(data){
              //$.preloader('hide');
              if (data.status == 'ok') {
                location.reload();
              }
            }
          });
          return false;
        },
        commentChangeActive: function (comment_id) {
          $.clientRequest({
            path: './?action=comment_change_active' + '&comment_id=' + comment_id,
            callBack: function () {
              //$.preloader('hide');
            },
          });
          return false;
        },
        clientRequest: function (j) {
          if (typeof j.callBack == 'undefined') {
            alert('Callback function is undefined');
          }
          //$.preloader('show');
          var l = j.path,
            k = {};
          k._ = Math.round(new Date().getTime());
          jQuery.ajax({
            context: j.context,
            url: l,
            type: 'POST',
            data: k,
            dataType: 'json',
            success: j.callBack,
          });
          return false;
        },
        preloader: function (method) {
          if (methods[method]) {
            return methods[method].apply(
              this,
              Array.prototype.slice.call(arguments, 1)
            );
          } else {
            $.error('Method ' + method + ' does not exist');
          }
        },
      });
    });
  </script>
</body>
</html>