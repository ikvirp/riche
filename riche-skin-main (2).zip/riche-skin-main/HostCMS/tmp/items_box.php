<?php

$oQueryBuilderSelect = Core_QueryBuilder::select(
  'id',
  'marking',
  'name',
  'price',
  'weight',

  'package_length',
  'package_width',
  'package_height',
  'package_weight'
)
  ->from('shop_items')
  ->where('shortcut_id', '=', 0);

$aResult = $oQueryBuilderSelect
  ->execute()
  ->asAssoc()
  ->result();

foreach ($aResult as $item) {
  echo '<br/>';
  echo implode('|', $item);
}
