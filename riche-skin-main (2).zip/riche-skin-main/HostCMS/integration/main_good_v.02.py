# coding utf-8

import retailcrm

client = retailcrm.v5('https://b7w2x7a.retailcrm.ru', '6Dt53oZM07hAggJtSmsFFsPSCqFygU8v')

order = {
  'firstName': 'John',
  'lastName': 'Doe',
  'phone': '+79000000000',
  'email': 'john@example.com',
  'orderMethod': 'call-request',
  'weight': 353,
  'length': 450,
  'width': 200,
  'height': 150,
  'managerId': 331,
  'shipmentStore': "cheb",
  'customFields': { 'delivery_apiship_provider_key': "cdek" }, # Провайдер доставки
  'items': [
              {
              'bonusesChargeTotal': 0,
              'bonusesCreditTotal': 0,
              'markingCodes': [ ],
              'id': 2097220,
              'priceType': {
                'code': "base"
              },
              'initialPrice': 999,
              'discounts': [ ],
              'discountTotal': 0,
              'prices': [
              {
                'price': 999,
                'quantity': 1
              }
              ],
              'vatRate': "20.00",
              'quantity': 1,
              'status': "new",
              'offer': {
              'displayName': "Матирующий крем для лица Адаптогены + Центелла",
              'id': 4550,
              'externalId': "7294",
              'xmlId': "7294",
              'name': "Матирующий крем для лица Адаптогены + Центелла",
              'article': "FC/22/FC/BMA/50",
              'vatRate': "20.00",
              'properties': {
              'tnved': "3304990000",
              'volume': "50"
              },
              'unit': {
              'code': "pcs",
              'name': "Штука",
              'sym': "шт."
              }
              },
              'properties': [ ],
              'purchasePrice': 0,
              'ordering': 100
              }
              ],
  'payments': {
                1179972: {
                  'id': 1179972,
                  'status': "paid",
                  'type': "tcs",
                  'amount': 1698,
                  }
              },
  'status': "send-to-assembling",
'delivery': {
'code': "apiship",
'integrationCode': "apiship",
'data': {
  'locked': 'true',
  'pickuppointAddress': "428018, Чувашия, Чебоксары, ул. Водопроводная, 22",
  'tariff': "53", # tariff_id
  'pickuppointId': "28910", # сapiship_point_id
  },
'cost': 150,
'netCost': 150,
'address': {
  'countryIso': "RU",
  'region': "Чувашская Республика - Чувашия",
  'regionId': 80,
  'city': "Чебоксары",
  'cityId': 1474,
  'cityType': "г.",
  'street': "Водопроводная",
  'streetId': 1114270,
  'streetType': "ул.",
  'building': "22",
  'housing': "1",
  'text': "ул. Водопроводная, д. 22, корп. 1"
  }
}
}

# for i in range(2):
result = client.order_create(order)