<?php
/**
 * HostCMS bootstrap file.
 *
 * @package HostCMS
 * @version 7.x
 * @author Hostmake LLC
 * @copyright © 2005-2021 ООО "Хостмэйк" (Hostmake LLC), http://www.hostcms.ru
 */
define('CMS_FOLDER', dirname(__FILE__) . DIRECTORY_SEPARATOR);
define('HOSTCMS', true);

// ini_set("memory_limit", "128M");
// ini_set("max_execution_time", "120");

// Константа запрещает выполнение ini_set, по умолчанию false - разрешено
define('DENY_INI_SET', false);

// Запрещаем установку локали, указанной в параметрах сайта
// define('ALLOW_SET_LOCALE', FALSE);
setlocale(LC_NUMERIC, 'POSIX');

if (!defined('DENY_INI_SET') || !DENY_INI_SET) {
	ini_set('display_errors', 1);

	if (version_compare(PHP_VERSION, '5.3', '<')) {
		/* Решение проблемы trict Standards: Implicit cloning object of class 'kernel' because of 'zend.ze1_compatibility_mode' */
		ini_set('zend.ze1_compatibility_mode', 0);

		set_magic_quotes_runtime(0);
		ini_set('magic_quotes_gpc', 0);
		ini_set('magic_quotes_sybase', 0);
		ini_set('magic_quotes_runtime', 0);
	}
}

require_once CMS_FOLDER . 'modules/core/core.php';

Core::init();

date_default_timezone_set(Core::$mainConfig['timezone']);

if (Core_Auth::logged()) {
	// Observers
	Core_Event::attach('Xsl_Processor.onBeforeProcess', [
		'Xsl_Processor_Observer',
		'onBeforeProcess',
	]);
	Core_Event::attach('Xsl_Processor.onAfterProcess', [
		'Xsl_Processor_Observer',
		'onAfterProcess',
	]);
	Core_Event::attach('Core_Cache.onBeforeGet', [
		'Core_Cache_Observer',
		'onBeforeGet',
	]);
	Core_Event::attach('Core_Cache.onAfterGet', [
		'Core_Cache_Observer',
		'onAfterGet',
	]);
	Core_Event::attach('Core_Cache.onBeforeSet', [
		'Core_Cache_Observer',
		'onBeforeSet',
	]);
	Core_Event::attach('Core_Cache.onAfterSet', [
		'Core_Cache_Observer',
		'onAfterSet',
	]);
}

// Windows locale
//setlocale(LC_ALL, array ('ru_RU.utf-8', 'rus_RUS.utf8'));

// debug
require_once CMS_FOLDER . 'modules/debug/debug.php';

// Округление цен в магазине
Shop_Controller::instance()->decimalDigits(0);
Shop_Controller::instance()->floatFormat('%.2f');

//$filePath = CMS_FOLDER . 'modules/retailcrm/events.php';
//is_file($filePath) && include_once($filePath);
