<?php

/* Акт */
class Shop_Print_Form_Handler2 extends Shop_Print_Form_Handler
{
  /**
   * Метод, запускающий выполнение обработчика
   */
  function execute()
  {
    parent::execute();

    $oShop_Order = $this->_Shop_Order;
    $oApp_Controller_Retailcrm = new App_Controller_Retailcrm(
      $oShop_Order->Shop
    );

    // sent paymentData
    $oApp_Controller_Retailcrm->orderPaid($oShop_Order);

    // check
    $aData = $oApp_Controller_Retailcrm->getOrder($oShop_Order);
    echo_r('Данные заказа:');
    echo_r($aData);

    return $this;
  }
}
