<?php

/* Акт */
class Shop_Print_Form_Handler1 extends Shop_Print_Form_Handler
{
  /**
   * Метод, запускающий выполнение обработчика
   */
  function execute()
  {
    parent::execute();

    $oShop_Order = $this->_Shop_Order;
    $oApp_Controller_Retailcrm = new App_Controller_Retailcrm(
      $oShop_Order->Shop
    );

    // create
    $oApp_Controller_Retailcrm->createOrder($oShop_Order);

    // check
    $aData = $oApp_Controller_Retailcrm->getOrder($oShop_Order);
    echo_r('Данные заказа:');
    echo_r($aData);

    return $this;
  }
}
