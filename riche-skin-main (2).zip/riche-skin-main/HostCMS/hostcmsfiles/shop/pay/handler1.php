<?php
/**
 * cloudpayments.ru
 */
class Shop_Payment_System_Handler1 extends Shop_Payment_System_Handler
{
  // INPUT POST PAY
  // https://data.riche.skin/app/v1.0/pay/

  // TEST
  // protected $publicId = 'pk_93153d44e9928fe7321e0f636e91b';
  // protected $secret = 'f9363e59afbec3bf5205b1b22752d101';

  // PROD RICHE_REACT
  protected $publicId = 'pk_a1ab96f0eae4f52b1f7a1646a10fb';
  protected $secret = 'fe990d1a2889dd5ac245e9a476c81fb3';

  protected $aStatuses = [
    'AwaitingAuthentication' => 'Операция ожидает аутентификации',
    'Authorized' => 'Операция Авторизована',
    'Completed' => 'Операция завершена',
    'Cancelled' => 'Операция отменена',
    'Declined' => 'Операция отклонена (нет денег на счете карты и т.п.)',
  ];

  protected function _getData($point, $requestData = null)
  {
    $url = 'https://api.cloudpayments.ru' . $point;

    $Core_Http = Core_Http::instance('curl')
      ->clear()
      ->timeout(5)
      ->method('POST')
      ->url($url)
      ->additionalHeader('Content-Type', 'application/json')
      ->additionalHeader('Accept', 'application/json')
      ->additionalHeader('Authorization', 'Basic ' . $this->_authData());

    if ($requestData) {
      $Core_Http->rawData(json_encode($requestData));
    }

    $Core_Http->execute();

    $aAnswer = json_decode($Core_Http->getDecompressedBody(), true);

    return $aAnswer;
  }

  protected function _authData()
  {
    return base64_encode($this->publicId . ':' . $this->secret);
  }

  protected function _blockOptions()
  {
    $oShop_Order = $this->_shopOrder;
    $amount = $oShop_Order->getAmount();

    $shopObserverHmp = new Shop_Observer_Hmp();
    $aPrintData = $shopObserverHmp->Shop_Order__Print($oShop_Order);

    $aItems = [];
    foreach ($aPrintData as $item) {
      $aItems[] = [
        'label' => mb_substr($item['name'], 0, 128), //наименование товара
        'price' => floatval($item['price']), //цена
        'quantity' => floatval($item['quantity']), //количество
        'amount' => floatval($item['price'] * $item['quantity']), //сумма
        'vat' => 20, //ставка НДС —Общая система налогообложения
        'method' => 4, // тег-1214 признак способа расчета - признак способа расчета — gjkysq hfcx\n
        'object' => $item['type'] == 1 ? 4 : 1, // тег-1212 признак предмета расчета - признак предмета товара, работы, услуги, платежа, выплаты, иного предмета расчета
        'measurementUnit' => 'шт', //единица измерения
      ];
    }

    $aReceiptData = [
      'Items' => $aItems,
      'calculationPlace' => 'riche.skin', //место осуществления расчёта, по умолчанию берется значение из кассы
      'taxationSystem' => 0, //система налогообложения; необязательный, если у вас одна система налогообложения
      'email' => $oShop_Order->email, //e-mail покупателя, если нужно отправить письмо с чеком
      'phone' => $oShop_Order->phone, //телефон покупателя в любом формате, если нужно отправить сообщение со ссылкой на чек
      'customerInfo' => $oShop_Order->surname . ' ' . $oShop_Order->name, // тег-1227 Покупатель - наименование организации или фамилия, имя, отчество (при наличии), серия и номер паспорта покупателя (клиента)
      //'customerInn' => '7708806063', // тег-1228 ИНН покупателя
      //'isBso' => false, //чек является бланком строгой отчётности
      //'AgentSign' => null, //признак агента, тег ОФД 1057
      // 'amounts' => [
      //   'electronic' => $amount, // Сумма оплаты электронными деньгами
      //   'advancePayment' => 0.0, // Сумма из предоплаты (зачетом аванса) (2 знака после запятой)
      //   'credit' => 0.0, // Сумма постоплатой(в кредит) (2 знака после запятой)
      //   'provision' => 0.0, // Сумма оплаты встречным предоставлением (сертификаты, др. мат.ценности) (2 знака после запятой)
      // ],
    ];

    return [
      'publicId' => $this->publicId,
      //'publicId' => 'test_api_00000000000000000000002',
      'description' => 'Оплата заказа ' . $oShop_Order->invoice,
      'amount' => $amount,
      'currency' => 'RUB',
      'invoiceId' => $oShop_Order->invoice,
      'accountId' => $oShop_Order->Siteuser->email,
      'email' => $oShop_Order->email,
      'requireEmail' => true,
      'language' => 'ru-RU',
      'applePaySupport' => true,
      'googlePaySupport' => true,
      'yandexPaySupport' => true,
      'sbpSupport' => true,
      'data' => [
        //содержимое элемента data
        'CloudPayments' => [
          'CustomerReceipt' => $aReceiptData, //онлайн-чек
        ],
      ],
    ];
  }

  protected function _blockConfig()
  {
    return [
      'appearance' => [
        'colors' => [
          'primaryButtonColor' => '#0000',
          'activeInputColor' => '#000',
          'inputBackground' => '#FFFFFF',
          'inputColor' => '#8C949F',
          'inputBorderColor' => '#E2E8EF',
          'errorColor' => '#EB5757',
          'skeletonBackground' => '#E2E8EF',
        ],
        'borders' => [
          'radius' => '12px',
        ],
      ],
      'components' => [
        'paymentButton' => [
          'text' => 'Оплатить',
          'fontSize' => '16px',
        ],
        'paymentForm' => [
          'labelFontSize' => '16px',
          'activeLabelFontSize' => '12px',
          'fontSize' => '16px',
        ],
      ],
    ];
  }

  public function getStatus()
  {
    $oShop_Order = $this->_shopOrder;

    $aBlock = null;
    $aConfig = null;

    if (!$oShop_Order->paid) {
      $aBlock = $this->_blockOptions();
      $aConfig = $this->_blockConfig();
    }

    $aStatus = [
      'paid' => boolval($oShop_Order->paid),
      'error' => false,
      'message' => 'Ошибка получения данных оплаты',
    ];

    // var_dump('start');
    // var_dump($aStatus);

    $aStatusData = $this->_getData('/payments/find', [
      'InvoiceId' => $oShop_Order->id,
    ]);

    // var_dump('aStatusData');
    // var_dump($aStatusData);

    $inSuccess = $aStatusData['Success'];
    $aStatus['error'] = !$inSuccess;

    // var_dump('inSuccess');
    // var_dump($aStatusData['Success']);

    // exit();

    if ($aStatusData['Success'] && isset($aStatusData['Model']['Status'])) {
      // var_dump('$inSuccess && isset($aStatusData["Model"]["Status"])');

      // exit();

      if ($this->aStatuses[$aStatusData['Model']['Status']]) {
        $aStatus['message'] = $this->aStatuses[$aStatusData['Model']['Status']];

        if ($aStatusData['Model']['Status'] == 'Completed') {
          $aStatus['paid'] = true;
        }
      }
    }

    return [
      'status' => $aStatus,
      'block' => $aBlock,
      'config' => $aConfig,
    ];
  }

  public function setXSLs()
  {
    Core_Event::notify('Shop_Payment_System_Handler.onBeforeSetXSLs', $this);

    $oShopOrder = $this->_shopOrder;
    $oStructure = $oShopOrder->Shop->Structure;
    $libParams = $oStructure->Lib->getDat($oStructure->id);

    $this->xslAdminMail(
      Core_Entity::factory('Xsl')->getByName('letter__order__admin')
    )->xslSiteuserMail(
      Core_Entity::factory('Xsl')->getByName('letter__order__siteuser')
    );

    Core_Event::notify('Shop_Payment_System_Handler.onAfterSetXSLs', $this);

    return $this;
  }

  public function sendOrderData()
  {
    $this->setMailSubjects()
      ->setXSLs()
      ->send();
    return $this;
  }
}
