<?php
/**
 * APIShip
 */
class Shop_Delivery_Handler1 extends Shop_Delivery_Handler
{
}
