<?php
/**
 * APP API
 *
 * @package HostCMS 6
 * @subpackage Appapi
 * @version 1.x
 * @author onbd.ru
 */
return [
  'menu' => 'APP API',
];
