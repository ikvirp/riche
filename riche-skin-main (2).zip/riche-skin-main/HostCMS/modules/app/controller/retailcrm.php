<?php

defined('HOSTCMS') || exit('HostCMS: access denied.');

class App_Controller_Retailcrm extends Core_Controller
{
	protected $_prefix = 'b7w2x7a';
	protected $_site = 'app-riche-skin';
	protected $_key = 'NWzkdJlsJsfAhA0bw6nts5PeNr8WOCj5';
	protected $_siteUrl = 'https://riche.skin';

	protected $_url = null;
	protected $_type = 'GET';

	protected $_oShop = null;

	protected $_allowedProperties = [];
	// protected $_cacheSignatures = [];

	/**
	 * Constructor.
	 * @param Shop_Model $oShop
	 */
	public function __construct(Shop_Model $oShop)
	{
		parent::__construct($oShop->clearEntities());

		//Core_Session::close();
	}

	public function getKey()
	{
		return $this->_key;
	}

	public function setType($type = 'FALSE')
	{
		$this->_type = $type;
		return $this;
	}

	protected function url($postfix)
	{
		return 'https://' . $this->_prefix . '.retailcrm.ru/api/v5' . $postfix;
	}

	protected function executeRequest($endpoint, $aParams = [])
	{
		$url = $this->url($endpoint);

		if ($this->_type == 'GET' && count($aParams)) {
			$url .= '?' . http_build_query($aParams);
		}

		//var_dump($url);
		//var_dump($this->_type);
		//exit();

		try {
			$Core_Http = Core_Http::instance('curl');
			$Core_Http
				->clear()
				->timeout(10)
				->method($this->_type)
				->url($url)
				//->additionalHeader('Content-Type', 'application/json')
				//->additionalHeader('Accept', 'application/json')
				->additionalHeader('X-API-KEY', $this->_key);

			if ($this->_type == 'POST') {
				//$Core_Http->rawData(json_encode($aParams));

				if (count($aParams)) {
					foreach ($aParams as $key => $value) {
						$Core_Http->data($key, $value);
					}
				}

				// if ($endpoint = '/customers/create') {
				//   echo $aParams['customer'];
				//   $Core_Http->execute();
				//   //var_dump($Core_Http->getBody());
				//   var_dump($Core_Http->getDecompressedBody());
				//   exit();
				// }
			}
			$Core_Http->execute();

			// var_dump($Core_Http->getDecompressedBody());
			// exit();

			$aAnswer = json_decode($Core_Http->getDecompressedBody(), true);

			return $aAnswer;
		} catch (Exception $e) {
			Core_Log::instance()
				->clear()
				->status(Core_Log::$ERROR)
				->write($e->getMessage());
		}

		return false;
	}

	public function validPhone($phone)
	{
		$phone = trim($phone);
		$phone = preg_replace('/[^0-9\+]/', '', $phone);
		$phone = preg_replace('/^(7|8|007)/', '+7', $phone);
		strlen($phone) == 10 && ($phone = "+7{$phone}");

		return $phone;
	}

	public function createCustomer($oSiteuser)
	{
		$aJSON = [];

		//$aJSON['isContact'] = true;
		//$aJSON['contragent']['contragentType'] = 'individual';
		$aJSON['externalId'] = $oSiteuser->id;
		$aJSON['email'] = $oSiteuser->email;
		$aJSON['site'] = $this->_site;

		$oSiteuser_Person = null;
		$aSiteuser_People = $oSiteuser->Siteuser_People->findAll(false);

		if (isset($aSiteuser_People[0])) {
			$oSiteuser_Person = $aSiteuser_People[0];
		}

		if ($oSiteuser_Person) {
			$aDirectory_Phones = $oSiteuser_Person->Directory_Phones->findAll(false);
			$oPhone = array_shift($aDirectory_Phones);
			//$phone = $oPhone->value;
			$aJSON['phones'][]['number'] = $oPhone->value;
			$aJSON['firstName'] = $oSiteuser_Person->name;
			$aJSON['lastName'] = $oSiteuser_Person->surname;
		}

		$aCustomer = [
			'site' => $this->_site,
			'customer' => json_encode($aJSON),
		];

		//return $aCustomer;

		return $this->setType('POST')->executeRequest(
			'/customers/create',
			$aCustomer
		);
	}

	public function findUserById($oSiteuser)
	{
		$aParams = [];
		$aParams['externalIds'] = [$oSiteuser->id];

		// $oSiteuser_Person = null;
		// $aSiteuser_People = $oSiteuser->Siteuser_People->findAll(false);

		// if (isset($aSiteuser_People[0])) {
		// 	$oSiteuser_Person = $aSiteuser_People[0];
		// }

		// if ($oSiteuser_Person) {
		// 	$aParams['filter[name]'] = $oSiteuser_Person->name;

		// 	$aDirectory_Phones = $oSiteuser_Person->Directory_Phones->findAll(false);
		// 	if (count($aDirectory_Phones)) {
		// 		$oPhone = array_shift($aDirectory_Phones);
		// 		$aParams['filter[name]'] = $oPhone->value;
		// 	}
		// }
		$aParams['filter[email]'] = $oSiteuser->email;

		$aReturnaFilter = $this->setType('GET')->executeRequest(
			'/customers',
			$aParams
		);

		// var_dump($aParams);
		// var_dump($aReturnaFilter);
		// exit();

		if (isset($aReturnaFilter['customers'][0])) {
			return $aReturnaFilter['customers'][0];
		}
		return false;
	}

	public function findUserByIdDev($oSiteuser)
	{
		$aParams = [];
		$aParams['externalIds'] = [$oSiteuser->id];

		// $oSiteuser_Person = null;
		// $aSiteuser_People = $oSiteuser->Siteuser_People->findAll(false);

		// if (isset($aSiteuser_People[0])) {
		// 	$oSiteuser_Person = $aSiteuser_People[0];
		// }

		// if ($oSiteuser_Person) {
		// 	$aParams['filter[name]'] = $oSiteuser_Person->name;

		// 	$aDirectory_Phones = $oSiteuser_Person->Directory_Phones->findAll(false);
		// 	if (count($aDirectory_Phones)) {
		// 		$oPhone = array_shift($aDirectory_Phones);
		// 		$aParams['filter[name]'] = $oPhone->value;
		// 	}
		// }
		$aParams['filter[email]'] = $oSiteuser->email;

		$aReturnaFilter = $this->setType('GET')->executeRequest(
			'/customers',
			$aParams
		);

		var_dump($aParams);
		var_dump($aReturnaFilter);
		exit();

		if (isset($aReturnaFilter['customers'][0])) {
			return $aReturnaFilter['customers'][0];
		}
		return false;
	}

	public function getOrder($oShop_Order)
	{
		$url = '/orders/' . $oShop_Order->invoice;

		// $aOrder = ['order' => null];
		// $aJSON = [];
		// $aOrder['order'] = json_encode($aJSON);

		$aParams = [];
		$aParams['site'] = $this->_site;

		$aAnswer = $this->setType('GET')->executeRequest($url, $aParams);

		return $aAnswer;
	}

	// OUT создание заказа
	// /api/v5/orders/create
	public function createOrderBad($oShop_Order)
	{
		$customer = $this->findUserById($oShop_Order->Siteuser);

		$aParams = [];
		$aParams['site'] = $this->_site;

		$aOrder = [];

		if ($customer) {
			$aOrder['customer']['externalId'] = $oShop_Order->Siteuser->id;
		} else {
			$aCustomer = $this->createCustomer($oShop_Order->Siteuser);
			if (isset($aCustomer['id'])) {
				$aOrder['customer']['externalId'] = $oShop_Order->Siteuser->id;
			}
		}

		$aOrder['customer']['type'] = 'customer';
		$aOrder['customer']['site'] = $this->_site;
		$aJSON['contragent']['contragentType'] = 'individual';

		$aOrder['number'] = $aOrder['externalId'] = $oShop_Order->invoice
			? $oShop_Order->invoice
			: $oShop_Order->id;
		// //$aOrder['order']['orderMethod'] = 'riche-website';
		$aOrder['createdAt'] = $oShop_Order->datetime;
		// $aOrder['order']['contragent']['contragentType'] = 'individual';

		// $aOrder['order']['firstName'] = $oShop_Order->name;
		// $aOrder['order']['lastName'] = $oShop_Order->surname;
		// $aOrder['order']['phone'] = $this->validPhone($oShop_Order->phone);
		// $aOrder['order']['email'] = $oShop_Order->email;

		$aOrder['firstName'] = $oShop_Order->name;
		$aOrder['lastName'] = $oShop_Order->surname;
		$aOrder['phone'] = $this->validPhone($oShop_Order->phone);
		$aOrder['email'] = $oShop_Order->email;

		$aOrder['orderMethod'] = 'app-riche-skin'; // # Источник заказа

		$shopObserverHmp = new Shop_Observer_Hmp();
		// посчитанные суммы
		$aItemsPre = $shopObserverHmp->Shop_Order__Print($oShop_Order);

		// 0 — Товар
		// 1 — Доставка
		// 2 — Пополнение лицевого счета
		// 3 — Скидка от суммы заказа
		// 4 — Скидка по дисконтной карте
		// 5 — Списание бонусов
		// 6 — Частичная оплата с лицевого счета

		$aItems = [];
		$delivery = $discount = $amount = 0;
		foreach ($aItemsPre as $item) {
			// товары
			if ($item['type'] == 0 && $item['price'] >= 0 && $item['quantity'] > 0) {
				$amount += floatval($item['price']) * floatval($item['quantity']);
				$aItems[] = [
					'initialPrice' => floatval($item['price_before_sale']),
					'discountManualAmount' => floatval(
						$item['price_before_sale'] - $item['price']
					),
					'quantity' => floatval($item['quantity']),
					'vatRate' => 20,
					//'status' => 'prepay',
					'productName' => $item['name'],
					'offer' => [
						'externalId' => $item['shop_item_id'],
						'vatRate' => 20,
					],
				];
			}
			// доставка
			if ($item['type'] == 1 && $item['price'] >= 0) {
				$delivery += $item['price'];
			}
		}

		$aOrder['items'] = $aItems;
		$aOrder['summ'] = $amount;
		$aOrder['totalSumm'] = $amount + $delivery;
		$aOrder['status'] = 'prepay'; //В ожидании предоплаты

		$oShop_Country = $oShop_Order->Shop_Country;
		$aOrder['countryIso'] = $oShop_Country->alpha2;
		$aOrder['delivery']['cost'] = $delivery;

		// "address": {
		//         "index": "postcode",
		//         "country": "shop_country_id",
		//         "region": "shop_country_location_id",
		//         "city": "shop_country_location_city_id",
		//         "street": "address",
		//         "notes": "0",
		//         "building": "0",
		//         "flat": "0"
		//     },

		$aAddress = [];
		if ($oShop_Order->postcode != '') {
			$aAddress[] = $oShop_Order->postcode;
		}
		$aAddress[] = $oShop_Order->Shop_Country->name;
		$aAddress[] = $oShop_Order->Shop_Country_Location->name;
		$aAddress[] = $oShop_Order->Shop_Country_Location_City->name;
		if ($oShop_Order->address != '') {
			$aAddress[] = $oShop_Order->address;
		}

		//$aOrder['delivery']['address']['text'] = implode(', ', $aAddress);
		$aOrder['delivery']['address'] = [
			'index' => $oShop_Order->postcode,
			'countryIso' => $oShop_Country->alpha2,
			'region' => $oShop_Order->Shop_Country_Location->name,
			'city' => $oShop_Order->Shop_Country_Location_City->name,
			'street' => $oShop_Order->address,
		];

		$aOrder['delivery']['code'] = 'apiship';
		$aOrder['delivery']['integrationCode'] = 'apiship';

		$tariff_prop = 0;
		$pickuppoin_prop = 0;

		// pickuppointId
		$oProperty = Core_Entity::factory('Property', 26);
		$aPropertyValues = $oProperty->getValues($oShop_Order->id);
		if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
			$pickuppoin_prop = $aPropertyValues[0]->value;
		}

		// tariff
		$oProperty = Core_Entity::factory('Property', 27);
		$aPropertyValues = $oProperty->getValues($oShop_Order->id);
		if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
			$tariff_prop = $aPropertyValues[0]->value;
		}

		$aOrder['delivery']['data'] = [
			'locked' => true,
			'pickuppointAddress' => implode(', ', $aAddress),
			'tariff' => $tariff_prop,
			'pickuppointId' => $pickuppoin_prop,
		];

		//'customFields': { 'delivery_apiship_provider_key': "cdek", }
		$oProperty = Core_Entity::factory('Property', 25);
		$aPropertyValues = $oProperty->getValues($oShop_Order->id);
		if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
			$aOrder['customFields']['delivery_apiship_provider_key'] =
				$aPropertyValues[0]->value;
		}

		$aOrder['payments'][0]['type'] = 'cloudpayments';
		$aOrder['payments'][0]['status'] = 'invoice'; // invoice Выставлен счет

		//promocod
		if ($oShop_Order->coupon) {
			$aOrder['customFields']['promocod'] = $oShop_Order->coupon;
		}

		// starter_total
		$aOrder['customFields']['starter_total'] = $oShop_Order->getAmount();

		// ссылка на оплату
		$aOrder['customFields']['payment_link'] =
			$this->_siteUrl . '/checkout/' . $oShop_Order->guid;

		$aParams['order'] = json_encode($aOrder);
		//$aParams['order'] = $aOrder;

		//public function show()
		$url = '/orders/create';

		//return $aParams;
		// print_r($aParams);
		//exit();

		$aAnswer = $this->setType('POST')->executeRequest($url, $aParams);

		// var_dump($aAnswer);
		// exit();
		if (isset($aAnswer['success'])) {
			return true;
		}
		return $aAnswer;
	}
	public function createOrder($oShop_Order)
	{
		$customer = $this->findUserById($oShop_Order->Siteuser);

		$aParams = [];
		$aParams['site'] = $this->_site;

		$aOrder = [];

		if ($customer) {
			//$aOrder['customer']['externalId'] = $oShop_Order->Siteuser->id;
			$aOrder['customer']['externalId'] = $customer['externalId'];

			// print_r($customer);
			// print_r($aOrder);
			// exit();
		} else {
			$aCustomer = $this->createCustomer($oShop_Order->Siteuser);
			if (isset($aCustomer['id'])) {
				$aOrder['customer']['externalId'] = $oShop_Order->Siteuser->id;
			}
		}

		$aOrder['customer']['type'] = 'customer';
		$aOrder['customer']['site'] = $this->_site;
		$aJSON['contragent']['contragentType'] = 'individual';

		$aOrder['number'] = $aOrder['externalId'] = $oShop_Order->invoice
			? $oShop_Order->invoice
			: $oShop_Order->id;
		// //$aOrder['order']['orderMethod'] = 'riche-website';
		$aOrder['createdAt'] = $oShop_Order->datetime;
		// $aOrder['order']['contragent']['contragentType'] = 'individual';

		// $aOrder['order']['firstName'] = $oShop_Order->name;
		// $aOrder['order']['lastName'] = $oShop_Order->surname;
		// $aOrder['order']['phone'] = $this->validPhone($oShop_Order->phone);
		// $aOrder['order']['email'] = $oShop_Order->email;

		$aOrder['firstName'] = $oShop_Order->name;
		$aOrder['lastName'] = $oShop_Order->surname;
		$aOrder['phone'] = $this->validPhone($oShop_Order->phone);
		$aOrder['email'] = $oShop_Order->email;

		$aOrder['orderMethod'] = 'app-riche-skin'; // # Источник заказа

		$shopObserverHmp = new Shop_Observer_Hmp();
		// посчитанные суммы
		$aItemsPre = $shopObserverHmp->Shop_Order__Print($oShop_Order);

		// 0 — Товар
		// 1 — Доставка
		// 2 — Пополнение лицевого счета
		// 3 — Скидка от суммы заказа
		// 4 — Скидка по дисконтной карте
		// 5 — Списание бонусов
		// 6 — Частичная оплата с лицевого счета

		$aItems = [];
		$delivery = $discount = $amount = 0;
		foreach ($aItemsPre as $item) {
			// товары
			if ($item['type'] == 0 && $item['price'] >= 0 && $item['quantity'] > 0) {
				$amount += floatval($item['price']) * floatval($item['quantity']);
				$aItems[] = [
					'initialPrice' => floatval($item['price_before_sale']),
					'discountManualAmount' => floatval(
						$item['price_before_sale'] - $item['price']
					),
					'quantity' => floatval($item['quantity']),
					'vatRate' => 20,
					//'status' => 'prepay',
					'productName' => $item['name'],
					'offer' => [
						'externalId' => $item['shop_item_id'],
						'vatRate' => 20,
					],
				];
			}
			// доставка
			if ($item['type'] == 1 && $item['price'] >= 0) {
				$delivery += $item['price'];
			}
		}

		$aOrder['items'] = $aItems;
		$aOrder['summ'] = $amount;
		$aOrder['totalSumm'] = $amount + $delivery;
		$aOrder['status'] = 'prepay'; //В ожидании предоплаты

		$oShop_Country = $oShop_Order->Shop_Country;
		$aOrder['countryIso'] = $oShop_Country->alpha2;
		$aOrder['delivery']['cost'] = $delivery;

		// "address": {
		//         "index": "postcode",
		//         "country": "shop_country_id",
		//         "region": "shop_country_location_id",
		//         "city": "shop_country_location_city_id",
		//         "street": "address",
		//         "notes": "0",
		//         "building": "0",
		//         "flat": "0"
		//     },

		$aAddress = [];
		if ($oShop_Order->postcode != '') {
			$aAddress[] = $oShop_Order->postcode;
		}
		$aAddress[] = $oShop_Order->Shop_Country->name;
		$aAddress[] = $oShop_Order->Shop_Country_Location->name;
		$aAddress[] = $oShop_Order->Shop_Country_Location_City->name;
		if ($oShop_Order->address != '') {
			$aAddress[] = $oShop_Order->address;
		}

		//$aOrder['delivery']['address']['text'] = implode(', ', $aAddress);
		$aOrder['delivery']['address'] = [
			'index' => $oShop_Order->postcode,
			'countryIso' => $oShop_Country->alpha2,
			'region' => $oShop_Order->Shop_Country_Location->name,
			'city' => $oShop_Order->Shop_Country_Location_City->name,
			'street' => $oShop_Order->address,
		];

		$aOrder['delivery']['code'] = 'apiship';
		$aOrder['delivery']['integrationCode'] = 'apiship';

		$tariff_prop = 0;
		$pickuppoin_prop = 0;

		// pickuppointId
		$oProperty = Core_Entity::factory('Property', 26);
		$aPropertyValues = $oProperty->getValues($oShop_Order->id);
		if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
			$pickuppoin_prop = $aPropertyValues[0]->value;
		}

		// tariff
		$oProperty = Core_Entity::factory('Property', 27);
		$aPropertyValues = $oProperty->getValues($oShop_Order->id);
		if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
			$tariff_prop = $aPropertyValues[0]->value;
		}

		$aOrder['delivery']['data'] = [
			'locked' => true,
			'pickuppointAddress' => implode(', ', $aAddress),
			'tariff' => $tariff_prop,
			'pickuppointId' => $pickuppoin_prop,
		];

		//'customFields': { 'delivery_apiship_provider_key': "cdek", }
		$oProperty = Core_Entity::factory('Property', 25);
		$aPropertyValues = $oProperty->getValues($oShop_Order->id);
		if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
			$aOrder['customFields']['delivery_apiship_provider_key'] =
				$aPropertyValues[0]->value;
		}

		$aOrder['payments'][0]['type'] = 'cloudpayments';
		$aOrder['payments'][0]['status'] = 'invoice'; // invoice Выставлен счет

		//promocod
		if ($oShop_Order->coupon) {
			$aOrder['customFields']['promocod'] = $oShop_Order->coupon;
		}

		// starter_total
		$aOrder['customFields']['starter_total'] = $oShop_Order->getAmount();

		// ссылка на оплату
		$aOrder['customFields']['payment_link'] =
			$this->_siteUrl . '/checkout/' . $oShop_Order->guid;

		$aParams['order'] = json_encode($aOrder);
		//$aParams['order'] = $aOrder;

		//public function show()
		$url = '/orders/create';

		//return $aParams;

		$aAnswer = $this->setType('POST')->executeRequest($url, $aParams);

		// print_r($customer);
		// print_r($url);
		// print_r($aParams);
		// var_dump($aAnswer);
		// var_dump($aAnswer['success']);
		// exit();

		// var_dump($aAnswer);
		// exit();
		if (isset($aAnswer['success'])) {
			return true;
		}
		return $aAnswer;
	}

	public function createOrderDev($oShop_Order)
	{
		$customer = $this->findUserById($oShop_Order->Siteuser);

		$aParams = [];
		$aParams['site'] = $this->_site;

		$aOrder = [];

		if ($customer) {
			//$aOrder['customer']['externalId'] = $oShop_Order->Siteuser->id;
			$aOrder['customer']['externalId'] = $customer['externalId'];

			// print_r($customer);
			// print_r($aOrder);
			// exit();
		} else {
			$aCustomer = $this->createCustomer($oShop_Order->Siteuser);
			if (isset($aCustomer['id'])) {
				$aOrder['customer']['externalId'] = $oShop_Order->Siteuser->id;
			}
		}

		$aOrder['customer']['type'] = 'customer';
		$aOrder['customer']['site'] = $this->_site;
		$aJSON['contragent']['contragentType'] = 'individual';

		$aOrder['number'] = $aOrder['externalId'] = $oShop_Order->invoice
			? $oShop_Order->invoice
			: $oShop_Order->id;
		// //$aOrder['order']['orderMethod'] = 'riche-website';
		$aOrder['createdAt'] = $oShop_Order->datetime;
		// $aOrder['order']['contragent']['contragentType'] = 'individual';

		// $aOrder['order']['firstName'] = $oShop_Order->name;
		// $aOrder['order']['lastName'] = $oShop_Order->surname;
		// $aOrder['order']['phone'] = $this->validPhone($oShop_Order->phone);
		// $aOrder['order']['email'] = $oShop_Order->email;

		$aOrder['firstName'] = $oShop_Order->name;
		$aOrder['lastName'] = $oShop_Order->surname;
		$aOrder['phone'] = $this->validPhone($oShop_Order->phone);
		$aOrder['email'] = $oShop_Order->email;

		$aOrder['orderMethod'] = 'app-riche-skin'; // # Источник заказа

		$shopObserverHmp = new Shop_Observer_Hmp();
		// посчитанные суммы
		$aItemsPre = $shopObserverHmp->Shop_Order__Print($oShop_Order);

		// 0 — Товар
		// 1 — Доставка
		// 2 — Пополнение лицевого счета
		// 3 — Скидка от суммы заказа
		// 4 — Скидка по дисконтной карте
		// 5 — Списание бонусов
		// 6 — Частичная оплата с лицевого счета

		$aItems = [];
		$delivery = $discount = $amount = 0;
		foreach ($aItemsPre as $item) {
			// товары
			if ($item['type'] == 0 && $item['price'] >= 0 && $item['quantity'] > 0) {
				$amount += floatval($item['price']) * floatval($item['quantity']);
				$aItems[] = [
					'initialPrice' => floatval($item['price_before_sale']),
					'discountManualAmount' => floatval(
						$item['price_before_sale'] - $item['price']
					),
					'quantity' => floatval($item['quantity']),
					'vatRate' => 20,
					//'status' => 'prepay',
					'productName' => $item['name'],
					'offer' => [
						'externalId' => $item['shop_item_id'],
						'vatRate' => 20,
					],
				];
			}
			// доставка
			if ($item['type'] == 1 && $item['price'] >= 0) {
				$delivery += $item['price'];
			}
		}

		$aOrder['items'] = $aItems;
		$aOrder['summ'] = $amount;
		$aOrder['totalSumm'] = $amount + $delivery;
		$aOrder['status'] = 'prepay'; //В ожидании предоплаты

		$oShop_Country = $oShop_Order->Shop_Country;
		$aOrder['countryIso'] = $oShop_Country->alpha2;
		$aOrder['delivery']['cost'] = $delivery;

		// "address": {
		//         "index": "postcode",
		//         "country": "shop_country_id",
		//         "region": "shop_country_location_id",
		//         "city": "shop_country_location_city_id",
		//         "street": "address",
		//         "notes": "0",
		//         "building": "0",
		//         "flat": "0"
		//     },

		$aAddress = [];
		if ($oShop_Order->postcode != '') {
			$aAddress[] = $oShop_Order->postcode;
		}
		$aAddress[] = $oShop_Order->Shop_Country->name;
		$aAddress[] = $oShop_Order->Shop_Country_Location->name;
		$aAddress[] = $oShop_Order->Shop_Country_Location_City->name;
		if ($oShop_Order->address != '') {
			$aAddress[] = $oShop_Order->address;
		}

		//$aOrder['delivery']['address']['text'] = implode(', ', $aAddress);
		$aOrder['delivery']['address'] = [
			'index' => $oShop_Order->postcode,
			'countryIso' => $oShop_Country->alpha2,
			'region' => $oShop_Order->Shop_Country_Location->name,
			'city' => $oShop_Order->Shop_Country_Location_City->name,
			'street' => $oShop_Order->address,
		];

		$aOrder['delivery']['code'] = 'apiship';
		$aOrder['delivery']['integrationCode'] = 'apiship';

		$tariff_prop = 0;
		$pickuppoin_prop = 0;

		// pickuppointId
		$oProperty = Core_Entity::factory('Property', 26);
		$aPropertyValues = $oProperty->getValues($oShop_Order->id);
		if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
			$pickuppoin_prop = $aPropertyValues[0]->value;
		}

		// tariff
		$oProperty = Core_Entity::factory('Property', 27);
		$aPropertyValues = $oProperty->getValues($oShop_Order->id);
		if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
			$tariff_prop = $aPropertyValues[0]->value;
		}

		$aOrder['delivery']['data'] = [
			'locked' => true,
			'pickuppointAddress' => implode(', ', $aAddress),
			'tariff' => $tariff_prop,
			'pickuppointId' => $pickuppoin_prop,
		];

		//'customFields': { 'delivery_apiship_provider_key': "cdek", }
		$oProperty = Core_Entity::factory('Property', 25);
		$aPropertyValues = $oProperty->getValues($oShop_Order->id);
		if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
			$aOrder['customFields']['delivery_apiship_provider_key'] =
				$aPropertyValues[0]->value;
		}

		$aOrder['payments'][0]['type'] = 'cloudpayments';
		$aOrder['payments'][0]['status'] = 'invoice'; // invoice Выставлен счет

		//promocod
		if ($oShop_Order->coupon) {
			$aOrder['customFields']['promocod'] = $oShop_Order->coupon;
		}

		// starter_total
		$aOrder['customFields']['starter_total'] = $oShop_Order->getAmount();

		// ссылка на оплату
		$aOrder['customFields']['payment_link'] =
			$this->_siteUrl . '/checkout/' . $oShop_Order->guid;

		$aParams['order'] = json_encode($aOrder);
		//$aParams['order'] = $aOrder;

		//public function show()
		$url = '/orders/create';

		//return $aParams;

		$aAnswer = $this->setType('POST')->executeRequest($url, $aParams);

		print_r($customer);
		print_r($url);
		print_r($aParams);
		var_dump($aAnswer);
		var_dump($aAnswer['success']);
		exit();

		// var_dump($aAnswer);
		// exit();
		if (isset($aAnswer['success'])) {
			return true;
		}
		return $aAnswer;
	}

	public function createOrder2($oShop_Order)
	{
		$customer = $this->findUserById($oShop_Order->Siteuser);

		$aParams = [];
		$aParams['site'] = $this->_site;

		$aOrder = [];

		if ($customer) {
			$aOrder['customer']['externalId'] = $oShop_Order->Siteuser->id;
		} else {
			$aCustomer = $this->createCustomer($oShop_Order->Siteuser);
			if (isset($aCustomer['id'])) {
				$aOrder['customer']['externalId'] = $oShop_Order->Siteuser->id;
			}
		}

		$aOrder['customer']['type'] = 'customer';
		$aOrder['customer']['site'] = $this->_site;
		$aJSON['contragent']['contragentType'] = 'individual';

		$aOrder['number'] = $aOrder['externalId'] = $oShop_Order->invoice
			? $oShop_Order->invoice
			: $oShop_Order->id;
		// //$aOrder['order']['orderMethod'] = 'riche-website';
		$aOrder['createdAt'] = $oShop_Order->datetime;
		// $aOrder['order']['contragent']['contragentType'] = 'individual';

		// $aOrder['order']['firstName'] = $oShop_Order->name;
		// $aOrder['order']['lastName'] = $oShop_Order->surname;
		// $aOrder['order']['phone'] = $this->validPhone($oShop_Order->phone);
		// $aOrder['order']['email'] = $oShop_Order->email;

		$aOrder['firstName'] = $oShop_Order->name;
		$aOrder['lastName'] = $oShop_Order->surname;
		$aOrder['phone'] = $this->validPhone($oShop_Order->phone);
		$aOrder['email'] = $oShop_Order->email;

		$aOrder['orderMethod'] = 'app-riche-skin'; // # Источник заказа

		$shopObserverHmp = new Shop_Observer_Hmp();
		// посчитанные суммы
		$aItemsPre = $shopObserverHmp->Shop_Order__Print($oShop_Order);

		// 0 — Товар
		// 1 — Доставка
		// 2 — Пополнение лицевого счета
		// 3 — Скидка от суммы заказа
		// 4 — Скидка по дисконтной карте
		// 5 — Списание бонусов
		// 6 — Частичная оплата с лицевого счета

		$aItems = [];
		$delivery = $discount = $amount = 0;
		foreach ($aItemsPre as $item) {
			// товары
			if ($item['type'] == 0 && $item['price'] >= 0 && $item['quantity'] > 0) {
				$amount += floatval($item['price']) * floatval($item['quantity']);
				$aItems[] = [
					'initialPrice' => floatval($item['price_before_sale']),
					'discountManualAmount' => floatval(
						$item['price_before_sale'] - $item['price']
					),
					'quantity' => floatval($item['quantity']),
					'vatRate' => 20,
					//'status' => 'prepay',
					'productName' => $item['name'],
					'offer' => [
						'externalId' => $item['shop_item_id'],
						'vatRate' => 20,
					],
				];
			}
			// доставка
			if ($item['type'] == 1 && $item['price'] >= 0) {
				$delivery += $item['price'];
			}
		}

		$aOrder['items'] = $aItems;
		$aOrder['summ'] = $amount;
		$aOrder['totalSumm'] = $amount + $delivery;
		$aOrder['status'] = 'prepay'; //В ожидании предоплаты

		$oShop_Country = $oShop_Order->Shop_Country;
		$aOrder['countryIso'] = $oShop_Country->alpha2;
		$aOrder['delivery']['cost'] = $delivery;

		// "address": {
		//         "index": "postcode",
		//         "country": "shop_country_id",
		//         "region": "shop_country_location_id",
		//         "city": "shop_country_location_city_id",
		//         "street": "address",
		//         "notes": "0",
		//         "building": "0",
		//         "flat": "0"
		//     },

		$aAddress = [];
		if ($oShop_Order->postcode != '') {
			$aAddress[] = $oShop_Order->postcode;
		}
		$aAddress[] = $oShop_Order->Shop_Country->name;
		$aAddress[] = $oShop_Order->Shop_Country_Location->name;
		$aAddress[] = $oShop_Order->Shop_Country_Location_City->name;
		if ($oShop_Order->address != '') {
			$aAddress[] = $oShop_Order->address;
		}

		//$aOrder['delivery']['address']['text'] = implode(', ', $aAddress);
		$aOrder['delivery']['address'] = [
			'index' => $oShop_Order->postcode,
			'countryIso' => $oShop_Country->alpha2,
			'region' => $oShop_Order->Shop_Country_Location->name,
			'city' => $oShop_Order->Shop_Country_Location_City->name,
			'street' => $oShop_Order->address,
		];

		$aOrder['delivery']['code'] = 'apiship';
		$aOrder['delivery']['integrationCode'] = 'apiship';

		$tariff_prop = 0;
		$pickuppoin_prop = 0;

		// pickuppointId
		$oProperty = Core_Entity::factory('Property', 26);
		$aPropertyValues = $oProperty->getValues($oShop_Order->id);
		if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
			$pickuppoin_prop = $aPropertyValues[0]->value;
		}

		// tariff
		$oProperty = Core_Entity::factory('Property', 27);
		$aPropertyValues = $oProperty->getValues($oShop_Order->id);
		if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
			$tariff_prop = $aPropertyValues[0]->value;
		}

		$aOrder['delivery']['data'] = [
			'locked' => true,
			'pickuppointAddress' => implode(', ', $aAddress),
			'tariff' => $tariff_prop,
			'pickuppointId' => $pickuppoin_prop,
		];

		//'customFields': { 'delivery_apiship_provider_key': "cdek", }
		$oProperty = Core_Entity::factory('Property', 25);
		$aPropertyValues = $oProperty->getValues($oShop_Order->id);
		if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
			$aOrder['customFields']['delivery_apiship_provider_key'] =
				$aPropertyValues[0]->value;
		}

		$aOrder['payments'][0]['type'] = 'cloudpayments';
		$aOrder['payments'][0]['status'] = 'invoice'; // invoice Выставлен счет

		//promocod
		if ($oShop_Order->coupon) {
			$aOrder['customFields']['promocod'] = $oShop_Order->coupon;
		}

		// ссылка на оплату
		$aOrder['customFields']['payment_link'] =
			$this->_siteUrl . '/checkout/' . $oShop_Order->guid;

		$aParams['order'] = json_encode($aOrder);
		//$aParams['order'] = $aOrder;

		//public function show()
		$url = '/orders/create';

		return $aParams;
		//print_r($aParams);
		//exit();

		$aAnswer = $this->setType('POST')->executeRequest($url, $aParams);

		// var_dump($aAnswer);
		// exit();
		if (isset($aAnswer['success'])) {
			return true;
		}
		return $aAnswer;
	}

	// OUT Оплата заказа (editPayment)
	// /orders/payments/{$id}/edit
	public function orderPaid($oShop_Order)
	{
		$cloudPayId = null;
		$aAnswer = $this->getOrder($oShop_Order);
		if (isset($aAnswer['success'])) {
			if (isset($aAnswer['order']['payments'])) {
				foreach ($aAnswer['order']['payments'] as $aPay) {
					if (isset($aPay['type']) && $aPay['type'] == 'cloudpayments') {
						//var_dump($aPay['id']);
						$cloudPayId = $aPay['id'];
					}
				}
			}
		}

		// var_dump($aAnswer);
		// var_dump($cloudPayId);
		// exit();

		//return $aAnswer;

		if ($cloudPayId) {
			// обновляем платёж
			$url = '/orders/payments/' . $cloudPayId . '/edit';
			$aParams = [];
			$aParams['site'] = $this->_site;

			$aPay = [
				'status' => 'paid',
				'paidAt' => $oShop_Order->payment_datetime,
				'comment' => $oShop_Order->system_information,
			];

			$aParams['payment'] = json_encode($aPay);

			$aAnswer = $this->setType('POST')->executeRequest($url, $aParams);

			//return $aAnswer;

			// записали оплату
			if (isset($aAnswer['success'])) {
				//меняем статус заказу
				$url = '/orders/' . $oShop_Order->invoice . '/edit';

				$aParams = [];
				$aParams['site'] = $this->_site;

				$aOrder = [];
				$aOrder['status'] = 'prepayed'; //Предоплата поступила
				$aParams['order'] = json_encode($aOrder);

				$aAnswer = $this->setType('POST')->executeRequest($url, $aParams);

				if (isset($aAnswer['success'])) {
					return true;
				}
			}

			return $aAnswer;
		}
	}

	// IN Трек номер + смена статуса на Доставляется + письмо покупателю
	// /api/v5/orders/{externalId}/edit
	public function orderDelivery($oShop_Order, $aRequest = null)
	{
		//ТрекНомер	track_number
		$aReturn = false;
		if ($oShop_Order && $aRequest && isset($aRequest['track_number'])) {
			$oShop_Payment_System_Handler = Shop_Payment_System_Handler::factory(
				Core_Entity::factory(
					'Shop_Payment_System',
					$oShop_Order->shop_payment_system_id
				)
			);

			$oShop_Order->delivery_information = trim(
				strval($aRequest['track_number'])
			);
			$oShop_Order->shop_order_status_id = 3; //  Доставляется
			$oShop_Order->posted = 1; // Отправлен
			$oShop_Order->save();
			$oShop_Order->historyPushPosted();

			$oShop_Payment_System_Handler
				->shopOrder($oShop_Order)
				//->setMailSubjects()
				->setXSLs()
				->send();
		}

		return $aReturn;
	}

	// IN Смена статуса на Выполнен + письмо покупателю
	// /api/v5/orders/{externalId}/edit
	public function orderCompleted($oShop_Order, $aRequest = null)
	{
		// complete
		$aReturn = false;
		if ($oShop_Order && $aRequest && isset($aRequest['status'])) {
			$oShop_Payment_System_Handler = Shop_Payment_System_Handler::factory(
				Core_Entity::factory(
					'Shop_Payment_System',
					$oShop_Order->shop_payment_system_id
				)
			);

			$oShop_Order->shop_order_status_id = 5; //  Выполнен
			$oShop_Order->save();
			$oShop_Order->historyPushChangeStatus();

			$oShop_Payment_System_Handler
				->shopOrder($oShop_Order)
				//->setMailSubjects()
				->setXSLs()
				->send();
		}

		return $aReturn;
	}

	// IN Смена статуса на отменён
	// /api/v5/orders/{externalId}/edit
	public function orderCanceled($oShop_Order, $aRequest = null)
	{
		// canceled
		$aReturn = false;
		if ($oShop_Order && $aRequest && isset($aRequest['status'])) {
			$oShop_Order->changeStatusCanceled();

			$oShop_Payment_System_Handler = Shop_Payment_System_Handler::factory(
				Core_Entity::factory(
					'Shop_Payment_System',
					$oShop_Order->shop_payment_system_id
				)
			);

			// $oShop_Order->shop_order_status_id = 5; //  Выполнен
			// $oShop_Order->save();
			// $oShop_Order->historyPushChangeStatus();

			$oShop_Payment_System_Handler
				->shopOrder($oShop_Order)
				->setMailSubjects()
				->setXSLs()
				->send();
		}

		return $aReturn;
	}

	// IN Изменение заказа в HostCMS
	// order.orderMethod.code == "app-riche-skin" and (changeSet.hasChangedField("order_product") or changeSet.hasChangedField("delivery_cost") or changeSet | contains (product => product.fieldName == 'order_product.quantity' or product.fieldName == 'order_product.price' or product.fieldName == 'order_product.discount' or product.fieldName == 'order_product.discount_manual_amount'))
	public function orderChanged($shopOrder, $aRequest = null)
	{
		$aReturn = false;
		if ($shopOrder && $aRequest) {
			$orderProductsFromRequest = Core_Array::get(
				$aRequest,
				'orderProducts',
				[]
			);
			/*
                            $appCommandController = new App_Command_Controller();

                            $requestOrderSummary = 0;
                            foreach ($orderProductsFromRequest as $orderProduct) {
                                $requestOrderSummary += $orderProduct['price'];
                            }

                            $propertyDeliveryProvider = Core_Entity::factory('Property', 25);
                            $propertyDeliveryProviderValues = $propertyDeliveryProvider->getValues($shopOrder->id);

                            if ($propertyDeliveryProviderValues) {
                                $delivery = [
                                    'delivery_type' => $propertyDeliveryProviderValues[0]->value == 'courier' ? 'door' : 'point',
                                    'delivery_provider' => $propertyDeliveryProviderValues[0]->value
                                ];
                            } else {
                                $delivery = [
                                    'delivery_type' => null,
                                    'delivery_provider' => null
                                ];
                            }

                            $deliveryPrice = $appCommandController->_getDeliveryPrice(
                                intval($shopOrder->shop_country_location_city_id),
                                $delivery,
                                $requestOrderSummary
                            );*/

			$currentOrderProducts = $shopOrder->Shop_Order_Items->findAll();

			/*                $shopOrder->name = $aRequest['firstName'];
                            $shopOrder->surname = $aRequest['lastName'];
                            $shopOrder->phone = $this->validPhone($aRequest['phone']);
                            $shopOrder->email = $aRequest['email'];*/

			$newDelivery = null;
			$shopOrderHistoryText = '';

			foreach ($currentOrderProducts as $orderProduct) {
				if ($orderProduct->type == 0) {
					$orderProduct->markDeleted();
				} else {
					$newDelivery = clone $orderProduct;
					$orderProduct->markDeleted();
				}
			}

			foreach ($orderProductsFromRequest as $orderProduct) {
				$shopOrderItem = Core_Entity::factory('Shop_Order_Item');
				$shopOrderItem->name = $orderProduct['name'];
				$shopOrderItem->quantity = $orderProduct['quantity'];
				$shopOrderItem->price =
					$orderProduct['price'] + $orderProduct['discount'];
				$shopOrderItem->marking = $orderProduct['article'];
				$shopOrderItem->shop_item_id = $orderProduct['externalId'];
				$shopOrderItem->type = 0;
				$shopOrder->add($shopOrderItem);

				if ($orderProduct['discount'] > 0) {
					$shopOrderItemDiscount = Core_Entity::factory('Shop_Order_Item');
					$shopOrderItemDiscount->name =
						'Скидка на товар ' . $orderProduct['name'];
					$shopOrderItemDiscount->quantity = 1;
					$shopOrderItemDiscount->price = -1 * $orderProduct['discount'];
					$shopOrderItemDiscount->type = 3;
					$shopOrder->add($shopOrderItemDiscount);
				}
			}

			if ($newDelivery) {
				$newDelivery->price = $aRequest['deliveryCost'];
				$shopOrder->add($newDelivery);
			}

			$oShop_Payment_System_Handler = Shop_Payment_System_Handler::factory(
				Core_Entity::factory(
					'Shop_Payment_System',
					$shopOrder->shop_payment_system_id
				)
			);

			$updatedCurrentOrderProducts = $shopOrder->Shop_Order_Items->findAll();
			foreach ($updatedCurrentOrderProducts as $orderProduct) {
				$amountColumn =
					$orderProduct->price .
					' x ' .
					$orderProduct->quantity .
					' = ' .
					$orderProduct->price * $orderProduct->quantity;
				$shopOrderHistoryText .=
					$orderProduct->name . ' — ' . $amountColumn . PHP_EOL;
			}

			$shopOrder->shop_order_status_id = 6; // Изменён
			$shopOrder->save();

			$oShop_Order_History = Core_Entity::factory('Shop_Order_History');
			$oShop_Order_History->shop_order_id = $shopOrder->id;
			$oShop_Order_History->shop_order_status_id =
				$shopOrder->shop_order_status_id;
			$oShop_Order_History->text = $shopOrderHistoryText;
			$oShop_Order_History->color = $shopOrder->Shop_Order_Status->color;
			$oShop_Order_History->save();

			//$shopOrder->historyPushChangeStatus();

			$oShop_Payment_System_Handler
				->shopOrder($shopOrder)
				//->setMailSubjects()
				->setXSLs()
				->send();
		}

		return $aReturn;
	}
}
