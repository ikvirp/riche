<?php

defined('HOSTCMS') || exit('HostCMS: access denied.');

class App_Controller_ICML extends Core_Controller
{
  // protected $_prefix = 'riche-skin-vercel';
  // protected $_key = 'tmOoiCrgWos6dH7PuqjIdjz3jAl6qUJS';

  protected $_price_coefficient = 1;

  private $_default_coefficient = 1; // 0.001 граммы, 1 - кг в магазине

  private $_coefficient = [
    0 => 1, // по умолчанию в килограмм
    2 => 1, // ID 2 килограмм
    29 => 0.001, // ID 29 грамм
  ];

  protected $_aTypes = [
    0 => 'Товар',
    1 => 'Делимый товар',
    2 => 'Электронный товар',
    3 => 'Комплект',
    4 => 'Сертификат',
  ];

  protected $_allowedProperties = [
    'itemsProperties',
    'itemsForbiddenProperties',
    'modifications',
    'groupModifications',
    'checkRest',
    'onStep',
    'protocol',
    'stdOut',
    'delay',
    'mode',
    '_price_coefficient',
  ];

  protected $_Shop_Items = null;

  protected $_Shop_Groups = null;

  protected $_Shop_Order = null;

  protected $_aSiteuserGroups = [];

  protected $_Shop_Item_Controller = null;

  protected $_currentModificationGroupId = null;

  //protected $_oRetailCRM = NULL;

  public function setCoefPrice($coef)
  {
    $this->_price_coefficient(floatval($coef));
  }

  public function __construct(Shop_Model $oShop)
  {
    parent::__construct($oShop->clearEntities());

    $this->protocol = Core::httpsUses() ? 'https' : 'http';

    $siteuser_id = 0;

    $this->_aSiteuserGroups = [0, -1];
    if (Core::moduleIsActive('siteuser')) {
      $oSiteuser = Core_Entity::factory('Siteuser')->getCurrent();

      if ($oSiteuser) {
        $siteuser_id = $oSiteuser->id;

        $aSiteuser_Groups = $oSiteuser->Siteuser_Groups->findAll(false);
        foreach ($aSiteuser_Groups as $oSiteuser_Group) {
          $this->_aSiteuserGroups[] = $oSiteuser_Group->id;
        }
      }
    }

    $this->_setShopItems();

    $this->_setShopGroups();

    $this->itemsProperties = $this->modifications = $this->checkRest = $this->groupModifications = false;

    $this->itemsForbiddenProperties = [];

    $this->onStep = 500;

    $this->stdOut = new Core_Out_Std();

    $this->_Shop_Item_Controller = new Shop_Item_Controller();
    //$this->_oRetailCRM = Core_Entity::factory('retailCRM')->getByShopId($oShop->id);

    $this->delay = 0;
    $this->mode = 'between';

    Core_Session::close();
  }

  public function setDefaultCoefficient($value = 1)
  {
    return $this->_default_coefficient = $value;
  }

  protected function _setShopGroups()
  {
    $oShop = $this->getEntity();

    $this->_Shop_Groups = $oShop->Shop_Groups;
    $this->_Shop_Groups
      ->queryBuilder()
      //->where('shop_groups.siteuser_group_id', 'IN', $this->_aSiteuserGroups)
      //->where('shop_groups.active', '=', 1)
      ->clearOrderBy()
      ->orderBy('shop_groups.parent_id', 'ASC');

    // 6.9.0
    if (HOSTCMS_UPDATE_NUMBER >= 180) {
      $this->_Shop_Groups
        ->queryBuilder()
        ->where('shop_groups.shortcut_id', '=', 0);
    }

    return $this;
  }

  protected function _addShopItemConditions($oShop_Item)
  {
    $dateTime = Core_Date::timestamp2sql(time());

    $oShop_Item
      ->queryBuilder()
      ->select('shop_items.*')
      ->leftJoin(
        'shop_groups',
        'shop_groups.id',
        '=',
        'shop_items.shop_group_id' /*,
				array(
						array('AND' => array('shop_groups.active', '=', 1)),
						array('OR' => array('shop_items.shop_group_id', '=', 0))
					)*/
      )
      // Активность группы или группа корневая
      ->open()
      ->where('shop_groups.active', '=', 1)
      ->setOr()
      ->where('shop_groups.id', 'IS', null)
      ->close()
      ->where('shop_items.shortcut_id', '=', 0)
      //->where('shop_items.active', '=', 1)
      //->where('shop_items.siteuser_id', 'IN', $this->_aSiteuserGroups)
      ->open()
      ->where('shop_items.start_datetime', '<', $dateTime)
      ->setOr()
      ->where('shop_items.start_datetime', '=', '0000-00-00 00:00:00')
      ->close()
      ->setAnd()
      ->open()
      ->where('shop_items.end_datetime', '>', $dateTime)
      ->setOr()
      ->where('shop_items.end_datetime', '=', '0000-00-00 00:00:00')
      ->close()
      //->where('shop_items.yandex_market', '=', 1)
      //->where('shop_items.price', '>', 0)
      ->where('shop_items.modification_id', '=', 0);

    if ($this->checkRest) {
      $oShop_Item
        ->queryBuilder()
        ->join(
          'shop_warehouse_items',
          'shop_warehouse_items.shop_item_id',
          '=',
          'shop_items.id'
        )
        ->groupBy('shop_items.id')
        ->having(
          Core_QueryBuilder::expression('SUM(shop_warehouse_items.count)'),
          '>',
          0
        );
    }

    return $this;
  }

  protected function _setShopItems()
  {
    $oShop = $this->getEntity();

    $this->_Shop_Items = $oShop->Shop_Items;
    $this->_Shop_Items
      ->queryBuilder()
      ->clearOrderBy()
      ->orderBy('shop_items.id', 'ASC');

    $this->_addShopItemConditions($this->_Shop_Items);

    return $this;
  }

  public function shopItems()
  {
    return $this->_Shop_Items;
  }

  public function shopGroups()
  {
    return $this->_Shop_Groups;
  }

  protected $_aCategoriesId = [];

  protected function _getMaxGroupId()
  {
    $oShop = $this->getEntity();

    $oCore_QueryBuilder_Select = Core_QueryBuilder::select([
      'MAX(id)',
      'max_id',
    ]);
    $oCore_QueryBuilder_Select
      ->from('shop_groups')
      ->where('shop_groups.shop_id', '=', $oShop->id)
      ->where('shop_groups.deleted', '=', 0);

    $aRow = $oCore_QueryBuilder_Select
      ->execute()
      ->asAssoc()
      ->current();

    return $aRow['max_id'];
  }

  protected function _categories()
  {
    $this->stdOut->write("<categories>\n");

    // Название магазина
    $oShop = $this->getEntity();

    // Массив активных ID групп
    $this->_aCategoriesId = [0 => 0];

    // Массив отключенных ID групп
    $aDisabledCategoriesId = [];

    $maxId = $this->mode == 'between' ? $this->_getMaxGroupId() : 0;

    $iFrom = 0;

    do {
      $this->_setShopGroups();

      $this->mode == 'between'
        ? $this->_Shop_Groups
          ->queryBuilder()
          ->where('shop_groups.id', 'BETWEEN', [
            $iFrom + 1,
            $iFrom + $this->onStep,
          ])
        : $this->_Shop_Groups
          ->queryBuilder()
          ->offset($iFrom)
          ->limit($this->onStep);

      $aShop_Groups = $this->_Shop_Groups->findAll(false);
      foreach ($aShop_Groups as $oShop_Group) {
        if (
          $oShop_Group->active &&
          // Группа в корневой или в списке отключенных нет ее родителя
          ($oShop_Group->parent_id == 0 ||
            !isset($aDisabledCategoriesId[$oShop_Group->parent_id]))
        ) {
          $this->_aCategoriesId[$oShop_Group->id] = $oShop_Group->id;

          $group_parent_id =
            $oShop_Group->parent_id == '' || $oShop_Group->parent_id == 0
              ? ''
              : ' parentId="' . $oShop_Group->parent_id . '"';

          $this->stdOut->write(
            '<category id="' .
              $oShop_Group->id .
              '"' .
              $group_parent_id .
              '>' .
              Core_Str::xml($oShop_Group->name) .
              "</category>\n"
          );
        } else {
          // Группа в отключенные если она сама отключена или родитель отключен
          $aDisabledCategoriesId[$oShop_Group->id] = $oShop_Group->id;
        }
      }

      $iFrom += $this->onStep;

      $iCount = count($aShop_Groups);

      // Delay execution
      $this->delay && $iCount && usleep($this->delay);
    } while ($this->mode == 'between' ? $iFrom < $maxId : $iCount);

    $this->stdOut->write("</categories>\n");

    unset($aShop_Groups);

    return $this;
  }

  protected function _getMaxId()
  {
    $oShop = $this->getEntity();

    $oCore_QueryBuilder_Select = Core_QueryBuilder::select([
      'MAX(id)',
      'max_id',
    ]);
    $oCore_QueryBuilder_Select
      ->from('shop_items')
      ->where('shop_items.shop_id', '=', $oShop->id)
      ->where('shop_items.deleted', '=', 0);

    $aRow = $oCore_QueryBuilder_Select
      ->execute()
      ->asAssoc()
      ->current();

    return $aRow['max_id'];
  }

  protected function _offers()
  {
    $this->stdOut->write("<offers>\n");

    //$offset = 0;

    $oShop = $this->getEntity();

    $maxId = $this->mode == 'between' ? $this->_getMaxId() : 0;

    $iFrom = 0;

    do {
      $this->_setShopItems();

      $this->mode == 'between'
        ? $this->_Shop_Items
          ->queryBuilder()
          ->where('shop_items.id', 'BETWEEN', [
            $iFrom + 1,
            $iFrom + $this->onStep,
          ])
        : $this->_Shop_Items
          ->queryBuilder()
          ->offset($iFrom)
          ->limit($this->onStep);

      $aShop_Items = $this->_Shop_Items->findAll(false);

      foreach ($aShop_Items as $oShop_Item) {
        if (isset($this->_aCategoriesId[$oShop_Item->shop_group_id])) {
          if ($this->modifications && $this->groupModifications) {
            $this->_currentModificationGroupId = $oShop_Item->id;
          }

          // Если отключена группировка groupModifications или нет модификаций, то основной товар показывается
          if (
            !$this->groupModifications ||
            $oShop_Item->Modifications->getCount(false) == 0
          ) {
            $this->_showOffer($oShop_Item);
          }

          if ($this->modifications) {
            $iModificationOffset = 0;

            do {
              $oModifications = $oShop_Item->Modifications;
              $oModifications
                ->queryBuilder()
                ->where('shop_items.active', '=', 1)
                //->where('shop_items.yandex_market', '=', 1)
                //->where('shop_items.siteuser_id', 'IN', $this->_aSiteuserGroups)
                ->clearOrderBy()
                ->orderBy('shop_items.id', 'ASC')
                ->offset($iModificationOffset)
                ->limit($this->onStep);

              if ($this->checkRest) {
                $oModifications
                  ->queryBuilder()
                  ->select('shop_items.*')
                  ->join(
                    'shop_warehouse_items',
                    'shop_warehouse_items.shop_item_id',
                    '=',
                    'shop_items.id'
                  )
                  ->groupBy('shop_items.id')
                  ->having(
                    Core_QueryBuilder::expression(
                      'SUM(shop_warehouse_items.count)'
                    ),
                    '>',
                    0
                  );
              }

              $aModifications = $oModifications->findAll(false);

              foreach ($aModifications as $oModification) {
                $this->_showOffer($oModification);
              }

              $iModificationOffset += $this->onStep;
            } while (count($aModifications) == $this->onStep);
          }
        }
      }

      //Core_File::flush();
      $iFrom += $this->onStep;

      $iCount = count($aShop_Items);

      // Delay execution
      $this->delay && $iCount && usleep($this->delay);
    } while ($this->mode == 'between' ? $iFrom < $maxId : $iCount);

    $this->stdOut->write('</offers>' . "\n");

    return $this;
  }

  protected function _showOffer($oShop_Item)
  {
    $oShop = $this->getEntity();

    $quantity = (int) $oShop_Item->getRest();

    $this->stdOut->write(
      '<offer id="' .
        $oShop_Item->id .
        '" productId="' .
        (!is_null($this->_currentModificationGroupId)
          ? $this->_currentModificationGroupId
          : $oShop_Item->id) .
        '"' .
        " quantity=\"{$quantity}\">\n"
    );

    $this->stdOut->write('<xmlId>' . $oShop_Item->guid . '</xmlId>' . "\n");

    /* URL */
    // $this->stdOut->write(
    //   '<url>' .
    //     Core_Str::xml(
    //       $this->groupModifications && $oShop_Item->modification_id
    //         ? $this->_shopPath . $oShop_Item->Modification->getPath()
    //         : $this->_shopPath . $oShop_Item->getPath()
    //     ) .
    //     '</url>' .
    //     "\n"
    // );

    $domain = 'https://riche.skin';
    $this->stdOut->write(
      '<url>' .
        Core_Str::xml(
          $this->groupModifications && $oShop_Item->modification_id
            ? $domain .
              '/product/' .
              $oShop_Item->Modification->path .
              '-' .
              $oShop_Item->Modification->id
            : $domain . '/product/' . $oShop_Item->path . '-' . $oShop_Item->id
        ) .
        '</url>' .
        "\n"
    );

    /* Определяем цену со скидкой */
    $aPrices = $this->_Shop_Item_Controller->calculatePriceInItemCurrency(
      $oShop_Item->price,
      $oShop_Item
    );

    /* Цена */

    $realPrice = floatval(
      $this->_price_coefficient * $aPrices['price_discount']
    );
    $this->stdOut->write('<price>' . $realPrice . '</price>' . "\n");

    $purchasePrice = $realPrice;

    // if(!is_null($this->_oRetailCRM) && $this->_oRetailCRM->shop_price_id)
    // {
    // 	$oShop_Item_Price = $oShop_Item->Shop_Item_Prices->getByPriceId($this->_oRetailCRM->shop_price_id);

    // 	!is_null($oShop_Item_Price) && $purchasePrice = $oShop_Item_Price->value;
    // }

    $this->stdOut->write(
      '<purchasePrice>' . $purchasePrice . '</purchasePrice>' . "\n"
    );

    $vatRate = $aPrices['rate'] ? $aPrices['rate'] : 'none';
    $this->stdOut->write('<vatRate>' . $vatRate . '</vatRate>' . "\n");

    /* Идентификатор категории */
    // Основной товар
    if ($oShop_Item->modification_id == 0) {
      $categoryId = $oShop_Item->shop_group_id;
    }
    // Модификация, берем ID родительской группы
    else {
      $categoryId = $oShop_Item->Modification->Shop_Group->id
        ? $oShop_Item->Modification->Shop_Group->id
        : 0;
    }
    $this->stdOut->write('<categoryId>' . $categoryId . '</categoryId>' . "\n");

    /* PICTURE */
    if ($oShop_Item->image_large != '') {
      $this->stdOut->write(
        '<picture>' .
          $this->protocol .
          '://' .
          Core_Str::xml(
            $this->_siteAlias->name . $oShop_Item->getLargeFileHref()
          ) .
          '</picture>' .
          "\n"
      );
    } elseif (
      $oShop_Item->modification_id &&
      $oShop_Item->Modification->image_large != ''
    ) {
      $this->stdOut->write(
        '<picture>' .
          $this->protocol .
          '://' .
          Core_Str::xml(
            $this->_siteAlias->name .
              $oShop_Item->Modification->getLargeFileHref()
          ) .
          '</picture>' .
          "\n"
      );
    }

    $this->stdOut->write(
      '<name>' . Core_Str::xml($oShop_Item->name) . '</name>' . "\n"
    );
    $this->stdOut->write(
      '<productName>' .
        Core_Str::xml(
          $this->groupModifications && $oShop_Item->modification_id
            ? $oShop_Item->Modification->name
            : $oShop_Item->name
        ) .
        '</productName>' .
        "\n"
    );

    if ($oShop_Item->shop_producer_id) {
      $this->stdOut->write(
        '<vendor>' .
          Core_Str::xml($oShop_Item->Shop_Producer->name) .
          '</vendor>' .
          "\n"
      );
    }

    /* DESCRIPTION */
    $description = !empty($oShop_Item->description)
      ? $oShop_Item->description
      : $oShop_Item->text;

    if (strlen($description)) {
      $description = Core_Str::cutSentences(
        html_entity_decode(strip_tags($description), ENT_COMPAT, 'UTF-8'),
        3000
      );

      $this->stdOut->write(
        '<description>' . Core_Str::xml($description) . '</description>' . "\n"
      );
    }

    /* weight передавать в килограммах*/
    if ($oShop_Item->weight > 0) {
      $coefficient = isset($this->_coefficient[$oShop->shop_measure_id])
        ? $this->_coefficient[$oShop->shop_measure_id]
        : $this->_default_coefficient;

      $this->stdOut->write(
        '<weight>' .
          number_format($oShop_Item->weight * $coefficient, 3, '.', '') .
          '</weight>' .
          "\n"
      );
    }

    if (!empty($oShop_Item->marking)) {
      $this->stdOut->write(
        '<param name="Артикул" code="article">' .
          Core_Str::xml($oShop_Item->marking) .
          '</param>' .
          "\n"
      );
    }

    // тип продукта _aTypes
    $this->stdOut->write(
      '<param name="Тип продукта" code="type">' .
        Core_Str::xml($this->_aTypes[$oShop_Item->type]) .
        '</param>' .
        "\n"
    );
    // Комплект
    if ($oShop_Item->type == 3) {
      $aShop_Item_Sets = $oShop_Item->Shop_Item_Sets->findAll(false);
      foreach ($aShop_Item_Sets as $oItemSet) {
        $oTmp_Shop_Item = Core_Entity::factory(
          'Shop_Item',
          $oItemSet->shop_item_set_id
        );

        $this->stdOut->write(
          '<param name="Состав комплекта" code="set_content">' .
            Core_Str::xml($oTmp_Shop_Item->guid) .
            '</param>' .
            "\n"
        );
      }
    }

    // barcode
    $this->_addBarcodes($oShop_Item);

    /**
     * маркировка
     * https://help.retailcrm.ru/Users/MarkingOfGoods
     */

    //$this->stdOut->write('<markable>Y</markable>' . "\n");

    $this->itemsProperties && $this->_addPropertyValues($oShop_Item);

    $this->stdOut->write('</offer>' . "\n");
  }

  protected function _addBarcodes(Shop_Item_Model $oShop_Item)
  {
    $aShop_Item_Barcodes = $oShop_Item->Shop_Item_Barcodes->findAll(false);
    foreach ($aShop_Item_Barcodes as $oShop_Item_Barcode) {
      // EAN-8 and EAN-13 only
      if ($oShop_Item_Barcode->type == 1 || $oShop_Item_Barcode->type == 2) {
        $this->stdOut->write(
          '<barcode>' .
            Core_Str::xml($oShop_Item_Barcode->value) .
            '</barcode>' .
            "\n"
        );
      }
    }

    return $this;
  }

  protected $_cacheProperties = [];

  protected function _getProperty($property_id)
  {
    if (!isset($this->_cacheProperties[$property_id])) {
      $this->_cacheProperties[$property_id] = Core_Entity::factory(
        'Property',
        $property_id
      );
    }

    return $this->_cacheProperties[$property_id];
  }

  protected $_cacheListItems = [];

  protected function _getCacheListItem($oProperty, $listItemId)
  {
    if (!isset($this->_cacheListItems[$listItemId])) {
      $this->_cacheListItems[$listItemId] = null;

      if ($listItemId) {
        $oList_Item = $oProperty->List->List_Items->getById(
          $listItemId /*, FALSE*/
        );

        !is_null($oList_Item) &&
          ($this->_cacheListItems[$listItemId] = $oList_Item->value);
      }
    }

    return $this->_cacheListItems[$listItemId];
  }

  protected function _addPropertyValues(Shop_Item_Model $oShop_Item)
  {
    // Доп. св-ва выводятся в <param>
    // <param name="Максимальный формат">А4</param>
    //$aProperty_Values = $oShop_Item->getPropertyValues(FALSE);

    $aProperty_Values =
      is_array($this->itemsProperties) &&
      !count($this->itemsForbiddenProperties)
        ? Property_Controller_Value::getPropertiesValues(
          $this->itemsProperties,
          $oShop_Item->id,
          false
        )
        : $oShop_Item->getPropertyValues(false);

    $aAlreadyExistProperties = [];

    foreach ($aProperty_Values as $oProperty_Value) {
      // Исключаем запрещенные
      if (
        !in_array(
          $oProperty_Value->property_id,
          $this->itemsForbiddenProperties
        )
      ) {
        $oProperty = $this->_getProperty($oProperty_Value->property_id);

        if (
          !in_array($oProperty->type, [2, 5, 12, 13, 10, 14]) &&
          $oProperty_Value->value !== ''
        ) {
          $aAlreadyExistProperties[] = $oProperty->id;
        }

        $this->_addPropertyValue($oProperty_Value);
      }
    }

    return $this;
  }

  protected $_aForbid = ['markable'];

  protected function _addPropertyValue($oProperty_Value)
  {
    $oProperty = $this->_getProperty($oProperty_Value->property_id);

    switch ($oProperty->type) {
      case 0: // Int
      case 1: // String
      case 4: // Textarea
      case 6: // Wysiwyg
        $value = $oProperty_Value->value;
        break;

      case 8: // Date
        $value = Core_Date::sql2date($oProperty_Value->value);
        break;

      case 9: // Datetime
        $value = Core_Date::sql2datetime($oProperty_Value->value);
        break;

      case 3: // List
        //$oList_Item = $oProperty->List->List_Items->getById(
        //	$oProperty_Value->value/*, FALSE*/
        //);

        //$value = !is_null($oList_Item)
        //	? $oList_Item->value
        //	: NULL;
        $value = Core::moduleIsActive('list')
          ? $this->_getCacheListItem($oProperty, $oProperty_Value->value)
          : null;
        break;

      case 7: // Checkbox
        $value = $oProperty_Value->value == 1 ? 'есть' : null;
        break;

      case 2: // File
      case 5: // Элемент информационной системы
      case 13: // Группа информационной системы
      case 12: // Товар интернет-магазина
      case 14: // Группа интернет-магазина
      case 10: // Hidden field
      default:
        $value = null;
        break;
    }

    if (!is_null($value)) {
      $sTagName = 'param';

      $unit =
        $oProperty->type == 0 && $oProperty->Shop_Item_Property->shop_measure_id
          ? ' unit="' .
            Core_Str::xml($oProperty->Shop_Item_Property->Shop_Measure->name) .
            '"'
          : '';

      $sAttr =
        ' name="' .
        Core_Str::xml(Core_Str::cut($oProperty->name, 100)) .
        '"' .
        $unit;
      $sAttr .= ' code="' . Core_Str::xml($oProperty->tag_name) . '"';

      if ($value !== '') {
        if (!in_array($oProperty->tag_name, $this->_aForbid)) {
          $this->stdOut->write(
            '<' .
              $sTagName .
              $sAttr .
              '>' .
              Core_Str::xml(
                Core_Str::cut(
                  html_entity_decode(strip_tags($value), ENT_COMPAT, 'UTF-8'),
                  250
                )
              ) .
              '</' .
              $sTagName .
              '>' .
              "\n"
          );
        } elseif ($oProperty->tag_name == 'markable' && $value !== '') {
          $this->stdOut->write('<markable>Y</markable>' . "\n");
        }
      }
    }

    return $this;
  }

  protected $_siteAlias = null;

  protected $_shopPath = null;

  protected $_headersSent = false;

  public function sendHeaders()
  {
    if (!$this->_headersSent && !headers_sent()) {
      // Stop buffering
      ob_get_clean();

      header('Content-Type: raw/data');
      header('Cache-Control: no-cache, must-revalidate');
      header('X-Accel-Buffering: no');

      $this->_headersSent = true;
    }

    return $this;
  }

  public function show()
  {
    $this->sendHeaders();

    $this->stdOut->open();

    $oShop = $this->getEntity();
    $oSite = $oShop->Site;

    !is_null(Core_Page::instance()->response) &&
      Core_Page::instance()
        ->response->header('Content-Type', "text/xml; charset={$oSite->coding}")
        ->sendHeaders();

    $this->stdOut->write(
      '<?xml version="1.0" encoding="' . $oSite->coding . '"?>' . "\n"
    );
    $this->stdOut->write('<!DOCTYPE yml_catalog SYSTEM "shops.dtd">' . "\n");
    $this->stdOut->write(
      '<yml_catalog date="' . date('Y-m-d H:i') . '">' . "\n"
    );
    $this->stdOut->write("<shop>\n");

    // Название магазина
    $shop_name = trim(
      !empty($oShop->yandex_market_name)
        ? $oShop->yandex_market_name
        : $oSite->name
    );

    $this->stdOut->write(
      '<name>' . Core_Str::xml(mb_substr($shop_name, 0, 20)) . "</name>\n"
    );

    // Название компании.
    $this->stdOut->write(
      '<company>' . Core_Str::xml($oShop->Shop_Company->name) . "</company>\n"
    );

    $this->_siteAlias = $oSite->getCurrentAlias();
    $this->_shopPath =
      $this->protocol .
      '://' .
      $this->_siteAlias->name .
      $oShop->Structure->getPath();

    /* Категории */
    $this->_categories();

    //Core_File::flush();

    /* Товары */
    $this->_offers();

    $this->stdOut->write("</shop>\n");
    $this->stdOut->write('</yml_catalog>');

    $this->stdOut->close();

    //Core_File::flush();
  }
}
