<?php

defined('HOSTCMS') || exit('HostCMS: access denied.');

/**
 * APP API
 *
 * @package HostCMS 6
 * @subpackage App
 * @version 1.x
 * @author onbd.ru
 */
class App_Module extends Core_Module
{
  /**
   * Module version
   * @var string
   */
  public $version = '1.0';

  /**
   * Module date
   * @var date
   */
  public $date = '2022-06-01';

  /**
   * Module name
   * @var string
   */
  protected $_moduleName = 'app';

  /**
   * Constructor.
   */
  public function __construct()
  {
    parent::__construct();

    $aConfig = Core_Config::instance()->get('app_config', []) + [
      'url' => '/app',
    ];

    Core_Router::add(
      'app',
      rtrim($aConfig['url'], '/') . '/(v{version}/)({path}/)'
    )->controller('App_Command_Controller');
  }

  // /**
  //  * Get Module's Menu
  //  * @return array
  //  */
  // public function getMenu()
  // {
  //   $this->menu = [
  //     [
  //       'sorting' => 40,
  //       'block' => 0,
  //       'ico' => 'fa fa-share-alt',
  //       'name' => Core::_('App.menu'),
  //       'href' => '/admin/app/index.php',
  //       'onclick' =>
  //         "$.adminLoad({path: '/admin/app/index.php'}); return false",
  //     ],
  //   ];

  //   return parent::getMenu();
  // }
}
