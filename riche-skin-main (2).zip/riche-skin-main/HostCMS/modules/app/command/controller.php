<?php

class My_Siteuser_Controller_Restore_Password extends
	Siteuser_Controller_Restore_Password
{
	public function sendNewPassword()
	{
		$oSiteuser = $this->getEntity();

		$oSite = $oSiteuser->Site;

		// Create and save new password
		$new_password = Core_Password::get();
		$oSiteuser->password = Core_Hash::instance()->hash($new_password);
		$oSiteuser->save();

		$this->addEntity(
			Core::factory('Core_Xml_Entity')
				->name('new_password')
				->value($new_password)
		)->addEntity($oSite->clearEntities()->showXmlAlias());

		Core_Event::notify(get_class($this) . '.onBeforeSendNewPassword', $this, [
			$new_password,
		]);

		$sXml = $this->getXml();

		$content = Xsl_Processor::instance()
			->xml($sXml)
			->xsl($this->_xsl)
			->process();

		$this->clearEntities();

		$this->contentType = 'text/html';

		$oCore_Mail = Core_Mail::instance()
			->to($oSiteuser->email)
			->from($this->from)
			->subject($this->subject)
			->message(trim($content))
			->contentType($this->contentType)
			->header('X-HostCMS-Reason', 'User-Restore-Password')
			->header('Precedence', 'bulk')
			->messageId();

		$oSite->sender_name != '' && $oCore_Mail->senderName($oSite->sender_name);

		$oCore_Mail->send();

		// if (Core::moduleIsActive('siteuser') && $oSiteuser->id) {
		//   $oSiteuser_Email = Core_Entity::factory('Siteuser_Email');
		//   $oSiteuser_Email->siteuser_id = $oSiteuser->id;
		//   $oSiteuser_Email->subject = $this->subject;
		//   $oSiteuser_Email->email = $oSiteuser->email;
		//   $oSiteuser_Email->from = $this->from;
		//   $oSiteuser_Email->type = $this->contentType = 'text/html' ? 1 : 0;
		//   $oSiteuser_Email->text = trim($content);
		//   $oSiteuser_Email->save();
		// }

		return $this;
	}
}

defined('HOSTCMS') || exit('HostCMS: access denied.');

/**
 * APP API
 *
 * @package HostCMS 6
 * @subpackage App
 * @version 1.x
 * @author onbd.ru
 */
class App_Command_Controller extends Core_Command_Controller
{
	protected $_mail_from = 'noreply@richescrub.ru';

	// WAYS
	// -------------
	protected $_aGetWays = [
		'test',
		'doc',
		'info',
		'cert',
		'blog',
		'catalog',
		'city',
		'menu',
		'main',
		'pay',
		'marketredirects',
		//'marketredirectsdb',
		'export_shop',
		'product_comments',

		'qr',

		'retailcrm',
		'r46',
	];
	protected $_aPostWays = [
		'import_shop',
		'import_price',
		'signin',
		'signinphone',
		'signup',
		'restore',
		'cart',
		'view',
		'checkout',
		'makeorder',
		'me',
		'apiship',
		'pay',
		'rcrm',
		'comment_vote',
		'comment_add',
		'address_add',
		'codeauth',
		'codeauthinput',
	];

	protected $_aDeliveryTypes = [
		'point' => 1,
		'door' => 2,
	];
	protected $_aProviders = [
		'accordpost' => 'Accordpost',
		'axilog' => 'Axilog',
		'azexpress' => 'AZ.Express',
		'b2cpl' => 'B2Cpl',
		'boxberry' => 'Boxberry',
		'cdek' => 'СДЭК',
		'checkbox' => 'Checkbox',
		'cityex' => 'CityExpress',
		'courierist' => 'Курьерист',
		'cse' => 'CSE',
		'd-club' => 'Dostavka-Club',
		'dalli' => 'Dalli-Service',
		'dellin' => 'Деловые Линии',
		'dostavista' => 'Dostavista',
		'dpd' => 'DPD',
		'drhl' => 'DRH logistic',
		'e-kit' => 'Е-КИТ',
		'easyway' => 'ПЭК Easyway',
		'ebulky' => 'EASY BULKY',
		'ecomlog' => 'E-COMLOG',
		'exmail' => 'ExMail',
		'guru' => 'Dostavka.GURU',
		'integral' => 'Интеграл',
		'kazpost' => 'Почта Казахстана',
		'kgt' => 'КГТ',
		'logsis' => 'Logsis',
		'lpost' => 'Л-Пост',
		'marlinzet' => 'Marlinzet',
		'omnic' => 'Omnic',
		'pecom' => 'ПЭК',
		'pickpoint' => 'PickPoint',
		'podorojnik' => 'Подорожник',
		'pony' => 'PONY EXPRESS',
		'redexpress' => 'RedExpress',
		'rudostavka' => 'РУ-ДОСТАВКА',
		'runcrm' => 'runCRM',
		'rupost' => 'Почта России',
		'sberlog' => 'Сберлогистика',
		'smart' => 'SmartDostavka',
		'strizh' => 'СТРИЖ',
		'td' => 'TopDelivery',
		'vozovoz' => 'Возовоз',
		'x5' => '5Post',
		'yataxi' => 'Яндекс.Доставка',
	];
	// -------------

	// DEBUG
	// -------------
	protected $_request = null;
	protected $_path = null;
	protected $_debug = false;
	protected $_unescape = false;
	// -------------

	// SETUP
	// -------------
	public $site = null;
	public $version = null;
	public $path = null;
	protected $_mode = null; // JSON, XML
	// -------------

	// VARS
	// -------------
	protected $_error = null;
	protected $_statusCode = 200;
	protected $_answer = null;
	protected $_user = null;
	// -------------

	protected $_config = [];

	// DATA
	// -------------
	protected $_slug = '';
	protected $_subgroups = false;
	protected $_group = false;
	protected $_groupsMode = 'tree';
	protected $_limit = 10;
	protected $_page = 1;
	protected $_offset = 0;
	protected $_total = 0;
	protected $_oInformationsystem = null;
	protected $_oShop = null;
	protected $_oInfoDataAllowed = [];
	protected $_oSiteuser = null;
	protected $_useFiletime = false;

	//shop
	protected $applyDiscounts = true;
	protected $applyDiscountCards = true;
	protected $checkStock = true;
	protected $minRest = 5;

	// -------------

	protected $_allowedProperties = ['cache'];

	// CACHE
	// -------------
	protected $cache = true;
	protected $_cacheName = 'app_command';
	protected $_cacheKey = 'appcachekey';
	protected $_aChacheGetWays = [
		'test',
		'doc',
		'info',
		'cert',
		'blog',
		'catalog',
		'city',
		'menu',
		'main',
		//'pay',
		'marketredirects',
		//'marketredirectsdb',
		'product_comments',
		'qr',
		// 'export_shop',
		// 'retailcrm',
	];

	/**
	 * Core_Response
	 * @var Core_Response|NULL
	 */
	protected $_oCore_Response = null;

	/**
	 * Constructor.
	 */
	public function __construct()
	{
		$this->_config = Core_Config::instance()->get('app_config', []) + [
			'url' => '/app',
			'xmlRootNode' => 'request',
			'log' => true,
		];

		$oSite = Core_Entity::factory('Site', 1);
		//$oSite_Alias = $oSite->getCurrentAlias();

		$this->site = $oSite;
	}

	protected function _groupCondition($oEntityItems)
	{
		$table_col = $this->_oShop
			? 'shop_items.shop_group_id'
			: 'informationsystem_items.informationsystem_group_id';

		$this->applyFilterGroupCondition($oEntityItems->queryBuilder(), $table_col);

		return $oEntityItems;
	}

	protected function _itemsCondition($oEntityItems)
	{
		$table = $this->_oShop ? 'shop_items' : 'informationsystem_items';

		$oEntityItems->queryBuilder()->sqlCalcFoundRows();

		$dateTime = Core_Date::timestamp2sql(time());
		$oEntityItems
			->queryBuilder()
			->open()
			->where($table . '.start_datetime', '<', $dateTime)
			->setOr()
			->where($table . '.start_datetime', '=', '0000-00-00 00:00:00')
			->close()
			->setAnd()
			->open()
			->where($table . '.end_datetime', '>', $dateTime)
			->setOr()
			->where($table . '.end_datetime', '=', '0000-00-00 00:00:00')
			->close();

		$oEntityItems->queryBuilder()->where($table . '.active', '=', 1);

		return $oEntityItems;
	}

	protected function _itemsAviableOrder($oEntityItems)
	{
		$oShop = $this->_oShop;
		if ($oShop && $oShop->filter) {
			$table = 'shop_filter' . $oShop->id;

			$oEntityItems
				->queryBuilder()
				->leftJoin($table, 'shop_items.id', '=', $table . '.shop_item_id')
				->orderBy($table . '.available', 'DESC');
		}

		return $oEntityItems;
	}

	protected function _itemsPriceCondition($oEntityItems)
	{
		$oEntityItems->queryBuilder()->where('shop_items.price', '>', 0);
	}

	protected function _applyWarehouseConditions($oEntityItems)
	{
		//Exception: SQLSTATE[HY000]: General error: could not call class constructor
		$table_col = 'shop_items.id';

		$oEntityItems
			->queryBuilder()
			->clearSelect()
			->select('shop_items.*')
			// ->clearSelect()
			// ->select('shop_warehouse_items.*')
			->join(
				'shop_warehouse_items',
				'shop_warehouse_items.shop_item_id',
				'=',
				$table_col
			)
			// ->clearSelect()
			// ->select('shop_warehouses.*')
			->join(
				'shop_warehouses',
				'shop_warehouses.id',
				'=',
				'shop_warehouse_items.shop_warehouse_id'
			)

			->where('shop_warehouses.active', '=', 1)
			->where('shop_warehouses.deleted', '=', 0)
			//->where($table_col, '=', 1)
			->groupBy($table_col)
			->having('SUM(shop_warehouse_items.count)', '>', 0);

		// $oEntityItems
		//   ->queryBuilder()
		//   ->select([
		//     Core_QueryBuilder::expression(
		//       'IF(`shop_items`.`shortcut_id` > 0, `shop_items`.`shortcut_id`, `shop_items`.`id`)'
		//     ),
		//     'dataTmpId',
		//   ])
		//   //->clearGroupBy()
		//   ->groupBy('dataTmpId');

		return $oEntityItems;
	}

	protected function _forbidSelectShortcuts($oEntityItems)
	{
		$table_col = $this->_oShop
			? 'shop_items.shortcut_id'
			: 'informationsystem_items.shortcut_id';

		// Отключаем выбор ярлыков из текущей группы
		$oEntityItems->queryBuilder()->where($table_col, '=', 0);

		return $oEntityItems;
	}

	protected function _groupShortcuts($oEntityItems)
	{
		$oEntityItems
			->queryBuilder()
			->select([
				Core_QueryBuilder::expression(
					'IF(`shop_items`.`shortcut_id` > 0, `shop_items`.`shortcut_id`, `shop_items`.`id`)'
				),
				'dataTmpId',
			])
			->select('shop_items.*')
			->clearGroupBy()
			->groupBy('dataTmpId');

		return $oEntityItems;
	}

	protected function _groupExist($sPath)
	{
		$aReturn = false;
		$aPath = $this->_parsePath($sPath);

		if (isset($aPath['path']) && isset($aPath['id'])) {
			$aEntity = $this->_oShop
				? $this->_oShop->Shop_Groups
				: $this->_oInformationsystem->Informationsystem_Groups;
			$aEntity
				->queryBuilder()
				//->clear()
				->where(
					'path',
					'LIKE',
					Core_DataBase::instance()->escapeLike($aPath['path'])
				)
				->where('id', '=', $aPath['id'])
				->where('active', '=', 1)
				->where('deleted', '=', 0)
				->clearOrderBy()
				->limit(1);

			$aEntities = $aEntity->findAll(false);

			// echo Core_DataBase::instance()->getLastQuery();

			// foreach ($aEntities as $tmp) {
			//   var_dump($tmp->toArray());
			//   exit();
			// }

			$oEntity = isset($aEntities[0]) ? $aEntities[0]->id : false;

			return $oEntity;
		}

		return $aReturn;
	}

	protected $_aGroupTree = null;
	public function fillGroups($parent_id = 0)
	{
		$parent_id = intval($parent_id);

		if (is_null($this->_aGroupTree)) {
			$this->_aGroupTree = [];

			$oObj = $this->_oShop ? $this->_oShop : $this->_oInformationsystem;
			$table = $this->_oShop ? 'shop_groups' : 'informationsystem_groups';
			$col = $this->_oShop ? 'shop_id' : 'informationsystem_id';

			$aTmp = Core_QueryBuilder::select('id', 'parent_id')
				->from($table)
				->where($col, '=', $oObj->id)
				->where('shortcut_id', '=', 0)
				->where('deleted', '=', 0)
				->execute()
				->asAssoc()
				->result();

			foreach ($aTmp as $aGroup) {
				$this->_aGroupTree[$aGroup['parent_id']][] = $aGroup;
			}
		}

		$aReturn = [];

		if (isset($this->_aGroupTree[$parent_id])) {
			foreach ($this->_aGroupTree[$parent_id] as $childrenGroup) {
				$aReturn[] = $childrenGroup['id'];
				$aReturn = array_merge(
					$aReturn,
					$this->fillGroups($childrenGroup['id'])
				);
			}
		}

		return $aReturn;
	}

	protected $_subgroupsAll = [];
	public function getSubgroups($group_id)
	{
		if (!isset($this->_subgroupsAll[$group_id])) {
			$this->_subgroupsAll[$group_id] = $this->fillGroups($group_id);
			// Set first ID as current group
			array_unshift($this->_subgroupsAll[$group_id], $group_id);
		}

		return $this->_subgroupsAll[$group_id];
	}

	public function applyFilterGroupCondition($oQueryBuilder, $fieldName)
	{
		if ($this->_group !== false) {
			if ($this->_subgroups) {
				$oQueryBuilder->where(
					$fieldName,
					'IN',
					!is_array($this->_group)
						? $this->getSubgroups($this->_group)
						: $this->_group
				);
			} else {
				$oQueryBuilder->where(
					$fieldName,
					is_array($this->_group) ? 'IN' : '=',
					$this->_group
				);
			}
		}

		return $this;
	}

	/**
	 * Default controller action
	 * @return Core_Response
	 * @hostcms-event App_Command_Controller.onBeforeShowAction
	 * @hostcms-event App_Command_Controller.onAfterShowAction
	 */
	public function showAction()
	{
		Core_Event::notify(get_class($this) . '.onBeforeShowAction', $this);

		$this->_oCore_Response = new Core_Response();

		$aPath = explode('/', $this->path);
		$this->_path = $aPath;
		$bCache = $this->cache && Core::moduleIsActive('cache');
		$sMethod = Core_Array::get($_SERVER, 'REQUEST_METHOD');

		if (
			$bCache &&
			$sMethod == 'GET' &&
			in_array($aPath[0], $this->_aChacheGetWays)
		) {
			$this->_cacheKey =
				'path_' .
				json_encode($aPath) .
				'__' .
				'method_' .
				json_encode($sMethod) .
				'__' .
				'request_' .
				json_encode($_GET);

			$oCore_Cache = Core_Cache::instance(Core::$mainConfig['defaultCache']);
			$inCache = $oCore_Cache->get($this->_cacheKey, $this->_cacheName);

			if ($inCache) {
				// var_dump($this->_cacheKey);
				// var_dump($this->_cacheName);
				// var_dump($inCache);
				// exit();

				$this->_oCore_Response
					->header('Pragma', 'no-cache')
					->header('Cache-Control', 'private, no-cache')
					->header('Vary', 'Accept');

				$this->_oCore_Response
					->header('Content-Disposition', 'inline; filename="files.json"')
					->header('Content-Type', 'application/json; charset=utf-8');

				$this->_oCore_Response
					->header('Access-Control-Allow-Origin', '*')
					->header('Access-Control-Allow-Headers', '*');

				$this->_oCore_Response->body($inCache);

				return $this->_oCore_Response;
			}
		}

		ob_start();

		switch ($this->version) {
			case '1':
			case '1.0':
				$this->_version1();
				break;
			default:
				$this->_error = 'Wrong version';
				$this->_statusCode = 400;
				break;
		}

		if (!is_null($this->_statusCode)) {
			$this->_oCore_Response->status($this->_statusCode);
		}

		$messageContent = ob_get_clean();

		$this->_oCore_Response
			->header('Pragma', 'no-cache')
			->header('Cache-Control', 'private, no-cache')
			->header('Vary', 'Accept');

		$return = $this->_answer;

		if ($this->_statusCode >= 300) {
			$return['error']['code'] = $this->_statusCode;

			if ($this->_config['log']) {
				Core_Log::instance()
					->clear()
					->notify(false)
					->status(Core_Log::$MESSAGE)
					->write(
						sprintf(
							'APP API. CODE: %d, ERROR: %s',
							$this->_statusCode,
							$this->_error
						)
					);
			}
		}

		if (!is_null($this->_error)) {
			is_array($return) && ($return['error']['message'] = $this->_error);
		}

		if ($this->_debug) {
			$return['_debug']['path'] = $this->_path;
			$return['_debug']['request'] = $this->_request;

			if ($messageContent != '') {
				is_array($return) &&
					($return['_debug']['extraMessage'] = $messageContent);
			}

			if ($this->_config['log']) {
				Core_Log::instance()
					->clear()
					->notify(false)
					->status(Core_Log::$MESSAGE)
					->write(
						sprintf('APP API. REQUEST: %s', json_encode($this->_request, true))
					);
			}
		}

		switch ($this->_mode) {
			// header('Pragma: no-cache');
			// header('Cache-Control: private, no-cache');
			// header('Content-Disposition: inline; filename="files.json"');
			// header('Vary: Accept');

			case 'json':
			default:
				// $this->_oCore_Response
				//   //->header('Pragma', 'no-cache')
				//   //->header('Cache-Control', 'private, no-cache')
				//   //->header('Content-Disposition', 'inline; filename="files.json"')
				//   ->header('Content-Type', 'application/json; charset=utf-8')
				//   ->header('Cache-Control', 'public, max-age=60, s-maxage=60')
				//   ->header('Vary', 'Accept, Accept-Encoding, Accept, X-Requested-With')

				//   ->header('Access-Control-Allow-Origin', '*')
				//   ->header(
				//     'Strict-Transport-Security',
				//     'max-age=31536000; includeSubdomains; preload'
				//   )
				//   // ->header('Access-Control-Allow-Credentials', 'true')
				//   ->header(
				//     'Referrer-Policy',
				//     'origin-when-cross-origin, strict-origin-when-cross-origin'
				//   )
				//   //->header('Content-Security-Policy', "default-src 'none'")
				//   //->header('Access-Control-Allow-Methods', 'GET, POST')
				//   ->header('Access-Control-Allow-Headers', '*');
				$this->_oCore_Response
					->header('Content-Disposition', 'inline; filename="files.json"')
					->header('Content-Type', 'application/json; charset=utf-8');

				$this->_oCore_Response
					->header('Access-Control-Allow-Origin', '*')
					->header('Access-Control-Allow-Headers', '*');

				$aJson = null;
				if (is_array($return)) {
					foreach ($return as $key => $tmp) {
						$aJson[$key] = $this->_entity2array($tmp);
					}
				} else {
					$aJson = $this->_entity2array($return);
				}

				$answerBody = $this->_unescape
					? json_encode($aJson, JSON_UNESCAPED_UNICODE)
					: json_encode($aJson);

				if (
					$bCache &&
					$sMethod == 'GET' &&
					in_array($aPath[0], $this->_aChacheGetWays)
				) {
					$this->_cacheKey =
						'path_' .
						json_encode($aPath) .
						'__' .
						'method_' .
						json_encode($sMethod) .
						'__' .
						'request_' .
						json_encode($_GET);

					$oCore_Cache->set($this->_cacheKey, $answerBody, $this->_cacheName);
				}

				// if ($bCache && $sMethod == 'GET') {
				//   $aPath = explode('/', $this->path);
				//   if (in_array($aPath[0], $this->_aChacheGetWays)) {
				//     $oCore_Cache = Core_Cache::instance(
				//       Core::$mainConfig['defaultCache']
				//     );

				//     $this->_cacheName =
				//       'path_' .
				//       json_encode($aPath) .
				//       '__' .
				//       'method_' .
				//       json_encode($sMethod) .
				//       '__' .
				//       'request_' .
				//       json_encode($_GET);

				//     // var_dump($aPath);
				//     // var_dump($aPath[0]);
				//     // var_dump(in_array($aPath[0], $this->_aChacheGetWays));
				//     // var_dump($sMethod);
				//     // exit();

				//     $oCore_Cache->set($this->_cacheKey, $answerBody, $this->_cacheName);

				//     // var_dump($this->_cacheName);
				//     // exit();
				//   }
				// }

				$this->_oCore_Response->body($answerBody);

				// if ($this->_unescape) {
				//   $this->_oCore_Response->body(
				//     json_encode($return, JSON_UNESCAPED_UNICODE)
				//   );
				// } else {
				//   $this->_oCore_Response->body(json_encode($aJson));
				// }

				break;
			case 'xml':
				$this->_oCore_Response->header(
					'Content-Type',
					'application/xml; charset=utf-8'
				);

				$this->_oCore_Response->body(
					'<?xml version="1.0" encoding="UTF-8"?>' .
						"\r\n" .
						'<' .
						Core_Str::xml($this->_config['xmlRootNode']) .
						'>' .
						"\r\n"
				);

				$this->_oCore_Response->body($this->_entity2XML($return));

				$this->_oCore_Response->body(
					'</' . Core_Str::xml($this->_config['xmlRootNode']) . '>'
				);
				break;
		}

		Core_Event::notify(get_class($this) . '.onAfterShowAction', $this, [
			$this->_oCore_Response,
		]);

		return $this->_oCore_Response;
	}

	/**
	 * Convert $entity to array
	 * @var mixed $entity
	 * @return array
	 */
	protected function _entity2array($entity)
	{
		if (is_object($entity)) {
			return $entity instanceof Core_ORM ? $entity->toArray() : $entity;
		}

		return $entity;
	}

	/**
	 * Convert $entity to XML
	 * @var mixed $entity
	 * @return string
	 */
	protected function _entity2XML($entity)
	{
		if (is_object($entity) && $entity instanceof Core_ORM) {
			return $entity->getXml();
		}

		return is_array($entity) ? Core_Xml::array2xml($entity) : null;
	}

	/**
	 * Verson 1.0
	 * @hostcms-event App_Command_Controller.onBeforeAddNewEntity
	 * @hostcms-event App_Command_Controller.onBeforeUpdateEntity
	 */
	protected function _version1()
	{
		$oPreviosEntity = null;
		$bFound = false;

		$aPath = explode('/', $this->path);
		$this->_path = $aPath;

		$sMethod = Core_Array::get($_SERVER, 'REQUEST_METHOD');

		if ($this->_config['log']) {
			Core_Log::instance()
				->clear()
				->notify(false)
				->status(Core_Log::$MESSAGE)
				->write(
					sprintf('APP API: method "%s", path: "%s"', $sMethod, $this->path)
				);
		}

		if ($sMethod == 'OPTIONS') {
			$this->_oCore_Response->header('Allow', 'GET,POST,OPTIONS');

			if (
				in_array($aPath[0], $this->_aGetWays) ||
				in_array($aPath[0], $this->_aPostWays)
			) {
				$sSingularName = $aPath[0];
			} else {
				$this->_error = sprintf('Unexpected %s', $this->_path);
				$this->_statusCode = 422;

				return false;
			}

			//$this->_answer['fields'] = $oPreviosEntity->getTableColumns();
			$this->_answer['methods'] = $aPath[0];
		} else {
			//Check Authorization
			// $this->_checkAuthorization();
			// // //$this->_checkScret();

			// if (is_null($this->_user)) {
			//   $this->_error = 'Authentication Required';
			//   $this->_statusCode = 401;

			//   return false;
			// }

			// Check Content-Type
			$this->_checkContentType();

			if ($aPath[0] != 'pay') {
				if (is_null($this->_mode)) {
					$this->_error = 'Wrong Content-Type';
					$this->_statusCode = 400;

					return false;
				}
			}

			// Check main entity
			if (is_null($this->path)) {
				$this->_error = 'Empty Request';
				$this->_statusCode = 400;

				return false;
			}

			$sAnswer = null;

			switch ($sMethod) {
				// SELECT ITEMS
				case 'GET':
					$this->_request = $_GET;

					// protected $_aGetWays = ['doc', 'category', 'item', 'cart'];
					if (in_array($aPath[0], $this->_aGetWays)) {
						//$mAnswer = $aPath;

						if ($this->_statusCode == 200) {
							//$this->_answer = $mAnswer;

							switch ($aPath[0]) {
								case 'test':
									$this->_test();
									break;

								case 'doc':
									if (isset($aPath[1])) {
										$this->doc($aPath[1]);
									} else {
										$this->_error = sprintf('Method "%s" Not Allowed', 'doc');
										$this->_statusCode = 405;
									}
									break;

								case 'info':
									// Информация
									$infoId = 1;
									$this->_oInformationsystem = Core_Entity::factory(
										'informationsystem',
										$infoId
									);
									$this->_slug = $aPath[0];
									$is_group = strval(Core_Array::getGet('group', false));
									$group_id = $this->_groupExist($is_group);

									if ($is_group) {
										$group_id = $this->_groupExist($is_group);
										if ($group_id) {
											$this->_group = $group_id;
											$this->_subgroups = true;
											if (count($aPath) == 1) {
												$this->info_list();
											}
										} else {
											$this->_error = sprintf(
												'Path: "%s" Not Found',
												$this->path . '?group=' . $is_group
											);
											$this->_statusCode = 404;
										}
									} else {
										$this->_group = $is_group;
										$this->_subgroups = true;
										if (count($aPath) == 1) {
											$this->info_list();
										}
									}

									//$this->_oInfoDataAllowed = ['tags', 'shop_items'];

									if (count($aPath) == 2) {
										$this->info_item($aPath[1]);
									}
									break;

								case 'cert':
									// Сертификаты
									$infoId = 5;
									$this->_oInformationsystem = Core_Entity::factory(
										'informationsystem',
										$infoId
									);
									$this->_slug = 'certificates';
									$this->_group = false;
									$this->_subgroups = true;
									$this->_oInfoDataAllowed = ['media'];
									if (count($aPath) == 1) {
										$this->info_list();
									}
									break;

								case 'blog':
									// Блог
									$infoId = 3;
									$this->_oInformationsystem = Core_Entity::factory(
										'informationsystem',
										$infoId
									);

									$this->_slug = $aPath[0];
									$is_group = strval(Core_Array::getGet('group', false));

									if ($is_group) {
										$group_id = $this->_groupExist($is_group);
										if ($group_id) {
											$this->_group = $group_id;
											$this->_subgroups = true;
											if (count($aPath) == 1) {
												$this->info_list();
											}
										} else {
											$this->_error = sprintf(
												'Path: "%s" Not Found',
												$this->path . '?group=' . $is_group
											);
											$this->_statusCode = 404;
										}
									} else {
										$this->_group = $is_group;
										$this->_subgroups = true;
										if (count($aPath) == 1) {
											$this->info_list();
										}
									}

									$this->_oInfoDataAllowed = ['tags', 'shop_items', 'media'];

									if (count($aPath) == 2) {
										$this->info_item($aPath[1]);
									}
									break;

								case 'catalog':
									// Каталог
									$shopId = 1;
									$this->_oShop = Core_Entity::factory('Shop', $shopId);
									$this->_slug = $aPath[0];
									$is_group = strval(Core_Array::getGet('group', false));
									$group_id = $this->_groupExist($is_group);

									if ($is_group) {
										$group_id = $this->_groupExist($is_group);
										if ($group_id) {
											$this->_group = $group_id;
											$this->_subgroups = true;
											if (count($aPath) == 1) {
												$this->_groupsMode = 'all';

												$this->shop_list();
											}
										} else {
											$this->_error = sprintf(
												'Path: "%s" Not Found',
												$this->path . '?group=' . $is_group
											);
											$this->_statusCode = 404;
										}
									} else {
										$this->_group = $is_group;
										$this->_subgroups = true;
										if (count($aPath) == 1) {
											$this->_groupsMode = 'all';

											$this->shop_list();
										}
									}

									if (count($aPath) == 2) {
										$this->_slug = 'product';

										$this->_oInfoDataAllowed = [
											'labels',
											'volume',
											'instruction',
											'sostav',
											'for',
											//'certs',
											'plus',
											'faq',
											'promo',
											'comments',
											//'rate',
											//'same',
											'media',
											'dopmedia',
											'recommendation',
											'bottom_recommendation',
										];

										$this->shop_item($aPath[1]);
									}
									break;

								case 'product_comments':
									if (count($aPath) == 2) {
										$this->product_comments($aPath[1]);
									}

									break;
								case 'qr':
									if (count($aPath) == 2) {
										$this->product_qr($aPath[1]);
									} else {
										$this->_error = sprintf(
											'Path: "%s" Not Found',
											$this->path
										);
										$this->_statusCode = 404;
									}

									break;

								case 'export_shop':
									$shopId = 1;
									$this->_oShop = Core_Entity::factory('Shop', $shopId);
									$this->export_shop();
									break;

								case 'retailcrm':
									$shopId = 1;
									$this->_oShop = Core_Entity::factory('Shop', $shopId);
									//$this->retailcrm();
									break;

								case 'r46':
									// Каталог
									$shopId = 1;
									$this->_slug = $aPath[0];
									$this->_oShop = Core_Entity::factory('Shop', $shopId);

									if (count($aPath) == 2) {
										switch ($aPath[1]) {
											// Блоки реккомендации
											case 'recommend':
												$this->r46__recommend();
												break;
											// Профиль клиента
											case 'profile':
												$this->r46__profile();
												break;

											default:
												$this->_error = sprintf(
													'Path: "%s" Not Found',
													$this->path
												);
												$this->_statusCode = 404;
										}
									} else {
										$this->_error = sprintf(
											'Path: "%s" Not Found',
											$this->path
										);
										$this->_statusCode = 404;
									}

									break;

								case 'city':
									$this->city_list();
									break;

								case 'menu':
									// Каталог
									$shopId = 1;
									$this->_slug = $aPath[0];
									$this->_subgroups = true;
									$this->_oShop = Core_Entity::factory('Shop', $shopId);

									$this->menu();
									break;

								case 'main':
									// Блоки на главной
									$infoId = 7;
									$this->_oInformationsystem = Core_Entity::factory(
										'informationsystem',
										$infoId
									);
									$this->main_page();
									break;

								case 'pay':
									$this->pay_input();
									break;
								case 'marketredirects':
									//$this->marketredirects();
									$this->marketredirectsdb();
									break;

								// case 'marketredirectsdb':
								//   $this->marketredirectsdb();
								//   break;

								default:
									$this->_error = sprintf('Path: "%s" Not Found', $this->path);
									$this->_statusCode = 404;
							}
						} else {
							//return $sAnswer;

							$this->_error = sprintf('Path: "%s" Not Found', $this->path);
							$this->_statusCode = 404;
						}
					} else {
						$this->_error = sprintf('Path: "%s" Not Found', $this->path);
						$this->_statusCode = 404;
					}

					break;
				// CREATE NEW ITEM
				case 'POST':
					$rawData = @file_get_contents('php://input');

					if (strlen($rawData) > 2) {
						try {
							$aJson = json_decode($rawData, true);

							$this->_request = $aJson;

							//$this->_answer = $newEntity->getPrimaryKey();
							//$this->_answer = $aJson;

							// $login = isset($aJson['username']) ? $aJson['username'] : null;
							// $pwd = isset($aJson['password']) ? $aJson['password'] : null;

							if (in_array($aPath[0], $this->_aPostWays)) {
								if ($this->_statusCode == 200) {
									switch ($aPath[0]) {
										case 'import_shop':
											$shopId = 1;
											$this->_oShop = Core_Entity::factory('Shop', $shopId);
											$this->import_shop();
											break;

										case 'import_price':
											$shopId = 1;
											$this->_oShop = Core_Entity::factory('Shop', $shopId);
											$this->import_price();
											break;

										case 'comment_vote':
											$this->comment_vote();
											break;

										case 'comment_add':
											$shopId = 1;
											$this->_oShop = Core_Entity::factory('Shop', $shopId);
											$this->comment_add();
											break;

										case 'address_add':
											$this->address_add();
											break;

										case 'signin':
											$this->signin();
											break;
										case 'signup':
											$this->signup();
											break;
										case 'signinphone':
											$this->signinphone();
											break;
										case 'restore':
											$this->restore();
											break;
										case 'cart':
											$shopId = 1;
											$this->_oShop = Core_Entity::factory('Shop', $shopId);
											$this->cart();
											break;
										case 'view':
											$this->view();
											break;

										case 'checkout':
											$shopId = 1;
											$this->_oShop = Core_Entity::factory('Shop', $shopId);
											$this->checkout();
											break;

										case 'makeorder':
											$shopId = 1;
											$this->_oShop = Core_Entity::factory('Shop', $shopId);
											$this->makeorder();
											break;

										case 'pay':
											$this->pay_inputpost();
											break;

										case 'codeauthinput':
											$this->codeauthinput();
											break;

										case 'codeauth':
											if (isset($aPath[1])) {
												switch ($aPath[1]) {
													case 'register':
														$this->codeauth__register();
														break;

													case 'check':
														$this->codeauth__check();
														break;

													default:
														$this->_error = sprintf(
															'Path: "%s" Not Found',
															$this->path
														);
														$this->_statusCode = 404;
												}
											} else {
												$this->_error = sprintf(
													'Path: "%s" Not Found',
													$this->path
												);
												$this->_statusCode = 404;
											}

											break;

										case 'me':
											$shopId = 1;
											$this->_oShop = Core_Entity::factory('Shop', $shopId);

											if (isset($aPath[1])) {
												switch ($aPath[1]) {
													case 'comments':
														$this->commentshistory();
														break;
													case 'orders':
														$this->orderhistory();
														break;

													case 'update':
														$this->updateprofile();
														break;

													case 'password':
														$this->updatepassword();
														break;

													case 'addresses':
														$this->me_addresses();
														break;

													default:
														$this->_error = sprintf(
															'Path: "%s" Not Found',
															$this->path
														);
														$this->_statusCode = 404;
												}
											} else {
												$this->me();
											}
											break;

										case 'apiship':
											if (isset($aPath[1])) {
												switch ($aPath[1]) {
													case 'points':
														$this->apiship_list_points();
														break;

													default:
														$this->_error = sprintf(
															'Path: "%s" Not Found',
															$this->path
														);
														$this->_statusCode = 404;
												}
											} else {
												$this->_error = sprintf(
													'Path: "%s" Not Found',
													$this->path
												);
												$this->_statusCode = 404;
											}

											break;

										case 'rcrm':
											$shopId = 1;
											$this->_oShop = Core_Entity::factory('Shop', $shopId);

											if (isset($aPath[1])) {
												switch ($aPath[1]) {
													case 'track':
														$this->rcrm__track();
														break;

													case 'complete':
														$this->rcrm__complete();
														break;

													case 'canceled':
														$this->rcrm__canceled();
														break;

													case 'orderchange':
														$this->rcrm__changeorder();
														break;

													default:
														$this->_error = sprintf(
															'Path: "%s" Not Found',
															$this->path
														);
														$this->_statusCode = 404;
												}
											} else {
												$this->_error = sprintf(
													'Path: "%s" Not Found',
													$this->path
												);
												$this->_statusCode = 404;
											}
											break;
									}
								}
							} else {
								$this->_error = sprintf('Path: "%s" Not Found', $this->path);
								$this->_statusCode = 404;
							}
						} catch (Exception $e) {
							$this->_error = $e->getMessage();
							$this->_statusCode = 422;

							return false;
						}
					} else {
						$this->_error = 'Wrong POST data';
						$this->_statusCode = 422;

						return false;
					}
					break;

				default:
					$this->_error = sprintf(
						'Method "%s" Not Allowed',
						htmlspecialchars($sMethod)
					);
					$this->_statusCode = 405;
					break;
			}
		}
	}

	/**
	 * Сheck Content Type by $_SERVER['CONTENT_TYPE']
	 * @return boolean
	 */
	protected function _checkContentType()
	{
		$contentType = Core_Array::get(
			$_SERVER,
			'CONTENT_TYPE',
			'application/json; charset=utf-8'
		);

		$aContentTypes = array_map('trim', explode(',', $contentType));

		foreach ($aContentTypes as $sContentType) {
			$sTmpContentType = array_map('trim', explode(';', $sContentType));

			switch ($sTmpContentType[0]) {
				case 'application/json':
					$this->_mode = 'json';
					break 2;
				case 'application/xml':
					$this->_mode = 'xml';
					break 2;
			}
		}

		return !is_null($this->_mode);
	}

	/**
	 * Chech Authorization
	 */
	protected function _checkAuthorization()
	{
		$this->_user = null;

		$aHeaders = $this->_getRequestHeaders();

		if (isset($aHeaders['Authorization'])) {
			if (
				preg_match(
					'/Bearer ([0-9a-zA-Z]+)/',
					$aHeaders['Authorization'],
					$matches
				)
			) {
				if (isset($matches[1])) {
					$sCurrentDate = Core_Date::timestamp2sql(time());

					$oRestapi_Tokens = Core_Entity::factory('Restapi_Token');
					$oRestapi_Tokens
						->queryBuilder()
						->where('token', '=', $matches[1])
						->where('active', '=', 1)
						->where('datetime', '<=', $sCurrentDate)
						->open()
						->where('expire', '=', '0000-00-00 00:00:00')
						->setOr()
						->where('expire', '>', $sCurrentDate)
						->close()
						->limit(1);

					$aRestapi_Tokens = $oRestapi_Tokens->findAll(false);
					if (isset($aRestapi_Tokens[0])) {
						$oRestapi_Token = $aRestapi_Tokens[0];

						if (!$oRestapi_Token->https || Core::httpsUses()) {
							if ($oRestapi_Token->user_id) {
								$oUser = $oRestapi_Token->User;

								if (
									$oUser->active &&
									!$oUser->read_only &&
									!$oUser->dismissed
								) {
									$this->_user = $oUser;
								}
							}
						}
					}
				}
			}
		}

		return !is_null($this->_user);
	}

	/**
	 * Get Request Headers. Use apache_request_headers() or $_SERVER
	 * @return array
	 */
	protected function _getRequestHeaders()
	{
		// PHP 5.4.0: This function became available under FastCGI. Previously, it was supported when PHP was installed as an Apache module or by the NSAPI server module in Netscape/iPlanet/SunONE webservers.
		// PHP 7.3.0: This function became available in the FPM SAPI.
		// FPM available just from 7.3
		if (function_exists('apache_request_headers')) {
			$aHeaders = apache_request_headers();
		} else {
			$aHeaders = [];
			foreach ($_SERVER as $key => $val) {
				if (substr($key, 0, 5) == 'HTTP_') {
					$aKey = array_map(
						'ucfirst',
						explode('_', strtolower(substr($key, 5)))
					);
					$key = implode('-', $aKey);

					$aHeaders[$key] = $val;
				}
			}
		}

		// fix bug with adding REDIRECT_ while using "RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]"
		if (!isset($aHeaders['Authorization'])) {
			foreach ($_SERVER as $key => $value) {
				if (preg_replace('/^(REDIRECT_)*/', '', $key) == 'HTTP_AUTHORIZATION') {
					$aHeaders['Authorization'] = $_SERVER[$key];
					break;
				}
			}
		}

		return $aHeaders;
	}

	protected function _tokenCMSAuth($token)
	{
		$this->_user = null;

		$sCurrentDate = Core_Date::timestamp2sql(time());

		$oRestapi_Tokens = Core_Entity::factory('Restapi_Token');
		$oRestapi_Tokens
			->queryBuilder()
			->where('token', '=', $token)
			->where('active', '=', 1)
			->where('datetime', '<=', $sCurrentDate)
			->open()
			->where('expire', '=', '0000-00-00 00:00:00')
			->setOr()
			->where('expire', '>', $sCurrentDate)
			->close()
			->limit(1);

		$aRestapi_Tokens = $oRestapi_Tokens->findAll(false);
		if (isset($aRestapi_Tokens[0])) {
			$oRestapi_Token = $aRestapi_Tokens[0];

			if (!$oRestapi_Token->https || Core::httpsUses()) {
				if ($oRestapi_Token->user_id) {
					$oUser = $oRestapi_Token->User;

					if ($oUser->active && !$oUser->read_only && !$oUser->dismissed) {
						$this->_user = $oUser;
					}
				}
			}
		}

		return !is_null($this->_user);
	}

	protected function _test()
	{
		$aResult = range(mt_rand(0, 100), mt_rand(10, 100));

		$this->_answer['result'] = $aResult;
		$this->_answer['count'] = count($aResult);
	}

	protected function _prePagination()
	{
		$this->_limit = $this->_oShop
			? $this->_oShop->items_on_page
			: $this->_oInformationsystem->items_on_page;

		// LIMIT
		$tmpLimit = Core_Array::getGet('limit');
		if (is_numeric($tmpLimit) && $tmpLimit > 0) {
			$this->_limit = intval($tmpLimit);
		}

		// OFFSET
		$tmpOffset = Core_Array::getGet('offset');
		if (is_numeric($tmpOffset) && $tmpOffset >= 0) {
			$this->_offset = intval($tmpOffset);
		}

		$tmpPage = Core_Array::getGet('page');
		if (is_numeric($tmpPage) && $tmpPage >= 2) {
			$this->_page = intval($tmpPage);
			$this->_offset = $this->_limit * ($this->_page - 1);
		}

		// Load model columns BEFORE FOUND_ROWS()
		$model = $this->_oShop ? 'Shop_Item' : 'Informationsystem_Item';
		Core_Entity::factory($model)->getTableColumns();
	}

	protected function _getPagination()
	{
		//https://vpilip.com/how-build-simple-pagination-in-nextjs/
		return [
			// 'total' => intval($this->_total),
			// 'limit' => intval($this->_limit),
			// 'offset' => intval($this->_offset),
			// 'page' => intval($this->_page),

			'totalCount' => intval($this->_total),
			'pageCount' => ceil(intval($this->_total) / intval($this->_limit)),
			'currentPage' => intval($this->_page),
			'perPage' => intval($this->_limit),
		];
	}

	protected function _makeShortcode($content)
	{
		$bShortcodeTags = Core::moduleIsActive('shortcode');
		if ($bShortcodeTags) {
			$oShortcode_Controller = Shortcode_Controller::instance();
			$iCountShortcodes = $oShortcode_Controller->getCount();

			if ($iCountShortcodes) {
				$content = $oShortcode_Controller->applyShortcodes($content);
			}
		}
		return $content;
	}

	protected function _getSeo($oEntity)
	{
		$class = get_class($oEntity);

		// Defaults
		$seo_title = $seo_description = $_seoTitle = $_seoDescription = null;

		$oRootEntity = null;

		$oCore_Meta = new Core_Meta();

		// $oCore_Meta
		// ->addObject('informationsystem', $oRootEntity)
		// ->addObject('group', $oInformationsystem_Item->Informationsystem_Group)
		// ->addObject('item', $oInformationsystem_Item)
		// ->addObject('this', $this);

		switch ($class) {
			case 'Informationsystem_Model':
				$oRootEntity = $oEntity;
				$_seoTitle = $oRootEntity->seo_root_title_template;
				$_seoDescription = $oRootEntity->seo_root_description_template;

				$oCore_Meta->addObject('informationsystem', $oRootEntity);

				break;
			case 'Informationsystem_Group_Model':
				$oRootEntity = Core_Entity::factory(
					'Informationsystem',
					$oEntity->informationsystem_id
				);
				$_seoTitle = $oRootEntity->seo_group_title_template;
				$_seoDescription = $oRootEntity->seo_group_description_template;

				$oCore_Meta
					->addObject('informationsystem', $oRootEntity)
					->addObject('group', $oEntity);

				break;
			case 'Informationsystem_Item_Model':
				$oRootEntity = Core_Entity::factory(
					'Informationsystem',
					$oEntity->informationsystem_id
				);
				$_seoTitle = $oRootEntity->seo_item_title_template;
				$_seoDescription = $oRootEntity->seo_item_description_template;

				$oGroup = Core_Entity::factory(
					'Informationsystem_Group',
					$oEntity->informationsystem_group_id
				);

				$oCore_Meta
					->addObject('informationsystem', $oRootEntity)
					->addObject('group', $oGroup)
					->addObject('item', $oEntity);

				break;

			case 'Shop_Model':
				$oRootEntity = $oEntity;
				$_seoTitle = $oRootEntity->seo_root_title_template;
				$_seoDescription = $oRootEntity->seo_root_description_template;

				$oCore_Meta->addObject('shop', $oRootEntity);

				break;
			case 'Shop_Group_Model':
				$oRootEntity = Core_Entity::factory('Shop', $oEntity->shop_id);
				$_seoTitle = $oRootEntity->seo_group_title_template;
				$_seoDescription = $oRootEntity->seo_group_description_template;

				$oCore_Meta
					->addObject('shop', $oRootEntity)
					->addObject('group', $oEntity);

				break;
			case 'Shop_Item_Model':
				$oRootEntity = Core_Entity::factory('Shop', $oEntity->shop_id);
				$_seoTitle = $oRootEntity->seo_item_title_template;
				$_seoDescription = $oRootEntity->seo_item_description_template;

				$oGroup = Core_Entity::factory('Shop_Group', $oEntity->shop_group_id);

				$oCore_Meta
					->addObject('shop', $oRootEntity)
					->addObject('group', $oGroup)
					->addObject('item', $oEntity);

				break;
		}

		//   Core_Str::stripTags(
		//   strval(Core_Array::get($aInput, 'postcode'))
		// );

		switch ($class) {
			case 'Informationsystem_Model':
			case 'Shop_Model':
				if ($_seoTitle != '') {
					$seo_title = $oCore_Meta->apply($_seoTitle);
				} else {
					$seo_title = $oEntity->name;
				}

				if ($_seoDescription != '') {
					$seo_description = $oCore_Meta->apply($_seoDescription);
				} else {
					$seo_description = $oEntity->description;
				}

				break;

			default:
				// Title
				if ($oEntity->seo_title != '') {
					$seo_title = $oEntity->seo_title;
				} elseif ($_seoTitle != '') {
					$seo_title = $oCore_Meta->apply($_seoTitle);
				} else {
					$seo_title = $oEntity->name;
				}

				// Description
				if ($oEntity->seo_description != '') {
					$seo_description = $oEntity->seo_description;
				} elseif ($_seoDescription != '') {
					$seo_description = $oCore_Meta->apply($_seoDescription);
				} else {
					$seo_description = $oEntity->description;
				}
				break;
		}

		$aReturn = [
			'title' => Core_Str::stripTags(strval($seo_title)),
			'description' => Core_Str::stripTags(strval($seo_description)),
		];

		return $aReturn;
	}

	protected function doc($docId)
	{
		$oDoc = Core_Entity::factory('Document', $docId);

		if ($oDoc->name && $oDoc->document_status_id == 1) {
			$content = $this->_makeShortcode($oDoc->text);

			$this->_answer = [
				'id' => $oDoc->id,
				'name' => $oDoc->name,
				'text' => $content,
			];
		} else {
			$this->_error = sprintf('Path: "%s" Not Found', $this->path);
			$this->_statusCode = 404;
		}
	}
	protected function _parsePath($sPath)
	{
		$aReturn = null;
		$sPath = trim($sPath);

		if (strlen($sPath) > 0) {
			$aPath = explode('-', $sPath);
			$id = array_pop($aPath);
			$aReturn = [
				'full' => $sPath,
				'path' => implode('-', $aPath),
				'id' => intval($id),
			];
		}

		return $aReturn;
	}

	protected function _getGroups()
	{
		if ($this->_groupsMode == 'none') {
			return [];
		}

		$aReturn = [];
		$oEntityGroups = $this->_oShop
			? $this->_oShop->Shop_Groups
			: $this->_oInformationsystem->Informationsystem_Groups;

		if ($this->_groupsMode == 'tree') {
			$aGroups = $oEntityGroups->getByParentId(intval($this->_group));
		}

		if ($this->_groupsMode == 'all') {
			$aGroups = $oEntityGroups->findAll();
		}

		if (count($aGroups)) {
			foreach ($aGroups as $oGroup) {
				if ($oGroup->active && !$oGroup->deleted) {
					$aReturn[] = $this->_groupCard($oGroup);
				}
			}
		}

		return $aReturn;
	}

	protected function _getMedia($oEntity)
	{
		$class = get_class($oEntity);

		$aPropImages = [];

		switch ($class) {
			case 'Informationsystem_Group_Model':
				$href = $oEntity->getGroupHref();
				break;
			case 'Informationsystem_Item_Model':
				$href = $oEntity->getItemHref();
				break;
			case 'Shop_Group_Model':
				$href = $oEntity->getGroupHref();
				break;
			case 'Shop_Item_Model':
				$href = $oEntity->getItemHref();
				$aPropImages = [12];
				break;

			default:
				$href = null;
				break;
		}

		$aMedia = ['thumb' => null];

		$aPreMedia = [];

		if ($href) {
			$aItem = [];
			if ($oEntity->image_small != '') {
				//$aMedia['thumb'] = $href . $oEntity->image_small;

				$url = $href . $oEntity->image_small;
				$aMedia['thumb'] = [
					//'file' => $url . '?' . filemtime(CMS_FOLDER . $url),
					'file' => $this->_useFiletime
						? $url . '?' . filemtime(CMS_FOLDER . $url)
						: $url,
					'width' => $oEntity->image_small_width,
					'height' => $oEntity->image_small_height,
				];

				if (in_array('media', $this->_oInfoDataAllowed)) {
					$url = $href . $oEntity->image_small;
					$aItem['thumb'] = [
						'file' => $this->_useFiletime
							? $url . '?' . filemtime(CMS_FOLDER . $url)
							: $url,
						'width' => $oEntity->image_small_width,
						'height' => $oEntity->image_small_height,
					];
				}
			}

			if (in_array('media', $this->_oInfoDataAllowed)) {
				if ($oEntity->image_large != '') {
					$url = $href . $oEntity->image_large;
					$aItem['original'] = [
						'file' => $this->_useFiletime
							? $url . '?' . filemtime(CMS_FOLDER . $url)
							: $url,
						'width' => $oEntity->image_large_width,
						'height' => $oEntity->image_large_height,
					];
				}
				if (isset($aItem['thumb']) || isset($aItem['original'])) {
					$aItem['sorting'] = -1;
					$aPreMedia[] = $aItem;
				}

				if (in_array('dopmedia', $this->_oInfoDataAllowed)) {
					if (count($aPropImages)) {
						foreach ($aPropImages as $prop_id) {
							$oProperty = Core_Entity::factory('Property', $prop_id);
							$aPropertyValues = $oProperty->getValues($oEntity->id);

							if (count($aPropertyValues)) {
								$sorting = 0;
								foreach ($aPropertyValues as $oPropertyValue) {
									$aItem = [];
									if ($oPropertyValue && $oPropertyValue->file_small) {
										// if ($oEntity->id == 5) {
										//   var_dump($href);
										//   var_dump($oPropertyValue->file_small);
										//   exit();
										// }

										$sorting = $oPropertyValue->sorting;

										$url = $href . $oPropertyValue->file_small;
										$aItem['thumb'] = [
											'file' => $this->_useFiletime
												? $url . '?' . filemtime(CMS_FOLDER . $url)
												: $url,
											'width' => $oEntity->image_small_width,
											'height' => $oEntity->image_small_height,
										];
									}
									if ($oPropertyValue && $oPropertyValue->file) {
										$sorting = $oPropertyValue->sorting;
										$url = $href . $oPropertyValue->file;
										$aItem['original'] = [
											'file' => $this->_useFiletime
												? $url . '?' . filemtime(CMS_FOLDER . $url)
												: $url,
											'width' => $oEntity->image_large_width,
											'height' => $oEntity->image_large_height,
										];
									}
									if (isset($aItem['thumb']) || isset($aItem['original'])) {
										$aItem['sorting'] = $sorting;
										$aPreMedia[] = $aItem;
									}
								}

								// if (isset($aItem['thumb']) || $aItem['original']) {
								//   $aItem['sorting'] = $oPropertyValue->sorting;
								// }
							}
						}
					}
				}
			}
		}

		if (count($aPreMedia)) {
			$aMedia['media'] = $aPreMedia;
		}

		return $aMedia;
	}

	protected function _commentCard($oEntity, $me = false)
	{
		$from = null;
		$oProperty = Core_Entity::factory('Property', 19);
		$aPropertyValues = $oProperty->getValues($oEntity->id);
		if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
			$oList_Item = Core_Entity::factory(
				'List_Item',
				$aPropertyValues[0]->value
			);

			$from = [
				//'id' => $oList_Item->id,
				'name' => $oList_Item->value,
				// 'color' => $oList_Item->color != '' ? $oList_Item->color : null,
				// 'icon' => $oList_Item->icon != '' ? $oList_Item->icon : null,
				'image' =>
					$oList_Item->image_small != ''
						? $oList_Item->getHref() . $oList_Item->image_small
						: null,
			];
		}

		$sAdvantages = null;
		$oProperty = Core_Entity::factory('Property', 33);
		$aPropertyValues = $oProperty->getValues($oEntity->id);
		if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
			$sAdvantages = $aPropertyValues[0]->value;
		}

		$sFlaws = null;
		$oProperty = Core_Entity::factory('Property', 36);
		$aPropertyValues = $oProperty->getValues($oEntity->id);
		if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
			$sFlaws = $aPropertyValues[0]->value;
		}

		$aVotingStatistic = ['likes' => 0, 'dislikes' => 0, 'rate' => 0];

		$aVotes = $oEntity->Votes->findAll();
		foreach ($aVotes as $oVote) {
			$aVotingStatistic[$oVote->value < 0 ? 'dislikes' : 'likes'] +=
				$oVote->value;
		}

		$aVotingStatistic['rate'] =
			$aVotingStatistic['likes'] + $aVotingStatistic['dislikes'];
		$aVotingStatistic['dislikes'] *= -1;

		$aCommentsList = [];
		$oComments = $oEntity->Comments;
		$oComments
			->queryBuilder()
			->where('active', '=', 1)
			->where('deleted', '=', 0)
			->where('parent_id', '=', $oEntity->id)
			->orderBy('datetime', 'ASC');

		$aComments = $oComments->findAll();
		$i = 0;
		foreach ($aComments as $oComment) {
			if ($i < 10) {
				$aCommentsList[] = $this->_commentCard($oComment);
			}

			$i++;
		}
		$aEntity['comments']['list'] = $aCommentsList;

		$sAuthor = trim($oEntity->author);
		if (strlen($sAuthor) < 2) {
			$profile = $this->_getSiteuserProfile();

			$sName = $profile['name'];
			$sSurname = mb_substr($profile['surname'], 0, 1);

			$pre = $sName . ' ' . $sSurname;

			if (strlen($pre) > 1) {
				$sAuthor = $pre;
			}
		}

		$itemCard = null;
		if ($me) {
			if ($oEntity->Comment_Shop_Item->Shop_Item) {
				$cardData = $this->_shopCard($oEntity->Comment_Shop_Item->Shop_Item);
				if (isset($cardData['thumb']) && $cardData['thumb']) {
					$itemCard = [
						'id' => $cardData['id'],
						'name' => $cardData['name'],
						'thumb' => $cardData['thumb'],
						'slug' => $cardData['slug'],
					];
				}
			}
		}

		$edited = false;
		if ($me) {
			$oProperty = Core_Entity::factory('Property', 50);
			$aPropertyValues = $oProperty->getValues($oEntity->id);

			// var_dump($oEntity->id);
			// var_dump(count($aPropertyValues));
			// exit();
			if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
				$edited = boolval($aPropertyValues[0]->value);
				//$edited = $aPropertyValues[0]->value;
			}
		}

		return [
			'id' => $oEntity->id,
			'author' => $sAuthor,
			//'author_id' => $oEntity->Siteuser->id,
			'datetime' => $oEntity->datetime,
			'grade' => $oEntity->grade,
			'advantages' => $sAdvantages,
			'flaws' => $sFlaws,
			'text' => $oEntity->text,
			'from' => $from,
			'vote' => $aVotingStatistic,
			'list' => $aCommentsList,
			'edited' => $edited,
			'item' => $itemCard,
		];

		//return $aReturn;
	}

	protected function _infoCard($oEntity)
	{
		$thumb = null;
		$aMedia = [];
		$aMediaPre = $this->_getMedia($oEntity);
		if (isset($aMediaPre['thumb'])) {
			$thumb = $aMediaPre['thumb'];
		}
		if (isset($aMediaPre['media'])) {
			$aMedia = $aMediaPre['media'];
		}

		$aReturn = [
			'id' => intval($oEntity->id),
			'name' => $oEntity->name,
			'description' => $oEntity->description,
			'group_id' => $oEntity->informationsystem_group_id,
			//'type' => $oShop_Item->type,
			'media' => $aMedia,
			'thumb' => $thumb,
			'slug' => $oEntity->path . '-' . $oEntity->id,
			'sorting' => intval($oEntity->sorting),
		];

		if (in_array('tags', $this->_oInfoDataAllowed)) {
			if (Core::moduleIsActive('tag')) {
				$aTags = [];
				$aTagsItems = $oEntity->Tags->findAll();
				foreach ($aTagsItems as $oTag) {
					$aTags[] = [
						'id' => $oTag->id,
						'name' => $oTag->name,
						'slug' => $oTag->path . '-' . $oTag->id,
					];
				}

				$aReturn['tags'] = $aTags;
			}
		}

		return $aReturn;
	}

	protected function _promoCard($oEntity)
	{
		$thumb = null;
		$aMedia = [];
		$aMediaPre = $this->_getMedia($oEntity);
		if (isset($aMediaPre['thumb'])) {
			$thumb = $aMediaPre['thumb'];
		}
		if (isset($aMediaPre['media'])) {
			$aMedia = $aMediaPre['media'];
		}
		$video = null;
		$oProperty = Core_Entity::factory('Property', 5);
		$aPropertyValues = $oProperty->getValues($oEntity->id);
		if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
			$video = $aPropertyValues[0]->value;
		}

		$aFaq = [];
		$oProperty = Core_Entity::factory('Property', 6);
		$aPropertyValues = $oProperty->getValues($oEntity->id);

		foreach ($aPropertyValues as $oPropertyValue) {
			$oItemFaq = Core_Entity::factory(
				'Informationsystem_Item',
				$oPropertyValue->value
			);

			if ($oItemFaq->name && $oItemFaq->active && !$oItemFaq->deleted) {
				$aData = $this->_infoCard($oItemFaq);
				$aData['sorting'] = $oPropertyValue->sorting;
				$aFaq[] = $aData;
			}
		}

		usort($aFaq, function ($a, $b) {
			return $a['sorting'] <=> $b['sorting'];
		});

		$oLink = [
			'href' => null,
			'title' => 'Подробнее',
		];

		$oProperty = Core_Entity::factory('Property', 29);
		$aPropertyValues = $oProperty->getValues($oEntity->id);
		if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
			$oLink['href'] = $aPropertyValues[0]->value;
		}

		$oProperty = Core_Entity::factory('Property', 30);
		$aPropertyValues = $oProperty->getValues($oEntity->id);
		if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
			$oLink['title'] = $aPropertyValues[0]->value;
		}

		// $aEntity['promo'] = $aPromo;

		$aReturn = [
			'id' => intval($oEntity->id),
			'name' => $oEntity->name,
			'description' => $oEntity->description,
			'group_id' => $oEntity->informationsystem_group_id,
			//'type' => $oShop_Item->type,
			'media' => $aMedia,
			'thumb' => $thumb,
			'slug' => $oEntity->path . '-' . $oEntity->id,
			'sorting' => intval($oEntity->sorting),
			'video' => $video,
			'faq' => $aFaq,
			'link' => $oLink,
		];

		return $aReturn;
	}

	protected function _groupCard($oEntity)
	{
		if (intval($oEntity->id) == 0) {
			return null;
		}

		$thumb = null;
		$aMedia = [];
		$aMediaPre = $this->_getMedia($oEntity);
		if (isset($aMediaPre['thumb'])) {
			$thumb = $aMediaPre['thumb'];
		}
		if (isset($aMediaPre['media'])) {
			$aMedia = $aMediaPre['media'];
		}

		$sTitle = $oEntity->name;
		$oProperty = Core_Entity::factory('Property', 10);
		$aPropertyValues = $oProperty->getValues($oEntity->id);
		if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
			$sTitle = $aPropertyValues[0]->value;
		}

		$aReturn = [
			'id' => intval($oEntity->id),
			'name' => $oEntity->name,
			'title' => $sTitle,
			'description' => $oEntity->description,
			'group_id' => $oEntity->parent_id,
			//'type' => $oShop_Item->type,
			'media' => $aMedia,
			'thumb' => $thumb,
			'slug' => $oEntity->path . '-' . $oEntity->id,
			'sorting' => intval($oEntity->sorting),

			'count' => [
				// 'subgroups_count' => $oEntity->subgroups_count,
				// 'subgroups_total_count' => $oEntity->subgroups_total_count,
				// 'items_count' => $oEntity->items_count,
				'items_total_count' => $oEntity->items_total_count,
			],
		];

		return $aReturn;
	}

	protected function info_list()
	{
		$is_list = intval(Core_Array::getGet('list', false));
		$oEntity = $this->_oInformationsystem;

		if ($oEntity->name) {
			$this->_prePagination();

			$items_sorting_direction =
				$oEntity->items_sorting_direction == 1 ? 'DESC' : 'ASC';
			$items_sorting_field = ($oEntity->items_sorting_field == 1
					? 'informationsystem_items.name'
					: $oEntity->items_sorting_field == 2)
				? 'informationsystem_items.sorting'
				: 'informationsystem_items.datetime';

			$iId = $oEntity->id;
			$sTitle = $oEntity->name;
			$sDescription = $oEntity->description;
			$sSlug = '/' . $this->_slug;

			$oEntityItems = $oEntity->Informationsystem_Items;

			if ($this->_group) {
				$oEntityItems = $this->_groupCondition($oEntityItems);
			}
			$oEntityItems = $this->_itemsCondition($oEntityItems);

			if (!$is_list) {
				$oEntityItems
					->queryBuilder()
					->limit($this->_limit)
					->offset($this->_offset);
			}

			$oEntityItems
				->queryBuilder()
				->clearOrderBy()
				->orderBy($items_sorting_field, $items_sorting_direction);

			// при выборе из всего магазина / инфо ярлыки не требуются, так как будут присутствовать оригинальные товары
			if (!$this->_group) {
				$oEntityItems = $this->_forbidSelectShortcuts($oEntityItems);
			} else {
			}

			$oEntityItems = $oEntityItems->findAll(false);
			$this->_total = Core_QueryBuilder::select()->getFoundRows();

			$aItems = [];
			$thumb = null;

			if ($is_list) {
				foreach ($oEntityItems as $oEntityItem) {
					// if ($oEntityItem->shortcut_id) {
					//   $oEntityItem = Core_Entity::factory(
					//     'Shop_Item',
					//     $oEntityItem->shortcut_id
					//   );
					// }

					if (!$oEntityItem->shortcut_id) {
						$aItems[] = $oEntityItem->path . '-' . $oEntityItem->id;
					}
				}

				$aGroupsPre = $this->_getGroups();
				$aGroups = [];
				foreach ($aGroupsPre as $item) {
					$aGroups[] = $item['slug'];
				}

				$this->_answer = [
					'groups' => $aGroups,
					'items' => $aItems,
				];
				return $this;
			}

			foreach ($oEntityItems as $oEntityItem) {
				if ($oEntityItem->shortcut_id) {
					$oEntityItem = Core_Entity::factory(
						'informationsystem_Item',
						$oEntityItem->shortcut_id
					);
				}

				$aItems[] = $this->_infoCard($oEntityItem, true);
			}

			$aSeo = $this->_getSeo($oEntity);

			if ($this->_group) {
				$oGroup = Core_Entity::factory(
					'informationsystem_Group',
					$this->_group
				);
				$iId = $oGroup->id;
				$sTitle = $oGroup->name;
				$sDescription = $oGroup->description;
				$sSlug = '/' . $this->_slug . '/' . $oGroup->path . '-' . $oGroup->id;

				if ($oGroup->image_small != '') {
					$thumb = $oGroup->getGroupHref() . $oGroup->image_small;
				}

				$aSeo = $this->_getSeo($oGroup);
			}

			$aEntity = [
				'id' => $iId,
				'name' => $sTitle,
				'description' => $sDescription,
				'slug' => $sSlug,
				'current' => intval($this->_group),
				'thumb' => $thumb,
				'seo' => $aSeo,
			];

			// Группы информационной системы
			$aGroups = $this->_getGroups();

			$aPagination = $this->_getPagination();

			$this->_answer = [
				//'000' => $this->_groupsMode,
				'entity' => $aEntity,
				'pagination' => $aPagination,
				'groups' => $aGroups,
				'items' => $aItems,
			];
		} else {
			$this->_error = sprintf('Path: "%s" Not Found', $this->path);
			$this->_statusCode = 404;
		}
	}

	protected function info_item($ItemSlug)
	{
		//$oEntity = Core_Entity::factory('informationsystem_Item', $ItemId);

		$aPath = $this->_parsePath($ItemSlug);
		if (
			$aPath &&
			isset($aPath['path']) &&
			$aPath['path'] != '' &&
			isset($aPath['id']) &&
			$aPath['id'] != 0
		) {
			$aEntity = $this->_oInformationsystem->Informationsystem_Items;
			$aEntity
				->queryBuilder()
				//->clear()
				->where(
					'path',
					'LIKE',
					Core_DataBase::instance()->escapeLike($aPath['path'])
				)
				->where('id', '=', $aPath['id'])
				->clearOrderBy()
				->limit(1);

			$aEntities = $aEntity->findAll(false);

			// echo Core_DataBase::instance()->getLastQuery();

			// foreach ($aEntities as $tmp) {
			//   var_dump($tmp->toArray());
			//   exit();
			// }

			$oEntity = isset($aEntities[0]) ? $aEntities[0] : null;

			if ($oEntity) {
				if ($oEntity->name && !$oEntity->deleted && $oEntity->active) {
					$thumb = null;
					$aMedia = [];
					$aMediaPre = $this->_getMedia($oEntity);
					if (isset($aMediaPre['thumb'])) {
						$thumb = $aMediaPre['thumb'];
					}
					if (isset($aMediaPre['media'])) {
						$aMedia = $aMediaPre['media'];
					}

					$aEntity = [
						'id' => intval($oEntity->id),
						'name' => $oEntity->name,
						'description' => $oEntity->description,
						'text' => $this->_makeShortcode($oEntity->text),
						'group_id' => $oEntity->informationsystem_group_id,
						'media' => $aMedia,
						'thumb' => $thumb,
						'slug' => $oEntity->path . '-' . $oEntity->id,
						'sorting' => intval($oEntity->sorting),
						//'del' => $oInformationsystem_Item->deleted,
						'seo' => $this->_getSeo($oEntity),
					];

					if (in_array('tags', $this->_oInfoDataAllowed)) {
						if (Core::moduleIsActive('tag')) {
							$aTags = [];
							if (Core::moduleIsActive('tag')) {
								$aTagsItems = $oEntity->Tags->findAll();
								foreach ($aTagsItems as $oTag) {
									$aTags[] = [
										'id' => $oTag->id,
										'name' => $oTag->name,
										'slug' => $oTag->path . '-' . $oTag->id,
									];
								}
							}
							$aEntity['tags'] = $aTags;
						}
					}

					if (in_array('shop_items', $this->_oInfoDataAllowed)) {
						$aShopItems = [];
						$oProperty = Core_Entity::factory('Property', 4);
						$aPropertyValues = $oProperty->getValues($oEntity->id);
						foreach ($aPropertyValues as $oPropertyValue) {
							if ($oPropertyValue && $oPropertyValue->value) {
								$oShop_Item = Core_Entity::factory(
									'Shop_Item',
									$oPropertyValue->value
								);

								if ($oShop_Item->name && $oShop_Item->active) {
									$aData = $this->_shopCard($oShop_Item);
									$aData['sorting'] = $oPropertyValue->sorting;

									$aShopItems[] = $aData;
								}
							}
						}

						$aEntity['shop_items'] = $aShopItems;
					}

					$this->_answer['group'] = $this->_groupCard(
						$oEntity->Informationsystem_Group
					);

					$this->_answer['entity'] = $aEntity;
				} else {
					$this->_error = sprintf('Path: "%s" Not Found', $this->path);
					$this->_statusCode = 404;
				}
			} else {
				$this->_error = sprintf('Path: "%s" Not Found', $this->path);
				$this->_statusCode = 404;
			}
		} else {
			$this->_error = sprintf('Path: "%s" Not Found', $this->path);
			$this->_statusCode = 404;
		}
	}

	protected function _getPrice($oEntity)
	{
		$oShop_Item_Controller = new Shop_Item_Controller();
		$aPrices = $oShop_Item_Controller->getPrices($oEntity);
		$currency = '';
		if ($oEntity->shop_currency_id) {
			$oShopCurrency = $oEntity->Shop->Shop_Currency;
			$currency = $oShopCurrency->sign;
		}

		$oShop_Controller = Shop_Controller::instance();
		$discount_percent =
			floatval($oEntity->price) > 0
				? $oShop_Controller->round(
					((floatval($oEntity->price) - $aPrices['price_discount']) * 100) /
						floatval($oEntity->price)
				)
				: 0;

		return [
			'current' => $oShop_Controller->round($aPrices['price_discount']),
			'old' => $oShop_Controller->round(floatval($oEntity->price)),
			'discount' => $oShop_Controller->round(
				floatval($oEntity->price) - $aPrices['price_discount']
			),
			'discount_percent' => $discount_percent,
			'currency' => $currency,
		];
	}

	protected function _shopCard($oEntity)
	{
		$thumb = null;
		$aMedia = [];
		$aMediaPre = $this->_getMedia($oEntity);
		if (isset($aMediaPre['thumb'])) {
			$thumb = $aMediaPre['thumb'];
		}
		if (isset($aMediaPre['media'])) {
			$aMedia = $aMediaPre['media'];
		}

		$aLabelsVals = [];
		$aLabels = [];
		$propId = 8;
		$oProperty = Core_Entity::factory('Property', $propId);
		$aPropertyValues = $oProperty->getValues($oEntity->id);

		foreach ($aPropertyValues as $oPropertyValue) {
			$aLabelsVals[$oPropertyValue->value] = [
				'value' => $oPropertyValue->value,
				'sorting' => $oPropertyValue->sorting,
			];
		}

		if (count($aLabelsVals)) {
			$oQueryBuilderSelect = Core_QueryBuilder::select();
			$oQueryBuilderSelect
				->select('list_items.*')
				->from('property_value_ints')
				->leftJoin(
					'list_items',
					'property_value_ints.value',
					'=',
					'list_items.id'
				)
				->where('list_items.active', '=', 1)
				->where('list_items.deleted', '=', 0)
				->where('property_value_ints.property_id', '=', $propId)
				->where('property_value_ints.entity_id', '=', $oEntity->id);

			$aResult = $oQueryBuilderSelect
				->execute()
				->asAssoc()
				->result();

			if (count($aResult)) {
				foreach ($aResult as $item) {
					# code...

					if (isset($aLabelsVals[$item['id']])) {
						$aLabels[] = [
							'name' => $item['value'],
							'sorting' => $aLabelsVals[$item['id']]['sorting'],
							'color' => $item['color'],
							'icon' => $item['icon'],
						];
					}
				}
			}
		}

		$aEntity['labels'] = $aLabels;

		return [
			'id' => intval($oEntity->id),
			'name' => $oEntity->name,
			'marking' => $oEntity->marking,
			'description' => $oEntity->description,
			'group_id' => $oEntity->shop_group_id,
			'group_name' => $oEntity->Shop_Group->name,
			//'type' => $oShop_Item->type,
			'media' => $aMedia,
			'thumb' => $thumb,
			'slug' => $oEntity->path . '-' . $oEntity->id,
			'sorting' => intval($oEntity->sorting),
			'rest' => intval($oEntity->getRest()),
			'min_rest_add' => $this->minRest,
			'price' => $this->_getPrice($oEntity),
			'labels' => $aLabels,
			//'shop_items' => $aShopItems,
		];
	}

	protected function export_shop()
	{
		$oEntity = $this->_oShop;
		if ($oEntity->name) {
			$oEntityItems = $oEntity->Shop_Items;

			$oEntityItems
				->queryBuilder()
				->where('shop_items.shop_item_type_id', '=', 1)
				->where('shop_items.shortcut_id', '=', 0);

			$oEntityItems = $oEntityItems->findAll(false);

			$aItems = [];

			foreach ($oEntityItems as $oEntity) {
				$media = null;
				if ($oEntity->image_small != '') {
					$href = $oEntity->getItemHref();
					$url = $href . $oEntity->image_small;
					$media = $url;

					$aItems[] = [
						'id' => intval($oEntity->id),
						'guid' => $oEntity->guid,
						'name' => $oEntity->name,
						'marking' => $oEntity->marking,
						'media' => $media,
						'price' => floatval($oEntity->price),
					];
				}
			}

			$this->_answer = [
				'items' => $aItems,
			];
			//return $this;

			// $oEntityItems
			//   ->queryBuilder()
			//   ->clearOrderBy()
			//   ->orderBy($items_sorting_field, $items_sorting_direction);
		} else {
			$this->_error = sprintf('Path: "%s" Not Found', $this->path);
			$this->_statusCode = 404;
		}
	}

	protected function shop_list()
	{
		$is_list = intval(Core_Array::getGet('list', false));
		$is_popular = intval(Core_Array::getGet('popular', false));
		$is_search = trim(strval(Core_Array::getGet('search', false)));
		$is_fav = Core_Array::getGet('fav', false);
		$oEntity = $this->_oShop;

		$aListFav = $is_fav ? explode(',', $is_fav) : [];

		if ($oEntity->name) {
			//$aQuery = [];
			$this->_prePagination();

			$items_sorting_direction =
				$oEntity->items_sorting_direction == 1 ? 'DESC' : 'ASC';
			$items_sorting_field = ($oEntity->items_sorting_field == 1
					? 'shop_items.name'
					: $oEntity->items_sorting_field == 2)
				? 'shop_items.sorting'
				: 'shop_items.datetime';

			$iId = $oEntity->id;
			$sTitle = $oEntity->name;
			$sDescription = $oEntity->description;
			$sSlug = '/' . $this->_slug;

			$oEntityItems = $oEntity->Shop_Items;

			if ($is_popular) {
				$oPopularConst = Core_Entity::factory('Constant')->getByName(
					'SHOP_POPULAR'
				);
				$aPopular = $oPopularConst ? explode(',', $oPopularConst->value) : [];
				$oEntityItems->queryBuilder()->where('shop_items.id', 'IN', $aPopular);
			} elseif ($aListFav) {
				// var_dump($aListFav);
				// exit();
				$oEntityItems->queryBuilder()->where('shop_items.id', 'IN', $aListFav);
			} else {
				if ($this->_group) {
					$oEntityItems = $this->_groupCondition($oEntityItems);
				}
			}

			$oEntityItems = $this->_itemsCondition($oEntityItems);

			if (!$is_list) {
				$oEntityItems
					->queryBuilder()
					->limit($this->_limit)
					->offset($this->_offset);
			}

			$oEntityItems->queryBuilder()->clearOrderBy();
			$oEntityItems = $this->_itemsAviableOrder($oEntityItems);
			$oEntityItems
				->queryBuilder()
				->orderBy($items_sorting_field, $items_sorting_direction);

			// if ($is_group) {
			//   $oEntityItems
			//     ->queryBuilder()
			//     ->where(
			//       'informationsystem_items.informationsystem_group_id',
			//       '=',
			//       $is_group
			//     );
			// } else {
			//   $oEntityItems
			//     ->queryBuilder()
			//     ->where('informationsystem_items.informationsystem_group_id', '=', 0);
			// }

			// при выборе из всего магазина / инфо ярлыки не требуются, так как будут присутствовать оригинальные товары
			if (!$this->_group) {
				$oEntityItems = $this->_forbidSelectShortcuts($oEntityItems);
			}

			// оганичение по наличию
			//$oEntityItems = $this->_applyWarehouseConditions($oEntityItems);

			// группировка ярлыков
			$oEntityItems = $this->_groupShortcuts($oEntityItems);

			if (strlen($is_search) > 2) {
				$oEntityItems
					->queryBuilder()
					->open()
					->where('shop_items.name', 'LIKE', '%' . $is_search . '%')
					->setOr()
					->where('shop_items.marking', 'LIKE', '%' . $is_search . '%')
					->close();
			}

			//$oEntityItems = $this->_itemsPriceCondition($oEntityItems);

			//$aQuery[] = Core_DataBase::instance()->getLastQuery();

			$oEntityItems = $oEntityItems->findAll(false);
			//$aQuery[] = Core_DataBase::instance()->getLastQuery();

			// var_dump($this->_subgroupsAll);
			// var_dump(Core_DataBase::instance()->getLastQuery());
			// exit();
			$this->_total = Core_QueryBuilder::select()->getFoundRows();
			//$aQuery[] = Core_DataBase::instance()->getLastQuery();

			$aItems = [];
			$thumb = null;
			$aMedia = [];

			if ($is_list) {
				foreach ($oEntityItems as $oEntityItem) {
					// if ($oEntityItem->shortcut_id) {
					//   $oEntityItem = Core_Entity::factory(
					//     'Shop_Item',
					//     $oEntityItem->shortcut_id
					//   );
					// }

					if (!$oEntityItem->shortcut_id) {
						$aItems[] = $oEntityItem->path . '-' . $oEntityItem->id;
					}
				}

				$aGroupsPre = $this->_getGroups();
				$aGroups = [];
				foreach ($aGroupsPre as $item) {
					$aGroups[] = $item['slug'];
				}

				$this->_answer = [
					'groups' => $aGroups,
					'items' => $aItems,
				];
				return $this;
			}

			foreach ($oEntityItems as $oEntityItem) {
				if ($oEntityItem->shortcut_id) {
					$oEntityItem = Core_Entity::factory(
						'Shop_Item',
						$oEntityItem->shortcut_id
					);
				}

				if ($oEntityItem->active && !$oEntityItem->deleted) {
					$aItems[] = $this->_shopCard($oEntityItem, true);
				}
			}

			$oEntityTmp = $oEntity;

			$sTitleT = $oEntity->name;

			if ($this->_group) {
				$oGroup = Core_Entity::factory('Shop_Group', $this->_group);
				$oEntityTmp = $oGroup;
				$iId = $oGroup->id;
				$sTitle = $sTitleT = $oGroup->name;
				$sDescription = $oGroup->description;
				$sSlug = '/' . $this->_slug . '/' . $oGroup->path . '-' . $oGroup->id;

				$this->_oInfoDataAllowed = ['media'];

				$thumb = null;
				$aMedia = [];
				$aMediaPre = $this->_getMedia($oGroup);
				if (isset($aMediaPre['thumb'])) {
					$thumb = $aMediaPre['thumb'];
				}
				if (isset($aMediaPre['media'])) {
					$aMedia = $aMediaPre['media'];
				}

				$oProperty = Core_Entity::factory('Property', 10);
				$aPropertyValues = $oProperty->getValues($oGroup->id);
				if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
					$sTitleT = $aPropertyValues[0]->value;
				}
			}

			$aEntity = [
				'id' => $iId,
				'name' => $sTitle,
				'title' => $sTitleT,
				'description' => $sDescription,
				'slug' => $sSlug,
				'current' => intval($this->_group),
				'thumb' => $thumb,
				'media' => $aMedia,
				'seo' => $this->_getSeo($oEntityTmp),
			];

			// Группы информационной системы
			$aGroups = [];
			if (!$is_popular && !$aListFav && !strlen($is_search)) {
				$aGroups = $this->_getGroups();
			}
			//$aGroups = [];

			$aPagination = $this->_getPagination();

			$this->_answer = [
				//'aQuery' => $aQuery,
				'search' => strlen($is_search) > 2 ? $is_search : null,
				'entity' => $aEntity,
				'pagination' => $aPagination,
				'groups' => $aGroups,
				'items' => $aItems,
			];
		} else {
			$this->_error = sprintf('Path: "%s" Not Found', $this->path);
			$this->_statusCode = 404;
		}
	}

	protected function shop_item($ItemSlug)
	{
		//$oEntity = $this->_oShop->Shop_Items->find($ItemId);

		$aPath = $this->_parsePath($ItemSlug);
		if (
			$aPath &&
			isset($aPath['path']) &&
			$aPath['path'] != '' &&
			isset($aPath['id']) &&
			$aPath['id'] != 0
		) {
			$aEntity = $this->_oShop->Shop_Items;
			$aEntity
				->queryBuilder()
				//->clear()
				->where(
					'path',
					'LIKE',
					Core_DataBase::instance()->escapeLike($aPath['path'])
				)
				->where('id', '=', $aPath['id'])
				->clearOrderBy()
				->limit(1);

			$aEntities = $aEntity->findAll(false);

			// echo Core_DataBase::instance()->getLastQuery();

			// foreach ($aEntities as $tmp) {
			//   var_dump($tmp->toArray());
			//   exit();
			// }

			$oEntity = isset($aEntities[0]) ? $aEntities[0] : null;

			if ($oEntity) {
				if ($oEntity->name && !$oEntity->deleted && $oEntity->active) {
					$thumb = null;
					$aMedia = [];
					$aMediaPre = $this->_getMedia($oEntity);
					if (isset($aMediaPre['thumb'])) {
						$thumb = $aMediaPre['thumb'];
					}
					if (isset($aMediaPre['media'])) {
						$aMedia = $aMediaPre['media'];
					}

					$oShop_Item_Controller = new Shop_Item_Controller();
					$aPrices = $oShop_Item_Controller->getPrices($oEntity);
					$currency = '';
					if ($oEntity->shop_currency_id) {
						$oShopCurrency = $oEntity->Shop->Shop_Currency;
						$currency = $oShopCurrency->sign;
					}
					$oShop_Controller = Shop_Controller::instance();
					$discount_percent =
						floatval($oEntity->price) > 0
							? $oShop_Controller->round(
								((floatval($oEntity->price) - $aPrices['price_discount']) *
									100) /
									floatval($oEntity->price)
							)
							: 0;

					$aEntity = [
						'id' => intval($oEntity->id),
						'name' => $oEntity->name,
						'marking' => $oEntity->marking,
						'type' => $oEntity->type,
						'description' => $oEntity->description,
						'text' => $this->_makeShortcode($oEntity->text),
						'group_id' => $oEntity->shop_group_id,
						'group_name' => $oEntity->Shop_Group->name,
						'media' => $aMedia,
						'thumb' => $thumb,
						'slug' => $oEntity->path . '-' . $oEntity->id,
						'sorting' => intval($oEntity->sorting),
						'rest' => intval($oEntity->getRest()),
						'min_rest_add' => $this->minRest,
						//'del' => $oInformationsystem_Item->deleted,
						'seo' => $this->_getSeo($oEntity),
						'weight' => [
							'value' => floatval($oEntity->weight),
							'measure' => $this->_oShop->Shop_Measure->name,
						],

						'price' => $this->_getPrice($oEntity),
					];

					if (in_array('labels', $this->_oInfoDataAllowed)) {
						$aLabelsVals = [];
						$aLabels = [];
						$propId = 8;
						$oProperty = Core_Entity::factory('Property', $propId);
						$aPropertyValues = $oProperty->getValues($oEntity->id);

						foreach ($aPropertyValues as $oPropertyValue) {
							$aLabelsVals[$oPropertyValue->value] = [
								'value' => $oPropertyValue->value,
								'sorting' => $oPropertyValue->sorting,
							];
						}

						if (count($aLabelsVals)) {
							$oQueryBuilderSelect = Core_QueryBuilder::select();
							$oQueryBuilderSelect
								->select('list_items.*')
								->from('property_value_ints')
								->leftJoin(
									'list_items',
									'property_value_ints.value',
									'=',
									'list_items.id'
								)
								->where('list_items.active', '=', 1)
								->where('list_items.deleted', '=', 0)
								->where('property_value_ints.property_id', '=', $propId)
								->where('property_value_ints.entity_id', '=', $oEntity->id);

							$aResult = $oQueryBuilderSelect
								->execute()
								->asAssoc()
								->result();

							if (count($aResult)) {
								foreach ($aResult as $item) {
									# code...

									if (isset($aLabelsVals[$item['id']])) {
										$aLabels[] = [
											'name' => $item['value'],
											'sorting' => $aLabelsVals[$item['id']]['sorting'],
											'color' => $item['color'],
											'icon' => $item['icon'],
										];
									}
								}
							}
						}

						$aEntity['labels'] = $aLabels;
					}
					if (in_array('volume', $this->_oInfoDataAllowed)) {
						$iVolume = [
							'value' => 0,
							'measure' => 'мл',
						];

						$oProperty = Core_Entity::factory('Property', 7);
						$aPropertyValues = $oProperty->getValues($oEntity->id);

						if (isset($aPropertyValues[0])) {
							$iVolume = [
								'value' => floatval($aPropertyValues[0]->value),
								'measure' => 'мл',
							];
						}

						$aEntity['volume'] = $iVolume;
					}
					if (in_array('instruction', $this->_oInfoDataAllowed)) {
						$sInstruction = '';

						$oProperty = Core_Entity::factory('Property', 1);
						$aPropertyValues = $oProperty->getValues($oEntity->id);

						if (isset($aPropertyValues[0])) {
							$sInstruction = $aPropertyValues[0]->value;
						}

						$aEntity['instruction'] = $sInstruction;
					}

					if (in_array('sostav', $this->_oInfoDataAllowed)) {
						$sSostav = '';

						$oProperty = Core_Entity::factory('Property', 14);
						$aPropertyValues = $oProperty->getValues($oEntity->id);

						if (isset($aPropertyValues[0])) {
							$sSostav = $aPropertyValues[0]->value;
						}

						$aEntity['sostav'] = $sSostav;
					}

					if (in_array('for', $this->_oInfoDataAllowed)) {
						$sFor = '';

						$oProperty = Core_Entity::factory('Property', 18);
						$aPropertyValues = $oProperty->getValues($oEntity->id);

						if (isset($aPropertyValues[0])) {
							$sFor = $aPropertyValues[0]->value;
						}

						$aEntity['for'] = $sFor;
					}

					if (in_array('certs', $this->_oInfoDataAllowed)) {
						$aCert = [];

						$oProperty = Core_Entity::factory('Property', 11);
						$aPropertyValues = $oProperty->getValues($oEntity->id);

						foreach ($aPropertyValues as $oPropertyValue) {
							$oItemFaq = Core_Entity::factory(
								'Informationsystem_Item',
								$oPropertyValue->value
							);

							if ($oItemFaq->name && $oItemFaq->active && !$oItemFaq->deleted) {
								$aData = $this->_infoCard($oItemFaq);
								$aData['sorting'] = $oPropertyValue->sorting;

								$aCert[] = $aData;
							}
						}

						usort($aCert, function ($a, $b) {
							return $a['sorting'] <=> $b['sorting'];
						});

						$aEntity['cert'] = $aCert;
					}

					if (in_array('plus', $this->_oInfoDataAllowed)) {
						$aPlus = [];

						$oProperty = Core_Entity::factory('Property', 17);
						$aPropertyValues = $oProperty->getValues($oEntity->id);

						foreach ($aPropertyValues as $oPropertyValue) {
							$oItemFaq = Core_Entity::factory(
								'Informationsystem_Item',
								$oPropertyValue->value
							);

							if ($oItemFaq->name && $oItemFaq->active && !$oItemFaq->deleted) {
								$aData = $this->_infoCard($oItemFaq);
								$aData['sorting'] = $oPropertyValue->sorting;

								$aPlus[] = $aData;
							}
						}

						usort($aPlus, function ($a, $b) {
							return $a['sorting'] <=> $b['sorting'];
						});

						$aEntity['plus'] = $aPlus;
					}

					if (in_array('faq', $this->_oInfoDataAllowed)) {
						$aFaq = [];

						$oProperty = Core_Entity::factory('Property', 2);
						$aPropertyValues = $oProperty->getValues($oEntity->id);

						foreach ($aPropertyValues as $oPropertyValue) {
							$oItemFaq = Core_Entity::factory(
								'Informationsystem_Item',
								$oPropertyValue->value
							);

							if ($oItemFaq->name && $oItemFaq->active && !$oItemFaq->deleted) {
								$aData = $this->_infoCard($oItemFaq);
								$aData['sorting'] = $oPropertyValue->sorting;
								$aFaq[] = $aData;
							}
						}

						usort($aFaq, function ($a, $b) {
							return $a['sorting'] <=> $b['sorting'];
						});

						$aEntity['faq'] = $aFaq;
					}

					if (in_array('promo', $this->_oInfoDataAllowed)) {
						$aPromo = [];

						$oProperty = Core_Entity::factory('Property', 9);
						$aPropertyValues = $oProperty->getValues($oEntity->id);

						foreach ($aPropertyValues as $oPropertyValue) {
							$oItemFaq = Core_Entity::factory(
								'Informationsystem_Item',
								$oPropertyValue->value
							);

							if ($oItemFaq->name && $oItemFaq->active && !$oItemFaq->deleted) {
								$aData = $this->_promoCard($oItemFaq);
								$aData['sorting'] = $oPropertyValue->sorting;

								$aPromo[] = $aData;
							}
						}

						usort($aPromo, function ($a, $b) {
							return $a['sorting'] <=> $b['sorting'];
						});

						$aEntity['promo'] = $aPromo;
					}

					$gradeSum = $gradeCount = 0;
					if (in_array('comments', $this->_oInfoDataAllowed)) {
						$gradeSum = $gradeCount = $gradeCount = $avgGrade = 0;
						//$this->Comments
						$aCommentsList = [];

						$oComments = $oEntity->Comments;
						$oComments
							->queryBuilder()
							->where('active', '=', 1)
							->where('deleted', '=', 0)
							->where('parent_id', '=', 0)
							->orderBy('datetime', 'DESC');

						$aComments = $oComments->findAll();
						$i = 0;
						foreach ($aComments as $oComment) {
							if ($oComment->grade > 0) {
								$gradeSum += $oComment->grade;
								$gradeCount++;
							}

							if ($i < 4) {
								$aCommentsList[] = $this->_commentCard($oComment);
							}

							$i++;
						}

						//$aEntity['comments']['sorting'] = [];

						$aEntity['comments']['list'] = $aCommentsList;

						// Средняя оценка
						$avgGrade = $gradeCount > 0 ? $gradeSum / $gradeCount : 0;

						$avgGrade = round($avgGrade, 1, PHP_ROUND_HALF_UP);
						if ($avgGrade < 1) {
							$avgGrade = 0;
						}

						// $fractionalPart = $avgGrade - floor($avgGrade);
						// $avgGrade = floor($avgGrade);

						// if ($fractionalPart >= 0.25 && $fractionalPart < 0.75) {
						//   $avgGrade += 0.5;
						// } elseif ($fractionalPart >= 0.75) {
						//   $avgGrade += 1;
						// }

						// if (floatval($gradeSum) / floatval($gradeCount) >= 1) {
						//   $newRate = round(
						//     floatval($gradeSum) / floatval($gradeCount),
						//     1,
						//     PHP_ROUND_HALF_UP
						//   );
						// }

						$aEntity['comments']['rate'] = [
							'comments_count' => count($aComments),
							'comments_grade_sum' => $gradeSum,
							'comments_grade_count' => $gradeCount,
							'comments_average_grade' => $avgGrade,
							//'comments_average_grade' => $$newRate,
						];
					}

					if (in_array('rate', $this->_oInfoDataAllowed)) {
						$gradeSum = $gradeCount = $gradeCount = $avgGrade = 0;

						$oComments = $oEntity->Comments;
						$oComments
							->queryBuilder()
							->where('active', '=', 1)
							->where('deleted', '=', 0)
							->where('parent_id', '=', 0)
							->orderBy('datetime', 'DESC');

						$aComments = $oComments->findAll();
						foreach ($aComments as $oComment) {
							if ($oComment->grade > 0) {
								$gradeSum += $oComment->grade;
								$gradeCount++;
							}
						}

						// Средняя оценка
						$avgGrade = $gradeCount > 0 ? $gradeSum / $gradeCount : 0;

						$fractionalPart = $avgGrade - floor($avgGrade);
						$avgGrade = floor($avgGrade);

						if ($fractionalPart >= 0.25 && $fractionalPart < 0.75) {
							$avgGrade += 0.5;
						} elseif ($fractionalPart >= 0.75) {
							$avgGrade += 1;
						}

						$aEntity['rate'] = [
							'comments_count' => count($aComments),
							'comments_grade_sum' => $gradeSum,
							'comments_grade_count' => $gradeCount,
							'comments_average_grade' => $avgGrade,
						];
					}

					// if (in_array('same', $this->_oInfoDataAllowed)) {
					//   $aSame = [];

					//   $oGroup = $oEntity->Shop_Group;
					//   $oSameItem = $this->_oShop->Shop_Items;
					//   $oSameItem
					//     ->queryBuilder()
					//     ->where('id', '!=', $oEntity->id)
					//     ->where('shop_group_id', '=', $oGroup->id)
					//     ->where('active', '=', 1)
					//     ->where('deleted', '=', 0)
					//     ->limit(10);

					//   $aSameItems = $oSameItem->findAll();

					//   foreach ($aSameItems as $oSameItem) {
					//     $aSame[] = $this->_shopCard($oSameItem);
					//   }

					//   $aEntity['same'] = $aSame;
					// }

					if (
						in_array('recommendation', $this->_oInfoDataAllowed) &&
						$oEntity->type != 3
					) {
						$aRec = [];
						//$aEntity['recommendation'] = null;

						$oProperty = Core_Entity::factory('Property', 28);
						$aPropertyValues = $oProperty->getValues($oEntity->id);
						foreach ($aPropertyValues as $oPropertyValue) {
							$oItemRec = Core_Entity::factory(
								'Shop_Item',
								$oPropertyValue->value
							);

							//$aRec[] = $oPropertyValue->value;

							if ($oItemRec->name && $oItemRec->active && !$oItemRec->deleted) {
								$aData = $this->_shopCard($oItemRec);
								$aData['sorting'] = $oPropertyValue->sorting;

								$aRec[] = $aData;
							}
						}

						usort($aRec, function ($a, $b) {
							return $a['sorting'] <=> $b['sorting'];
						});

						if (!count($aRec)) {
							// same
							$oGroup = $oEntity->Shop_Group;
							$oSameItem = $this->_oShop->Shop_Items;

							if ($this->_oShop && $this->_oShop->filter) {
								$table = 'shop_filter' . $this->_oShop->id;

								$oSameItem
									->queryBuilder()
									->select('shop_items.*')
									->leftJoin(
										$table,
										'shop_items.id',
										'=',
										$table . '.shop_item_id'
									)
									->orderBy($table . '.available', 'DESC');
							}

							$oSameItem
								->queryBuilder()
								->where('shop_items.id', '!=', $oEntity->id)
								->where('shop_items.shop_group_id', '=', $oGroup->id)
								->where('shop_items.shortcut_id', '=', 0)
								->where('shop_items.active', '=', 1)
								->where('shop_items.deleted', '=', 0)
								->limit(10);

							$aSameItems = $oSameItem->findAll();

							foreach ($aSameItems as $oSameItem) {
								$aRec[] = $this->_shopCard($oSameItem);
							}
						}

						//$aEntity['recommendation'] = count($aPropertyValues);

						$aEntity['recommendation'] = $aRec;
					}

					if (in_array('bottom_recommendation', $this->_oInfoDataAllowed)) {
						$aRecBottom = [];
						//$aEntity['recommendation'] = null;

						$oProperty = Core_Entity::factory('Property', 31);
						$aPropertyValues = $oProperty->getValues($oEntity->id);
						foreach ($aPropertyValues as $oPropertyValue) {
							$oItemRec = Core_Entity::factory(
								'Shop_Item',
								$oPropertyValue->value
							);

							//$aRec[] = $oPropertyValue->value;

							if ($oItemRec->name && $oItemRec->active && !$oItemRec->deleted) {
								$aData = $this->_shopCard($oItemRec);
								$aData['sorting'] = $oPropertyValue->sorting;

								$aRecBottom[] = $aData;
							}
						}

						usort($aRecBottom, function ($a, $b) {
							return $a['sorting'] <=> $b['sorting'];
						});

						$aEntity['bottom_recommendation'] = $aRecBottom;
					}

					// Набор
					if ($oEntity->type == 3) {
						$aSet = [];
						$aShop_Item_Sets = $oEntity->Shop_Item_Sets->findAll(false);
						foreach ($aShop_Item_Sets as $oItemSet) {
							$oTmp_Shop_Item = Core_Entity::factory(
								'Shop_Item',
								$oItemSet->shop_item_set_id
							);

							if (
								$oTmp_Shop_Item->name &&
								$oTmp_Shop_Item->active &&
								!$oTmp_Shop_Item->deleted
							) {
								$aData = $this->_shopCard($oTmp_Shop_Item);

								$aSet[] = $aData;
							}
						}
						$aEntity['set'] = $aSet;
					}

					$aGroups = [$this->_groupCard($oEntity->Shop_Group)];

					if ($oEntity->Shop_Group->parent_id) {
						$oShop_Group_Parent = Core_Entity::factory(
							'Shop_Group',
							$oEntity->Shop_Group->parent_id
						);
						$aGroups[] = $this->_groupCard($oShop_Group_Parent);
					}

					$this->_answer['groups'] = $aGroups;

					$this->_answer['entity'] = $aEntity;
				}
			} else {
				$this->_error = sprintf('Path: "%s" Not Found', $this->path);
				$this->_statusCode = 404;
			}
		} else {
			$this->_error = sprintf('Path: "%s" Not Found', $this->path);
			$this->_statusCode = 404;
		}
	}

	protected function _getRest($id)
	{
		$queryBuilder = Core_QueryBuilder::select(['SUM(count)', 'count'])
			->from('shop_warehouse_items')
			->join(
				'shop_warehouses',
				'shop_warehouses.id',
				'=',
				'shop_warehouse_items.shop_warehouse_id'
			)
			->where('shop_warehouse_items.shop_item_id', '=', $id)
			->where('shop_warehouses.active', '=', 1)
			->where('shop_warehouses.deleted', '=', 0);
		$aResult = $queryBuilder
			->execute()
			->asAssoc()
			->current();
		return intval($aResult['count']);
	}

	protected function _countRest($array)
	{
		$aCount = [];
		foreach ($array as $item) {
			$aCount[$item] = $this->_getRest($item);
		}
		asort($aCount);
		return $aCount;
	}

	protected function _updateSets()
	{
		// находим все комплекты
		$oQueryBuilderSelect = Core_QueryBuilder::select(
			'id',
			'shop_item_id',
			'shop_item_set_id'
		)->from('shop_item_sets');

		$aResult = $oQueryBuilderSelect
			->execute()
			->asAssoc()
			->result();

		$aSets = [];
		$aRemove = [];

		if (count($aResult)) {
			foreach ($aResult as $item) {
				$aRemove[] = $item['shop_item_id'];
				$aSets[$item['shop_item_id']][] = $item['shop_item_set_id'];
			}
		}

		// Чистим наличие у комплектов
		if (count($aRemove)) {
			Core_QueryBuilder::delete('shop_warehouse_items')
				->lowPriority()
				->quick()
				->ignore()
				->where('shop_item_id', 'IN', $aRemove)
				->execute();
		}

		// устанавливаем количество
		if (count($aSets)) {
			foreach ($aSets as $item_id => $array) {
				$aRest = $this->_countRest($array);
				//$aRest['total'] = 0;

				// по наименьшему из комплекта
				// если есть хотябы один товар
				$firstVal = array_values($aRest)[0];
				if ($firstVal != 0) {
					//$i++;

					//$aRest['total'] = $firstVal;

					Core_QueryBuilder::insert('shop_warehouse_items', [
						'shop_warehouse_id' => 2, // Наборы
						'shop_item_id' => $item_id,
						'count' => intval($firstVal),
						'user_id' => $this->_user ? $this->_user->id : 0,
					])->execute();
				}

				//$aResult[$item_id] = $aRest;

				// if (countRest($array)) {
				//   echo_r($item_id . ' есть');
				// } else {
				//   echo_r($item_id . ' нет');
				// }
			}
		}
	}

	protected function _updateFilters($oShop)
	{
		if ($oShop && $oShop->filter) {
			// Groups
			$Shop_Filter_Group_Controller = new Shop_Filter_Group_Controller($oShop);
			$Shop_Filter_Group_Controller
				->dropTable()
				->createTable()
				->rebuild();

			// Items
			$oShop_Filter_Controller = new Shop_Filter_Controller($oShop);
			$oShop_Filter_Controller->dropTable()->createTable();

			$limit = 1000;
			$position = 0;

			do {
				$oShop_Items = $oShop->Shop_Items;
				$oShop_Items
					->queryBuilder()
					->where('shop_items.active', '=', 1)
					->limit($limit)
					->offset($position)
					->clearOrderBy()
					->orderBy('shop_items.id');

				$aShop_Items = $oShop_Items->findAll(false);

				foreach ($aShop_Items as $oShop_Item) {
					$oShop_Filter_Controller->fill($oShop_Item);
				}

				$position += $limit;
			} while (count($aShop_Items));
		}
	}

	protected function import_shop()
	{
		$token = isset($this->_request['token']) ? $this->_request['token'] : null;

		if ($token) {
			$this->_tokenCMSAuth($token);

			if (!is_null($this->_user)) {
				$aItems = isset($this->_request['items'])
					? $this->_request['items']
					: null;

				if ($aItems && count($aItems)) {
					$aNotFound = [];
					$i = 0;

					//$aQuery = [];
					foreach ($aItems as $item) {
						if (isset($item['marking'])) {
							$oShop_Item = Core_Entity::factory('Shop_Item')->getByMarking(
								strval($item['marking'])
							);

							if ($oShop_Item) {
								// GUID
								isset($item['guid']) &&
									($oShop_Item->guid = strval($item['guid']));

								// price
								// isset($item['price']) &&
								//   ($oShop_Item->price = floatval($item['price']));

								// active
								// isset($item['active']) &&
								//   ($oShop_Item->active = intval($item['active']));

								$oShop_Item->save();

								//$aQuery[$i][] = 'save';
								//$aQuery[$i][] = isset($item['warehouse']);
								//$aQuery[$i][] = is_array($item['warehouse']);

								if (isset($item['warehouse']) && is_array($item['warehouse'])) {
									foreach ($item['warehouse'] as $warehouse_item) {
										if (isset($warehouse_item['guid'])) {
											$oShop_Warehouse = Core_Entity::factory(
												'Shop_Warehouse'
											)->getByGuid(strval($warehouse_item['guid']));

											//$aQuery[$i][] = $warehouse_item['guid'];
											//$aQuery[$i][] = $oShop_Warehouse->toArray();

											if ($oShop_Warehouse) {
												// delete old

												//$aQuery[] = $warehouse_item['count'];

												Core_QueryBuilder::delete('shop_warehouse_items')
													->lowPriority()
													->quick()
													->ignore()
													->where(
														'shop_warehouse_id',
														'=',
														$oShop_Warehouse->id
													)
													->where('shop_item_id', '=', $oShop_Item->id)
													->execute();

												//$aQuery[$i][] = 'delete';

												// insert new
												Core_QueryBuilder::insert('shop_warehouse_items', [
													'shop_warehouse_id' => $oShop_Warehouse->id,
													'shop_item_id' => $oShop_Item->id,
													'count' => intval($warehouse_item['count']),
													'user_id' => $this->_user->id,
												])->execute();

												// $aQuery[
												//   $i
												// ][] = Core_DataBase::instance()->getLastQuery();

												// $aQuery[$i][] = 'insert';
											}
										}
									}
								}

								$i++;
							} else {
								$aNotFound[] = $item['marking'];
							}
						}
					}

					// обновляем данные по комплектам
					$this->_updateSets();

					// пересчитываем магазин
					if ($this->_oShop && $this->_oShop->filter) {
						$this->_updateFilters($this->_oShop);
					}

					// чистим кэш
					if (Core::moduleIsActive('cache')) {
						Core_Cache::instance(Core::$mainConfig['defaultCache'])->deleteAll(
							$this->_cacheName
						);
					}

					$this->_answer = [
						//'query' => $aQuery,
						'count_input' => count($aItems),
						'count_updated' => $i,
						'not_found' => $aNotFound,
					];
				} else {
					$this->_error = 'Wrong POST data';
					$this->_statusCode = 422;
					return false;
				}
			} else {
				$this->_error = 'Authentication Required';
				$this->_statusCode = 401;
				return false;
			}
		} else {
			$this->_error = 'Bad Request';
			$this->_statusCode = 400;
			return false;
		}
	}

	protected function import_price()
	{
		$token = isset($this->_request['token']) ? $this->_request['token'] : null;

		if ($token) {
			$this->_tokenCMSAuth($token);

			if (!is_null($this->_user)) {
				$aItems = isset($this->_request['items'])
					? $this->_request['items']
					: null;

				if ($aItems && count($aItems)) {
					$backup = isset($this->_request['backup'])
						? $this->_request['backup']
						: false;

					if ($backup) {
						$oBackup_Controller = new Backup_Controller();
						$oBackup_Controller->backupDatabase(BACKUP_DIR);
					}

					$aNotFound = [];
					$i = 0;

					//$aQuery = [];
					foreach ($aItems as $item) {
						if (isset($item['marking'])) {
							$oShop_Item = Core_Entity::factory('Shop_Item')->getByMarking(
								strval($item['marking'])
							);

							if ($oShop_Item) {
								// change_price
								if (isset($item['price']) && intval($item['price'])) {
									$oShop_Item->price = intval($item['price']);
									$oShop_Item->save();
								}
								// remove all sales
								$oShop_Item->Shop_Item_Discounts->deleteAll(false);

								//add discount
								if (isset($item['sale']) && intval($item['sale'])) {
									$discountValue = intval($item['sale']);

									$name = $guid = 'wb_discount_' . $discountValue;

									$oShop_Discount = Core_Entity::factory(
										'Shop_Discount'
									)->getByGuid($guid);

									if (is_null($oShop_Discount)) {
										$oShop_Discount = Core_Entity::factory('Shop_Discount');
										$oShop_Discount->guid = $guid;
										$oShop_Discount->shop_id = $this->_oShop->id;
										//$this->_shop->add($oShop_Discount);

										$oShop_Discount->deleted = 0;
										$oShop_Discount->name = $name;
										$oShop_Discount->start_datetime = '2020-01-01 00:00:00';
										$oShop_Discount->end_datetime = '2030-01-01 00:00:00';
										$oShop_Discount->type = 0;

										$oShop_Discount->value = $discountValue;
										$oShop_Discount->save();
									}

									// чистим привязку к группе
									$oCore_QueryBuilder_Delete = Core_QueryBuilder::delete(
										'shop_discount_siteuser_groups'
									)
										->lowPriority()
										->quick()
										->ignore()
										->where('shop_discount_id', '=', $oShop_Discount->id)
										->execute();

									// добавляем в группу
									$oCore_QueryBuilder_Insert = Core_QueryBuilder::insert(
										'shop_discount_siteuser_groups',
										[
											'shop_discount_id' => $oShop_Discount->id,
											'siteuser_group_id' => 0,
										]
									)->execute();

									// добавляем скидку к товару
									$oCore_QueryBuilder_Insert = Core_QueryBuilder::insert(
										'shop_item_discounts',
										[
											'shop_item_id' => $oShop_Item->id,
											'shop_discount_id' => $oShop_Discount->id,
										]
									)->execute();

									// чистим кэш
									//$oShop_Item->clearCache();
								}

								$i++;
							} else {
								$aNotFound[] = $item['marking'];
							}
						}
					}

					// пересчитываем магазин
					if ($this->_oShop && $this->_oShop->filter) {
						$this->_updateFilters($this->_oShop);
					}

					// чистим кэш
					if (Core::moduleIsActive('cache')) {
						Core_Cache::instance(Core::$mainConfig['defaultCache'])->deleteAll(
							$this->_cacheName
						);
					}

					$this->_answer = [
						//'query' => $aQuery,
						'count_input' => count($aItems),
						'count_updated' => $i,
						'not_found' => $aNotFound,
					];
				} else {
					$this->_error = 'Wrong POST data';
					$this->_statusCode = 422;
					return false;
				}
			} else {
				$this->_error = 'Authentication Required';
				$this->_statusCode = 401;
				return false;
			}
		} else {
			$this->_error = 'Bad Request';
			$this->_statusCode = 400;
			return false;
		}
	}

	protected function signin()
	{
		$login = isset($this->_request['username'])
			? $this->_request['username']
			: null;
		$pwd = isset($this->_request['password'])
			? $this->_request['password']
			: null;

		if ($login && $pwd) {
			$oSiteuser = Core_Entity::factory('Siteuser');
			$oSiteuser
				->queryBuilder()
				//->clear()
				->where('login', '=', $login)
				->where('password', '=', Core_Hash::instance()->hash($pwd))
				->limit(1);

			$aSiteusers = $oSiteuser->findAll(false);
			$oSiteuser = isset($aSiteusers[0]) ? $aSiteusers[0] : null;

			if (!is_null($oSiteuser)) {
				$this->_oSiteuser = $oSiteuser;
				$redirectToProfile = false;

				$this->_answer = [
					'id' => $oSiteuser->id,
					'token' => $oSiteuser->guid,
					'email' => $oSiteuser->email,
					'profile' => $this->_getSiteuserProfile(),
					'redirect' => $redirectToProfile,
					'url' => '/me',
				];
			} else {
				$this->_error = 'Access denied';
				$this->_statusCode = 403;
			}
		} else {
			$this->_error = 'Bad Request';
			$this->_statusCode = 400;

			return false;
		}

		//$this->_answer = $this->_request;
	}

	protected function signup()
	{
		$login = isset($this->_request['username'])
			? trim(strval($this->_request['username']))
			: null;

		if ($login && Core_Valid::email($login)) {
			$oSiteuser = Core_Entity::factory('Siteuser')->getByEmail($login, false);

			if (is_null($oSiteuser)) {
				// new user

				$password = Core_Password::get();
				$passwordHash = Core_Hash::instance()->hash($password);

				$oSiteuser = Core_Entity::factory('Siteuser')->site_id($this->site->id);
				$oSiteuser->login = $login;
				$oSiteuser->email = $login;
				$oSiteuser->password = $passwordHash;
				$oSiteuser->active = 1;
				$oSiteuser->save();

				// Внесение пользователя в группу по умолчанию
				$oSiteuser_Group = $oSiteuser->Site->Siteuser_Groups->getDefault();

				if (!is_null($oSiteuser_Group)) {
					$oSiteuser_Group->add($oSiteuser);
				}

				$xslRestorePasswordMailXsl = 'letter__signup';
				$Siteuser_Controller_Restore_Password = new My_Siteuser_Controller_Restore_Password(
					$oSiteuser
				);
				$Siteuser_Controller_Restore_Password
					->subject($this->site->name)
					->from($this->_mail_from)
					->contentType('text/html')
					->xsl(
						Core_Entity::factory('Xsl')->getByName($xslRestorePasswordMailXsl)
					)
					->sendNewPassword();

				$this->_answer['request'] = $this->_request;
				$this->_answer['message'] = 'Пароль отправлен на вашу почту';
			} else {
				// user exist
				$this->_answer['request'] = $this->_request;
				$this->_answer['message'] = 'Пользователь уже существует';
			}
		} else {
			$this->_error = 'Неверные данные: email';
			$this->_statusCode = 400;
			return false;
		}

		//$this->_answer = $this->_request;
	}

	protected function signinphone()
	{
		$login = isset($this->_request['username'])
			? trim(strval($this->_request['username']))
			: null;

		$code = isset($this->_request['code'])
			? trim(strval($this->_request['code']))
			: null;

		// var_dump($this->_request);
		// exit();

		if ($login && $code) {
			$sCurrentDate = Core_Date::timestamp2sql(time());
			$oCodeauth_Token = Core_Entity::factory('Codeauth_Token');
			$oCodeauth_Token
				->queryBuilder()
				->where('phone', '=', $login)
				->where('code', '=', $code)
				->where('active', '=', 1)
				->where('datetime', '<=', $sCurrentDate)
				->open()
				->where('expire', '=', '0000-00-00 00:00:00')
				->setOr()
				->where('expire', '>', $sCurrentDate)
				->close()
				->limit(1);

			$aCodeauth_Tokens = $oCodeauth_Token->findAll(false);
			if (isset($aCodeauth_Tokens[0])) {
				$oSiteuser = Core_Entity::factory('Siteuser')->getByLogin(
					$login,
					false
				);

				$redirectToProfile = false;
				$newUser = false;

				if (is_null($oSiteuser)) {
					// new user

					$newUser = true;

					$password = Core_Password::get();
					$passwordHash = Core_Hash::instance()->hash($password);

					$oSiteuser = Core_Entity::factory('Siteuser')->site_id(
						$this->site->id
					);
					$oSiteuser->login = $login;
					$oSiteuser->email = $login . '@riche.skin';
					$oSiteuser->password = $passwordHash;
					$oSiteuser->active = 1;
					$oSiteuser->save();

					//профиль - телефон
					$oSiteuser_Person = null;
					$aSiteuser_People = $oSiteuser->Siteuser_People->findAll(false);

					// if (isset($aSiteuser_People[0])) {
					// 	$oSiteuser_Person = $aSiteuser_People[0];
					// } else {

					if (!count($aSiteuser_People)) {
						$oSiteuser_Person = Core_Entity::factory('Siteuser_Person');
						$oSiteuser_Person->siteuser_id = $oSiteuser->id;
						$oSiteuser_Person->save();
					}
					// else {
					// 	$oSiteuser_Person = $aSiteuser_People[0];
					// }

					if ($oSiteuser_Person) {
						// var_dump($oSiteuser_Person->toArray());
						// exit();
						// Телефон
						$oDirectory_Phone_Type = Core_Entity::factory(
							'Directory_Phone_Type'
						)->getByName('Рабочий');
						if (is_null($oDirectory_Phone_Type)) {
							$oDirectory_Phone_Type = Core_Entity::factory(
								'Directory_Phone_Type'
							);
							$oDirectory_Phone_Type->name = Core::_(
								'Directory_Phone_Type.default_name'
							);
							$oDirectory_Phone_Type->save();
						}

						$aDirectory_Phones = $oSiteuser_Person->Directory_Phones->findAll(
							false
						);
						// if (isset($aDirectory_Phones[0])) {
						// 	$oDirectory_Phone = $aDirectory_Phones[0];

						// 	$oPhone = array_shift($aDirectory_Phones);

						// 	$oPhone->value = '+' . $oSiteuser->login;
						// 	$oPhone->save();
						// } else {

						if (!count($aDirectory_Phones)) {
							$oDirectory_Phone = Core_Entity::factory('Directory_Phone');
							$oDirectory_Phone->directory_phone_type_id =
								$oDirectory_Phone_Type->id;
							$oDirectory_Phone->public = 0;

							$oDirectory_Phone->value = '+' . $oSiteuser->login;
							$oDirectory_Phone->save();

							$oSiteuser_Person->add($oDirectory_Phone);
						}
					}

					// Внесение пользователя в группу по умолчанию
					$oSiteuser_Group = $oSiteuser->Site->Siteuser_Groups->getDefault();

					if (!is_null($oSiteuser_Group)) {
						$oSiteuser_Group->add($oSiteuser);
					}
					$redirectToProfile = true;
				}
				$oCodeauth_Token = $aCodeauth_Tokens[0];

				$oCodeauth_Token->active = 0;
				$oCodeauth_Token->save();

				$this->_oSiteuser = $oSiteuser;

				$this->_answer = [
					'id' => $oSiteuser->id,
					'token' => $oSiteuser->guid,
					'email' => $this->_oSiteuser->email,
					'profile' => $this->_getSiteuserProfile(),
					'redirect' => $redirectToProfile,
					'url' => '/me/profile',
					'new' => $newUser,
				];
			} else {
				$this->_error = 'Неверный код авторизации';
				$this->_statusCode = 400;
			}
		} else {
			$this->_error = 'Wrong POST data';
			$this->_statusCode = 422;
			return false;
		}

		//$this->_answer = $this->_request;
	}

	protected function codeauthinput()
	{
		// {"id":"3273115189380362741","user_id":"0","status":"deliver","time_change_state":"2023-10-09 13:35:57","phone":"79127799442","type":"sms"}

		// $logsDir =
		// 	CMS_FOLDER .
		// 	'modules' .
		// 	DIRECTORY_SEPARATOR .
		// 	'app' .
		// 	DIRECTORY_SEPARATOR .
		// 	'command';
		// $paymentLogsFile = $logsDir . DIRECTORY_SEPARATOR . 'codeauth.txt';
		// $fileLog = fopen($paymentLogsFile, 'a');
		// $aWrite = json_encode($this->_request);
		// if ($aWrite) {
		// 	fwrite($fileLog, $aWrite . PHP_EOL);
		// }

		// fclose($fileLog);

		$oCodeauth_Token = Core_Entity::factory('Codeauth_Token')->getByExternal_id(
			$this->_request['id']
		);
		if (
			$oCodeauth_Token &&
			$this->_request['phone'] == $oCodeauth_Token->phone
		) {
			$oCodeauth_Token->status = $this->_request['status'];
			$oCodeauth_Token->save();
			$this->_answer = [
				'request' => $this->_request,
				'status' => $oCodeauth_Token->status,
			];
		} else {
			$this->_error = 'Неверные данные';
			$this->_statusCode = 400;
			return false;
		}
	}

	protected function codeauth__register()
	{
		if (isset($this->_request['phone'])) {
			$result = Codeauth_Controller::sendCode($this->_request['phone']);
			$this->_answer = $result;
		} else {
			$this->_error = 'Неверные данные';
			$this->_statusCode = 400;
			return false;
		}
	}

	protected function codeauth__check()
	{
		$login = isset($this->_request['username'])
			? trim(strval($this->_request['username']))
			: null;

		$code = isset($this->_request['code'])
			? trim(strval($this->_request['code']))
			: null;

		// var_dump($this->_request);
		// exit();
		$newUser = false;

		$aReturn = [
			'result' => false,
			'message' => 'Неверные данные. Попробуйте ещё раз',
			'new' => $newUser,
		];

		if ($login && $code) {
			$oSiteuser = Core_Entity::factory('Siteuser')->getByLogin($login, false);

			if (is_null($oSiteuser)) {
				$newUser = true;
			}

			$sCurrentDate = Core_Date::timestamp2sql(time());
			$oCodeauth_Token = Core_Entity::factory('Codeauth_Token');
			$oCodeauth_Token
				->queryBuilder()
				->where('phone', '=', $login)
				->where('code', '=', $code)
				->where('active', '=', 1)
				->where('datetime', '<=', $sCurrentDate)
				->open()
				->where('expire', '=', '0000-00-00 00:00:00')
				->setOr()
				->where('expire', '>', $sCurrentDate)
				->close()
				->limit(1);

			$aCodeauth_Tokens = $oCodeauth_Token->findAll(false);
			if (isset($aCodeauth_Tokens[0])) {
				$aReturn = [
					'result' => true,
					'message' => null,
					'new' => $newUser,
				];
			} else {
				$aReturn = [
					'result' => false,
					'message' => 'Неверный код или он устарел',
					'new' => $newUser,
				];
			}
		}

		$this->_answer = $aReturn;
	}

	protected function restore()
	{
		$login = isset($this->_request['username'])
			? trim(strval($this->_request['username']))
			: null;

		if ($login && Core_Valid::email($login)) {
			$oSiteuser = Core_Entity::factory('Siteuser')->getByEmail($login, false);

			if (!is_null($oSiteuser)) {
				// new user

				$xslRestorePasswordMailXsl = 'letter__restore';
				$Siteuser_Controller_Restore_Password = new My_Siteuser_Controller_Restore_Password(
					$oSiteuser
				);
				$Siteuser_Controller_Restore_Password
					->subject($this->site->name)
					->from($this->_mail_from)
					->contentType('text/html')
					->xsl(
						Core_Entity::factory('Xsl')->getByName($xslRestorePasswordMailXsl)
					)
					->sendNewPassword();

				$this->_answer['request'] = $this->_request;
				$this->_answer['message'] = 'Новый пароль отправлен на вашу почту';
			} else {
				// user exist
				$this->_answer['request'] = $this->_request;
				$this->_answer['message'] = 'Пользователь не существует';
			}
		} else {
			$this->_error = 'Неверные данные: email';
			$this->_statusCode = 400;
			return false;
		}

		//$this->_answer = $this->_request;
	}

	protected function city_list()
	{
		$aCountry = [
			'ru' => 175, // Россия
			'kz' => 88, // Казахстан
			'by' => 24, // Беларусь
		];

		$in__text = trim(strval(Core_Array::getGet('query', false)));
		$in__country = trim(strval(Core_Array::getGet('country', 'ru')));

		$aCityFirst = [
			'ru' => [
				1, // Москва
				173, // Санкт-Петербург
				1384, // Новосибирск
				1888, // Екатеринбург
				2055, // Казань
				1321, // Нижний Новгород
				2391, // Челябинск
				1745, // Самара
				401, // Уфа
				1677, // Ростов-на-Дону

				// 1414, // Омск
				// 526, // Волгоград
			],
			'kz' => [
				4243, // Астана
				4261, // Алматы
				4338, // Атырау
				4426, // Павлодар
				//4261, // Тараз
				4287, // Усть-Каменогорск
				//4261, // Шымкент
				4361, // Караганда
			],
		];
		$aItems = [];

		$oQueryBuilderSelect = Core_QueryBuilder::select();

		if ($in__text) {
			$oQueryBuilderSelect
				->where(
					'shop_country_location_cities.name',
					'LIKE',
					'%' . $in__text . '%'
				)
				->orderBy('shop_country_location_cities.name', 'ASC');
		} else {
			if (isset($aCityFirst[$in__country])) {
				$oQueryBuilderSelect->where(
					'shop_country_location_cities.id',
					'IN',
					$aCityFirst[$in__country]
				);
			}
		}

		$oQueryBuilderSelect
			->select(['shop_country_location_cities.id', 'city_id'])
			// ->select(['shop_country_location_cities.name', 'city_name'])
			// ->select(['shop_country_locations.id', 'location_id'])
			// ->select(['shop_country_locations.name', 'location_name'])
			//->select(['shop_country_locations.shop_country_id', 'country_id'])
			->from('shop_country_location_cities')
			->leftJoin(
				'shop_country_locations',
				'shop_country_location_cities.shop_country_location_id',
				'=',
				'shop_country_locations.id'
			)
			->where('shop_country_location_cities.deleted', '=', 0)
			->where('shop_country_location_cities.active', '=', 1)
			->where(
				'shop_country_locations.shop_country_id',
				'=',
				$aCountry[$in__country]
			)

			->limit(10);

		// echo $oQueryBuilderSelect->execute()->getLastQuery();
		// exit();

		$aItems = $oQueryBuilderSelect
			->execute()
			->asAssoc()
			->result();

		$aCity = [];

		foreach ($aItems as $item) {
			$oShop_Country_Location_City = Core_Entity::factory(
				'Shop_Country_Location_City',
				$item['city_id']
			);

			$aCity[] = [
				'id' => $oShop_Country_Location_City->id,
				'city_name' => $oShop_Country_Location_City->name,
				'region_name' =>
					$oShop_Country_Location_City->Shop_Country_Location->name,
				'country_name' =>
					$oShop_Country_Location_City->Shop_Country_Location->Shop_Country
						->name,
			];
		}

		$this->_answer['query'] = $in__text;
		$this->_answer['country'] = $in__country;
		$this->_answer['country_id'] = $aCountry[$in__country];
		$this->_answer['items'] = $aCity;
	}

	protected function menu()
	{
		$aMenu = [
			'pages' => [
				[
					'name' => 'Каталог',
					'slug' => '/catalog',
					'sorting' => 10,
					'action' => 'sidebar',
					'in_sidebar' => false,
				],
				[
					'name' => 'Покупателям',
					'slug' => '/info',
					'sorting' => 20,
					'action' => null,
					'in_sidebar' => false,
				],
				// [
				//   'name' => 'Блог',
				//   'slug' => '/blog',
				//   'sorting' => 30,
				//   'action' => null,
				//   'in_sidebar' => true,
				// ],
				[
					'name' => 'О бренде',
					'slug' => '/about',
					'sorting' => 40,
					'action' => null,
					'in_sidebar' => true,
				],
			],
			'groups' => $this->_getGroups(),
			'subscribe' => false,
		];

		$oPopularConst = Core_Entity::factory('Constant')->getByName(
			'SHOP_POPULAR'
		);
		$aPopular = $oPopularConst ? explode(',', $oPopularConst->value) : [];
		if (count($aPopular)) {
			foreach ($aPopular as $item) {
				$oShop_Item = Core_Entity::factory('Shop_Item', $item);
				if ($oShop_Item->name && $oShop_Item->active && !$oShop_Item->deleted) {
					$aMenu['popular'][] = [
						'name' => $oShop_Item->name,
						'slug' => '/product/' . $oShop_Item->path . '-' . $oShop_Item->id,
					];
				}
			}
		}

		$this->_answer['menu'] = $aMenu;
	}

	protected function _infoCardMain($oEntity)
	{
		$aReturn = null;
		$aTypes = [
			28 => 'shop', // Часть магазина
			29 => 'shop_groups', // Группы магазина
			30 => 'promo', // Промоблок
			31 => 'blog', // Блог
			32 => 'baner', // Банер
			59 => 'reccomendR46', // Блок рекомендации R46
		];

		$type = null;
		$oProperty = Core_Entity::factory('Property', 20);
		$aPropertyValues = $oProperty->getValues($oEntity->id);
		if (
			isset($aPropertyValues[0]) &&
			$aPropertyValues[0]->value != '' &&
			isset($aTypes[$aPropertyValues[0]->value])
		) {
			$type = $aTypes[$aPropertyValues[0]->value];
		}

		if ($type) {
			$this->_oInfoDataAllowed = ['media'];

			$thumb = null;
			$aMedia = [];
			$aMediaPre = $this->_getMedia($oEntity);
			if (isset($aMediaPre['thumb'])) {
				$thumb = $aMediaPre['thumb'];
			}
			if (isset($aMediaPre['media'])) {
				$aMedia = $aMediaPre['media'];
			}

			$aReturn = [
				'type' => $type,
				'id' => intval($oEntity->id),
				'name' => $oEntity->name,
				'media' => $aMedia,
				'thumb' => $thumb,
				'sorting' => intval($oEntity->sorting),
			];

			switch ($type) {
				// 28 => 'shop', // Часть магазина
				case 'shop':
					$aShopItems = [];
					$oProperty = Core_Entity::factory('Property', 21);
					$aPropertyValues = $oProperty->getValues($oEntity->id);
					foreach ($aPropertyValues as $oPropertyValue) {
						if ($oPropertyValue && $oPropertyValue->value) {
							$oShop_Item = Core_Entity::factory(
								'Shop_Item',
								$oPropertyValue->value
							);

							if (
								$oShop_Item->name &&
								$oShop_Item->active &&
								!$oShop_Item->deleted
							) {
								$aData = $this->_shopCard($oShop_Item);
								$aData['sorting'] = $oPropertyValue->sorting;

								$aShopItems[] = $aData;
							}
						}
					}

					$aReturn['shop_items'] = $aShopItems;

					break;

				// 29 => 'shop_groups', // Группы магазина
				case 'shop_groups':
					$aShopGroups = [];
					$oProperty = Core_Entity::factory('Property', 22);
					$aPropertyValues = $oProperty->getValues($oEntity->id);
					foreach ($aPropertyValues as $oPropertyValue) {
						if ($oPropertyValue && $oPropertyValue->value) {
							$oShop_Group = Core_Entity::factory(
								'Shop_Group',
								$oPropertyValue->value
							);

							if (
								$oShop_Group->name &&
								$oShop_Group->active &&
								!$oShop_Group->deleted
							) {
								$aData = $this->_groupCard($oShop_Group);
								$aData['sorting'] = $oPropertyValue->sorting;

								$aShopGroups[] = $aData;
							}
						}
					}

					$aReturn['shop_groups'] = $aShopGroups;

					break;

				//30 => 'promo', // Промоблок
				case 'promo':
					$link = null;
					$oProperty = Core_Entity::factory('Property', 23);
					$aPropertyValues = $oProperty->getValues($oEntity->id);
					if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
						$link = $aPropertyValues[0]->value;
					}
					$aReturn['description'] = $oEntity->description;
					$aReturn['link'] = $link;

					break;

				// 31 => 'blog', // Блог
				case 'blog':
					$aBlogItems = [];
					$oProperty = Core_Entity::factory('Property', 24);
					$aPropertyValues = $oProperty->getValues($oEntity->id);
					foreach ($aPropertyValues as $oPropertyValue) {
						if ($oPropertyValue && $oPropertyValue->value) {
							$oInfo_Item = Core_Entity::factory(
								'Informationsystem_Item',
								$oPropertyValue->value
							);

							if (
								$oInfo_Item->name &&
								$oInfo_Item->active &&
								!$oInfo_Item->deleted
							) {
								$aData = $this->_infoCard($oInfo_Item);
								$aData['sorting'] = $oPropertyValue->sorting;

								$aBlogItems[] = $aData;
							}
						}
					}

					$aReturn['blog_items'] = $aBlogItems;

					break;

				//32 => 'baner', // Банер
				case 'baner':
					$link = null;
					$oProperty = Core_Entity::factory('Property', 23);
					$aPropertyValues = $oProperty->getValues($oEntity->id);
					if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
						$link = $aPropertyValues[0]->value;
					}

					unset($aReturn['thumb']);
					$aReturn['description'] = $oEntity->description;
					$aReturn['link'] = $link;

					break;

				case 'reccomendR46':
					$idr46 = null;
					$oProperty = Core_Entity::factory('Property', 47);
					$aPropertyValues = $oProperty->getValues($oEntity->id);
					if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
						$idr46 = $aPropertyValues[0]->value;
					}

					// unset($aReturn['thumb']);
					// $aReturn['description'] = $oEntity->description;
					// $aReturn['link'] = $link;

					//unset($aReturn);

					// unset($aReturn['thumb']);
					// $aReturn['r46'] = $idr46;

					$aReturn = [
						'type' => $aReturn['type'],
						'id' => $idr46,

						'title' => $oEntity->name,
					];

					break;

				default:
					$aReturn = $this->_infoCard($oEntity);
					break;
			}
		}

		return $aReturn;
	}

	protected function main_page()
	{
		$oEntity = $this->_oInformationsystem;

		if ($oEntity->name) {
			$items_sorting_direction =
				$oEntity->items_sorting_direction == 1 ? 'DESC' : 'ASC';
			$items_sorting_field = ($oEntity->items_sorting_field == 1
					? 'informationsystem_items.name'
					: $oEntity->items_sorting_field == 2)
				? 'informationsystem_items.sorting'
				: 'informationsystem_items.datetime';

			$oEntityItems = $oEntity->Informationsystem_Items;

			$oEntityItems = $this->_itemsCondition($oEntityItems);

			$oEntityItems
				->queryBuilder()
				->clearOrderBy()
				->orderBy($items_sorting_field, $items_sorting_direction);

			// при выборе из всего магазина / инфо ярлыки не требуются, так как будут присутствовать оригинальные товары
			$oEntityItems = $this->_forbidSelectShortcuts($oEntityItems);

			$oEntityItems = $oEntityItems->findAll(false);

			$aItems = [];
			$thumb = null;

			foreach ($oEntityItems as $oEntityItem) {
				if ($oEntityItem->shortcut_id) {
					$oEntityItem = Core_Entity::factory(
						'informationsystem_Item',
						$oEntityItem->shortcut_id
					);
				}

				$aItems[] = $this->_infoCardMain($oEntityItem);
			}

			$this->_answer = [
				'blocks' => $aItems,
			];
		} else {
			$this->_error = sprintf('Path: "%s" Not Found', $this->path);
			$this->_statusCode = 404;
		}
	}

	protected function _countCart($aItems, $oSiteuser)
	{
		// Есть скидки на N-й товар, доступные для текущей даты
		$bPositionDiscount = $this->_oShop->Shop_Purchase_Discounts->checkAvailableWithPosition();
		$totalAmount = $totalQuantity = $totalTax = $totalWeight = $totalVolume = $totalQuantityForPurchaseDiscount = $totalAmountForPurchaseDiscount = $totalDiscount = $totalAmountBefore = 0;

		$aDiscountPrices = [];
		$oShop_Item_Controller = new Shop_Item_Controller();

		$aItemsReturn = [];

		foreach ($aItems as $item) {
			$item_id = intval($item['id']);
			$item_quantity = intval($item['quantity']);
			$item_timestamp = intval($item['timestamp']);

			$oShop_Item = Core_Entity::factory('Shop_Item', $item_id);

			if ($oShop_Item->name && $oShop_Item->active && !$oShop_Item->deleted) {
				// Проверять остаток для обычных товаров
				if ($this->checkStock && $oShop_Item->type != 1) {
					$iRest = $oShop_Item->getRest() - $oShop_Item->getReserved();
					$iRest < $item_quantity && ($item_quantity = $iRest);
				}

				$aItem = $this->_shopCard($oShop_Item);

				$aItem['cart']['id'] = $aItem['id'];
				$aItem['cart']['timestamp'] = $item_timestamp;
				$aItem['cart']['price'] = floatval($aItem['price']['current']);
				$aItem['cart']['price_old'] = floatval($aItem['price']['old']);
				$aItem['cart']['quantity'] = $item_quantity;
				$aItem['cart']['amount'] = $item_quantity * $aItem['price']['current'];
				$aItem['cart']['amount_old'] = $item_quantity * $aItem['price']['old'];
				$aItem['cart']['discount'] =
					$item_quantity * $aItem['price']['discount'];
				$aItem['cart']['currency'] = $aItem['price']['currency'];

				unset(
					$aItem['description'],
					$aItem['group_id'],
					$aItem['media'],
					$aItem['sorting'],
					$aItem['labels']
				);

				$aItemsReturn[] = $aItem;

				$totalDiscount += $aItem['cart']['discount'];
				$totalAmountBefore += $aItem['cart']['amount_old'];

				$bSkipItem = $oShop_Item->type == 4;

				$totalQuantity += $item_quantity;

				// Prices
				if (Core::moduleIsActive('siteuser') && $oSiteuser) {
					$oShop_Item_Controller->siteuser($oSiteuser);
				}

				$oShop_Item_Controller->count($item_quantity);
				$aPrices = $oShop_Item_Controller->getPrices($oShop_Item);
				$totalAmount += $aPrices['price_discount'] * $item_quantity;

				if ($bPositionDiscount && !$bSkipItem) {
					// По каждой единице товара добавляем цену в массив, т.к. может быть N единиц одого товара
					for ($i = 0; $i < $item_quantity; $i++) {
						$aDiscountPrices[] = $aPrices['price_discount'];
					}
				}

				if ($oShop_Item->apply_purchase_discount && !$bSkipItem) {
					$bApplyPurchaseDiscount = true;
					foreach ($aPrices['discounts'] as $oShop_Discount) {
						if ($oShop_Discount->not_apply_purchase_discount) {
							$bApplyPurchaseDiscount = false;
							break;
						}
					}

					if ($bApplyPurchaseDiscount) {
						// Сумма для скидок от суммы заказа рассчитывается отдельно
						$totalAmountForPurchaseDiscount +=
							$aPrices['price_discount'] * $item_quantity;

						// Количество для скидок от суммы заказа рассчитывается отдельно
						$totalQuantityForPurchaseDiscount += $item_quantity;
					}
				}

				$totalTax += $aPrices['tax'] * $item_quantity;

				$totalWeight += $oShop_Item->weight * $item_quantity;

				$totalVolume +=
					Shop_Controller::convertSizeMeasure(
						$oShop_Item->length,
						$this->_oShop->size_measure,
						0
					) *
					Shop_Controller::convertSizeMeasure(
						$oShop_Item->width,
						$this->_oShop->size_measure,
						0
					) *
					Shop_Controller::convertSizeMeasure(
						$oShop_Item->height,
						$this->_oShop->size_measure,
						0
					);
			}
		}

		$totalDiscountPrices = $aDiscountPrices;

		return [
			'cart' => $aItemsReturn,
			'total' => [
				'totalAmountBefore' => $totalAmountBefore,
				'totalDiscount' => $totalDiscount,
				'totalAmount' => $totalAmount,
				'totalQuantity' => $totalQuantity,
				'totalTax' => $totalTax,
				'totalWeight' => $totalWeight,
				'totalVolume' => $totalVolume,
				'totalQuantityForPurchaseDiscount' => $totalQuantityForPurchaseDiscount,
				'totalAmountForPurchaseDiscount' => $totalAmountForPurchaseDiscount,
				'aDiscountPrices' => $aDiscountPrices,
				'totalDiscountPrices' => $totalDiscountPrices,
			],
		];
	}

	protected function _getDiscoutAmount(
		$quantityPurchaseDiscount,
		$amountPurchaseDiscount
	) {
		$oShop = $this->_oShop;

		// Дисконтная карта
		$bApplyMaxDiscount = $bApplyShopPurchaseDiscounts = false;
		$fDiscountcard = $fAppliedDiscountsAmount = 0;

		if (
			$this->applyDiscountCards &&
			Core::moduleIsActive('siteuser') &&
			$this->_oSiteuser
		) {
			$oShop_Discountcard = $this->_oSiteuser->Shop_Discountcards->getByShop_id(
				$oShop->id
			);
			if (
				!is_null($oShop_Discountcard) &&
				$oShop_Discountcard->active &&
				$oShop_Discountcard->shop_discountcard_level_id
			) {
				$oShop_Discountcard_Level =
					$oShop_Discountcard->Shop_Discountcard_Level;

				$bApplyMaxDiscount = $oShop_Discountcard_Level->apply_max_discount == 1;

				// Сумма скидки по дисконтной карте
				$fDiscountcard =
					$amountPurchaseDiscount * ($oShop_Discountcard_Level->discount / 100);
			}
		}

		if ($this->applyDiscounts) {
			// Скидки от суммы заказа
			$oShop_Purchase_Discount_Controller = new Shop_Purchase_Discount_Controller(
				$oShop
			);
			$oShop_Purchase_Discount_Controller
				->amount($amountPurchaseDiscount)
				->quantity($quantityPurchaseDiscount)
				->couponText($this->couponText)
				->siteuserId($this->_oSiteuser ? $this->_oSiteuser->id : 0)
				->prices($this->_aDiscountPrices);

			$aShop_Purchase_Discounts = $oShop_Purchase_Discount_Controller->getDiscounts();

			// Если применять только максимальную скидку, то считаем сумму скидок по скидкам от суммы заказа
			if ($bApplyMaxDiscount) {
				$totalPurchaseDiscount = 0;

				foreach ($aShop_Purchase_Discounts as $oShop_Purchase_Discount) {
					$totalPurchaseDiscount += $oShop_Purchase_Discount->getDiscountAmount();
				}

				$bApplyShopPurchaseDiscounts = $totalPurchaseDiscount > $fDiscountcard;
			} else {
				$bApplyShopPurchaseDiscounts = true;
			}

			// Если решили применять скидку от суммы заказа
			if ($bApplyShopPurchaseDiscounts) {
				foreach ($aShop_Purchase_Discounts as $oShop_Purchase_Discount) {
					// if (!$bTpl) {
					//   $this->addEntity($oShop_Purchase_Discount->clearEntities());
					// } else {
					//   $this->append('aShop_Purchase_Discounts', $oShop_Purchase_Discount);
					// }

					$fAppliedDiscountsAmount += $oShop_Purchase_Discount->getDiscountAmount();
				}
			}

			// Скидка больше суммы заказа
			$fAppliedDiscountsAmount > $amountPurchaseDiscount &&
				($fAppliedDiscountsAmount = $amountPurchaseDiscount);
		}

		// Не применять максимальную скидку или сумма по карте больше, чем скидка от суммы заказа
		if (!$bApplyMaxDiscount || !$bApplyShopPurchaseDiscounts) {
			if ($fDiscountcard) {
				$fAmountForCard = $amountPurchaseDiscount - $fAppliedDiscountsAmount;

				if ($fAmountForCard > 0) {
					$oShop_Discountcard->discountAmount(
						Shop_Controller::instance()->round(
							$fAmountForCard * ($oShop_Discountcard_Level->discount / 100)
						)
					);

					// if (!$bTpl) {
					//   $this->addEntity($oShop_Discountcard->clearEntities());
					// } else {
					//   $this->append('aShop_Discountcards', $oShop_Discountcard);
					// }

					$fAppliedDiscountsAmount += $oShop_Discountcard->getDiscountAmount();
				}
			}
		}

		return $fAppliedDiscountsAmount;
	}

	protected function _getDeliveryDate($city_id, $aDelivery)
	{
		$aDayDeliveryDays = [
			'default' => 10,
			'point' => 10,
			'door' => 10,
		];

		$aMonths = [
			'января',
			'февраля',
			'марта',
			'апреля',
			'майя',
			'июня',
			'июля',
			'августа',
			'сентября',
			'октября',
			'ноября',
			'декабря',
		];

		$delivery_type = isset($aDelivery['delivery_type'])
			? $aDelivery['delivery_type']
			: 'default';

		$days = $aDayDeliveryDays[$delivery_type];

		if (intval($city_id) > 0) {
			$oShop_Country_Location_City = Core_Entity::factory(
				'Shop_Country_Location_City',
				$city_id
			);

			$region_id = $oShop_Country_Location_City->Shop_Country_Location->id;

			$aRegionsDelivery = [
				925 => 9, // Агинский Бурятский округ
				3 => 7, // Адыгея
				924 => 7, // Алтай
				4 => 8, // Алтайский край
				5 => 9, // Амурская область
				6 => 7, // Архангельская область
				7 => 8, // Астраханская область
				8 => 6, // Башкортостан
				9 => 6, // Белгородская область
				10 => 8, // Брянская область
				11 => 9, // Бурятия
				12 => 5, // Владимирская область
				13 => 7, // Волгоградская область
				14 => 7, // Вологодская область
				15 => 6, // Воронежская область
				16 => 7, // Дагестан
				17 => 10, // Еврейская АО
				74 => 8, // Забайкальский край
				18 => 6, // Ивановская область
				73 => 7, // Ингушетия
				19 => 6, // Иркутская область
				20 => 7, // Кабардино-Балкарская
				21 => 6, // Калининградская область
				22 => 9, // Калмыкия
				23 => 6, // Калужская область
				24 => 8, // Камчатский край
				926 => 7, // Карачаево-Черкесская
				25 => 7, // Карелия
				26 => 7, // Кемеровская область
				27 => 7, // Кировская область
				28 => 8, // Коми
				29 => 7, // Костромская область
				30 => 6, // Краснодарский край
				31 => 7, // Красноярский край
				927 => 7, // Крым
				32 => 6, // Курганская область
				33 => 6, // Курская область
				34 => 5, // Липецкая область
				35 => 12, // Магаданская область
				36 => 5, // Марий Эл
				37 => 5, // Мордовия
				1 => 5, // Москва и Московская область
				38 => 7, // Мурманская область
				923 => 7, // Ненецкий АО
				39 => 4, // Нижегородская область
				40 => 7, // Новгородская область
				41 => 7, // Новосибирская область
				42 => 6, // Омская область
				43 => 6, // Оренбургская область
				44 => 7, // Орловская область
				45 => 5, // Пензенская область
				46 => 5, // Пермский край
				47 => 7, // Приморский край
				48 => 8, // Псковская область
				49 => 6, // Ростовская область
				50 => 6, // Рязанская область
				51 => 6, // Самарская область
				2 => 5, // Санкт-Петербург и Ленинградская область
				52 => 7, // Саратовская область
				53 => 12, // Саха (Якутия)
				54 => 9, // Сахалинская область
				55 => 7, // Свердловская область
				928 => 7, // Севастополь
				56 => 7, // Северная Осетия - Алания
				57 => 6, // Смоленская область
				58 => 6, // Ставропольский край
				59 => 6, // Тамбовская область
				60 => 5, // Татарстан
				61 => 5, // Тверская область
				62 => 8, // Томская область
				64 => 7, // Тульская область
				63 => 10, // Тыва (Тува)
				65 => 8, // Тюменская область
				66 => 5, // Удмуртская
				67 => 6, // Ульяновская область
				69 => 8, // Хабаровский край
				70 => 9, // Хакасия
				71 => 9, // Ханты-Мансийский Автономный округ - Югра АО
				72 => 7, // Челябинская область
				922 => 7, // Чеченская республика
				75 => 4, // Чувашская республика
				76 => 13, // Чукотский АО
				77 => 12, // Ямало-Ненецкий АО
				78 => 8, // Ярославская область
			];

			if (
				isset($aRegionsDelivery[$region_id]) &&
				intval($aRegionsDelivery[$region_id]) > 0
			) {
				$days = $aRegionsDelivery[$region_id];
			}
		}

		$now = Core_Date::timestamp2sql(time());
		$start_date = strtotime($now);
		$end_date = strtotime('+' . $days . ' day', $start_date);

		$sMonth = date('n', $end_date) - 1;
		$sReturn = 'до ' . date('d', $end_date) . ' ' . $aMonths[$sMonth];

		return $sReturn;
	}

	public function _getDeliveryPrice($city_id, $aDelivery, $amount)
	{
		$deliveryPrice = -1;
		$aCond = null;

		if (intval($city_id) > 0) {
			$oShop_Country_Location_City = Core_Entity::factory(
				'Shop_Country_Location_City',
				$city_id
			);

			$region_id = $oShop_Country_Location_City->Shop_Country_Location->id;
			$country_id =
				$oShop_Country_Location_City->Shop_Country_Location->Shop_Country->id;

			$delivery_type = isset($aDelivery['delivery_type'])
				? $aDelivery['delivery_type']
				: null;
			$delivery_provider = isset($aDelivery['delivery_provider'])
				? $aDelivery['delivery_provider']
				: null;
			$delivery_address = isset($aDelivery['delivery_address'])
				? $aDelivery['delivery_address']
				: null;

			// $aPre = ['door', 'point'];

			// foreach ($aPre as $key) {
			//   switch ($key) {
			//     case 'point':
			//       switch ($delivery_provider) {
			//         case 'rupost':
			//           $deliveryPrice = 550;
			//           break;
			//         default:
			//           $deliveryPrice = 150;
			//           if ($amount > 1000) {
			//             $deliveryPrice = 0;
			//           }
			//           break;
			//       }

			//       break;
			//     case 'door':
			//       $deliveryPrice = 400;
			//       if ($amount > 3000) {
			//         $deliveryPrice = 0;
			//       }
			//       break;
			//   }

			//   $aCond[$key] = $deliveryPrice;
			// }

			switch ($delivery_type) {
				case 'point':
					switch ($delivery_provider) {
						case 'rupost':
							$deliveryPrice = 550;
							break;
						default:
							$deliveryPrice = 150;
							if ($amount > 1000) {
								$deliveryPrice = 0;
							}
							break;
					}

					break;
				case 'door':
					$deliveryPrice = 400;
					if ($amount > 3000) {
						$deliveryPrice = 0;
					}
					break;
			}
		}

		return $aResult = [
			'price' => $deliveryPrice,
			//'delivery_conditions' => $aCond,
		];

		//return $deliveryPrice;
	}

	protected $_aDiscountPrices = [];
	protected $couponText = '';
	protected function cart($returnArray = false)
	{
		$oSiteuser = null;
		$sCoupon = null;

		if (isset($this->_request['token'])) {
			$oSiteuser = Core_Entity::factory('Siteuser')->getByGuid(
				$this->_request['token']
			);

			$this->_oSiteuser = $oSiteuser;
		}

		if (
			isset($this->_request['coupon']) &&
			strlen(trim($this->_request['coupon']))
		) {
			$sCoupon = trim($this->_request['coupon']);
			$this->couponText = $sCoupon;
		}

		$aPreItems = isset($this->_request['items'])
			? $this->_request['items']
			: [];

		$aCount = $this->_countCart($aPreItems, $this->_oSiteuser);

		// $Shop_Cart_Controller = Shop_Cart_Controller::instance();

		$quantityPurchaseDiscount = $amountPurchaseDiscount = $quantity = $amount = $tax = $weight = 0;
		$tax = $aCount['total']['totalTax'];
		$weight = $aCount['total']['totalWeight'];
		$amount = $aCount['total']['totalAmount'];
		$quantity = $aCount['total']['totalQuantity'];
		// Массив цен для расчета скидок каждый N-й со скидкой N%
		$this->_aDiscountPrices = $aCount['total']['totalDiscountPrices'];

		$fAppliedDiscountsAmount = $this->_getDiscoutAmount(
			$aCount['total']['totalQuantityForPurchaseDiscount'],
			$aCount['total']['totalAmountForPurchaseDiscount']
		);

		// Скидка больше суммы заказа
		$fAppliedDiscountsAmount > $amount && ($fAppliedDiscountsAmount = $amount);

		// Применяем скидку от суммы заказа
		$amount -= $fAppliedDiscountsAmount;

		$aBonuses = [
			'siteuser_bonuses' => 0,
			'available_bonuses' => 0,
			'apply_bonuses' => 0,
		];
		// Бонусы

		$currency = '';
		$oShopCurrency = $this->_oShop->Shop_Currency;
		$currency = $oShopCurrency->sign;

		//$aDeliveryConditions = null;
		$deliveryPrice = -1;
		$totalOrder = $amount;
		if (
			isset($this->_request['city_id']) &&
			intval($this->_request['city_id']) > 0 &&
			isset($this->_request['delivery'])
		) {
			$aDeliveryFull = $this->_getDeliveryPrice(
				intval($this->_request['city_id']),
				$this->_request['delivery'],
				$amount
			);

			$deliveryPrice = $aDeliveryFull['price'];
			//$aDeliveryConditions = $aDeliveryFull['delivery_conditions'];
		}

		if ($deliveryPrice >= 0) {
			$totalOrder = $amount + $deliveryPrice;
		}

		$aAnswer = [
			'user' => $oSiteuser ? $oSiteuser->login : $oSiteuser,
			'coupon' => $sCoupon,
			'cart' => $aCount['cart'],
			//'total' => $aCount['total'],
			'bonuses' => $aBonuses,
			//'delivery_conditions' => $aDeliveryConditions,
			'total' => [
				'total_amount_items' => $aCount['total']['totalAmountBefore'],
				'total_quantity' => $quantity,
				'total_discount_items' => $aCount['total']['totalDiscount'],
				'total_discount_order' => $fAppliedDiscountsAmount,
				'total_amount' => $amount,
				'total_delivery_price' => $deliveryPrice,
				'total_order' => $totalOrder,
				'tax' => $tax,
				'total_weight' => $weight,
				'currency' => $currency,
			],
		];

		if ($returnArray) {
			return $aAnswer;
		} else {
			$this->_answer = $aAnswer;
		}
	}

	protected function view()
	{
		$aModels = [
			'shop' => 'Shop_Item',
			'info' => 'Informationsystem_Item',
		];

		if (
			isset($this->_request['type']) &&
			isset($this->_request['id']) &&
			intval($this->_request['id']) > 0 &&
			isset($aModels[$this->_request['type']])
		) {
			$oEntity_Item = Core_Entity::factory(
				$aModels[$this->_request['type']],
				intval($this->_request['id'])
			);

			if ($oEntity_Item->name && !$oEntity_Item->deleted) {
				$oEntity_Item->showed = intval($oEntity_Item->showed) + 1;
				$oEntity_Item->save();

				$thumb = null;
				$aMediaPre = $this->_getMedia($oEntity_Item);
				if (isset($aMediaPre['thumb'])) {
					$thumb = $aMediaPre['thumb'];
				}
				$this->_answer = [
					'id' => $oEntity_Item->id,
					'showed' => $oEntity_Item->showed,
					'name' => $oEntity_Item->name,
					'slug' => $oEntity_Item->path . '-' . $oEntity_Item->id,
					'thumb' => $thumb,
				];
			} else {
				$this->_error = sprintf('Not Found "%s', $this->_request['id']);
				$this->_statusCode = 404;
			}
		} else {
			$this->_error = 'Bad Request';
			$this->_statusCode = 400;
			return false;
		}
	}

	protected function _getSiteuserProfile()
	{
		$login = $email = $phone = $name = $surname = '';

		$token = null;

		$avatar = null;
		$status_tawk = 0;

		if ($this->_oSiteuser) {
			$token = $this->_oSiteuser->guid;
			$email = $this->_oSiteuser->email;
			$login = $this->_oSiteuser->login;
			$oSiteuser_Person = null;
			$aSiteuser_People = $this->_oSiteuser->Siteuser_People->findAll(false);
			if (isset($aSiteuser_People[0])) {
				$oSiteuser_Person = $aSiteuser_People[0];
			}

			if ($oSiteuser_Person) {
				$aDirectory_Phones = $oSiteuser_Person->Directory_Phones->findAll(
					false
				);
				$oPhone = array_shift($aDirectory_Phones);
				$phone = $oPhone->value;
				$name = $oSiteuser_Person->name;
				$surname = $oSiteuser_Person->surname;

				$avatar = $oSiteuser_Person->image
					? $oSiteuser_Person->getImageHref()
					: null;
			}

			// 48 avatar stringConfig
			// $oProperty = Core_Entity::factory('Property', 48);
			// $aPropertyValues = $oProperty->getValues($this->_oSiteuser->id);
			// if (
			// 	isset($aPropertyValues[0]) &&
			// 	trim($aPropertyValues[0]->value) != ''
			// ) {
			// 	$avatar = json_decode($aPropertyValues[0]->value, true);
			// }

			// 49 status_tawk
			$oProperty = Core_Entity::factory('Property', 49);
			$aPropertyValues = $oProperty->getValues($this->_oSiteuser->id);
			if (isset($aPropertyValues[0])) {
				$status_tawk = intval($aPropertyValues[0]->value);
			}
		}

		if (!$phone) {
			$phone = '';
		}
		if (!$name) {
			$name = '';
		}
		if (!$surname) {
			$surname = '';
		}

		// костыль для телефона
		$aPreEmail = explode('@', $email);
		if (
			count($aPreEmail) == 2 &&
			strlen($aPreEmail[0]) == 11 &&
			$aPreEmail[1] == 'riche.skin'
		) {
			$phone = '+' . $aPreEmail[0];

			if ($email == $aPreEmail[0] . '@riche.skin') {
				$email = '';
			}
		}

		return [
			'token' => $token,
			'login' => $login,
			'email' => $email,
			'phone' => $phone,
			'name' => $name,
			'surname' => $surname,
			'avatar' => $avatar,
			'status_tawk' => $status_tawk,
		];
	}

	protected function checkout()
	{
		$oSiteuser = null;
		$sCoupon = null;

		if (isset($this->_request['token'])) {
			$oSiteuser = Core_Entity::factory('Siteuser')->getByGuid(
				$this->_request['token']
			);

			$this->_oSiteuser = $oSiteuser;
		}

		if ($this->_oSiteuser) {
			if (
				isset($this->_request['coupon']) &&
				strlen(trim($this->_request['coupon']))
			) {
				$sCoupon = trim($this->_request['coupon']);
				$this->couponText = $sCoupon;
			}

			$aDelivery = $aPay = [];

			$oShop_Deliveries = $this->_oShop->Shop_Deliveries;
			$oShop_Deliveries
				->queryBuilder()
				->where('active', '=', 1)
				->where('deleted', '=', 0);
			$aShop_Deliveries = $oShop_Deliveries->findAll();

			foreach ($aShop_Deliveries as $oShop_Delivery) {
				$thumb =
					$oShop_Delivery->image != ''
						? $oShop_Delivery->getDeliveryFileHref()
						: null;

				$aDelivery[] = [
					'id' => $oShop_Delivery->id,
					'name' => $oShop_Delivery->name,
					'description' => $oShop_Delivery->description,
					'thumb' => $thumb,
				];
			}

			$oShop_Payment_Systems = $this->_oShop->Shop_Payment_Systems;
			$oShop_Payment_Systems
				->queryBuilder()
				->where('active', '=', 1)
				->where('deleted', '=', 0);
			$aShop_Payment_Systems = $oShop_Payment_Systems->findAll();

			foreach ($aShop_Payment_Systems as $oShop_Payment_System) {
				$thumb =
					$oShop_Payment_System->image != ''
						? $oShop_Payment_System->getPaymentSystemImageFileHref()
						: null;

				$aPay[] = [
					'id' => $oShop_Payment_System->id,
					'name' => $oShop_Payment_System->name,
					'description' => $oShop_Payment_System->description,
					'thumb' => $thumb,
				];
			}

			$profile = $this->_getSiteuserProfile();
			$showSave = true;

			if (
				$profile['email'] &&
				$profile['email'] != '' &&
				($profile['phone'] && $profile['phone'] != '') &&
				($profile['name'] && $profile['name'] != '') &&
				($profile['surname'] && $profile['surname'] != '')
			) {
				$showSave = false;
			}

			$aTotal = null;
			//$aConditions = null;

			$sDeliveryDate = null;

			if (
				isset($this->_request['city_id']) &&
				intval($this->_request['city_id']) > 0
			) {
				$aCartData = $this->cart(true);
				$aTotal = $aCartData['total'];

				//$aConditions = $aCartData['delivery_conditions'];

				//$sDeliveryDate = 'до 26 августа';
				$sDeliveryDate = $this->_getDeliveryDate(
					intval($this->_request['city_id']),
					$this->_request['delivery']
				);

				//intval($this->_request['city_id']),
				//$this->_request['delivery'],
			}

			if ($aTotal) {
				$aTotal['delivery_date'] = $sDeliveryDate;
			}

			$this->_answer = [
				'profile' => $profile,
				'updateprofile' => $showSave,
				'delivery' => $aDelivery,
				//'delivery_conditions' => $aConditions,
				'pay' => $aPay,
				'total' => $aTotal,
				//'zzz' => $aCartData,
			];
		} else {
			$this->_error = 'Authentication Required';
			$this->_statusCode = 401;
		}
	}

	protected function makeorder()
	{
		$oSiteuser = null;
		$sCoupon = null;

		if (isset($this->_request['token'])) {
			$oSiteuser = Core_Entity::factory('Siteuser')->getByGuid(
				$this->_request['token']
			);

			$this->_oSiteuser = $oSiteuser;
		}

		if ($this->_oSiteuser) {
			if (
				isset($this->_request['coupon']) &&
				strlen(trim($this->_request['coupon']))
			) {
				$sCoupon = trim($this->_request['coupon']);
				$this->couponText = $sCoupon;
			}

			$aCartData = $this->cart(true);

			$city_id = intval($this->_request['city_id']);
			$oShop_Country_Location_City = Core_Entity::factory(
				'Shop_Country_Location_City',
				$city_id
			);
			$region_id = $oShop_Country_Location_City->Shop_Country_Location->id;
			$country_id =
				$oShop_Country_Location_City->Shop_Country_Location->Shop_Country->id;

			$oShop_Order = Core_Entity::factory('Shop_Order');
			$oShop_Order->shop_country_id = $country_id;
			$oShop_Order->shop_country_location_id = $region_id;
			$oShop_Order->shop_country_location_city_id = $city_id;
			$oShop_Order->address = strval(
				trim($this->_request['delivery']['delivery_address'])
			);

			$oShop_Order->postcode = strval(
				trim($this->_request['delivery']['delivery_index'])
			);

			$oShop_Order->email = strval(trim($this->_request['profile']['email']));
			$oShop_Order->phone = strval(trim($this->_request['profile']['phone']));
			$oShop_Order->surname = strval(
				trim($this->_request['profile']['surname'])
			);
			$oShop_Order->name = strval(trim($this->_request['profile']['name']));

			if (
				isset($this->_request['profile']['save']) &&
				$this->_request['profile']['save']
			) {
				$oSiteuser->email = strval(trim($this->_request['profile']['email']));
				$oSiteuser->save();
				$oSiteuser_Person = null;
				$aSiteuser_People = $oSiteuser->Siteuser_People->findAll(false);

				if (isset($aSiteuser_People[0])) {
					$oSiteuser_Person = $aSiteuser_People[0];
				} else {
					$oSiteuser_Person = Core_Entity::factory('Siteuser_Person');
					$oSiteuser_Person->siteuser_id = $this->_oSiteuser->id;
					$oSiteuser_Person->save();
				}

				if ($oSiteuser_Person) {
					if (isset($this->_request['profile']['phone'])) {
						// Телефон
						$oDirectory_Phone_Type = Core_Entity::factory(
							'Directory_Phone_Type'
						)->getByName('Рабочий');
						if (is_null($oDirectory_Phone_Type)) {
							$oDirectory_Phone_Type = Core_Entity::factory(
								'Directory_Phone_Type'
							);
							$oDirectory_Phone_Type->name = Core::_(
								'Directory_Phone_Type.default_name'
							);
							$oDirectory_Phone_Type->save();
						}

						$aDirectory_Phones = $oSiteuser_Person->Directory_Phones->findAll(
							false
						);
						if (isset($aDirectory_Phones[0])) {
							$oDirectory_Phone = $aDirectory_Phones[0];

							$oPhone = array_shift($aDirectory_Phones);

							$oPhone->value = $this->_request['profile']['phone'];
							$oPhone->save();
						} else {
							$oDirectory_Phone = Core_Entity::factory('Directory_Phone');
							$oDirectory_Phone->directory_phone_type_id =
								$oDirectory_Phone_Type->id;
							$oDirectory_Phone->public = 0;

							$oDirectory_Phone->value = $this->_request['profile']['phone'];
							$oDirectory_Phone->save();

							$oSiteuser_Person->add($oDirectory_Phone);
						}
					}

					if (isset($this->_request['profile']['name'])) {
						$oSiteuser_Person->name = $this->_request['profile']['name'];
						$oSiteuser_Person->save();
					}

					if (isset($this->_request['profile']['surname'])) {
						$oSiteuser_Person->surname = $this->_request['profile']['surname'];
						$oSiteuser_Person->save();
					}
				}
			}

			$shop_delivery_id =
				$this->_aDeliveryTypes[$this->_request['delivery']['delivery_type']];

			$oShop_Delivery = Core_Entity::factory(
				'Shop_Delivery',
				$shop_delivery_id
			);

			$oShop_Order->shop_delivery_id = $oShop_Delivery->id;
			$oShop_Order->shop_payment_system_id = $this->_request['pay_id'];

			$oShop_Order->shop_currency_id = intval($this->_oShop->shop_currency_id);
			$oShop_Order->shop_order_status_id = intval(
				$this->_oShop->shop_order_status_id
			);

			$oShop_Order->siteuser_id = $this->_oSiteuser->id;

			$this->_oShop->add($oShop_Order);

			$oShop_Order->createInvoice()->save();

			// add props
			$aProps = [
				25 => strval($this->_request['delivery']['delivery_provider']), // delivery_provider
				26 => intval($this->_request['delivery']['apiship_point_id']), // apiship_point_id
			];

			foreach ($aProps as $key => $value) {
				$oProperty = Core_Entity::factory('Property', $key);
				$oProperty_Value = $oProperty->createNewValue($oShop_Order->id);
				$oProperty_Value->value($value);
				$oProperty_Value->save();
			}

			$tariffId = 0;

			switch ($this->_request['delivery']['delivery_provider']) {
				case 'cdek':
					$tariffId = 53;
					break;
				case 'rupost':
					$tariffId = 277;
					break;
				case 'x5':
					$tariffId = 439;
					break;
				case 'dpd':
					$tariffId = 15;
					break;
				case 'cse':
					$tariffId = 143;
					break;
				default:
					$tariffId = 0;
					break;
			}

			$oProperty = Core_Entity::factory('Property', 27);
			$oProperty_Value = $oProperty->createNewValue($oShop_Order->id);
			$oProperty_Value->value($tariffId);
			$oProperty_Value->save();

			// add Items
			foreach ($aCartData['cart'] as $item) {
				if ($item['cart']['quantity'] > 0) {
					$oShop_Order_Item = Core_Entity::factory('Shop_Order_Item');
					$oShop_Order_Item->quantity = $item['cart']['quantity'];
					$oShop_Order_Item->shop_measure_id = 27; //шт
					$oShop_Order_Item->shop_item_id = $item['cart']['id'];

					$oShop_Order_Item->price = $item['cart']['price'];
					$oShop_Order_Item->name = $item['name'];
					$oShop_Order_Item->type = 0;
					$oShop_Order_Item->marking = $item['marking'];

					// Статус товаров по умолчанию.
					if (
						$this->_oShop->shop_order_status_id &&
						$this->_oShop->shop_order_status_id ==
							$oShop_Order->shop_order_status_id &&
						$oShop_Order->Shop_Order_Status->shop_order_item_status_id
					) {
						$oShop_Order_Item->shop_order_item_status_id =
							$oShop_Order->Shop_Order_Status->shop_order_item_status_id;
					}

					$oShop_Order->add($oShop_Order_Item);
				}
			}

			// Save coupon
			if ($aCartData['coupon']) {
				$oShop_Order->coupon = $aCartData['coupon'];
				$oShop_Order->save();
			}

			// скидки от суммы заказа
			if ($aCartData['total']['total_discount_order']) {
				$oShop_Order_Item = Core_Entity::factory('Shop_Order_Item');
				$oShop_Order_Item->quantity = 1;
				$oShop_Order_Item->shop_measure_id = 27; //шт

				$oShop_Order_Item->price =
					$aCartData['total']['total_discount_order'] * -1;
				$oShop_Order_Item->name = 'Дополнительные скидки';
				$oShop_Order_Item->type = 3;

				$oShop_Order->add($oShop_Order_Item);
			}

			// Доставка
			$sDeliveryName = $oShop_Delivery->name;
			$sDeliveryProviderName = isset(
				$this->_aProviders[$this->_request['delivery']['delivery_provider']]
			)
				? $this->_aProviders[$this->_request['delivery']['delivery_provider']]
				: '';

			$oShop_Order_Item = Core_Entity::factory('Shop_Order_Item');
			$oShop_Order_Item->quantity = 1;
			$oShop_Order_Item->shop_measure_id = 27; //шт

			$oShop_Order_Item->price = $aCartData['total']['total_delivery_price'];
			$oShop_Order_Item->marking =
				$this->_request['delivery']['delivery_provider'];
			$oShop_Order_Item->name =
				'Доставка: ' . $sDeliveryName . ' ' . $sDeliveryProviderName;
			$oShop_Order_Item->type = 1;

			$oShop_Order->add($oShop_Order_Item);

			// explode New order
			$shopObserverHmp = new Shop_Observer_Hmp();
			$shopObserverHmp->Shop_Order__Explode($oShop_Order);

			$oShop_Payment_System_Handler = Shop_Payment_System_Handler::factory(
				Core_Entity::factory(
					'Shop_Payment_System',
					$oShop_Order->shop_payment_system_id
				)
			);

			$oShop_Payment_System_Handler
				->shopOrder($oShop_Order)
				->setXSLs()
				->sendOrderData();

			// создание заказа в ретаил
			$oApp_Controller_Retailcrm = new App_Controller_Retailcrm($this->_oShop);
			$oApp_Controller_Retailcrm->createOrder($oShop_Order);
			//$aOrders = $oApp_Controller_Retailcrm->createOrder($oShop_Order);
			//$aOrders = $oApp_Controller_Retailcrm->createOrder($oShop_Order);

			// $this->_answer = [
			//   //'return' => null,
			//   'return' => $aOrders,
			// ];

			//_aProviders

			$shopObserverHmp = new Shop_Observer_Hmp();
			$aItemsPre = $shopObserverHmp->Shop_Order__Print($oShop_Order);

			$aOrderItems = [];

			foreach ($aItemsPre as $item) {
				$oShop_Item_Tmp = Core_Entity::factory(
					'Shop_Item',
					$item['shop_item_id']
				);

				$aOrderItems[] = [
					'id' => $item['shop_item_id'],
					'name' => $item['name'],
					'price' => floatval($item['price_before_sale']),
					'quantity' => floatval($item['quantity']),
					'category' => $oShop_Item_Tmp->Shop_Group->name,
				];
			}

			$this->_answer = [
				'order' => $oShop_Order->toArray(),
				'items' => $aOrderItems,
			];
		} else {
			$this->_error = 'Authentication Required';
			$this->_statusCode = 401;
		}
	}

	protected function _getOrdersItemComments($userId, $itemId, $date = false)
	{
		$return = $itemId;
		$endDate = Core_Date::timestamp2datetime(strtotime('-90 days', time()));

		$oQueryBuilderSelect = Core_QueryBuilder::select();
		$oQueryBuilderSelect
			//->sqlCalcFoundRows()
			->select('comments.id', 'comments.datetime')
			->from('comments')

			->leftJoin(
				'comment_shop_items',
				'comment_shop_items.comment_id',
				'=',
				'comments.id'
			)
			->where('comments.siteuser_id', '=', $userId)
			->where('comments.active', 'IN', [0, 1])
			->where('comments.deleted', '=', 0)
			->where('comments.parent_id', '=', 0)
			->where('comments.datetime', '>=', $endDate)
			->where('comment_shop_items.shop_item_id', '=', $itemId)
			->groupBy('comment_shop_items.shop_item_id')

			->clearOrderBy()
			->orderBy('comments.datetime', 'DESC');

		// echo $oQueryBuilderSelect->execute()->getLastQuery();
		// echo $endDate;

		$aResult = $oQueryBuilderSelect
			->execute()
			->asAssoc()
			->result();

		if (count($aResult)) {
			$return = false;
		}

		if (
			$date &&
			count($aResult) &&
			$aResult[0]['datetime'] != '000-00-00 00:00:00'
		) {
			$return = $aResult[0]['datetime'];
		}
		return $return;
	}

	protected function _getOrdersForUser(
		$oSiteuser,
		$limit = 0,
		$aStatus = false,
		$short = false
	) {
		$aOrders = [];
		$oShop_Orders = $oSiteuser->Shop_Orders;
		if ($limit && $limit > 0) {
			$oShop_Orders->queryBuilder()->limit($limit);
		}

		if ($aStatus && is_array($aStatus) && count($aStatus)) {
			$oShop_Orders
				->queryBuilder()
				->where('shop_order_status_id', 'IN', $aStatus);
		}

		$aHistory = [];

		if (isset($this->_request['guid'])) {
			$oShop_Orders
				->queryBuilder()
				->where('guid', '=', $this->_request['guid']);

			$aCheckStatuses = [
				3, // Доставляется
				4, // Ожидает выдачи
			];
			$object = Core_Entity::factory('Shop_Order')->getByGuid(
				$this->_request['guid']
			);
			// if($object)
			// {
			//   $aHistory = $this->apiship_history($object->invoice);
			// }
			if ($object && in_array($object->shop_order_status_id, $aCheckStatuses)) {
				$aHistory = $this->apiship_history($object->invoice);
			}
		}

		$oShop_Orders
			->queryBuilder()
			->clearOrderBy()
			->orderBy('datetime', 'DESC');

		$aShop_Orders = $oShop_Orders->findAll(false);

		foreach ($aShop_Orders as $oShop_Order) {
			$aAddress = [];
			$aAddress[] = $oShop_Order->Shop_Country->name;
			$aAddress[] = $oShop_Order->Shop_Country_Location->name;
			$aAddress[] = $oShop_Order->Shop_Country_Location_City->name;
			$aAddress[] = $oShop_Order->address;

			$aGoods = [];
			$amount = $totalQuantity = 0;
			$currency = '';
			$aShop_Order_Items = $oShop_Order->Shop_Order_Items->findAll(false);

			$realDeliveryProvider = $realDeliveryName = $realDeliveryUrl = null;
			$realDeliveryTrack = $oShop_Order->delivery_information;

			$commentItems = [];

			foreach ($aShop_Order_Items as $oShop_Order_Item) {
				$slug =
					$oShop_Order_Item->type == 0
						? $oShop_Order_Item->Shop_Item->path .
							'-' .
							$oShop_Order_Item->Shop_Item->id
						: null;

				$thumb = null;

				if ($oShop_Order_Item->type == 1) {
					$realDeliveryProvider = $oShop_Order_Item->marking;
				}

				if ($oShop_Order_Item->type == 0) {
					$aMediaPre = $this->_getMedia($oShop_Order_Item->Shop_Item);
					if (isset($aMediaPre['thumb'])) {
						$thumb = $aMediaPre['thumb'];
					}
				}

				if ($oShop_Order->Shop->Shop_Currency) {
					$oShopCurrency = $oShop_Order->Shop->Shop_Currency;
					$currency = $oShopCurrency->sign;
				}

				// статус выполнен
				if (
					$oShop_Order->Shop_Order_Status->id == 5 &&
					$oShop_Order_Item->type == 0
				) {
					$itemId =
						$oShop_Order_Item->type == 0 && $oShop_Order_Item->Shop_Item->name
							? $oShop_Order_Item->Shop_Item->id
							: null;

					$hasComment = $itemId
						? $this->_getOrdersItemComments($oSiteuser->id, $itemId)
						: false;

					$canComment = $hasComment ? true : false;
					$lastAdd = null;
					if (!$canComment) {
						$lastAdd = $this->_getOrdersItemComments(
							$oSiteuser->id,
							$itemId,
							true
						);
					}

					$commentItems[] = [
						'id' => $oShop_Order_Item->shop_item_id,
						'name' => $oShop_Order_Item->name,
						'marking' => $oShop_Order_Item->marking,
						'slug' => $slug,
						'thumb' => $thumb,
						'cancomment' => $canComment,
						'lastadd' => $lastAdd,
					];
				}

				$aGoods[] = [
					'id' => $oShop_Order_Item->shop_item_id,
					'name' => $oShop_Order_Item->name,
					'marking' => $oShop_Order_Item->marking,
					'slug' => $slug,
					'thumb' => $thumb,
					'price' => $oShop_Order_Item->price,
					'quantity' => floatval($oShop_Order_Item->quantity),
					'total' => $oShop_Order_Item->price * $oShop_Order_Item->quantity,
					'currency' => $currency,
					'type' => $oShop_Order_Item->type,
				];
				$amount += $oShop_Order_Item->price * $oShop_Order_Item->quantity;
				$totalQuantity += $oShop_Order_Item->quantity;
			}

			$aComments = [
				'order' => false,
				'items' => $commentItems,
			];

			// $userShopItems = Core_Entity::factory('Shop_Item');
			// 	$userShopItems
			// 		->queryBuilder()
			// 		->leftJoin(
			// 			'shop_order_items',
			// 			'shop_order_items.shop_item_id',
			// 			'=',
			// 			'shop_items.id'
			// 		)
			// 		->leftJoin(
			// 			'shop_orders',
			// 			'shop_orders.id',
			// 			'=',
			// 			'shop_order_items.shop_order_id'
			// 		)
			// 		->leftJoin(
			// 			'comment_shop_items',
			// 			'comment_shop_items.shop_item_id',
			// 			'=',
			// 			'shop_items.id'
			// 		)
			// 		->leftJoin(
			// 			'comments',
			// 			'comments.id',
			// 			'=',
			// 			'comment_shop_items.comment_id'
			// 		)
			// 		->where('shop_items.active', '=', 1)
			// 		->where('shop_items.deleted', '=', 0)
			// 		->where('shop_items.modification_id', '=', $oShop_item->id)
			// 		->where('shop_order_items.deleted', '=', 0)
			// 		->where('shop_orders.deleted', '=', 0)
			// 		->where('shop_orders.canceled', '=', 0)
			// 		->where('shop_orders.siteuser_id', '=', $oSiteuser->id)
			// 		->having(
			// 			Core_QueryBuilder::raw(
			// 				'SUM(IF(comments.siteuser_id = ' .
			// 					$oSiteuser->id .
			// 					' AND comments.active = 1 AND comments.deleted = 0, 1, 0))'
			// 			),
			// 			'=',
			// 			0
			// 		)
			// 		->groupBy('shop_items.id')
			// 		->orderBy('shop_items.marking');

			// 	$userShopItemsList = $userShopItems->findAll();

			$aI = [
				'id' => $oShop_Order->id,
				'guid' => $oShop_Order->guid,
				'invoice' => $oShop_Order->invoice,
				'datetime' => $oShop_Order->datetime,
				'paid' => boolval($oShop_Order->paid),
				'payment_datetime' => $oShop_Order->payment_datetime,
				'canceled' => boolval($oShop_Order->canceled),
				'delivery_information' => $oShop_Order->delivery_information,

				'amount' => $amount,
				'currency' => $currency,
				'quantity' => $totalQuantity,

				'status' => [
					'id' => $oShop_Order->Shop_Order_Status->id,
					'name' => $oShop_Order->Shop_Order_Status->name,
					'datetime' => $oShop_Order->status_datetime,
					'color' => $oShop_Order->Shop_Order_Status->color,
				],
				'goods' => $aGoods,
				'comments' => $aComments,
			];

			switch ($realDeliveryProvider) {
				case 'cdek':
					$realDeliveryUrl =
						'https://www.cdek.ru/ru/tracking?order_id=' . $realDeliveryTrack;
					$realDeliveryName = 'СДЭК';
					break;
				case 'rupost':
					$realDeliveryUrl =
						'https://www.pochta.ru/tracking?barcode=' . $realDeliveryTrack;
					$realDeliveryName = 'Почта России';
					break;
				case 'x5':
					$realDeliveryUrl =
						'https://fivepost.ru/tracking/?id=' . $realDeliveryTrack;
					$realDeliveryName = '5Post';
					break;
				case 'dpd':
					$realDeliveryUrl =
						'https://old.dpd.ru/dpd/search/search.do2?query=' .
						$realDeliveryTrack;
					$realDeliveryName = 'DPD';
					break;
				case 'cse':
					$realDeliveryUrl =
						'https://www.cse.ru/mow/track?numbers=' . $realDeliveryTrack;
					$realDeliveryName = 'CSE';
					break;
			}

			if (!$short) {
				$aI['person'] = [
					'email' => $oShop_Order->email,
					'phone' => $oShop_Order->phone,
					'name' => $oShop_Order->name,
					'surname' => $oShop_Order->surname,
				];
				$aI['address'] = [
					'country' => [
						'id' => $oShop_Order->Shop_Country->id,
						'name' => $oShop_Order->Shop_Country->name,
					],
					'location' => [
						'id' => $oShop_Order->Shop_Country_Location->id,
						'name' => $oShop_Order->Shop_Country_Location->name,
					],
					'city' => [
						'id' => $oShop_Order->Shop_Country_Location_City->id,
						'name' => $oShop_Order->Shop_Country_Location_City->name,
					],
					'address' => [
						'name' => $oShop_Order->address,
						'full' => implode(', ', $aAddress),
					],
				];

				$aI['delivery'] = [
					'id' => $oShop_Order->Shop_Delivery->id,
					'name' => $oShop_Order->Shop_Delivery->name,
					'provider_name' => $realDeliveryName,
					'track' => $realDeliveryTrack,
					'track_url' => $realDeliveryUrl,
					'track_history' => $aHistory,
				];
				$aI['payment'] = [
					'id' => $oShop_Order->Shop_Payment_System->id,
					'name' => $oShop_Order->Shop_Payment_System->name,
				];
			}

			$aOrders[] = $aI;
		}

		return $aOrders;
	}

	protected function orderhistory()
	{
		$oSiteuser = null;
		$aOrders = [];
		$aStatuses = [];
		$aTypesPre = [
			0 => 'Товар',
			1 => 'Доставка',
			2 => 'Пополнение лицевого счета',
			3 => 'Скидка от суммы заказа',
			4 => 'Скидка по дисконтной карте',
			5 => 'Списание бонусов',
			6 => 'Частичная оплата с лицевого счета',
		];

		if (isset($this->_request['token'])) {
			$oSiteuser = Core_Entity::factory('Siteuser')->getByGuid(
				$this->_request['token']
			);

			$this->_oSiteuser = $oSiteuser;
		}

		if ($this->_oSiteuser) {
			if (
				isset($this->_request['paydata']) &&
				$this->_request['paydata'] &&
				isset($this->_request['guid'])
			) {
				//authData

				$oShop_Order = Core_Entity::factory('Shop_Order')->getByGuid(
					$this->_request['guid']
				);

				if (
					$oShop_Order &&
					$oShop_Order->siteuser_id == $this->_oSiteuser->id
				) {
					$oShop_Payment_System_Handler = Shop_Payment_System_Handler::factory(
						Core_Entity::factory(
							'Shop_Payment_System',
							$oShop_Order->shop_payment_system_id
						)
					);

					$aStatus = $oShop_Payment_System_Handler
						->shopOrder($oShop_Order)
						->getStatus();

					$this->_answer = [
						'order' => [
							'id' => $oShop_Order->id,
							'invoice' => $oShop_Order->invoice,
							'guid' => $oShop_Order->guid,
							'amount' => $oShop_Order->getAmount(),
							'currency' => $oShop_Order->Shop_Currency->sign,
						],

						'handler' => $aStatus,
					];
				} else {
					$this->_error = 'Authentication Required';
					$this->_statusCode = 401;
				}
			} else {
				$aTypes = [];
				foreach ($aTypesPre as $key => $value) {
					$aTypes[] = [
						'id' => $key,
						'name' => $value,
					];
				}

				$aOrders = $this->_getOrdersForUser($oSiteuser, 0, false, false);

				$oQueryBuilderSelect = Core_QueryBuilder::select();
				$oQueryBuilderSelect
					->select('id', 'name')
					->from('shop_order_statuses')
					->where('deleted', '=', 0);

				//echo $oQueryBuilderSelect->execute()->getLastQuery();
				$aResult = $oQueryBuilderSelect
					->execute()
					->asAssoc()
					->result();

				foreach ($aResult as $item) {
					$aStatuses[] = [
						'id' => $item['id'],
						'name' => $item['name'],
					];
				}

				$this->_answer = [
					'statuses' => $aStatuses,
					'types' => $aTypes,
					'orders' => $aOrders,
				];
			}
		} else {
			$this->_error = 'Authentication Required';
			$this->_statusCode = 401;
		}
	}

	protected function commentshistory()
	{
		$oSiteuser = null;

		if (isset($this->_request['token'])) {
			$oSiteuser = Core_Entity::factory('Siteuser')->getByGuid(
				$this->_request['token']
			);

			$this->_oSiteuser = $oSiteuser;
		}

		if ($this->_oSiteuser) {
			$aCommentsList = [];

			$oComment = Core_Entity::factory('Comment');

			$oComment
				->queryBuilder()
				->leftJoin(
					'comment_shop_items',
					'comments.id',
					'=',
					'comment_shop_items.comment_id '
				)
				->where('active', '=', 1)
				->where('deleted', '=', 0)
				->where('parent_id', '=', 0)
				->where('siteuser_id', '=', $this->_oSiteuser->id)
				->orderBy('datetime', 'DESC');

			$aComments = $oComment->findAll();

			foreach ($aComments as $oComment) {
				$aCommentsList[] = $this->_commentCard($oComment, true);
			}

			// $aPagination = [
			// 	'totalCount' => intval($total),
			// 	'pageCount' => ceil(intval($total) / intval($limit)),
			// 	'currentPage' => intval($page),
			// 	'perPage' => intval($limit),
			// ];

			//var_dump($aCommentsList);

			// $aAnswer = [
			// 	// 'pagination' => $aPagination,
			// 	'comments' => $aCommentsList,
			// ];

			// print_r($aAnswer);

			// //echo json_encode($aAnswer, JSON_UNESCAPED_UNICODE);
			// exit();

			$this->_answer = [
				// 'pagination' => $aPagination,
				'comments' => $aCommentsList,
			];
		} else {
			$this->_error = 'Authentication Required';
			$this->_statusCode = 401;
		}
	}

	protected function me()
	{
		$oSiteuser = null;

		if (isset($this->_request['token'])) {
			$oSiteuser = Core_Entity::factory('Siteuser')->getByGuid(
				$this->_request['token']
			);

			$this->_oSiteuser = $oSiteuser;
		}

		$aOrders = null;
		if (isset($this->_request['orders']) && $this->_request['orders']) {
			$aOrders = $this->_getOrdersForUser($oSiteuser, 6, [1, 2, 3, 4], true);
		}

		if ($this->_oSiteuser) {
			$aStatusTawk = [['id' => 0, 'name' => 'Не указан', 'sorting' => -1]];

			$oQueryBuilder = Core_QueryBuilder::select();
			$oQueryBuilder
				->select('id', 'value', 'sorting')
				->from('list_items')
				->where('active', '=', 1)
				->where('deleted', '=', 0)
				->where('list_id', '=', 11)
				->clearOrderBy()
				->orderBy('sorting', 'ASC');

			//echo $oQueryBuilderSelect->execute()->getLastQuery();
			$aResult = $oQueryBuilder
				->execute()
				->asAssoc()
				->result();

			foreach ($aResult as $item) {
				$aStatusTawk[] = [
					'id' => intval($item['id']),
					'name' => $item['value'],
					'sorting' => $item['sorting'],
				];
			}

			$this->_answer = [
				'orders' => $aOrders,
				'profile' => $this->_getSiteuserProfile(),
				'statuses_tawk' => $aStatusTawk,
			];
		} else {
			$this->_error = 'Authentication Required';
			$this->_statusCode = 401;
		}
	}

	protected function updateprofile()
	{
		$oSiteuser = null;

		// $post = $_POST;
		// $this->_answer = $post;

		if (isset($this->_request['token'])) {
			$oSiteuser = Core_Entity::factory('Siteuser')->getByGuid(
				$this->_request['token']
			);

			$this->_oSiteuser = $oSiteuser;
		}

		if ($this->_oSiteuser) {
			if (
				isset($this->_request['email']) &&
				Core_Valid::email($this->_request['email'])
			) {
				//$oSiteuser->email = $login . '@riche.skin';

				$this->_oSiteuser->email = $this->_request['email'];
				$this->_oSiteuser->save();
			}

			$oSiteuser_Person = null;
			$aSiteuser_People = $oSiteuser->Siteuser_People->findAll(false);

			if (isset($aSiteuser_People[0])) {
				$oSiteuser_Person = $aSiteuser_People[0];
			} else {
				$oSiteuser_Person = Core_Entity::factory('Siteuser_Person');
				$oSiteuser_Person->siteuser_id = $this->_oSiteuser->id;
				$oSiteuser_Person->save();
			}

			//var_dump($oSiteuser_Person->id);

			if ($oSiteuser_Person) {
				if (isset($this->_request['phone'])) {
					// Телефон
					$oDirectory_Phone_Type = Core_Entity::factory(
						'Directory_Phone_Type'
					)->getByName('Рабочий');
					if (is_null($oDirectory_Phone_Type)) {
						$oDirectory_Phone_Type = Core_Entity::factory(
							'Directory_Phone_Type'
						);
						$oDirectory_Phone_Type->name = Core::_(
							'Directory_Phone_Type.default_name'
						);
						$oDirectory_Phone_Type->save();
					}

					$aDirectory_Phones = $oSiteuser_Person->Directory_Phones->findAll(
						false
					);
					if (isset($aDirectory_Phones[0])) {
						$oDirectory_Phone = $aDirectory_Phones[0];

						$oPhone = array_shift($aDirectory_Phones);

						$oPhone->value = $this->_request['phone'];
						$oPhone->save();
					} else {
						$oDirectory_Phone = Core_Entity::factory('Directory_Phone');
						$oDirectory_Phone->directory_phone_type_id =
							$oDirectory_Phone_Type->id;
						$oDirectory_Phone->public = 0;

						$oDirectory_Phone->value = $this->_request['phone'];
						$oDirectory_Phone->save();

						$oSiteuser_Person->add($oDirectory_Phone);
					}
				}

				if (isset($this->_request['name'])) {
					$oSiteuser_Person->name = $this->_request['name'];
					$oSiteuser_Person->save();
				}

				if (isset($this->_request['surname'])) {
					$oSiteuser_Person->surname = $this->_request['surname'];
					$oSiteuser_Person->save();
				}
			}

			if (isset($this->_request['avatar'])) {
				$oProperty = Core_Entity::factory('Property', 48);
				$aPropertyValues = $oProperty->getValues($this->_oSiteuser->id);

				$oProperty_Value = null;
				if (isset($aPropertyValues[0])) {
					$oProperty_Value = $aPropertyValues[0];
				} else {
					$oProperty_Value = $oProperty->createNewValue($this->_oSiteuser->id);
				}

				if ($oProperty_Value) {
					$oProperty_Value->value = json_encode($this->_request['avatar']);
					$oProperty_Value->save();
				}
			}

			if (isset($this->_request['status_tawk'])) {
				$oProperty = Core_Entity::factory('Property', 49);
				$aPropertyValues = $oProperty->getValues($this->_oSiteuser->id);

				$oProperty_Value = null;
				if (isset($aPropertyValues[0])) {
					$oProperty_Value = $aPropertyValues[0];
				} else {
					$oProperty_Value = $oProperty->createNewValue($this->_oSiteuser->id);
				}

				if ($oProperty_Value) {
					$oProperty_Value->value = intval($this->_request['status_tawk']);
					$oProperty_Value->save();
				}
			}

			$this->_answer = [
				//'req' => $this->_request,
				'profile' => $this->_getSiteuserProfile(),
			];
		} else {
			$this->_error = 'Authentication Required';
			$this->_statusCode = 401;
		}
	}
	protected function updatepassword()
	{
		$oSiteuser = null;

		if (isset($this->_request['token'])) {
			$oSiteuser = Core_Entity::factory('Siteuser')->getByGuid(
				$this->_request['token']
			);

			$this->_oSiteuser = $oSiteuser;
		}

		if (
			$this->_oSiteuser &&
			isset($this->_request['password']) &&
			strlen($this->_request['password'])
		) {
			$pass = Core_Hash::instance()->hash($this->_request['password']);
			$oSiteuser->password = $pass;
			$oSiteuser->save();

			$this->_answer = [
				//'req' => $this->_request,
				'profile' => $this->_getSiteuserProfile(),
				//'password' => $this->_oSiteuser->password,
			];
		} else {
			$this->_error = 'Authentication Required';
			$this->_statusCode = 401;
		}
	}

	protected function apiship_history($invoice)
	{
		$aReturn = [];
		$token = 'edc44f43713b0330176c21a9c8393fcf';

		if ($invoice == 'RU-10779') {
			$invoice = 'RU-10743';
		}

		$url =
			'https://api.apiship.ru/v1/orders/status/history?clientNumber=' .
			$invoice;

		$Core_Http = Core_Http::instance('curl')
			->clear()
			->timeout(5)
			->method('GET')
			->url($url)
			->additionalHeader('Content-Type', 'application/json')
			->additionalHeader('Accept', 'application/json')
			->additionalHeader('Authorization', $token)
			->execute();

		$aAnswer = json_decode($Core_Http->getDecompressedBody(), true);

		//$aReturn = $aAnswer;

		if (isset($aAnswer['statuses'])) {
			$aReturn = $aAnswer['statuses'];
		}

		return $aReturn;
	}

	protected function apiship_list_points()
	{
		$token = 'edc44f43713b0330176c21a9c8393fcf';

		if (
			isset($this->_request['city_id']) &&
			intval($this->_request['city_id']) > 0
		) {
			$oCity = Core_Entity::factory(
				'Shop_Country_Location_City',
				intval($this->_request['city_id'])
			);

			//       [
			//   {
			//     "id": 1,
			//     "description": "Пункт выдачи заказа"
			//   },
			//   {
			//     "id": 2,
			//     "description": "Постамат"
			//   },
			//   {
			//     "id": 3,
			//     "description": "Отделение Почты России"
			//   },
			//   {
			//     "id": 4,
			//     "description": "Терминал"
			//   }
			// ]

			$aTypes = [1, 2, 3, 4];
			//$aProviders = ['cdek', 'rupost', 'x5', 'dpd', 'cse'];
			//$aProviders = ['cdek', 'rupost', 'dpd', 'cse'];
			$aProviders = ['cdek', 'rupost', 'cse'];

			$aFields = [
				'id',
				'providerKey',
				'name',
				'address',
				'street',
				'streetType',
				'house',
				'lat',
				'lng',
				'code',
				'postIndex',
			];

			$limit = 1000;

			$url =
				'https://api.apiship.ru/v1/lists/points?filter=city=' . $oCity->name;

			$url .= ';cityType=г';
			$url .= ';type=[' . implode(',', $aTypes) . ']';
			$url .= ';providerKey=[' . implode(',', $aProviders) . ']';
			$url .= ';availableOperation=[2,3]';

			if (count($aFields)) {
				$url .= '&fields=' . implode(',', $aFields);
			}

			if ($limit) {
				$url .= '&limit=' . $limit;
			}

			$Core_Http = Core_Http::instance('curl')
				->clear()
				->timeout(5)
				->method('GET')
				->url($url)
				->additionalHeader('Content-Type', 'application/json')
				->additionalHeader('Accept', 'application/json')
				->additionalHeader('Authorization', $token)
				->execute();

			$aAnswer = json_decode($Core_Http->getDecompressedBody(), true);

			$this->_answer = $aAnswer;
		} else {
			$this->_error = 'Wrong POST data';
			$this->_statusCode = 422;

			return false;
		}
	}

	protected function comment_vote()
	{
		$oSiteuser = null;

		if (isset($this->_request['token'])) {
			$oSiteuser = Core_Entity::factory('Siteuser')->getByGuid(
				$this->_request['token']
			);

			$this->_oSiteuser = $oSiteuser;
		}

		if ($this->_oSiteuser) {
			$entity_id = intval($this->_request['id']);
			$vote = intval($this->_request['vote']);
			$entity_type = 'comment';

			$deleteVote = 0;
			$aAnswer = [];
			//$aAnswer = Vote_Controller::instance()->getRate($entity_type, $entity_id);

			$oObject = Vote_Controller::instance()->getVotedObject(
				$entity_type,
				$entity_id
			);

			// var_dump($entity_id);
			// var_dump($vote);
			//var_dump($aAnswer);
			// var_dump($oObject);
			//exit();

			if (!is_null($oObject)) {
				$oVote = $oObject->Votes->getBySiteuser_Id($this->_oSiteuser->id);

				// var_dump($oVote);
				// exit();

				$vote_value = $vote ? 1 : -1;

				// var_dump($aAnswer);
				// var_dump($vote_value);
				// var_dump(is_null($oVote));
				// var_dump($oVote->value != $vote_value);
				// exit();

				// Пользователь не голосовал ранее
				if (is_null($oVote)) {
					$oVote = Core_Entity::factory('Vote');
					$oVote->siteuser_id = $oSiteuser->id;
					$oVote->value = $vote_value;

					$oObject->add($oVote);
				}
				// Пользователь голосовал ранее, но поставил противоположную оценку
				elseif ($oVote->value != $vote_value) {
					$oVote->value = $vote_value;
					$oVote->save();
				}
				// Пользователь голосовал ранее и поставил такую же оценку как и ранее, обнуляем его голосование, как будто он вообще не голосовал
				else {
					$deleteVote = 1;
					$oVote->delete();
				}

				Core_Entity::factory('Shop_Item', $entity_id)->clearCache();

				$aAnswer = Vote_Controller::instance()->getRate(
					$entity_type,
					$entity_id
				);
			}

			$aAnswer['delete_vote'] = $deleteVote;

			$this->_answer = $aAnswer;

			// $this->_answer = [
			//   'req' => $this->_request,
			//   'profile' => $this->_getSiteuserProfile(),
			//   //'password' => $this->_oSiteuser->password,
			// ];
		} else {
			$this->_error = 'Authentication Required';
			$this->_statusCode = 401;
			//return false;
		}
	}

	protected function comment_add()
	{
		$oSiteuser = null;

		if (isset($this->_request['token'])) {
			$oSiteuser = Core_Entity::factory('Siteuser')->getByGuid(
				$this->_request['token']
			);

			$this->_oSiteuser = $oSiteuser;
		}

		if ($this->_oSiteuser) {
			// item_id: item_id, //!
			// parent_id: commentid, //!
			// rate: null,
			// advantages: null,
			// flaws: null,
			// text: data.text,
			// token: session.token,

			$item_id = intval($this->_request['item_id']);
			$parent_id = intval($this->_request['parent_id']);
			$rate = intval($this->_request['rate']);
			$advantages = strval(trim($this->_request['advantages']));
			$flaws = strval(trim($this->_request['flaws']));
			$text = strval(trim($this->_request['text']));
			$comment_id = isset($this->_request['comment_id'])
				? intval($this->_request['comment_id'])
				: 0;

			$allowable_tags = '<b><strong><i><em><br><p><u><strike><ul><ol><li>';

			if ($comment_id) {
				$oComment = Core_Entity::factory('Comment')->find($comment_id);

				// var_dump($oComment->toArray());
				// var_dump($oComment->siteuser_id);
				// exit();

				if ($oComment->id) {
					// текст комментария
					$oComment->text = nl2br(Core_Str::stripTags($text, $allowable_tags));

					$oComment->grade = $rate;

					// $advantages
					$oProperty = Core_Entity::factory('Property', 33);
					$oProperty_Value = null;

					$aPropertyValues = $oProperty->getValues($oComment->id);
					if (count($aPropertyValues)) {
						$oProperty_Value = $aPropertyValues[0];
					} else {
						$oProperty_Value = $oProperty->createNewValue($oComment->id);
					}

					$oProperty_Value->value(Core_Str::stripTags(strval($advantages)));
					$oProperty_Value->save();

					//$flaws
					$oProperty = Core_Entity::factory('Property', 36);
					$oProperty_Value = null;

					$aPropertyValues = $oProperty->getValues($oComment->id);

					if (count($aPropertyValues)) {
						$oProperty_Value = $aPropertyValues[0];
					} else {
						$oProperty_Value = $oProperty->createNewValue($oComment->id);
					}

					$oProperty_Value->value(Core_Str::stripTags(strval($flaws)));
					$oProperty_Value->save();

					// помечаем что изправлен
					$oProperty = Core_Entity::factory('Property', 50);
					$oProperty_Value = null;

					$aPropertyValues = $oProperty->getValues($oComment->id);
					if (isset($aPropertyValues[0]) && $aPropertyValues[0]->value != '') {
						$oProperty_Value = $aPropertyValues[0];
					} else {
						$oProperty_Value = $oProperty->createNewValue($oComment->id);
					}

					$oProperty_Value->value(1);
					$oProperty_Value->save();

					$oComment->save();

					$aAnswer = [
						'result' => true,
						'message' => 'Комментарий изменён',
						'data' => $this->_commentCard($oComment),
					];

					$this->_answer = $aAnswer;
				} else {
					$this->_error = sprintf('Item comment: "%s" Not Found', $comment_id);
					$this->_statusCode = 404;
				}
			} else {
				$oShop_Item = Core_Entity::factory('Shop_Item')->find($item_id);
				if (!is_null($oShop_Item->id)) {
					$aAnswer = [
						'result' => false,
						'message' => 'Ошибка добавления комментария',
						'data' => null,
					];

					$oComment = Core_Entity::factory('Comment');

					$sAuthor = '';
					if (mb_strlen($sAuthor) < 2) {
						$profile = $this->_getSiteuserProfile();

						$sName = $profile['name'];
						$sSurname = mb_substr($profile['surname'], 0, 1);

						$pre = $sName . ' ' . $sSurname;

						if (mb_strlen($pre) > 1) {
							$sAuthor = $pre;
						}
					}

					$oComment->parent_id = $parent_id;
					$oComment->active = $this->_oShop->comment_active;
					$oComment->author = $sAuthor;
					$oComment->grade = $rate;
					$oComment->subject = $oShop_Item->marking;
					$oComment->text = nl2br(Core_Str::stripTags($text, $allowable_tags));
					$oComment->siteuser_id = $this->_oSiteuser->id;

					$oComment->save();

					$oProperty = Core_Entity::factory('Property', 19);
					$oProperty_Value = $oProperty->createNewValue($oComment->id);
					$oProperty_Value->value(20); // RICHE.SKIN
					$oProperty_Value->save();

					if (strlen($advantages)) {
						$oProperty = Core_Entity::factory('Property', 33);
						$oProperty_Value = $oProperty->createNewValue($oComment->id);
						$oProperty_Value->value(Core_Str::stripTags(strval($advantages)));
						$oProperty_Value->save();
					}

					if (strlen($flaws)) {
						$oProperty = Core_Entity::factory('Property', 36);
						$oProperty_Value = $oProperty->createNewValue($oComment->id);
						$oProperty_Value->value(Core_Str::stripTags(strval($flaws)));
						$oProperty_Value->save();
					}

					$oComment
						->dateFormat($this->_oShop->format_date)
						->dateTimeFormat($this->_oShop->format_datetime);

					$oShop_Item->add($oComment)->clearCache();

					$aAnswer = [
						'result' => true,
						'message' => 'Спасибо! Ваш отзыв опубликован.',
						'data' => $this->_commentCard($oComment),
					];

					$this->_answer = $aAnswer;
				} else {
					$this->_error = sprintf('Item: "%s" Not Found', $item_id);
					$this->_statusCode = 404;
				}
			}
		} else {
			$this->_error = 'Authentication Required';
			$this->_statusCode = 401;
			//return false;
		}
	}

	protected function address_add()
	{
		$oSiteuser = null;

		if (isset($this->_request['token'])) {
			$oSiteuser = Core_Entity::factory('Siteuser')->getByGuid(
				$this->_request['token']
			);

			$this->_oSiteuser = $oSiteuser;
		}
		$profile = false;

		if ($this->_oSiteuser) {
			$oSiteuser_Person = null;
			$aSiteuser_People = $this->_oSiteuser->Siteuser_People->findAll(false);
			if (isset($aSiteuser_People[0])) {
				$oSiteuser_Person = $aSiteuser_People[0];
			}

			if ($oSiteuser_Person) {
				$profile = true;
				// $aDirectory_Addresses = $oSiteuser_Person->Directory_Addresses->findAll(
				// 	false
				// );

				$sAddress = Core_Array::get($this->_request, 'address', false);
				$sPostcode = Core_Array::get($this->_request, 'postcode', '');
				$iCity = Core_Array::get($this->_request, 'city', 0, 'int');
				$iAddressId = Core_Array::get($this->_request, 'address_id', 0, 'int');

				if ($iCity && $sAddress) {
					if ($iAddressId) {
						//edit
						$oDirectory_Address = Core_Entity::factory(
							'Directory_Address'
						)->find($iAddressId);
						if ($oDirectory_Address->id) {
							$oDirectory_Address->postcode = $sPostcode;
							$oDirectory_Address->city = $iCity;
							$oDirectory_Address->value = $sAddress;
							$oDirectory_Address->save();
						} else {
							$this->_error = sprintf('Address: "%s" Not Found', $iAddressId);
							$this->_statusCode = 404;
						}
					} else {
						// add
						$oDirectory_Address = Core_Entity::factory('Directory_Address')
							->directory_address_type_id(2) // почтовый
							->public(0)
							->postcode($sPostcode)
							->city($iCity)
							->value($sAddress)
							->save();
						$oSiteuser_Person->add($oDirectory_Address);
					}

					$this->_answer = [
						'profile' => $profile,
						//'types' => $aTypes,
						'addresses' => $this->_getSiteuserAddresses(),
					];
				} else {
					$this->_error = 'Wrong POST data';
					$this->_statusCode = 422;
				}
			} else {
				$this->_error = sprintf(
					'Profile: "%s" Not Found',
					$this->_oSiteuser->login
				);
				$this->_statusCode = 404;
			}

			$aAnswer = [
				'result' => true,
				'message' => 'Адрес добавлен',
			];

			$this->_answer = $aAnswer;
		} else {
			$this->_error = 'Authentication Required';
			$this->_statusCode = 401;
			//return false;
		}
	}

	protected function pay_input()
	{
		$transactionId = isset($_GET['TransactionId'])
			? $_GET['TransactionId']
			: null;
		$order_id = isset($_GET['InvoiceId']) ? $_GET['InvoiceId'] : null;
		$amount = isset($_GET['Amount']) ? $_GET['Amount'] : null;

		if ($transactionId && $order_id && $amount) {
			//$oShop_Order = Core_Entity::factory('Shop_Order')->find($order_id);

			$oShop_Order = Core_Entity::factory('Shop_Order')->getByInvoice(
				$order_id
			);

			//if (!is_null($oShop_Order->id)) {
			if (!is_null($oShop_Order)) {
				$oShop_Payment_System_Handler = Shop_Payment_System_Handler::factory(
					Core_Entity::factory(
						'Shop_Payment_System',
						$oShop_Order->shop_payment_system_id
					)
				);
				$oShop_Payment_System_Handler->shopOrder($oShop_Order);
				if ($amount == $oShop_Order->getAmount()) {
					$note = $oShop_Order->system_information;
					$oShop_Order->system_information =
						$note .
						"Заказ оплачен через CloudPayments.\nТранзакция #" .
						$this->_request['TransactionId'] .
						"\n";
					$oShop_Order->paid();
					$oShop_Order->shop_order_status_id = 2; //  Обрабатывается
					$oShop_Order->save();
					// $oShop_Payment_System_Handler->setXSLs();
					// $oShop_Payment_System_Handler->send();

					$oShop_Payment_System_Handler->changedOrder('changeStatusPaid');

					// orderPaid
					$oApp_Controller_Retailcrm = new App_Controller_Retailcrm(
						$oShop_Order->Shop
					);
					$oApp_Controller_Retailcrm->orderPaid($oShop_Order);
				}
			}
		}

		$this->_answer = [
			'code' => 0,
			//'request' => $_GET,
			// 'transactionId' => $transactionId,
			// 'order_id' => $order_id,
			// 'amount' => $amount,
			//'dddd' => $amount == $oShop_Order->getAmount() ? true : false,
		];
	}

	protected function pay_inputpost()
	{
		//$header = Core_Request::instance()->getRequestHeaders();
		$rawPost = Core_Request::instance()->getRawPost();

		parse_str($rawPost, $aPost);

		if ($aPost) {
			$transactionId = isset($aPost['TransactionId'])
				? $aPost['TransactionId']
				: null;
			$order_id = isset($aPost['InvoiceId']) ? $aPost['InvoiceId'] : null;
			$amount = isset($aPost['Amount']) ? $aPost['Amount'] : null;

			if ($transactionId && $order_id && $amount) {
				//$oShop_Order = Core_Entity::factory('Shop_Order')->find($order_id);
				$oShop_Order = Core_Entity::factory('Shop_Order')->getByInvoice(
					$order_id
				);

				//if (!is_null($oShop_Order->id)) {
				if (!is_null($oShop_Order)) {
					$oShop_Payment_System_Handler = Shop_Payment_System_Handler::factory(
						Core_Entity::factory(
							'Shop_Payment_System',
							$oShop_Order->shop_payment_system_id
						)
					);
					$oShop_Payment_System_Handler->shopOrder($oShop_Order);
					if ($amount == $oShop_Order->getAmount()) {
						$note = $oShop_Order->system_information;
						$oShop_Order->system_information =
							$note .
							"Заказ оплачен через CloudPayments.\nТранзакция #" .
							$transactionId .
							"\n";
						$oShop_Order->paid();
						$oShop_Order->shop_order_status_id = 2; //  Обрабатывается
						$oShop_Order->save();
						// $oShop_Payment_System_Handler->setXSLs();
						// $oShop_Payment_System_Handler->send();

						$oShop_Payment_System_Handler->changedOrder('changeStatusPaid');

						// orderPaid
						$oApp_Controller_Retailcrm = new App_Controller_Retailcrm(
							$oShop_Order->Shop
						);
						$oApp_Controller_Retailcrm->orderPaid($oShop_Order);
					}
				}
			}
		}

		$this->_answer = [
			'code' => 0,
			//'request' => $_GET,
			// 'transactionId' => $transactionId,
			// 'order_id' => $order_id,
			// 'amount' => $amount,
			//'dddd' => $amount == $oShop_Order->getAmount() ? true : false,
		];
	}

	protected function marketredirects()
	{
		$aRedirects = [
			'ozon' => [
				// '13019' =>
				//   'https://www.ozon.ru/product/shampun-i-balzam-maska-dlya-volos-professionalnaya-podarochnyy-nabor-dlya-zhenshchin-i-259300133/',
				'255' => 'https://www.ozon.ru/product/163083703',
				'2878' => 'https://www.ozon.ru/product/162780025',
				'24416' => 'https://www.ozon.ru/product/166392188',
				'6379' => 'https://www.ozon.ru/product/176807470',
				'6378' => 'https://www.ozon.ru/product/176807468',
				'24417' => 'https://www.ozon.ru/product/230271097',
				'6956' => 'https://www.ozon.ru/product/230350216',
				'13106' => 'https://www.ozon.ru/product/230505027',
				'12978' => 'https://www.ozon.ru/product/230507490',
				'12977' => 'https://www.ozon.ru/product/230389473',
				'24420' => 'https://www.ozon.ru/product/242760767',
				'24419' => 'https://www.ozon.ru/product/242788085',
				'24421' => 'https://www.ozon.ru/product/242816197',
				'12988' => 'https://www.ozon.ru/product/242969350',
				'12970' => 'https://www.ozon.ru/product/259277735',
				'12974' => 'https://www.ozon.ru/product/243031659',
				'12971' => 'https://www.ozon.ru/product/259645678',
				'12975' => 'https://www.ozon.ru/product/243007417',
				'13019' => 'https://www.ozon.ru/product/259300133',
				'12990' => 'https://www.ozon.ru/product/279568655',
				'13020' => 'https://www.ozon.ru/product/296693216',
				'17473' => 'https://www.ozon.ru/product/340745607',
				'17447' => 'https://www.ozon.ru/product/340757636',
				'17833' => 'https://www.ozon.ru/product/422380794',
				'17838' => 'https://www.ozon.ru/product/422386652',
				'17840' => 'https://www.ozon.ru/product/422500281',
				'18519' => 'https://www.ozon.ru/product/427265327',
				'17820' => 'https://www.ozon.ru/product/478625028',
				'17819' =>
					'https://www.ozon.ru/product/termozashchitnyy-tonik-sprey-dlya-volos-s-keratinom-21-in-1-r-plex-riche-legkoe-478617136/?sh=T-c15BgmNQ&utm_campaign=vendor_org_14992_',
				'12979' =>
					'https://www.ozon.ru/product/antitsellyulitnyy-krem-gel-dlya-tela-riche-holodnoe-obertyvanie-dlya-pohudeniya-piling-sredstvo-257872528/?sh=T-c15GhnYg&utm_campaign=vendor_org_14992_',
				'12984' =>
					'https://www.ozon.ru/product/ochishchayushchaya-maska-dlya-litsa-ot-pryshchey-ot-chernyh-tochek-riche-shpinat-spirulina-242788085/?sh=T-c15BYUgw&utm_campaign=vendor_org_14992_',
			],
			'wildberries' => [
				// '13019' => 'https://www.wildberries.ru/catalog/72068585/detail.aspx',
				'2878' => 'https://www.wildberries.ru/catalog/10107445/detail.aspx',
				'6379' => 'https://www.wildberries.ru/catalog/12657591/detail.aspx',
				'12977' => 'https://www.wildberries.ru/catalog/21358431/detail.aspx',
				'12978' => 'https://www.wildberries.ru/catalog/21361041/detail.aspx',
				'13106' => 'https://www.wildberries.ru/catalog/21446660/detail.aspx',
				'17447' => 'https://www.wildberries.ru/catalog/43091690/detail.aspx',
				'17835' => 'https://www.wildberries.ru/catalog/51934219/detail.aspx',
				'17836' => 'https://www.wildberries.ru/catalog/51949667/detail.aspx',
				'17840' => 'https://www.wildberries.ru/catalog/51980917/detail.aspx',
				'17956' => 'https://www.wildberries.ru/catalog/52433035/detail.aspx',
				'18519' => 'https://www.wildberries.ru/catalog/52547278/detail.aspx',
				'13019' => 'https://www.wildberries.ru/catalog/21362364/detail.aspx',
				'12978' =>
					'https://www.wildberries.ru/catalog/21361041/detail.aspx?targetUrl=BP',
				'17819' =>
					'https://www.wildberries.ru/catalog/83511998/detail.aspx?targetUrl=XS?',
				'16918' => 'https://www.wildberries.ru/catalog/70445596/detail.aspx',
				'13195' => 'https://www.wildberries.ru/catalog/21403827/detail.aspx',
				'12976' => 'https://www.wildberries.ru/catalog/21525409/detail.aspx',
				'12984' => 'https://www.wildberries.ru/catalog/21449335/detail.aspx',

				'12985' => 'https://www.wildberries.ru/catalog/21616014/detail.aspx',
				'12986' => 'https://www.wildberries.ru/catalog/21454200/detail.aspx',
				'17820' => 'https://www.wildberries.ru/catalog/143752569/detail.aspx',

				'12988' => 'https://www.wildberries.ru/catalog/21616014/detail.aspx',
				'24476' =>
					'https://www.wildberries.ru/catalog/139285245/detail.aspx?targetUrl=XS',
				'24423' => 'https://www.wildberries.ru/catalog/123095481/detail.aspx',
				'22721' => 'https://www.wildberries.ru/catalog/112329771/detail.aspx',
				'6956' => 'https://www.wildberries.ru/catalog/113256050/detail.aspx',
				'24416' => 'https://www.wildberries.ru/catalog/123090601/detail.aspx',
				'6378' => 'https://www.wildberries.ru/catalog/14334489/detail.aspx',
				'24422' => 'https://www.wildberries.ru/catalog/123090601/detail.aspx',
				'12981' => 'https://www.wildberries.ru/catalog/21299362/detail.aspx',
			],
		];

		$sMarket = strval(Core_Array::getGet('market', false));
		$sFrom = strval(Core_Array::getGet('from', false));

		if ($sMarket && $sFrom) {
			if (isset($aRedirects[$sMarket][$sFrom])) {
				$this->_answer = [
					'from' => '/' . $sMarket . '/' . $sFrom . '/',
					'to' => $aRedirects[$sMarket][$sFrom],
				];
			} else {
				$this->_error = sprintf('Path: "%s" Not Found', $this->path);
				$this->_statusCode = 404;
			}
		} else {
			$this->_error = 'Wrong  data';
			$this->_statusCode = 422;

			return false;
		}
	}

	protected function marketredirectsdb()
	{
		$sMarket = strval(Core_Array::getGet('market', false));
		$sFrom = strval(Core_Array::getGet('from', false));

		if ($sMarket && $sFrom) {
			$oQueryBuilder = Core_QueryBuilder::select();
			$oQueryBuilder
				->from('deeplinks')
				->where('prefix', '=', $sMarket)
				->where('source', '=', $sFrom)
				->where('deleted', '=', 0)
				->where('active', '=', 1)
				//->where('parent_id', '!=', 0)
				->limit(1);

			// echo $oQueryBuilder->execute()->getLastQuery();
			// exit();
			$aResult = $oQueryBuilder
				->execute()
				->asAssoc()
				->result();

			// var_dump($aResult);
			// exit();

			if (count($aResult)) {
				$this->_answer = [
					'from' =>
						'/' . $aResult[0]['prefix'] . '/' . $aResult[0]['source'] . '/',
					'to' => $aResult[0]['destination'],
				];
			} else {
				$this->_error = sprintf('Path: "%s" Not Found', $this->path);
				$this->_statusCode = 404;
			}

			// if (isset($aRedirects[$sMarket][$sFrom])) {
			//   $this->_answer = [
			//     'from' => '/' . $sMarket . '/' . $sFrom . '/',
			//     'to' => $aRedirects[$sMarket][$sFrom],
			//   ];
			// } else {
			//   $this->_error = sprintf('Path: "%s" Not Found', $this->path);
			//   $this->_statusCode = 404;
			// }
		} else {
			$this->_error = 'Wrong  data';
			$this->_statusCode = 422;

			return false;
		}
	}

	protected function rcrm__track()
	{
		if ($this->_oShop) {
			$header = Core_Request::instance()->getRequestHeaders();

			$oApp_Controller_Retailcrm = new App_Controller_Retailcrm($this->_oShop);
			$apiKey = $oApp_Controller_Retailcrm->getKey();

			if (isset($header['apikey']) && $header['apikey'] == $apiKey) {
				//$this->_request['coupon'];

				if (
					isset($this->_request['isUpdate']) &&
					$this->_request['isUpdate'] &&
					isset($this->_request['externalId'])
				) {
					$oShop_Order = Core_Entity::factory('Shop_Order')->getByInvoice(
						$this->_request['externalId']
					);

					if ($oShop_Order) {
						$aReturn = $oApp_Controller_Retailcrm->orderDelivery(
							$oShop_Order,
							$this->_request
						);

						$this->_answer = [
							//'return' => null,
							'return' => $aReturn,
						];
					} else {
						$this->_error = sprintf(
							'Order: "%s" Not Found',
							$this->_request['externalId']
						);
						$this->_statusCode = 404;
					}
				} else {
					$this->_error = 'Wrong data';
					$this->_statusCode = 422;
					return false;
				}
			} else {
				$this->_error = 'Wrong data';
				$this->_statusCode = 422;
				return false;
			}
		} else {
			$this->_error = 'Wrong data';
			$this->_statusCode = 422;
			return false;
		}
	}

	protected function rcrm__complete()
	{
		if ($this->_oShop) {
			$header = Core_Request::instance()->getRequestHeaders();

			$oApp_Controller_Retailcrm = new App_Controller_Retailcrm($this->_oShop);
			$apiKey = $oApp_Controller_Retailcrm->getKey();

			if (isset($header['apikey']) && $header['apikey'] == $apiKey) {
				//$this->_request['coupon'];

				if (
					isset($this->_request['isUpdate']) &&
					$this->_request['isUpdate'] &&
					isset($this->_request['externalId'])
				) {
					$oShop_Order = Core_Entity::factory('Shop_Order')->getByInvoice(
						$this->_request['externalId']
					);

					if ($oShop_Order) {
						$aReturn = $oApp_Controller_Retailcrm->orderCompleted(
							$oShop_Order,
							$this->_request
						);

						$this->_answer = [
							//'return' => null,
							'return' => $aReturn,
						];
					} else {
						$this->_error = sprintf(
							'Order: "%s" Not Found',
							$this->_request['externalId']
						);
						$this->_statusCode = 404;
					}
				} else {
					$this->_error = 'Wrong data';
					$this->_statusCode = 422;
					return false;
				}
			} else {
				$this->_error = 'Wrong data';
				$this->_statusCode = 422;
				return false;
			}
		} else {
			$this->_error = 'Wrong data';
			$this->_statusCode = 422;
			return false;
		}
	}

	protected function rcrm__canceled()
	{
		if ($this->_oShop) {
			$header = Core_Request::instance()->getRequestHeaders();

			$oApp_Controller_Retailcrm = new App_Controller_Retailcrm($this->_oShop);
			$apiKey = $oApp_Controller_Retailcrm->getKey();

			if (isset($header['apikey']) && $header['apikey'] == $apiKey) {
				//$this->_request['coupon'];

				if (
					isset($this->_request['isUpdate']) &&
					$this->_request['isUpdate'] &&
					isset($this->_request['externalId'])
				) {
					$oShop_Order = Core_Entity::factory('Shop_Order')->getByInvoice(
						$this->_request['externalId']
					);

					if ($oShop_Order) {
						$aReturn = $oApp_Controller_Retailcrm->orderCanceled(
							$oShop_Order,
							$this->_request
						);

						$this->_answer = [
							//'return' => null,
							'return' => $aReturn,
						];
					} else {
						$this->_error = sprintf(
							'Order: "%s" Not Found',
							$this->_request['externalId']
						);
						$this->_statusCode = 404;
					}
				} else {
					$this->_error = 'Wrong data';
					$this->_statusCode = 422;
					return false;
				}
			} else {
				$this->_error = 'Wrong data';
				$this->_statusCode = 422;
				return false;
			}
		} else {
			$this->_error = 'Wrong data';
			$this->_statusCode = 422;
			return false;
		}
	}

	protected function rcrm__changeorder()
	{
		// $logsDir =
		// 	CMS_FOLDER .
		// 	'modules' .
		// 	DIRECTORY_SEPARATOR .
		// 	'app' .
		// 	DIRECTORY_SEPARATOR .
		// 	'command';
		// $paymentLogsFile = $logsDir . DIRECTORY_SEPARATOR . 'crm.txt';
		// $fileLog = fopen($paymentLogsFile, 'a');
		// $aWrite = json_encode($this->_request);
		// if ($aWrite) {
		// 	fwrite($fileLog, $aWrite . PHP_EOL);
		// }

		// fclose($fileLog);

		if ($this->_oShop) {
			$header = Core_Request::instance()->getRequestHeaders();

			$oApp_Controller_Retailcrm = new App_Controller_Retailcrm($this->_oShop);
			$apiKey = $oApp_Controller_Retailcrm->getKey();

			if (isset($header['apikey']) && $header['apikey'] == $apiKey) {
				if (
					isset($this->_request['isUpdate']) &&
					$this->_request['isUpdate'] &&
					isset($this->_request['externalId'])
				) {
					$oShop_Order = Core_Entity::factory('Shop_Order')->getByInvoice(
						$this->_request['externalId']
					);

					if ($oShop_Order) {
						$aReturn = $oApp_Controller_Retailcrm->orderChanged(
							$oShop_Order,
							$this->_request
						);

						$this->_answer = [
							'return' => $aReturn,
						];
					} else {
						$this->_error = sprintf(
							'Order: "%s" Not Found',
							$this->_request['externalId']
						);
						$this->_statusCode = 404;
					}
				} else {
					$this->_error = 'Wrong data';
					$this->_statusCode = 422;
					return false;
				}
			} else {
				$this->_error = 'Wrong data';
				$this->_statusCode = 422;
				return false;
			}
		} else {
			$this->_error = 'Wrong data';
			$this->_statusCode = 422;
			return false;
		}
	}

	protected function retailcrm()
	{
		if ($this->_oShop) {
			$aOrders = null;
			$oApp_Controller_Retailcrm = new App_Controller_Retailcrm($this->_oShop);

			$oShop_Order = Core_Entity::factory('Shop_Order', 101);
			$aOrders = $oApp_Controller_Retailcrm->createOrder($oShop_Order);

			//$oShop_Order = Core_Entity::factory('Shop_Order', 80);
			//$aOrders = $oApp_Controller_Retailcrm->orderPaid($oShop_Order);

			$this->_answer = [
				//'return' => null,
				'return' => $aOrders,
			];
		} else {
			$this->_error = 'Wrong  data';
			$this->_statusCode = 422;

			return false;
		}
	}

	protected function product_comments($item_id)
	{
		$oShop_item = Core_Entity::factory('Shop_Item', $item_id);

		$limit = 4;
		$page = Core_Array::getGet('page', 1);
		$offset = Core_Array::getGet('offset', ($page - 1) * $limit);
		$total = 0;

		if ($oShop_item->name && $oShop_item->active && !$oShop_item->deleted) {
			$total = $oShop_item->Comments->getCountByActive(1);

			$aCommentsList = [];

			$oComments = $oShop_item->Comments;
			$oComments
				->queryBuilder()
				->where('active', '=', 1)
				->where('deleted', '=', 0)
				->where('parent_id', '=', 0)
				->limit($limit)
				->offset($offset)
				->orderBy('datetime', 'DESC');

			$aComments = $oComments->findAll();

			foreach ($aComments as $oComment) {
				$aCommentsList[] = $this->_commentCard($oComment);
			}

			$aPagination = [
				'totalCount' => intval($total),
				'pageCount' => ceil(intval($total) / intval($limit)),
				'currentPage' => intval($page),
				'perPage' => intval($limit),
			];

			$this->_answer = [
				'pagination' => $aPagination,
				'list' => $aCommentsList,
			];
		} else {
			$this->_error = sprintf(
				'Product: "%s" Not Found',
				$this->_request['item']
			);
			$this->_statusCode = 404;
		}
	}

	protected function product_qr($qr)
	{
		//product_qr

		$utm = '?utm_source=package&utm_medium=qr';
		$prop_id = 32;
		$val = trim($qr);

		$oQueryBuilderSelect = Core_QueryBuilder::select();
		$oQueryBuilderSelect
			->select(['property_value_strings.value', 'qr'])
			->select([
				Core_QueryBuilder::expression(
					'CONCAT_WS("-", shop_items.path, shop_items.id)'
				),
				'to',
			])
			->select(['shop_items.active', 'active'])
			->from('property_value_strings')
			->leftJoin(
				'shop_items',
				'property_value_strings.entity_id',
				'=',
				'shop_items.id'
			)
			->where('property_value_strings.property_id', '=', $prop_id)
			->where('property_value_strings.value', '=', $val)
			->limit(1);

		//echo $oQueryBuilderSelect->execute()->getLastQuery();
		$aQr = $oQueryBuilderSelect
			->execute()
			->asAssoc()
			->current();

		if ($aQr && $aQr['qr'] != '' && $aQr['to'] != '' && $aQr['active']) {
			$this->_answer = [
				'from' => '/qr/' . $aQr['qr'],
				'to' => '/product/' . $aQr['to'] . $utm,
			];
		} else {
			$this->_error = sprintf('QR: "%s" Not Found', $qr);
			$this->_statusCode = 404;
		}
	}

	protected function r46__recommend()
	{
		$items = Core_Array::getGet('items', null);
		if ($items) {
			$aItemsPre = explode(',', $items);
			if (count($aItemsPre) > 0) {
				$aItems = [];
				$oEntityItems = $this->_oShop->Shop_Items;
				$oEntityItems
					->queryBuilder()
					->where('shop_items.active', '=', 1)
					->where('shop_items.deleted', '=', 0)
					->where('shop_items.id', 'IN', $aItemsPre);

				$oEntityItems = $oEntityItems->findAll(false);

				foreach ($oEntityItems as $oEntityItem) {
					if ($oEntityItem->shortcut_id) {
						$oEntityItem = Core_Entity::factory(
							'Shop_Item',
							$oEntityItem->shortcut_id
						);
					}

					$aItems[] = $this->_shopCard($oEntityItem, true);
				}

				$this->_answer['items'] = $aItems;
			} else {
				$this->_error = sprintf('Items: "%s" Not Found', $items);
				$this->_statusCode = 404;
				return false;
			}
		} else {
			$this->_error = sprintf('Items: "%s" Not Found', $items);
			$this->_statusCode = 404;
			return false;
		}
	}

	protected function r46__profile()
	{
		$token = Core_Array::getGet('token', false);

		if ($token) {
			$oSiteuser = Core_Entity::factory('Siteuser')->getByGuid($token);

			if ($oSiteuser) {
				$this->_oSiteuser = $oSiteuser;

				$bought_something = false;
				if ($oSiteuser->Shop_Orders->getCount() > 0) {
					$bought_something = true;
				}

				$this->_answer['profile'] = [
					'id' => $oSiteuser->id,
					'email' => $oSiteuser->email,
					'bought_something' => $bought_something,
				];
			} else {
				$this->_error = sprintf('User: "%s" Not Found', $token);
				$this->_statusCode = 404;
				return false;
			}
		} else {
			$this->_error = sprintf('User: "%s" Not Found', $token);
			$this->_statusCode = 404;
			return false;
		}
	}

	protected function me_addresses()
	{
		$oSiteuser = null;

		if (isset($this->_request['token'])) {
			$oSiteuser = Core_Entity::factory('Siteuser')->getByGuid(
				$this->_request['token']
			);

			$this->_oSiteuser = $oSiteuser;
		}

		if ($this->_oSiteuser) {
			$aTypes = [['id' => 0, 'name' => 'Не указан']];

			// $this->directory_address_type_id
			// && $this->addXmlTag('name', $this->Directory_Address_Type->name);

			// $aDirectory_Address_Types = Core_Entity::factory(
			// 	'Directory_Address_Type'
			// )->findAll();

			// foreach ($aDirectory_Address_Types as $oDirectory_Address_Type) {
			// 	$aTypes[] = [
			// 		'id' => $oDirectory_Address_Type->id,
			// 		'name' => $oDirectory_Address_Type->name,
			// 	];
			// }

			$profile = false;
			$aSiteuser_People = $this->_oSiteuser->Siteuser_People->findAll(false);
			if (isset($aSiteuser_People[0])) {
				$profile = true;
			}

			$this->_answer = [
				'profile' => $profile,
				//'types' => $aTypes,
				'addresses' => $this->_getSiteuserAddresses(),
			];
		} else {
			$this->_error = 'Authentication Required';
			$this->_statusCode = 401;
		}
	}

	protected function _getSiteuserAddresses()
	{
		$aReturn = [];
		if ($this->_oSiteuser) {
			$oSiteuser_Person = null;
			$aSiteuser_People = $this->_oSiteuser->Siteuser_People->findAll(false);
			if (isset($aSiteuser_People[0])) {
				$oSiteuser_Person = $aSiteuser_People[0];
			}

			if ($oSiteuser_Person) {
				$aDirectory_Addresses = $oSiteuser_Person->Directory_Addresses->findAll(
					false
				);

				foreach ($aDirectory_Addresses as $oDirectory_Address) {
					$cityId = intval($oDirectory_Address->city);
					if ($cityId) {
						$oShop_Country_Location_City = Core_Entity::factory(
							'Shop_Country_Location_City',
							$cityId
						);

						if (
							$oShop_Country_Location_City->name &&
							!$oShop_Country_Location_City->deleted
						) {
							$aCity[] = [
								'id' => $oShop_Country_Location_City->id,
								'city_name' => $oShop_Country_Location_City->name,
								'region_name' =>
									$oShop_Country_Location_City->Shop_Country_Location->name,
								'country_name' =>
									$oShop_Country_Location_City->Shop_Country_Location
										->Shop_Country->name,
							];

							$postcode = strlen(trim($oDirectory_Address->postcode))
								? trim($oDirectory_Address->postcode)
								: null;
							$address = strlen(trim($oDirectory_Address->value))
								? trim($oDirectory_Address->value)
								: null;

							$aType = $oDirectory_Address->Directory_Address_Type->id
								? [
									'id' => $oDirectory_Address->Directory_Address_Type->id,
									'name' => $oDirectory_Address->Directory_Address_Type->name,
								]
								: ['id' => 0, 'name' => 'Не указан'];

							if ($address) {
								$aReturn[] = [
									'id' => $oDirectory_Address->id,
									'country' => [
										'id' =>
											$oShop_Country_Location_City->Shop_Country_Location
												->Shop_Country->id,
										'name' =>
											$oShop_Country_Location_City->Shop_Country_Location
												->Shop_Country->Name,
									],
									'region' => [
										'id' =>
											$oShop_Country_Location_City->Shop_Country_Location->id,
										'name' =>
											$oShop_Country_Location_City->Shop_Country_Location->Name,
									],
									'city' => [
										'id' => $oShop_Country_Location_City->id,
										'name' => $oShop_Country_Location_City->Name,
									],
									'postcode' => $postcode,
									'address' => $address,
									'type' => $aType,
								];
							}
						}
					}
				}
			}
		}
		return $aReturn;
	}
}
