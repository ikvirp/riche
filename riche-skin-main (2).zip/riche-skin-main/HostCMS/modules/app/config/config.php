<?php

return [
  'url' => '/app',
  'xmlRootNode' => 'request',
  'log' => false,
];
