<?php

/**
 * Debug utils
 *
 * @author James V. Kotov
 * @copyright 2011-2015
 * @version 1.0.1
 *
 * @path /modules/debug/debug.php
 * @use в конце bootstrap.php добавить строчку
 * require_once (CMS_FOLDER . 'modules/debug/debug.php');
 */


// вывод содержимого через print_r
function echo_r($value)
{
	if (Core_Auth::logged())
	{
		echo '<pre>' . print_r($value, true) . '</pre>';
	}
}

// вывод содержимого через var_dump
function echo_v($value)
{
	if (Core_Auth::logged())
	{
		echo '<pre>' . var_dump($value) . '</pre>';
	}

}
