<?php
/**
 * Restapi.
 *
 * @package HostCMS
 * @subpackage Restapi
 * @version 6.x
 * @author Hostmake LLC
 * @copyright © 2005-2020 ООО "Хостмэйк" (Hostmake LLC), http://www.hostcms.ru
 */
return [
  'menu' => 'Codeauth',
];
