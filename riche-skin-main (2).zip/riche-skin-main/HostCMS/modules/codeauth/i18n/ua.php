<?php

return [
  'menu' => 'Codeauth',
];
