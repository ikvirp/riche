<?php

defined('HOSTCMS') || exit('HostCMS: access denied.');

/**
 * REST API
 *
 * @package HostCMS 6
 * @subpackage Codeauth
 * @version 7.x
 * @author Hostmake LLC
 * @copyright © 2005-2021 ООО "Хостмэйк" (Hostmake LLC), http://www.hostcms.ru
 */
class Codeauth_Module extends Core_Module
{
  /**
   * Module version
   * @var string
   */
  public $version = '1.0';

  /**
   * Module date
   * @var date
   */
  public $date = '2022-05-06';

  /**
   * Module name
   * @var string
   */
  protected $_moduleName = 'codeauth';

  /**
   * Constructor.
   */
  public function __construct()
  {
    parent::__construct();
  }

  /**
   * Get Module's Menu
   * @return array
   */
  public function getMenu()
  {
    $this->menu = [
      [
        'sorting' => 0,
        'block' => 3,
        'ico' => 'fa fa-key',
        'name' => Core::_('Codeauth.menu'),
        'href' => '/admin/codeauth/index.php',
        'onclick' =>
          "$.adminLoad({path: '/admin/codeauth/index.php'}); return false",
      ],
    ];

    return parent::getMenu();
  }
}
