<?php

return [
	'lifetime' => 120, // seconds
	'rand_start' => 1111,
	'rand_end' => 9999,

	'code_text_template' =>
		'Код подтверждения riche.skin: %s Не сообщайте никому!',

	'url' => 'https://gateway.api.sc/get/',
	'user' => '79370113662',
	'pwd' => 'xeds[0[3np',
	'sadr' => 'RICHE', // Имя отправителя.
	'callback_url' => 'https://data.riche.skin/app/v1.0/codeauthinput/',
	'no_replace' => false,
];
