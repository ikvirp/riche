<?php

defined('HOSTCMS') || exit('HostCMS: access denied.');

/**
 * Codeauth_Controller.
 *
 * @package HostCMS
 * @subpackage Codeauth
 * @version 6.x
 * @author Hostmake LLC
 * @copyright © 2005-2018 ООО "Хостмэйк" (Hostmake LLC), http://www.hostcms.ru
 */
class Codeauth_Controller extends Core_Servant_Properties
{
	/**
	 * Generate token
	 * @return string
	 */

	public static function createToken()
	{
		return mt_rand(1111, 9999);
	}

	public static function _sanitizePhoneNumber($phone)
	{
		$phone = preg_replace('/[^0-9]/', '', $phone);
		if (strlen($phone) == 11) {
			// 8928 => 7928
			substr($phone, 0, 2) == '89' && ($phone[0] = '7');
			// 8705 => 7705
			substr($phone, 0, 2) == '87' && ($phone[0] = '7');
			return trim($phone);
		} else {
			return false;
		}
	}

	/**
	 * Generate token
	 * @return string
	 */
	public static function sendCode($phone)
	{
		$realPhone = self::_sanitizePhoneNumber($phone);

		if ($realPhone) {
			$aConfig = Core_Config::instance()->get('codeauth_config');

			$aParams = [
				'user' => $aConfig['user'],
				'pwd' => $aConfig['pwd'],
			];

			if (isset($aConfig['sadr']) && $aConfig['sadr']) {
				$aParams['sadr'] = $aConfig['sadr'];
			}
			if (isset($aConfig['callback_url']) && $aConfig['callback_url']) {
				$aParams['callback_url'] = $aConfig['callback_url'];
			}
			if (isset($aConfig['no_replace']) && $aConfig['no_replace']) {
				$aParams['no_replace'] = $aConfig['no_replace'];
			}

			$code = mt_rand($aConfig['rand_start'], $aConfig['rand_end']);
			if ($code) {
				$aParams['text'] = sprintf($aConfig['code_text_template'], $code);
			}

			$aParams['dadr'] = $realPhone;

			$url = $aConfig['url'] . '?' . http_build_query($aParams);

			$Core_Http = Core_Http::instance('curl')
				->clear()
				->method('GET')
				->url($url)
				->execute();

			//$aAnswer = json_decode($Core_Http->getDecompressedBody(), true);
			$sAnswer = $Core_Http->getDecompressedBody();

			// var_dump($sAnswer);
			// exit();

			if ($sAnswer) {
				// добавляем запись
				$oCodeauth_Token = Core_Entity::factory('Codeauth_Token');

				$datetime = Core_Date::timestamp2sql(time());
				$expire = Core_Date::timestamp2sql(time() + $aConfig['lifetime']);

				$oCodeauth_Token
					->phone($realPhone)
					->code($code)
					->external_id($sAnswer)
					->datetime($datetime)
					->expire($expire)
					->save();

				$aResult = $oCodeauth_Token->toArray();

				return [
					'phone' => $aResult['phone'],
					'id' => $aResult['external_id'],
					'expire' => $aResult['expire'],
					'lifetime' => $aConfig['lifetime'],
				];
			}
			return false;
		}

		return false;
	}
}
