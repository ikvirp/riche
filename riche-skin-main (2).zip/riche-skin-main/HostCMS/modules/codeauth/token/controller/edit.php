<?php

defined('HOSTCMS') || exit('HostCMS: access denied.');

/**
 * Codeauth Token Backend Editing Controller.
 *
 * @package HostCMS
 * @subpackage Codeauth
 * @version 6.x
 * @author Hostmake LLC
 * @copyright © 2005-2021 ООО "Хостмэйк" (Hostmake LLC), http://www.hostcms.ru
 */
class Codeauth_Token_Controller_Edit extends
  Admin_Form_Action_Controller_Type_Edit
{
  /**
   * Set object
   * @param object $object object
   * @return self
   */
  public function setObject($object)
  {
    parent::setObject($object);

    $this->title(
      $this->_object->id
        ? Core::_(
          'Codeauth_Token.edit_title',
          $this->_object->phone . ' — ' . $this->_object->code
        )
        : Core::_('Codeauth_Token.add_title')
    );

    $oMainTab = $this->getTab('main');
    $oAdditionalTab = $this->getTab('additional');

    $windowId = $this->_Admin_Form_Controller->getWindowId();

    $oMainTab
      ->add($oMainRow1 = Admin_Form_Entity::factory('Div')->class('row'))
      ->add($oMainRow2 = Admin_Form_Entity::factory('Div')->class('row'))
      ->add($oMainRow3 = Admin_Form_Entity::factory('Div')->class('row'));

    $oMainTab->move(
      $this->getField('code')->divAttr(['class' => 'form-group col-xs-12']),
      $oMainRow1
    );

    if (!$this->_object->id) {
      $this->getField('code')->value(Codeauth_Controller::createToken());
    }

    $oMainTab
      ->move(
        $this->getField('code')->divAttr([
          'class' => 'form-group col-xs-12 col-sm-4',
        ]),
        $oMainRow2
      )
      ->move(
        $this->getField('datetime')->divAttr([
          'class' => 'form-group col-xs-12 col-sm-4',
        ]),
        $oMainRow2
      )
      ->move(
        $this->getField('expire')->divAttr([
          'class' => 'form-group col-xs-12 col-sm-4',
        ]),
        $oMainRow2
      )

      ->move(
        $this->getField('active')->divAttr([
          'class' => 'form-group col-xs-12 col-sm-4',
        ]),
        $oMainRow3
      );

    return $this;
  }

  /**
   * Processing of the form. Apply object fields.
   * @hostcms-event Codeauth_Token_Controller_Edit.onAfterRedeclaredApplyObjectProperty
   * @return self
   */
  protected function _applyObjectProperty()
  {
    parent::_applyObjectProperty();

    $this->_object->save();

    Core_Event::notify(
      get_class($this) . '.onAfterRedeclaredApplyObjectProperty',
      $this,
      [$this->_Admin_Form_Controller]
    );

    return $this;
  }
}
