<?php
/**
 * Restapi_Token.
 *
 * @package HostCMS
 * @subpackage Restapi
 * @version 6.x
 * @author Hostmake LLC
 * @copyright © 2005-2020 ООО "Хостмэйк" (Hostmake LLC), http://www.hostcms.ru
 */
return [
	'menu' => 'Codeauth Codes',
	'title' => 'Codeauth Codes',
	'model_name' => 'Codeauth Codes',
	'changeActive_success' => 'Status changed successfully!',
	'edit_title' => 'Edit Token "%s"',
	'add_title' => 'Add Token',
	'code' => 'Code',
	'status' => 'Status',
	'active' => '<acronym title="Status of Token">Active</acronym>',
	'external_id' => 'External id',
	'datetime' => 'Creation Date',
	'expire' => 'Expire Date',
	'id' => 'id',
	'phone' => 'Phone',
	'edit_success' => 'Token modified successfully.',
	'markDeleted_success' => 'Token deleted successfully.',
	'expire_0' => 'Active',
	'expire_1' => 'Expired',
];
