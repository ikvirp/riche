<?php
/**
 * Restapi_Token.
 *
 * @package HostCMS
 * @subpackage Restapi
 * @version 6.x
 * @author Hostmake LLC
 * @copyright © 2005-2018 ООО "Хостмэйк" (Hostmake LLC), http://www.hostcms.ru
 */
return [
	'menu' => 'Коды Codeauth',
	'title' => 'Коды Codeauth',
	'model_name' => 'Коды Codeauth',
	'changeActive_success' => 'Активность элемента изменена!',
	'edit_title' => 'Редактирование токена "%s"',
	'add_title' => 'Добавление токена',
	'code' => 'Код',
	'status' => 'Статус',
	'active' => 'Активность',
	'external_id' => 'Внешний id',
	'datetime' => 'Дата создания',
	'expire' => 'Дата истечения',
	'id' => 'Идентификатор',
	'phone' => 'Телефон',
	'edit_success' => 'Информация изменена успешно!',
	'markDeleted_success' => 'Токен удален успешно!',
	'expire_0' => 'Действует',
	'expire_1' => 'Истек',
];
