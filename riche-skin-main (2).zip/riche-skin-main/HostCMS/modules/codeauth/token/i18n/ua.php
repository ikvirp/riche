<?php

return [
  'menu' => 'Коды Codeauth',
  'title' => 'Коды Codeauth',
  'model_name' => 'Коды Codeauth',
  'changeActive_success' => 'Активність елемента змінена!',
  'edit_title' => 'Редагування токена "%s"',
  'add_title' => 'Додавання токена',
  'code' => 'Код',
  'active' => 'Активність',
  'external_id' => 'Внешний id',
  'datetime' => 'Дата створення',
  'expire' => 'Дата закінчення',
  'id' => 'Ідентифікатор',
  'phone' => 'Телефон',
  'edit_success' => 'Інформацію змінено успішно!',
  'markDeleted_success' => 'Токен видалений успішно!',
  'expire_0' => 'Діє',
  'expire_1' => 'Закінчився',
];
