<?php

defined('HOSTCMS') || exit('HostCMS: access denied.');

/**
 * Some useful helpers for every day!
 *
 * @package HostCMS 6\Core\Utils
 * @version 1.0.0
 * @author James V. Kotoff
 * @copyright 2013-2015
 */
class Core_Utils
{
  /**
   * Быстрая запись в лог
   * Core_Utils::log()
   *
   * @param string $sMessage сообщение
   * @param integer $iStatus уровень критичности сообщения от 0 (просто запись) до 4 (критическая ошибка), см /modules/core/log.php
   * @return
   *
   * @exapmle log('Лытдыбр', 0);
   * @exapmle log('Все в порядке', 1);
   * @exapmle log('Упс :)', 2);
   * @exapmle log('Чо-та я на измену присел', 3);
   * @exapmle log('Ааа! Пи...ц, все пропало!!!', 4);
   */
  public static function log($sMessage = '', $iStatus = 0)
  {
    $sMessage = trim(strval($sMessage));
    $iStatus = intval($iStatus);
    if (!empty($sMessage)) {
      $oCore_Log = Core_Log::instance();
      $oCore_Log->clear()->status($iStatus);
      $oSiteuser = Core::moduleIsActive('Siteuser')
        ? Core_Entity::factory('Siteuser')->getCurrent()
        : null;
      if ($oSiteuser) {
        $oCore_Log->login(
          'Пользователь сайта ' . $oSiteuser->login . " ({$oSiteuser->id})"
        );
        unset($oSiteuser);
      }
      $oCore_Log->write(strval($sMessage));
    }
  }

  /**
   * Core_Utils::getCanonicalUrl() - вычисляет канонический адрес страницы для link rel="canonical"
   *
   * @param boolean [$useParentShopItem = false] В интернет-магазине, для страниц товаров-модификаций считать каноническим урл родительского товара. По умолчанию выключено.
   * @param string [$sFirstPageSuffix = 'page-1/'] Суффикс пейджинга на первую страницу, удаляется из урла, чтобы каноническим урлом первой страницы был урл без пейджинга.
   * @return string
   *
   * @example:
   * <link rel="canonical" href="<?=Core_Utils::getCanonicalUrl(TRUE); ?>"/>
   *
   * @example:
   * <link rel="canonical" href="<?=Core_Utils::getCanonicalUrl(TRUE, 'pg_1/'); ?>"/>
   *
   * @example:
   * <link rel="canonical" href="<?=Core_Utils::getCanonicalUrl(FALSE, 'pg_1'); ?>"/>
   *
   */
  public static function getCanonicalUrl(
    $bUseParentShopItem = false,
    $sFirstPageSuffix = 'page-1/'
  ) {
    $sLink = '';

    $object = Core_Page::instance()->object;
    // если включен режим подстановки родительского товара вместо модификации
    // и текущая страница является страницей товара в магазине
    if (
      $bUseParentShopItem &&
      is_object($object) &&
      $object instanceof Shop_Controller_Show &&
      $object->item
    ) {
      // получаем товар
      $oShop_Item = Core_Entity::factory('Shop_Item', $object->item);
      // если товар найден и это модификация
      if ($oShop_Item && $oShop_Item->modification_id) {
        // формируем относительный путь к родительскому товару
        $oShop = Core_Entity::factory('Shop', $oShop_Item->shop_id);
        $sLink =
          $oShop->Structure->getPath() . $oShop_Item->Modification->getPath();
      }
    }

    // если мы еще не вычислили ссылку ранее, то преобразуем текущий request_uri
    if (!$sLink) {
      $aLink = explode('?', Core_Array::get($_SERVER, 'REQUEST_URI', ''));
      $sLink = reset($aLink);

      // проверим, что это не пейджинг на первую страницу
      $FirstPageSuffixLength = mb_strlen($sFirstPageSuffix);
      if (mb_substr($sLink, 0 - $FirstPageSuffixLength) == $sFirstPageSuffix) {
        // если это пейджинг на первую страницу, то уберем ее суффикс из урла
        $sLink = mb_substr(
          $sLink,
          0,
          mb_strlen($sLink) - $FirstPageSuffixLength
        );
      }
    }

    // получим главный алиас текущего сайта
    $oSite_Alias = Core_Entity::factory(
      'Site',
      CURRENT_SITE
    )->getCurrentAlias();
    if ($oSite_Alias) {
      // определим метод доступа у текущему узлу структуры, http или https
      $oStructure = Core_Entity::factory('Structure', CURRENT_STRUCTURE_ID);
      $scheme = $oStructure->https ? 'https' : 'http';

      // дополняем относительную ссылку до абсолютной
      $sLink = $scheme . '://' . $oSite_Alias->alias_name_without_mask . $sLink;
    }

    // вернем результат
    return $sLink;
  }

  /**
   * Core_Utils::getIndexationValue() - вычисляет значение для meta robots на основании активности лампочки индексации в свойствах структуры
   *
   * @param mixed $structure_id
   * @return string
   *
   * @exapmle
   * <meta name="robots" content="<?=Core_Utils::getIndexationValue()?>" />
   */
  public static function getIndexationValue(
    $structure_id = CURRENT_STRUCTURE_ID
  ) {
    $structure_id = intval($structure_id);

    $oStructure = Core_Entity::factory('Structure', $structure_id);

    // Проверка на доступ пользователя к странице
    $iStructureAccess = $oStructure->getSiteuserGroupId();

    $aSiteuserGroups = [0];

    if (Core::moduleIsActive('siteuser')) {
      $oSiteuser = Core_Entity::factory('Siteuser')->getCurrent();

      if ($oSiteuser) {
        $aSiteuser_Groups = $oSiteuser->Siteuser_Groups->findAll(false);
        foreach ($aSiteuser_Groups as $aSiteuserGroup) {
          $aSiteuserGroups[] = $aSiteuserGroup->id;
        }
      }
    }

    if (
      $oStructure->indexing == 1 &&
      in_array($iStructureAccess, $aSiteuserGroups)
    ) {
      // разрешаем роботам индексировать контент
      $meta_val = 'index, follow';
    } else {
      // запрещаем роботам индексировать контент
      $meta_val = 'noindex, nofollow';
    }
    return $meta_val;
  }

  /**
   * Детектор отключенного сайта
   * Core_Utils::is503error()
   *
   * @param mixed $site_id
   * @return
   *
   * @example
   * if (!Core_Utils::is503error())
   * {
   * 		// выводим форму входа в личный кабинет
   * }
   * else
   * {
   * 		// НЕ выводим форму входа в личный кабинет, пишем "Извините, сейчас залогниться нельзя"
   * }
   */
  public static function is503error($site_id = CURRENT_SITE)
  {
    $site_id = intval($site_id);
    $oSite = $site_id ? Core_Entity::factory('Site', $site_id) : null;
    return is_null($oSite) || !$oSite->active;
  }

  /**
   * Быстрый вывод документа по его id
   * Core_Utils::ShowDoc()
   *
   * @param mixed $doc_id
   * @return void
   *
   * @example
   * Core_Utils::ShowDoc(123); // <p>Это мой документ</p>
   *
   */
  public static function ShowDoc($doc_id)
  {
    $doc_id = intval($doc_id);
    $doc_id &&
      Core::moduleIsActive('document') &&
      Core_Entity::factory('document', $doc_id)
        ->Document_Versions->getCurrent()
        ->execute();
  }

  /**
   * Относительный урл к разделу структуры по его id
   * Core_Utils::getPathByStructureId()
   *
   * @param mixed $iStrucutreId
   * @return
   *
   * @example
   * Core_Utils::getPathByStructureId(456); //  /path/to/my/structure/
   *
   */
  static function getPathByStructureId($iStrucutreId = CURRENT_STRUCTURE_ID)
  {
    return intval($iStrucutreId)
      ? Core_Entity::factory('Structure', $iStrucutreId)->getPath()
      : '/';
  }

  /**
   * Возвращает id доп.свойства по названию его xml-тега.
   * Полезно, например, если у вас на одной ТДС несколько одинаковых магазинов, с одинаковым набором доп.свойств
   * (у одних и тех же свойств в разным магазинах разные id но одинаковые xml-теги)
   * Позволяет реализовать для таких случаев универсальную ТДС, не завязываясь на id свойств.
   *
   * Core_Utils::getPropertyByTagName()
   *
   * @param integer $iObjectId Идентификатор сущности, к которой относится доп.свойство (инфосистема, магазин, структура, пользователь)
   * @param string $sPropertyTagName xml-имя доп.свойства
   * @param string $sObjectType тип сущности, к которой относится доп.свойство. Одно из фиксированного набора значений: 'Informationsystem_Item', 'Informationsystem_Group', 'Shop_Item', 'Shop_Group', 'Structure', 'Siteuser'
   * @return integer
   *
   *
   * @example
   * В магазине 1 есть доп.свойство группы, с xml-тегом my_group_property, нужно узнать id этого доп.свойства и получить объект свойства
   *
   * $oShop = Core_Entity::factory('Shop', 1);
   * $propertyTagName = 'my_group_property';
   * $propertyType = 'Shop_Group';
   *
   * $oProperty = Core_Utils::getPropertyByTagName($oShop->id, $propertyTagName, $propertyType); // важно, в первом параметре идентификатор именно магазина, а не его группы или товара!
   */
  static $_aPropertiesCache = null;
  static $_aPropertiesObjCache = [];
  public static function getPropertyByTagName(
    $iObjectId = 0,
    $sPropertyTagName = '',
    $sObjectType = 'Informationsystem_Item'
  ) {
    $aAllowedObjectTypes = [
      'Informationsystem_Item',
      'Informationsystem_Group',
      'Shop_Item',
      'Shop_Group',
      'Structure',
      'Siteuser',
    ];

    $sObjectType = strval($sObjectType);
    $iObjectId = intval($iObjectId);
    $sPropertyTagName = strval($sPropertyTagName);

    if (
      $iObjectId > 0 &&
      $sPropertyTagName != '' &&
      in_array($sObjectType, $aAllowedObjectTypes)
    ) {
      $_oCore_Cache = Core::moduleIsActive('cache')
        ? Core_Cache::instance(Core::$mainConfig['defaultCache'])
        : null;
      $cacheKey =
        'getPropertyByTagName' . $iObjectId . $sPropertyTagName . $sObjectType;

      $iPropertyId = null;
      $oProperty = null;

      if (is_null(Core_Utils::$_aPropertiesCache)) {
        if ($_oCore_Cache) {
          Core_Utils::$_aPropertiesCache = $_oCore_Cache->get(
            'getPropertyByTagName',
            $cacheName = 'default'
          );
        }
        // если кеш отключен или пуст
        if (is_null(Core_Utils::$_aPropertiesCache)) {
          Core_Utils::$_aPropertiesCache = [];
        }
      }

      // в кеше храним id доп.свойства
      if (isset(Core_Utils::$_aPropertiesCache[$cacheKey])) {
        $iPropertyId = Core_Utils::$_aPropertiesCache[$cacheKey];
      }

      if (!$iPropertyId) {
        Core_Utils::$_aPropertiesCache[$cacheKey] = null;

        $linkedObject = Core_Entity::factory(
          $sObjectType . '_Property_List',
          $iObjectId
        );
        if (!is_null($linkedObject)) {
          $aProperties = $linkedObject->Properties->getAllByTag_Name(
            $sPropertyTagName
          );
          if ($aProperties && isset($aProperties[0])) {
            $oProperty = $aProperties[0];
            Core_Utils::$_aPropertiesCache[$cacheKey] = $oProperty->id;
            $_oCore_Cache &&
              $_oCore_Cache->set(
                'getPropertyByTagName',
                Core_Utils::$_aPropertiesCache,
                $cacheName = 'default'
              );
          }
        }
      } else {
        if (isset(Core_Utils::$_aPropertiesObjCache[$iPropertyId])) {
          return Core_Utils::$_aPropertiesObjCache[$iPropertyId];
        }
        $oProperty = Core_Entity::factory('Property', $iPropertyId);
      }
      !is_null($oProperty) &&
        (Core_Utils::$_aPropertiesObjCache[$oProperty->id] = $oProperty);
      return $oProperty;
    }
    return null;
  }

  /**
   * Быстрое получение первого значения доп.свойства
   * Core_Utils::getPropertyFirstValue()
   *
   * @param mixed $oProperty
   * @param integer $iEntityId
   * @return
   *
   * @example
   * Получение первого значения свойства товара магазина с id=123 для товара с id=456
   *
   * $oProperty = Core_Entity::factory('Property', 123);
   * $firstValue = Core_Utils::getPropertyFirstValue($oProperty, 456);
   *
   */
  public static function getPropertyFirstValue(
    $oProperty = null,
    $iEntityId = 0
  ) {
    if ($oProperty) {
      $aPropertyValues = $oProperty->getValues($iEntityId);
      if (isset($aPropertyValues[0])) {
        return $aPropertyValues[0]->value;
      }
    }
    return null;
  }

  /**
   * Построение урла возврата на текущую страницу.
   * Используется, когда вам нужно уйти со страницы в какой-то другой процесс (например, авторизация или регистрация) а потом вернуться сюда же.
   * Урл страницы для возврата передается в параметре retpath
   *
   * Core_Utils::prepareRetpath()
   *
   * @param string $sRetpath
   * @return
   */
  public static function prepareRetpath($sRetpath = '', $aAddQueryParams = [])
  {
    $aQueryTrashParams = ['hostcmsAction'];

    $sRetpath = htmlspecialchars_decode(rawurldecode(trim(strval($sRetpath))));
    if ($sRetpath == '') {
      $sRetpath = htmlspecialchars_decode(
        rawurldecode(trim(strval(Core_Array::get($_COOKIE, 'retpath'))))
      );
    }

    $aRetpath = parse_url($sRetpath);

    if (isset($aRetpath['query'])) {
      parse_str($aRetpath['query'], $aQuery);

      if (isset($aQuery['action']) && $aQuery['action'] == 'exit') {
        unset($aQuery['action']);
      }

      foreach ($aQueryTrashParams as $sParamName) {
        if (isset($aQuery[$sParamName])) {
          unset($aQuery[$sParamName]);
        }
      }

      if (is_array($aAddQueryParams) && sizeof($aAddQueryParams)) {
        foreach ($aAddQueryParams as $sParamName => $sParamValue) {
          trim(strval($sParamName)) != '' &&
            ($aQuery[trim(strval($sParamName))] = strval($sParamValue));
        }
      }

      $aQuery['ncrnd'] = rand();

      $aRetpath['query'] = http_build_query($aQuery);
    } else {
      $aQuery = [];

      $aQuery['ncrnd'] = rand();

      if (is_array($aAddQueryParams) && sizeof($aAddQueryParams)) {
        foreach ($aAddQueryParams as $sParamName => $sParamValue) {
          trim(strval($sParamName)) != '' &&
            ($aQuery[trim(strval($sParamName))] = strval($sParamValue));
        }
      }

      $aRetpath['query'] = http_build_query($aQuery);
    }

    $sRetpath = '';
    $sRetpath .= isset($aRetpath['scheme']) ? $aRetpath['scheme'] : 'http';
    $sRetpath .= '://';
    $sRetpath .= Core_Entity::factory('Site', CURRENT_SITE)->getCurrentAlias()
      ->name;
    isset($aRetpath['path']) && ($sRetpath .= $aRetpath['path']);
    $sRetpath .= mb_strlen($aRetpath['query']) > 0 ? '?' : '';
    $sRetpath .= $aRetpath['query'];
    $sRetpath .= isset($aRetpath['fragment'])
      ? '#' . $aRetpath['fragment']
      : '';

    return $sRetpath;
  }

  /**
   * Редирект на урл возврата
   * На самом деле, просто быстрый редирект на переданый урл.
   * Core_Utils::goToRetpath()
   *
   * @param string $sRetpath
   * @param integer $iHttpCode
   * @return void
   */
  public static function goToRetpath($sRetpath = '', $iHttpCode = 302)
  {
    $sRetpath = trim($sRetpath);
    if ($sRetpath != '') {
      $oCore_Response = new Core_Response();
      $oCore_Response
        ->status($iHttpCode)
        ->header('Expires', gmdate('D, d M Y H:i:s', time() - 100) . ' GMT')
        ->header('Cache-control', 'private, max-age=0')
        ->header('Location', $sRetpath)
        ->sendHeaders();
      exit();
    }
  }

  /**
   * Быстрая отправка аякс-ответа
   * Core_Utils::ajaxResponse()
   *
   * @param string $sResponseBody
   * @param integer $iHttpCode
   * @param string $contentType
   * @return void
   */
  public static function ajaxResponse(
    $sResponseBody = '',
    $iHttpCode = 200,
    $contentType = 'application/json'
  ) {
    $iHttpCode = intval($iHttpCode) || 200;
    $sResponseBody = trim(strval($sResponseBody));
    $contentType = trim(strval($contentType)) || 'application/json';

    $oSite = Core_Entity::factory('Site', CURRENT_SITE);
    $oCore_Response = new Core_Response();
    $oCore_Response
      ->status($iHttpCode)
      ->header('Content-Type', $contentType . '; charset=' . $oSite->coding)
      ->header('Expires', gmdate('D, d M Y H:i:s', time() - 100) . ' GMT')
      ->header('Cache-control', 'private, max-age=0')
      ->body($sResponseBody)
      ->sendHeaders()
      ->showBody();
    exit();
  }

  /**
   * Быстрое типографирование текста
   * Core_Utils::ProcessTypographic()
   *
   * @param mixed $sText
   * @param bool $bEnableOptic
   * @return
   */
  public static function ProcessTypographic($sText, $bEnableOptic = true)
  {
    $sText = trim(strval($sText));
    if ($sText && Core::moduleIsActive('typograph')) {
      $bEnableOptic = Core_Type_Conversion::toBool($bEnableOptic);
      $sText = Typograph_Controller::instance()->process($sText, $bEnableOptic);
    }
    return $sText;
  }

  /**
   * Быстрая подготовка текста (удаление всех тегов, кроме разрешенных, и типографирование)
   * Core_Utils::prepareUserText()
   *
   * @param string $sText
   * @param bool $bProcessTypographic
   * @param mixed $sAdditionalAllowedTags
   * @return
   */
  public static function prepareUserText(
    $sText = '',
    $bProcessTypographic = true,
    $aAllowedTags = [
      'a',
      'b',
      'br',
      'caption',
      'em',
      'h2',
      'h3',
      'h4',
      'h5',
      'h6',
      'i',
      'li',
      'ol',
      'p',
      'strike',
      'strong',
      'sub',
      'sup',
      'table',
      'tbody',
      'td',
      'thead',
      'thead',
      'tr',
      'u',
      'ul',
    ]
  ) {
    $sText = trim(strval($sText));
    if ($sText != '') {
      $sText = Core_Utils::textSmartCut($sText, -1, $aAllowedTags);
      $bProcessTypographic && ($sText = Core_Utils::ProcessTypographic($sText));
    }
    return $sText;
  }

  /**
   * Подготовка описания инфоэлемента из текста, введенного пользователем
   * Удаление из него списков и таблиц, интеллектуальная обрезка на заданную длинну с сохранением целых предложений (см ниже), и типографирование
   * Core_Utils::prepareUserDescription()
   *
   * @param string $sText
   * @param integer $iTextLength
   * @param bool $bProcessTypographic
   * @param mixed $bAllowTags
   * @return
   */
  public static function prepareUserDescription(
    $sText = '',
    $iTextLength = 250,
    $bProcessTypographic = true,
    $aAllowTags = []
  ) {
    $sText = trim(strval($sText));
    if ($sText != '') {
      // удалим из описания все таблицы и списки
      $sText = preg_replace(
        '%<table\b[^>]*+>(?:(?R)|[^<]*+(?:(?!</?table\b)<[^<]*+)*+)*+</table>%i',
        '',
        $sText
      );
      $sText = preg_replace(
        '%<ul\b[^>]*+>(?:(?R)|[^<]*+(?:(?!</?ul\b)<[^<]*+)*+)*+</ul>%i',
        '',
        $sText
      );
      $sText = preg_replace(
        '%<ol\b[^>]*+>(?:(?R)|[^<]*+(?:(?!</?ol\b)<[^<]*+)*+)*+</ol>%i',
        '',
        $sText
      );

      $sText = Core_Utils::textSmartCut($sText, $iTextLength, $aAllowTags);

      $bProcessTypographic && ($sText = Core_Utils::ProcessTypographic($sText));
    }
    return $sText;
  }

  /**
   * Core_Utils::textSmartCut() функция обрезки текста по концам предложений, с сохранением целостности тегов html и удалением лишних тегов и атрибутов.
   *
   * @param string $sText
   * @param integer $iLength
   * @param mixed $aAllowedTags
   * @param mixed $aDisabledAttributes
   * @param string $sDelim
   * @author James V. Kotov. Based on code from Ilya Lebedev.
   * @return
   */
  public static function textSmartCut(
    $sText = '',
    $iLength = 250,
    $aAllowedTags = [],
    $aDisabledAttributes = [],
    $sDelim = '\s;,.!?:#'
  ) {
    $_aAllowedTags = [
      'a',
      'b',
      'br',
      'em',
      'i',
      'li',
      'ol',
      'p',
      'strike',
      'strong',
      'sub',
      'sup',
      'u',
      'ul',
    ];

    $_aDisabledAttributes = [
      'align',
      'border',
      'cellpadding',
      'cellspacing',
      'class',
      'color',
      'face',
      'height',
      'lang',
      'nowrap',
      'onabort',
      'onactivate',
      'onafterprint',
      'onafterupdate',
      'onbeforeactivate',
      'onbeforecopy',
      'onbeforecut',
      'onbeforedeactivate',
      'onbeforeeditfocus',
      'onbeforepaste',
      'onbeforeprint',
      'onbeforeunload',
      'onbeforeupdate',
      'onblur',
      'onbounce',
      'oncellchange',
      'onchange',
      'onclick',
      'oncontextmenu',
      'oncontrolselect',
      'oncopy',
      'oncut',
      'ondataavaible',
      'ondatasetchanged',
      'ondatasetcomplete',
      'ondblclick',
      'ondeactivate',
      'ondrag',
      'ondragdrop',
      'ondragend',
      'ondragenter',
      'ondragleave',
      'ondragover',
      'ondragstart',
      'ondrop',
      'onerror',
      'onerrorupdate',
      'onfilterupdate',
      'onfinish',
      'onfocus',
      'onfocusin',
      'onfocusout',
      'onhelp',
      'onkeydown',
      'onkeypress',
      'onkeyup',
      'onlayoutcomplete',
      'onload',
      'onlosecapture',
      'onmousedown',
      'onmouseenter',
      'onmouseleave',
      'onmousemove',
      'onmouseover',
      'onmouseup',
      'onmousewheel',
      'onmove',
      'onmoveend',
      'onmoveout',
      'onmovestart',
      'onpaste',
      'onpropertychange',
      'onreadystatechange',
      'onreset',
      'onresize',
      'onresizeend',
      'onresizestart',
      'onrowexit',
      'onrowsdelete',
      'onrowsinserted',
      'onscroll',
      'onselect',
      'onselectionchange',
      'onselectstart',
      'onstart',
      'onstop',
      'onsubmit',
      'onunload',
      'rel',
      'size',
      'style',
      'valign',
      'vspace',
      'width',
    ];

    // готовим исходные данные
    $sText = str_replace('&nbsp;', ' ', strval($sText));
    $sText = html_entity_decode($sText, ENT_QUOTES, 'UTF-8');
    $iLength = intval($iLength);

    $sAllowedTags = '';
    is_array($aAllowedTags) &&
      !sizeof($aAllowedTags) &&
      ($aAllowedTags = $_aAllowedTags);
    $aAllowedTags !== false &&
      ($sAllowedTags = '<' . implode('><', $aAllowedTags) . '>');

    is_array($aDisabledAttributes) &&
      !sizeof($aDisabledAttributes) &&
      ($aDisabledAttributes = $_aDisabledAttributes);

    Core::moduleIsActive('typograph') &&
      ($sText = Typograph_Controller::instance()->eraseOpticalAlignment(
        $sText
      ));

    // здесь нам нужен текст вообще без тегов!
    $_sText = strip_tags($sText) . ' ';

    if ($iLength >= 0 && mb_strlen($_sText, 'UTF-8') > $iLength) {
      $__sText = mb_substr($_sText, 0, $iLength, 'UTF-8') . ' ';
      $last_point = mb_strrpos($__sText, '. ', 'UTF-8'); // последний '. ' в укороченной строке
      $last_point === false &&
        ($last_point = mb_strpos($_sText, '. ', 0, 'UTF-8')); // первый '. ' в исходной строке
      ($last_point === false || $last_point > $iLength * 2) &&
        ($last_point = mb_strrpos($__sText, ' ', 'UTF-8')); // последний ' ' в укороченной строке
      $_sText = trim(mb_substr($_sText, 0, $last_point + 1, 'UTF-8'));
      $iLength = strlen($_sText); // не mb_!

      unset($__sText, $_sText);

      $sText = preg_replace_callback(
        '#(</?[a-z]+(?:>|\s[^>]*>)|[^<]+)#mi',
        create_function(
          '$a',
          'static $iLength = ' .
            $iLength .
            ';' .
            '$iLength1 = $iLength-1;' .
            '$sDelim = \'' .
            str_replace('#', '\\#', $sDelim) .
            '\';' .
            'if ("<" == $a[0]{0}) return $a[0];' .
            'if ($iLength<=0) return "";' .
            '$res = preg_split("#(.{0,$iLength1}+(?=[$sDelim]))|(.{0,$iLength}[^$sDelim]*)#ms",$a[0],2,PREG_SPLIT_DELIM_CAPTURE);' .
            'if ($res[1]) { $iLength -= strlen($res[1])+1; $res = $res[1];}' .
            'else { $iLength -= strlen($res[2]); $res = $res[2];}' .
            '/*$res = rtrim($res);*//*preg_replace("#[$sDelim]+$#m","",$res);*/' .
            'return $res;'
        ),
        $sText
      );

      while (preg_match('#<([a-z]+)[^>]*>\s*</\\1>#mi', $sText)) {
        $sText = preg_replace('#<([a-z]+)[^>]*>\s*</\\1>#mi', '', $sText);
      }
    }

    // почистим лишние атрибуты и стили

    // Проверяем заголовки
    if ($aAllowedTags !== false) {
      $aReplaseHeadings = [];
      for ($i = 1; $i <= 6; $i++) {
        !in_array('h' . $i, $aAllowedTags) && ($aReplaseHeadings[] = $i);
      }
      if (sizeof($aReplaseHeadings)) {
        // заменяем заголовки на абзацы, для тех заголовков которые не разрешены
        $sHeaders = implode('|', $aReplaseHeadings);
        $sText = preg_replace(
          "/<h[({$sHeaders})]>(.*?)<\/h[({$sHeaders})]>/",
          '<p><b>$1</b></p>',
          $sText
        );
      }
    }
    if ($aDisabledAttributes === false) {
      $sText = strip_tags($sText, $sAllowedTags);
    } else {
      $sText = preg_replace(
        '/<(.*?)>/ieu',
        "'<' . preg_replace(array('/javascript:[^\"\']*/iu', '/(" .
          implode('|', $aDisabledAttributes) .
          ")[ \\t\\n]*=[ \\t\\n]*[\"\'][^\"\']*[\"\']/i', '/\s+/'), array('', '', ' '), stripslashes('\\1')) . '>'",
        strip_tags($sText, $sAllowedTags)
      );
    }
    // закроем внешние ссылки от индексации
    if (in_array('a', $aAllowedTags)) {
      $sText = preg_replace(
        '#<a([^>]+?)href\s*=\s*(["\']*)\s*(http://|https://|ftp://|mailto:)([^"\'\s>]+)\s*\\2([^>]*?)>(.*?)</a>#is',
        '<noindex><a$1href=$2$3$4$2 $5 rel="nofollow">$6</a></noindex>',
        $sText
      );
    }
    return $sText;
  }
}
