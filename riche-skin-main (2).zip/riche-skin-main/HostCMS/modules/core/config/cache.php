<?php

$aTypicalCaches = [
  'default' => ['expire' => 3600, 'size' => 262144, 'tags' => false],
  'Core_ORM' => ['expire' => 3600, 'size' => 262144, 'tags' => false],
  'Core_ORM_ColumnCache' => [
    'expire' => 3600,
    'size' => 262144,
    'tags' => false,
  ],
  'Core_ORM_RelationCache' => [
    'expire' => 3600,
    'size' => 262144,
    'tags' => false,
  ],
  'ipaddresses' => ['expire' => 1800, 'size' => 262144, 'tags' => false],
  'informationsystem_rss' => ['expire' => 14400, 'size' => 262144],
  'informationsystem_show' => [
    'expire' => 14400,
    'size' => 262144,
    'compress' => true,
  ],
  'informationsystem_tags' => [
    'expire' => 14400,
    'size' => 262144,
    'compress' => true,
  ],
  'shop_show' => ['expire' => 14400, 'size' => 262144, 'compress' => true],
  'shop_tags' => ['expire' => 14400, 'size' => 262144, 'compress' => true],
  'search' => ['expire' => 14400, 'size' => 262144, 'tags' => false],
  'structure_breadcrumbs' => ['expire' => 14400, 'size' => 262144],
  'structure_show' => ['expire' => 14400, 'size' => 262144, 'compress' => true],
  'counter_allSession' => ['expire' => 1800, 'size' => 1024, 'tags' => false],

  'app_command' => [
    'expire' => 14400, // 4 h
    'size' => 262144, // 262144 kb
    'compress' => true,
  ],
];

return [
  'memory' => [
    'name' => 'Memory',
    'driver' => 'Core_Cache_Memory',
    'caches' => [
      'default' => [],
    ],
  ],
  'file' => [
    'name' => 'File',
    'driver' => 'Cache_File',
    'checksum' => false,
    'caches' => $aTypicalCaches,
  ],
  'memcache' => [
    'name' => 'Memcache',
    'driver' => 'Cache_Memcache',
    'server' => '127.0.0.1',
    'port' => 11211,
    'checksum' => true,
    'caches' => $aTypicalCaches,
  ],
  'memcached' => [
    'name' => 'Memcached',
    'driver' => 'Cache_Memcached',
    'server' => '127.0.0.1',
    'port' => 11211,
    'checksum' => true,
    'caches' => $aTypicalCaches,
  ],
  'apc' => [
    'name' => 'APC/APCU',
    'driver' => 'Cache_APC',
    'checksum' => true,
    'caches' => $aTypicalCaches,
  ],
  'xcache' => [
    'name' => 'XCache',
    'driver' => 'Cache_XCache',
    'checksum' => true,
    'caches' => $aTypicalCaches,
  ],
  'static' => [
    'name' => 'Static',
    'driver' => 'Cache_Static',
    'caches' => [
      'default' => ['expire' => 3600, 'size' => null],
    ],
  ],
];
