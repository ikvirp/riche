<?php

return [
  'default' => [
    'driver' => 'smtp',
  ],
  'sendmail' => [
    'driver' => 'sendmail',
  ],
  'smtp' => [
    'driver' => 'smtp',
    'username' => 'noreply@riche.me',
    'port' => '465', // для SSL порт 465
    'host' => 'ssl://smtp.yandex.ru', // для SSL используйте ssl://smtp.gmail.com
    'password' => 'fxkgfebbpkxrnwoo', // Di1=Dow9-Sac9,
    'options' => [
      'ssl' => [
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true,
      ],
    ],
  ],
];
