<?php

return array(
	'default' => array(
		'driver' => 'pdo',
		'host' => 'localhost',
		'username' => 'riche_bd',
		'password' => 's<nms8T7[*Hy',
		'database' => 'riche_hostcms',
		'charset' => 'utf8mb4',
		'storageEngine' => 'InnoDB'
	)
);