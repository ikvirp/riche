<?php

defined('HOSTCMS') || exit('HostCMS: access denied.');

/**
 * Shop_Observer_Hmp
 *
 *
 * // Округление цены со скидкой
 * Core_Event::notify('Shop_Item_Controller.onAfterCalculatePrice', array('Shop_Observer_Hmp', 'ShopItemControllerOnAfterCalculatePrice'));
 *
 */

class Shop_Observer_Hmp
{
  // округление цены после скидки
  public static function ShopItemControllerOnAfterCalculatePrice($object, $args)
  {
  }

  // Общий алгоритм распределения скидок по товарам
  public static function Shop_Order__Explode($oShop_Order)
  {
    // self::_getRatio();

    // Массив для возврата
    $aReturn = [];

    // разбиваем количество товаров — по одному
    $aShop_Order_Items = $oShop_Order->Shop_Order_Items->findAll(false);
    if (count($aShop_Order_Items)) {
      // Разбиваем количество в заказе на отдельные товары
      foreach ($aShop_Order_Items as $oShop_Order_Item) {
        if ($oShop_Order_Item->type == 0 and $oShop_Order_Item->quantity > 1) {
          $for = intval($oShop_Order_Item->quantity);

          // ставим текущему товару 1
          $oShop_Order_Item->quantity = 1;
          $oShop_Order_Item->save();

          // добавляем осатаки по циклу
          for ($i = 1; $i < $for; $i++) {
            $oShop_Order->add(clone $oShop_Order_Item);
          }
        }
      }

      // Разбиваем бонусы и скидки
      $aShop_Order_Items = $oShop_Order->Shop_Order_Items;
      $aShop_Order_Items
        ->queryBuilder()
        ->clearOrderBy()
        ->orderBy('shop_item_id', 'ASC');
      $aShop_Order_Items = $aShop_Order_Items->findAll(false);
      $aPre_Shop_Order_Items = [];
      $aPre_Shop_Order_Delivery = [];
      $amount = $quantity = $amount_items = $quantity_items = $amount_delivery = $bonus_use = $sale_use = $minus_total = 0;
      foreach ($aShop_Order_Items as $oShop_Order_Item) {
        // 0 — Товар
        // 1 — Доставка
        // 2 — Пополнение лицевого счета
        // 3 — Скидка от суммы заказа
        // 4 — Скидка по дисконтной карте
        // 5 — Списание бонусов
        // 6 — Частичная оплата с лицевого счета

        // Общая сумма
        $amount += floatval(
          $oShop_Order_Item->quantity * $oShop_Order_Item->price
        );

        // Количество
        $quantity += floatval($oShop_Order_Item->quantity);

        // Добавляем товары в отдельный массив
        if ($oShop_Order_Item->type == 0) {
          $aPre_Shop_Order_Items[] = $oShop_Order_Item;
          $amount_items += floatval(
            $oShop_Order_Item->quantity * $oShop_Order_Item->price
          );
          $quantity_items += floatval($oShop_Order_Item->quantity);
        }

        // Добавляем доставку в отдельный массив
        if ($oShop_Order_Item->type == 1) {
          $aPre_Shop_Order_Delivery[] = $oShop_Order_Item;
          $amount_delivery += floatval(
            $oShop_Order_Item->quantity * $oShop_Order_Item->price
          );
        }

        // Бонусы
        if ($oShop_Order_Item->type == 5) {
          $bonus_use += floatval(
            $oShop_Order_Item->quantity * $oShop_Order_Item->price
          );
        }

        // Скидки
        if (
          $oShop_Order_Item->type == 3 || // от суммы
          $oShop_Order_Item->type == 4 || // по дисконтной карте
          $oShop_Order_Item->type == 6 // частичная оплата с лицевого счета
        ) {
          $sale_use += floatval(
            $oShop_Order_Item->quantity * $oShop_Order_Item->price
          );
        }
      }

      // echo_r('$amount: ' . $amount); // Сумма заказа
      // echo_r('$quantity: ' . $quantity); // Количество товаров в заказе
      // echo_r('$amount_items: ' . $amount_items); // Стоимостьтоваров
      // echo_r('$quantity_items: ' . $quantity_items); // Колиество товаров
      // echo_r('$amount_delivery: ' . $amount_delivery); // Стоимость доставки

      // абсолютное значение бонусов
      $bonus_use = abs($bonus_use);
      $sale_use = abs($sale_use);

      // echo_r('$bonus_use: ' . $bonus_use); // Стоимость бонусов
      // echo_r('$sale_use: ' . $sale_use); // Стоимость скидок

      // сумма для расписания по скидок и донусов по товарам
      $minus_total = $bonus_use + $sale_use;
      // echo_r('$bonus_use + $sale_use: ' . $minus_total);

      // Список всего что списывается
      $aMinus = [];

      // Расписываем бонусы по товарам
      if (intval($bonus_use) > 0) {
        // Считаем коэффициент на каждый товар
        $coef =
          $amount_items != 0 && $quantity_items != 0
            ? round(
              abs($bonus_use) / floatval($amount_items),
              4,
              PHP_ROUND_HALF_DOWN
            )
            : 0;

        // echo_r('-------------'); // коэффициент на каждый товар
        // echo_r('$coef: ' . $coef); // коэффициент на каждый товар

        // cчитаем количество элементов массива
        $iCountItems = count($aPre_Shop_Order_Items);

        // Проходим массив и распределяем сумму бонусов на карждый товар
        $iBonusCount = 0;
        $i = 1;

        foreach ($aPre_Shop_Order_Items as $oShop_Order_Item) {
          $fAmount = floatval(
            $oShop_Order_Item->quantity * $oShop_Order_Item->price
          );

          // Сколько бонусов на стоимость
          $iBonusForItemItem = intval($fAmount * $coef);

          // Если последний товар — Отнимаем остаток
          if ($i == $iCountItems) {
            $iBonusForItemItem = $bonus_use - $iBonusCount;
          }

          // Считаем уже расписаные бонусы
          $iBonusCount += $iBonusForItemItem;

          // echo_r(
          //   $oShop_Order_Item->id .
          //     ' — ' .
          //     $oShop_Order_Item->name .
          //     ' — ' .
          //     $fAmount .
          //     ' — ' .
          //     $iBonusForItemItem .
          //     ' — ' .
          //     $iBonusCount .
          //     ' - ' .
          //     abs($bonus_use)
          // );

          // Записываем в массив к какому товару сисываем бонус
          $aMinus['bonus_use'][$oShop_Order_Item->id] = $iBonusForItemItem;

          $i++;
        }
      }

      // Расписываем скидки по товарам
      if (intval($sale_use) > 0) {
        // Считаем коэффициент на каждый товар
        $coef =
          $amount_items != 0 && $quantity_items != 0
            ? round(
              abs($sale_use) / floatval($amount_items),
              4,
              PHP_ROUND_HALF_DOWN
            )
            : 0;

        // echo_r('-------------'); // коэффициент на каждый товар
        // echo_r('$coef: ' . $coef); // коэффициент на каждый товар

        // cчитаем количество элементов массива
        $iCountItems = count($aPre_Shop_Order_Items);

        // Проходим массив и распределяем сумму бонусов на карждый товар
        $iBonusCount = 0;
        $i = 1;

        foreach ($aPre_Shop_Order_Items as $oShop_Order_Item) {
          $fAmount = floatval(
            $oShop_Order_Item->quantity * $oShop_Order_Item->price
          );

          // Сколько бонусов на стоимость
          $iBonusForItemItem = intval($fAmount * $coef);

          // Если последний товар — Отнимаем остаток
          if ($i == $iCountItems) {
            $iBonusForItemItem = $sale_use - $iBonusCount;
          }

          // Считаем уже расписаные бонусы
          $iBonusCount += $iBonusForItemItem;

          // echo_r(
          //   $oShop_Order_Item->id .
          //     ' — ' .
          //     $oShop_Order_Item->name .
          //     ' — ' .
          //     $fAmount .
          //     ' — ' .
          //     $iBonusForItemItem .
          //     ' — ' .
          //     $iBonusCount .
          //     ' - ' .
          //     abs($sale_use)
          // );

          // Записываем в массив к какому товару сисываем скидку
          $aMinus['sale_use'][$oShop_Order_Item->id] = $iBonusForItemItem;

          $i++;
        }
      }

      // echo_r($aMinus);

      // Удаляем всё из заказа
      $oShop_Order->Shop_Order_Items->deleteAll(false);

      // Обходим все товары из времменного массива и добавляем в заказ
      foreach ($aPre_Shop_Order_Items as $oShop_Order_Item) {
        $oShop_Order->add(clone $oShop_Order_Item);

        $item_id = $oShop_Order_Item->id;

        // Сколько всего списывается из стоимости товара
        $iMinus = 0;

        // Бонусы из массива
        if (
          isset($aMinus['bonus_use'][$item_id]) &&
          intval($aMinus['bonus_use'][$item_id]) > 0
        ) {
          $iMinus += intval($aMinus['bonus_use'][$item_id]);

          $oShop_Order_Item__Bonus = self::Shop_Order_Item__Add(
            'Списание бонусов за товар ' . $oShop_Order_Item->name,
            intval($aMinus['bonus_use'][$item_id]) * -1,
            5
          );
          $oShop_Order->add($oShop_Order_Item__Bonus);
        }

        // Скидки из массива
        if (
          isset($aMinus['sale_use'][$item_id]) &&
          intval($aMinus['sale_use'][$item_id]) > 0
        ) {
          $iMinus += intval($aMinus['sale_use'][$item_id]);

          $oShop_Order_Item__Sale = self::Shop_Order_Item__Add(
            'Скидка на товар ' . $oShop_Order_Item->name,
            intval($aMinus['sale_use'][$item_id]) * -1,
            3
          );
          $oShop_Order->add($oShop_Order_Item__Sale);
        }

        $aReturn[$item_id] = [
          'name' => $oShop_Order_Item->name,
          'price' => $oShop_Order_Item->price,
          'sale' => $iMinus,
          'price_out' => $oShop_Order_Item->price - $iMinus,
        ];
      }

      // Обходим все доставки  и добавляем в заказ
      foreach ($aPre_Shop_Order_Delivery as $oShop_Order_Item) {
        $oShop_Order->add(clone $oShop_Order_Item);

        $item_id = $oShop_Order_Item->id;

        // С доставки ничего не списываем
        $iMinus = 0;

        $aReturn[$item_id] = [
          'name' => $oShop_Order_Item->name,
          'price' => $oShop_Order_Item->price,
          'sale' => $iMinus,
          'price_out' => $oShop_Order_Item->price - $iMinus,
        ];
      }

      // Сохраняем заказ
      $oShop_Order->save();

      // echo_r($aReturn);
    }
  }

  public static function Shop_Order_Item__Add($name, $amount, $type)
  {
    $oShop_Order_Item = Core_Entity::factory('Shop_Order_Item');
    $oShop_Order_Item->name = $name;
    $oShop_Order_Item->quantity = 1;
    $oShop_Order_Item->price = $amount;
    $oShop_Order_Item->type = $type;
    return $oShop_Order_Item;
  }

  public static function Shop_Order__Print($oShop_Order)
  {
    $aReturn = [];

    $aShop_Order_Items = $oShop_Order->Shop_Order_Items;
    $aShop_Order_Items
      ->queryBuilder()
      ->clearOrderBy()
      ->orderBy('shop_item_id', 'ASC');
    $aShop_Order_Items = $aShop_Order_Items->findAll(false);
    $aPre_Shop_Order_Items = [];
    $aPre_Shop_Order_Delivery = [];
    $amount = $quantity = $amount_items = $quantity_items = $amount_delivery = $bonus_use = $sale_use = $minus_total = 0;
    foreach ($aShop_Order_Items as $oShop_Order_Item) {
      // 0 — Товар
      // 1 — Доставка
      // 2 — Пополнение лицевого счета
      // 3 — Скидка от суммы заказа
      // 4 — Скидка по дисконтной карте
      // 5 — Списание бонусов
      // 6 — Частичная оплата с лицевого счета

      // Общая сумма
      $amount += floatval(
        $oShop_Order_Item->quantity * $oShop_Order_Item->price
      );

      // Количество
      $quantity += floatval($oShop_Order_Item->quantity);

      // Добавляем товары в отдельный массив
      if ($oShop_Order_Item->type == 0) {
        $aPre_Shop_Order_Items[] = $oShop_Order_Item;
        $amount_items += floatval(
          $oShop_Order_Item->quantity * $oShop_Order_Item->price
        );
        $quantity_items += floatval($oShop_Order_Item->quantity);
      }

      // Добавляем доставку в отдельный массив
      if ($oShop_Order_Item->type == 1) {
        $aPre_Shop_Order_Delivery[] = $oShop_Order_Item;
        $amount_delivery += floatval(
          $oShop_Order_Item->quantity * $oShop_Order_Item->price
        );
      }

      // Бонусы
      if ($oShop_Order_Item->type == 5) {
        $bonus_use += floatval(
          $oShop_Order_Item->quantity * $oShop_Order_Item->price
        );
      }

      // Скидки
      if (
        $oShop_Order_Item->type == 3 || // от суммы
        $oShop_Order_Item->type == 4 || // по дисконтной карте
        $oShop_Order_Item->type == 6 // частичная оплата с лицевого счета
      ) {
        $sale_use += floatval(
          $oShop_Order_Item->quantity * $oShop_Order_Item->price
        );
      }
    }

    // echo_r('$amount: ' . $amount); // Сумма заказа
    // echo_r('$quantity: ' . $quantity); // Количество товаров в заказе
    // echo_r('$amount_items: ' . $amount_items); // Стоимостьтоваров
    // echo_r('$quantity_items: ' . $quantity_items); // Колиество товаров
    // echo_r('$amount_delivery: ' . $amount_delivery); // Стоимость доставки

    // абсолютное значение бонусов
    $bonus_use = abs($bonus_use);
    $sale_use = abs($sale_use);

    // echo_r('$bonus_use: ' . $bonus_use); // Стоимость бонусов
    // echo_r('$sale_use: ' . $sale_use); // Стоимость скидок

    // сумма для расписания по скидок и донусов по товарам
    $minus_total = $bonus_use + $sale_use;
    // echo_r('$bonus_use + $sale_use: ' . $minus_total);

    // Список всего что списывается
    $aMinus = [];

    // Расписываем бонусы по товарам
    if (intval($bonus_use) > 0) {
      // Считаем коэффициент на каждый товар
      $coef =
        $amount_items != 0 && $quantity_items != 0
          ? round(
            abs($bonus_use) / floatval($amount_items),
            4,
            PHP_ROUND_HALF_DOWN
          )
          : 0;

      // echo_r('-------------'); // коэффициент на каждый товар
      // echo_r('$coef: ' . $coef); // коэффициент на каждый товар

      // cчитаем количество элементов массива
      $iCountItems = count($aPre_Shop_Order_Items);

      // Проходим массив и распределяем сумму бонусов на карждый товар
      $iBonusCount = 0;
      $i = 1;

      foreach ($aPre_Shop_Order_Items as $oShop_Order_Item) {
        $fAmount = floatval(
          $oShop_Order_Item->quantity * $oShop_Order_Item->price
        );

        // Сколько бонусов на стоимость
        $iBonusForItemItem = intval($fAmount * $coef);

        // Если последний товар — Отнимаем остаток
        if ($i == $iCountItems) {
          $iBonusForItemItem = $bonus_use - $iBonusCount;
        }

        // Считаем уже расписаные бонусы
        $iBonusCount += $iBonusForItemItem;

        // echo_r(
        //   $oShop_Order_Item->id .
        //     ' — ' .
        //     $oShop_Order_Item->name .
        //     ' — ' .
        //     $fAmount .
        //     ' — ' .
        //     $iBonusForItemItem .
        //     ' — ' .
        //     $iBonusCount .
        //     ' - ' .
        //     abs($bonus_use)
        // );

        // Записываем в массив к какому товару сисываем бонус
        $aMinus['bonus_use'][$oShop_Order_Item->id] = $iBonusForItemItem;

        $i++;
      }
    }

    // Расписываем скидки по товарам
    if (intval($sale_use) > 0) {
      // Считаем коэффициент на каждый товар
      $coef =
        $amount_items != 0 && $quantity_items != 0
          ? round(
            abs($sale_use) / floatval($amount_items),
            4,
            PHP_ROUND_HALF_DOWN
          )
          : 0;

      // echo_r('-------------'); // коэффициент на каждый товар
      // echo_r('$coef: ' . $coef); // коэффициент на каждый товар

      // cчитаем количество элементов массива
      $iCountItems = count($aPre_Shop_Order_Items);

      // Проходим массив и распределяем сумму бонусов на карждый товар
      $iBonusCount = 0;
      $i = 1;

      foreach ($aPre_Shop_Order_Items as $oShop_Order_Item) {
        $fAmount = floatval(
          $oShop_Order_Item->quantity * $oShop_Order_Item->price
        );

        // Сколько бонусов на стоимость
        $iBonusForItemItem = intval($fAmount * $coef);

        // Если последний товар — Отнимаем остаток
        if ($i == $iCountItems) {
          $iBonusForItemItem = $sale_use - $iBonusCount;
        }

        // Считаем уже расписаные бонусы
        $iBonusCount += $iBonusForItemItem;

        // echo_r(
        //   $oShop_Order_Item->id .
        //     ' — ' .
        //     $oShop_Order_Item->name .
        //     ' — ' .
        //     $fAmount .
        //     ' — ' .
        //     $iBonusForItemItem .
        //     ' — ' .
        //     $iBonusCount .
        //     ' - ' .
        //     abs($sale_use)
        // );

        // Записываем в массив к какому товару сисываем скидку
        $aMinus['sale_use'][$oShop_Order_Item->id] = $iBonusForItemItem;

        $i++;
      }
    }

    // echo_r($aMinus);

    // Обходим все товары из времменного массива и добавляем в заказ
    foreach ($aPre_Shop_Order_Items as $oShop_Order_Item) {
      $item_id = $oShop_Order_Item->id;

      // Сколько всего списывается из стоимости товара
      $iMinus = 0;

      // Бонусы из массива
      if (
        isset($aMinus['bonus_use'][$item_id]) &&
        intval($aMinus['bonus_use'][$item_id]) > 0
      ) {
        $iMinus += intval($aMinus['bonus_use'][$item_id]);
      }

      // Скидки из массива
      if (
        isset($aMinus['sale_use'][$item_id]) &&
        intval($aMinus['sale_use'][$item_id]) > 0
      ) {
        $iMinus += intval($aMinus['sale_use'][$item_id]);
      }

      $real_price = $oShop_Order_Item->price - $iMinus;
      // Если цена > 0
      if ($real_price > 0) {
        $oShop_Order_Item_Code = $oShop_Order_Item->Shop_Order_Item_Codes->getByshop_order_item_id(
          $oShop_Order_Item->id
        );

        // Массив с данными о товаре
        $aPre = [
          'id' => $oShop_Order_Item->id,
          'name' => mb_substr($oShop_Order_Item->name, 0, 128),
          'shop_item_id' => $oShop_Order_Item->shop_item_id,
          'quantity' => $oShop_Order_Item->quantity,
          'price' => $real_price,
          'price_before_sale' => $oShop_Order_Item->price,
          'sale' => $iMinus,
          'tax' => $oShop_Order_Item->rate,
          'type' => $oShop_Order_Item->type,
          'guid' => $oShop_Order_Item->Shop_Item->guid,
          'marking' => $oShop_Order_Item->marking,
        ];

        // Добавляем код маркировки
        $oShop_Order_Item_Code = $oShop_Order_Item->Shop_Order_Item_Codes->getByshop_order_item_id(
          $oShop_Order_Item->id
        );

        if (!is_null($oShop_Order_Item_Code)) {
          $aPre['code'] = $oShop_Order_Item_Code->code;
        }

        $aReturn[$item_id] = $aPre;
      }
    }

    // Обходим все доставки  и добавляем в заказ
    foreach ($aPre_Shop_Order_Delivery as $oShop_Order_Item) {
      $item_id = $oShop_Order_Item->id;

      // С доставки ничего не списываем
      $iMinus = 0;

      $real_price = $oShop_Order_Item->price - $iMinus;
      // Если цена > 0
      if ($real_price > 0) {
        // Массив с данными о товаре
        $aPre = [
          'id' => $oShop_Order_Item->id,
          'name' => mb_substr($oShop_Order_Item->name, 0, 128),
          'shop_item_id' => null,
          'quantity' => $oShop_Order_Item->quantity,
          'price' => $real_price,
          'price_before_sale' => $oShop_Order_Item->price,
          'sale' => $iMinus,
          'tax' => $oShop_Order_Item->rate,
          'type' => $oShop_Order_Item->type,
          'guid' => $oShop_Order_Item->marking,
          'marking' => $oShop_Order_Item->marking,
        ];

        $aReturn[$item_id] = $aPre;
      }
    }

    // echo_r($aReturn);

    return array_values($aReturn);
    //return $aReturn;
  }
}
