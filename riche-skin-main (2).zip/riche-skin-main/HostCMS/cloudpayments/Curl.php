<?php
    /**
     * Created by PhpStorm.
     * User: comp203
     * Date: 028 28.09.17
     * Time: 10:34
     */

    class Curl
    {

        /**
         * Instance curl.
         *
         * @var Resource
         */
        private $ch;

        /**
         * Curl constructor.
         *
         * @param $url
         */
        public function __construct($url)
        {
            $this->url = $url;
            $this->ch = curl_init();
        }

        /**
         * Destructor.
         */
        public function __destruct()
        {
            curl_close($this->ch);
        }

        /**
         * Returns base API url.
         *
         * @param   array  $parameters
         * @param   string $requestMethod
         *
         * @return  string
         */
        public function api($parameters = [], $requestMethod = 'get')
        {
            if ($requestMethod == 'execute' || $requestMethod == 'post') {
                $rs = $this->request($this->url, "POST", $parameters);
            }
            else {
                $rs = $this->request($this->createUrl($this->url, $parameters));
            }

            return $rs;
        }

        /**
         * Receiving a response
         *
         * @param string $url
         * @param string $method
         * @param array  $parameters
         *
         * @return string
         */
        private function request($url, $method = 'GET', $parameters = [])
        {

            curl_setopt_array($this->ch,
                              [
                                  CURLOPT_RETURNTRANSFER => true,
                                  CURLOPT_SSL_VERIFYPEER => false,
                                  CURLOPT_HTTPGET        => true,
                                  CURLOPT_POST           => ($method == 'POST'),
                                  CURLOPT_POSTFIELDS     => http_build_query($parameters),
                                  CURLOPT_CUSTOMREQUEST  => $method,
                                  CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded'],
                                  CURLOPT_URL            => $url,
                              ]
            );

            return curl_exec($this->ch);
        }

        /**
         * create Url
         *
         * @param string $url
         * @param mixed  $parameters
         *
         * @return string
         */
        private function createUrl($url, $parameters)
        {
            return $url . '?' . http_build_query($parameters);
        }

    }