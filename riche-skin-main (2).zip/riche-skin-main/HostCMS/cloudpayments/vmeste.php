<?php
    
    include 'Debug.php';
    include 'Curl.php';
    
    define('RETAIL_CRM_TOKEN', 'EijrgcVMZOQ4SNZ1nKfpBbbAZwRkqEPo');
    
    define(
        'SITE_CODE',
        [
            'riche-shop',
        ]
    );
    
    $orderNumber = $_REQUEST['InvoiceId'];
    
    $curlGetOrder = new Curl('https://b7w2x7a.retailcrm.ru/api/v5/orders');
    
    $data = json_decode(
        $curlGetOrder->api(
            [
                'apiKey' => RETAIL_CRM_TOKEN,
                'limit'  => 100,
                'filter' => [
                    'sites'   => SITE_CODE,
                    'numbers' => [$orderNumber],
                ],
            ]
        )
    );
    
    unset($curlGetOrder);
    
    $order   = $data->orders[0];
    $orderId = $order->id;
    $site    = $order->site;
    
    $currentStatus = $order->status;
    
    $payments    = $order->payments;
    $paymentsIds = [];
    
    if (count((array) $payments) > 1)
    {
        Debug::log("В заказе {$orderNumber} платежей больше чем 1" . PHP_EOL);
    }
    
    foreach ($payments as $key => $payment)
    {
        if ($payment->type == 'card-acquire-cloudpayments')
        {
            
            $params = [
                'apiKey'  => RETAIL_CRM_TOKEN,
                'by'      => 'id',
                'site'    => $site,
                'payment' => json_encode(['status' => 'paid']),
            ];
            
            for ($i = 0; $i <= 10; $i++)
            {
                if (setPaymentPaid($payment->id, $params) == true)
                {
                    break;
                }
            }
            
        }
        else
        {
            
            $curlRemovePayment = new Curl(
                'https://b7w2x7a.retailcrm.ru/api/v5/orders/payments/' . $payment->id . '/delete'
            );
            
            $response = $curlRemovePayment->api(['apiKey' => RETAIL_CRM_TOKEN, 'id' => $payment->id], 'post');
            
            unset($curlRemovePayment);
            unset($payments->{$key});
            
            Debug::log("В заказе {$orderNumber} удален платеж {$payment->id}" . PHP_EOL);
            
        }
        
    }
    
    if (empty((array) $payments))
    {
        
        $curlCreatePayment = new Curl('https://b7w2x7a.retailcrm.ru/api/v5/orders/payments/create');
        
        $response = json_decode(
            $curlCreatePayment->api(
                [
                    'apiKey'  => RETAIL_CRM_TOKEN,
                    'site'    => $site,
                    'payment' => json_encode(
                        [
                            'amount' => $_REQUEST['Amount'],
                            'paidAt' => date(
                                'Y-m-d H:i:s'
                            ),
                            'order'  => [
                                'number' => $orderNumber
                            ],
                            'type'   => 'card-acquire-cloudpayments',
                            'status' => 'paid'
                        ]
                    )
                ],
                'post'
            )
        );
        
        unset($curlCreatePayment);
        
        Debug::log(
            "В заказе {$orderNumber} создан платеж CloudPayments на сумму {$_REQUEST['Amount']} Id={$response->id}"
            . PHP_EOL
        );
        
    }
    
    $curlOrderPayed = new Curl('https://b7w2x7a.retailcrm.ru/api/v5/orders/' . $orderId . '/edit');
    
    $nowDate = date('Y-m-d');
    
    $dataRequest = json_decode($_REQUEST['Data']);
    
    if (!empty($_REQUEST['Email']))
    {
        $email = $_REQUEST['Email'];
    }
    elseif (isset($order->email))
    {
        $email = $order->email;
    }
    
    $edit = [
        "status"       => "prepayed",
        "email"        => $email,
        "customFields" => [
            "oplata"          => $nowDate,
            "website_payment" => $dataRequest->websitePayment
        ],
    ];
    
    $response = $curlOrderPayed->api(
        [
            'apiKey' => RETAIL_CRM_TOKEN,
            "by"     => "id",
            "site"   => $site,
            "order"  => json_encode($edit),
        ],
        "post"
    );
    
    unset($curlOrderPayed);
    
    echo json_encode(['code' => 0]);
    
    function setPaymentPaid($id, $params)
    {
        
        $curlChangePayment = new Curl('https://b7w2x7a.retailcrm.ru/api/v5/orders/payments/' . $id . '/edit');
        
        $response          = json_decode(
            $curlChangePayment->api(
                $params,
                'post'
            ),
            true
        );
        
        unset($curlChangePayment);
        
        if (isset($response['success']))
        {
            return $response['success'];
        }
        else
        {
            return false;
        }
        
    }
