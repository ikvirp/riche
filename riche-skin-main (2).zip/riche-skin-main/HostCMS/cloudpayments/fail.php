<?php
    
    //file_put_contents(__DIR__ . '/fail.txt', json_encode($_REQUEST));
    
    define('RETAIL_CRM_TOKEN', 'lnsAkFmt4VTwec22MMBayRGN5QJEhAH1--fail');
    define('RETAIL_SITE', 'riche-shop');
    
    function get($url, $params = [])
    {
        
        if ($curl = curl_init()) {
            curl_setopt($curl, CURLOPT_URL, $url . '?' . http_build_query($params));
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            $out = curl_exec($curl);
            curl_close($curl);
            
            return $out;
        }
    }
    
    function post($url, $params = [])
    {
        
        $params['order'] = json_encode($params['order']);
        if ($curl = curl_init()) {
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $params);
            $out = curl_exec($curl);
            curl_close($curl);
            
            return $out;
        }
        
        return false;
    }
    
    if (!empty($_REQUEST['InvoiceId'])) {
        
        $responseOrders = json_decode(
            get(
                "https://b7w2x7a.retailcrm.ru/api/v5/orders",
                [
                    'apiKey' => RETAIL_CRM_TOKEN,
                    'limit'  => 20,
                    'page'   => 1,
                    'filter' => [
                        'sites'          => [RETAIL_SITE],
                        'numbers'        => [$_REQUEST['InvoiceId']],
                        'extendedStatus' => ['unformed-order']
                    ],
                ]
            ),
            true
        );
        
        if (!empty($responseOrders['orders'])) {
            
            $response = post(
                "https://b7w2x7a.retailcrm.ru/api/v5/orders/{$responseOrders['orders'][0]['id']}/edit",
                [
                    'by'     => 'id',
                    'apiKey' => RETAIL_CRM_TOKEN,
                    'site'   => RETAIL_SITE,
                    'order'  => [
                        'status'        => 'new',
                        'statusComment' => $_REQUEST['Reason'],
                    ]
                ]
            );
            
        }
        
    }
