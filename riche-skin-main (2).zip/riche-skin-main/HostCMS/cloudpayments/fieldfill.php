<?php

//require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

/** @todo надо тут разобраться чтобы платежи не задваивались */

include 'Debug.php';
include 'Curl.php';

define('RETAIL_CRM_TOKEN', 'lnsAkFmt4VTwec22MMBayRGN5QJEhAH1');

define('SITE_CODE', [
  'riche-instagram',
  'riche-shop',
  'riche-test',
  'badclients',
  'riche-obr',
  'richeopt',
  'i2crm',
  'callback',
  'ADVICE',
  'riche-cheb',
  'riche-corp',
]);

if (empty($_REQUEST['orderId'])) {
  Debug::log($_REQUEST);
  die();
}

//d($_REQUEST);

$orderId = $_REQUEST['orderId'];

$curlGetOrder = new Curl('https://b7w2x7a.retailcrm.ru/api/v5/orders');

$data = json_decode(
  $curlGetOrder->api([
    'apiKey' => RETAIL_CRM_TOKEN,
    'limit' => 100,
    'filter' => [
      'sites' => SITE_CODE,
      'ids' => [$orderId],
    ],
  ])
);

unset($curlGetOrder);

$order = $data->orders[0];
$site = $order->site;

//d($order);

$curlChangeOrder = new Curl(
  "https://b7w2x7a.retailcrm.ru/api/v5/orders/{$orderId}/edit"
);

$edit = [
  'customFields' => [
    'payment_link' => "//riche.skin/integration/cloudpayments/create_invoice.php?orderId={$orderId}",
  ],
];

//d($edit);

$response = $curlChangeOrder->api(
  [
    'apiKey' => RETAIL_CRM_TOKEN,
    'by' => 'id',
    'site' => $order->site,
    'order' => json_encode($edit),
  ],
  'post'
);

//d($response);

unset($curlChangeOrder);

echo 'Ok';
