<?php
    
    //require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");
    
    include 'Debug.php';
    include 'Curl.php';
    
    // имя константы ключа должно отличаться от основного из init.php иначе не задаётся значение -- нужно для отладки
    const
    RCRM_TOKEN = 'lnsAkFmt4VTwec22MMBayRGN5QJEhAH1--notification',
    SITE_CODE
               = [
        'app-riche-skin',
        'riche-instagram',
        'riche-shop',
        'riche-test',
        'badclients',
        'riche-obr',
        'richeopt',
        'i2crm',
        'callback',
        'ADVICE',
        'riche-cheb',
        'riche-corp'
    ];
    
    // region получение данных заказа с РЦРМ по номеру заказа
    /**
     * это номер заказа из транзакции CloudPayments
     *
     * @var string $orderNumber
     */
    $orderNumber = $_REQUEST['InvoiceId'];
    
    // region получаем заказ по номеру из платежа
    
    $curlGetOrder = new Curl('https://b7w2x7a.retailcrm.ru/api/v5/orders');
    $data         = json_decode(
        $curlGetOrder->api(
            [
                'apiKey' => RCRM_TOKEN,
                'limit'  => 100,
                'filter' => [
                    'sites'   => SITE_CODE,
                    'numbers' => [$orderNumber],
                ],
            ]
        )
    );
    
    unset($curlGetOrder);
    
    // endregion
    
    $order = $data->orders[0];
    
    $orderId = $order->id;
    $site    = $order->site;
    
    $currentStatus = $order->status;
    
    $payments    = $order->payments;
    $paymentsIds = [];
    
    // endregion
    
    // region обработка платежа
    
    // region если заказ есть в РЦРМ
    
    if ($order->id) {
        
        Debug::log("Заказ {$orderNumber} найден в РЦРМ" . PHP_EOL);
        
        // region если в заказе есть платежи
        
        if (count((array)$payments) > 1) {
            Debug::log("В заказе {$orderNumber} платежей больше чем 1" . PHP_EOL);
        }
        
        foreach ($payments as $key => $payment) {
            
            //@todo  нужна проверка не по типу, а айди
            
            if ($payment->type == 'cloudpayments') {
                
                $params = [
                    'apiKey'  => RCRM_TOKEN,
                    'by'      => 'id',
                    'site'    => $site,
                    'payment' => json_encode(
                        [
                            'status'     => 'paid',
                            'amount'     => $_REQUEST['Amount'],
                            'externalId' => $_REQUEST['TransactionId'], // это не айди, а символьный код
                        ]
                    ),
                ];
                
                for ($i = 0; $i <= 10; $i++) {
                    if (setPaymentPaid($payment->id, $params) == true) {
                        break;
                    }
                }
                
                Debug::log("В заказе {$orderNumber} платеж #{$payment->id} оплачен" . PHP_EOL);
                
            }
            else {
                
                // удалить все платежи
                
                $curlRemovePayment = new Curl(
                    'https://b7w2x7a.retailcrm.ru/api/v5/orders/payments/' . $payment->id . '/delete'
                );
                
                $response = $curlRemovePayment->api(
                    [
                        'apiKey' => RCRM_TOKEN,
                        'id'     => $payment->id
                    ],
                    'post'
                );
                
                unset($curlRemovePayment);
                unset($payments->{$key});
                
                Debug::log("В заказе {$orderNumber} удален платеж {$payment->id}" . PHP_EOL);
                
            }
            
        }
        
        // endregion
        
        // region если нет платежей
        
        if (empty((array)$payments)) {
            
            Debug::log("В заказе {$orderNumber} нет платежей" . PHP_EOL);
            
            $curlCreatePayment = new Curl('https://b7w2x7a.retailcrm.ru/api/v5/orders/payments/create');
            
            $response = json_decode(
                $curlCreatePayment->api(
                    [
                        'apiKey'  => RCRM_TOKEN,
                        'site'    => $site,
                        'payment' => json_encode(
                            [
                                'amount'     => $_REQUEST['Amount'],
                                'externalId' => $_REQUEST['TransactionId'],  // это не айди, а симвоьный код
                                'paidAt'     => date(
                                    'Y-m-d H:i:s'
                                ),
                                'order'      => [
                                    'number' => $orderNumber
                                ],
                                'type'       => 'cloudpayments',
                                'status'     => 'paid'
                            ]
                        )
                    ],
                    'post'
                )
            );
            
            unset($curlCreatePayment);
            
            Debug::log(
                "В заказе {$orderNumber} создан платеж CloudPayments на сумму {$_REQUEST['Amount']} Id={$response->id}"
                . PHP_EOL
            );
            
        }
        
        // endregion
        
        $curlOrderPayed = new Curl('https://b7w2x7a.retailcrm.ru/api/v5/orders/' . $orderId . '/edit');
        $nowDate        = date('Y-m-d');
        
        $dataRequest = json_decode($_REQUEST['Data']);
        
        if (!empty($_REQUEST['Email'])) {
            $email = $_REQUEST['Email'];
        }
        elseif (isset($order->email)) {
            $email = $order->email;
        }
        
        $edit = [
            "email"        => $email,
            "customFields" => [
                "oplata"          => $nowDate,
                "website_payment" => $dataRequest->websitePayment
            ],
        ];
        
        $response = $curlOrderPayed->api(
            [
                'apiKey' => RCRM_TOKEN,
                "by"     => "id",
                "site"   => $site,
                "order"  => json_encode($edit),
            ],
            "post"
        );
        
        unset($curlOrderPayed);
        
        echo "Ok";
        
    }
    // endregion
    
    // region заказа нет в РЦРМ
    else {
        
        Debug::log("Заказ {$orderNumber} не найден в РЦРМ" . PHP_EOL);
        
    }
    // endregion
    
    function setPaymentPaid($id, $params)
    {
        
        $curlChangePayment = new Curl('https://b7w2x7a.retailcrm.ru/api/v5/orders/payments/' . $id . '/edit');
        
        $response = json_decode(
            $curlChangePayment->api(
                $params,
                'post'
            ),
            true
        );
        
        unset($curlChangePayment);
        
        if (isset($response['success'])) {
            return $response['success'];
        }
        else {
            return false;
        }
        
    }