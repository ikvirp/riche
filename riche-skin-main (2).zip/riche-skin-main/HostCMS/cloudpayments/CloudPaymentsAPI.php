<?php
    /**
     * Created by PhpStorm.
     * User: devevil
     * Date: 18.07.2018
     * Time: 9:12
     */
    
    class CloudPaymentsAPI
    {
        
        /**
         * @var string
         */
        protected $url = 'https://api.cloudpayments.ru';
        /**
         * @var string
         */
        protected $locale = 'ru-RU';
        /**
         * @var string
         */
        protected $publicKey;
        /**
         * @var string
         */
        protected $privateKey;
        
        /**
         * @param $publicKey
         * @param $privateKey
         */
        public function __construct($publicKey, $privateKey)
        {
            
            $this->publicKey  = $publicKey;
            $this->privateKey = $privateKey;
        }
        
        public function createInvoice($amount, $orderNumber, $userNumber, $userPhone, $items = [])
        {
            
            $response = $this->sendRequest(
                '/orders/create',
                [
                    'CultureName' => $this->locale,
                    'Amount'      => $amount,
                    'Currency'    => "RUB",
                    "Description" => "Оплата заказа на сайте RICHE",
                    "InvoiceId"   => $orderNumber,
                    "AccountId"   => $userNumber,
                    "Phone"       => $userPhone,
                    "JsonData"    => [
                        "cloudPayments"  => [
                            "customerReceipt" => [
                                "Items"   => $items,
                                "phone"   => $userPhone,
                                "amounts" => [
                                    "electronic" => $amount
                                ]
                            ]
                        ],
                        "websitePayment" => false,
                    ]
                ]
            );
            
            return $response;
        }
        
        /**
         * @param       $endpoint
         * @param array $params
         * @param array $headers
         *
         * @return array
         */
        protected function sendRequest($endpoint, $params)
        {
            
            $params = json_encode($params);
            $curl   = curl_init();
            curl_setopt($curl, CURLOPT_URL, $this->url . $endpoint);
            
            curl_setopt($curl, CURLOPT_USERPWD, sprintf('%s:%s', $this->publicKey, $this->privateKey));
            curl_setopt($curl, CURLOPT_TIMEOUT, 20);
            
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
            
            //            curl_setopt($curl, CURLOPT_INTERFACE, '159.69.71.105');
            
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
            
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $params);
            curl_setopt($curl, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
            
            $result = curl_exec($curl);
            
            curl_close($curl);
            
            return (array) json_decode($result, true);
        }
        
        public function removeInvoice($id)
        {
            
            $response = $this->sendRequest(
                '/orders/cancel',
                [
                    'Id' => $id
                ]
            );
            
            return $response;
        }
        
    }
