<?php

// это нам даёт d(), автозагруженные классы и весь остальной Битрикс.
//require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

//require_once '../../local/vendor/autoload.php';

include_once 'Curl.php';

/**
 * Ключ API RetailCRM для *создания* платежей
 */

const RCRM_TOKEN = 'lnsAkFmt4VTwec22MMBayRGN5QJEhAH1';

/**
 * Список кодов магазинов, записанных в RetailCRM
 */
const SHOPS = [
  'riche-shop',
  'riche-test',
  'riche-obr',
  'richeopt',
  'riche-corp',
];

// запросы приходят GET-ом

if (empty($_REQUEST['orderId'])) {
  echo 'No Id';
} else {
  $orderId = $_REQUEST['orderId'];

  $crmOrderRequest = new Curl('https://b7w2x7a.retailcrm.ru/api/v5/orders');

  $response = json_decode(
    $crmOrderRequest->api([
      'apiKey' => RCRM_TOKEN,
      'limit' => 100,
      'filter' => [
        'sites' => SHOPS,
        'ids' => [$orderId],
      ],
    ])
  );

  unset($crmOrderRequest);

  if (count($response->orders) > 0) {
    $order = $response->orders[0];

    $site = $order->site;

    if ($order->payments) {
      $crmOrderChangeRequest = new Curl(
        "https://b7w2x7a.retailcrm.ru/api/v5/orders/{$orderId}/edit"
      );

      $orderEditData = [
        'customFields' => [
          'payment_link' => "https://riche.skin/integration/cloudpayments/create_invoice.php?orderId={$orderId}",
        ],
      ];

      //d($orderEditData);

      $response = json_decode(
        $crmOrderChangeRequest->api(
          [
            'apiKey' => RCRM_TOKEN,
            'by' => 'id',
            'site' => $order->site,
            'order' => json_encode($orderEditData),
          ],
          'post'
        )
      );

      //d($response);

      unset($crmOrderChangeRequest);
    }
  }

  echo 'Ok';
}
