<?php

//require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

include 'Debug.php';
include 'Curl.php';

// имя константы ключа должно отличаться от основного из init.php иначе не задаётся значение -- нужно для отладки
const RCRM_TOKEN = 'lnsAkFmt4VTwec22MMBayRGN5QJEhAH1',
  SITE_CODE = [
    'app-riche-skin',
    'riche-instagram',
    'riche-shop',
    'riche-test',
    'badclients',
    'riche-obr',
    'richeopt',
    'i2crm',
    'callback',
    'ADVICE',
    'riche-cheb',
    'riche-corp',
  ];

// region проверка на запрос

if (empty($_REQUEST['orderId'])) {
  die();
}

$orderId = $_REQUEST['orderId'];

// endregion

// region CloudPayments API

include 'CloudPaymentsAPI.php';

$api = new CloudPaymentsAPI(
  'pk_a5c69936e3e49cf8c902795e0cf2e',
  '5fb012c582e5dc7462dbdf4108a6e74b'
);

// endregion

// region получаем заказы

$curlGetOrder = new Curl('https://b7w2x7a.retailcrm.ru/api/v5/orders');

$data = json_decode(
  $curlGetOrder->api([
    'apiKey' => RCRM_TOKEN,
    'limit' => 100,
    'filter' => [
      'sites' => SITE_CODE,
      'ids' => [$orderId],
    ],
  ])
);

unset($curlGetOrder);

$order = $data->orders[0];

// endregion

$site = $order->site;

// region Удаляет предыдущий платёж в CloudPayments при непустом поле ссылки на оплату

if (!empty($order->customFields->payment_id)) {
  $api->removeInvoice($order->customFields->payment_id);
}

// endregion

// region существующие платежи заказа РЦРМ

$paymentsIds = [];
$amount = 0;

$payments = $order->payments;

foreach ($payments as $payment) {
  if ($payment->type == 'cloudpayments') {
    // ключ способа оплаты из справочника Типы оплат

    $amount += $payment->amount;
    $paymentsIds[] = $payment->id;
  } else {
    $curlRemovePayment = new Curl(
      'https://b7w2x7a.retailcrm.ru/api/v5/orders/payments/' .
        $payment->id .
        '/delete'
    );

    $response = $curlRemovePayment->api(
      [
        'apiKey' => RCRM_TOKEN,
        'id' => $payment->id,
      ],
      'post'
    );

    unset($curlRemovePayment);
    unset($payments->{$key});
  }
}

if ($amount == 0) {
  die();
}

// region выставляет платежу из предыдущей выборки статус "выставлен счёт"

$paymentEdit = ['status' => 'invoice'];

foreach ($paymentsIds as $paymentId) {
  $curlChangePayment = new Curl(
    'https://b7w2x7a.retailcrm.ru/api/v5/orders/payments/' .
      $paymentId .
      '/edit'
  );

  $data = json_decode(
    $curlChangePayment->api(
      [
        'apiKey' => RCRM_TOKEN,
        'by' => 'id',
        'site' => $site,
        'payment' => json_encode($paymentEdit),
      ],
      'post'
    )
  );

  unset($curlChangePayment);
}

// endregion

// endregion

// region товары

$receiptItems = [];

foreach ($order->items as $orderItem) {
  $receiptItem = [];

  $receiptItem['label'] = htmlspecialchars($orderItem->offer->name);
  $receiptItem['price'] = number_format(
    $orderItem->initialPrice - $orderItem->discountTotal,
    2,
    '.',
    ''
  );
  $receiptItem['quantity'] = $orderItem->quantity;
  $receiptItem['amount'] = $receiptItem['price'] * $receiptItem['quantity'];
  $receiptItem['vat'] = 20;
  $receiptItem['method'] = 1;
  $receiptItem['object'] = 1;
  $receiptItem['measurementUnit'] = 'шт';

  array_push($receiptItems, $receiptItem);
}

// endregion

// region доставка

//Если есть доставка, добавляем товар - услуги доставки со стоимостью доставки

if (isset($order->delivery->cost) && $order->delivery->cost > 0) {
  $receiptItem = [];

  $receiptItem['label'] = htmlspecialchars('Услуги доставки');
  $receiptItem['price'] = number_format($order->delivery->cost, 2, '.', '');
  $receiptItem['quantity'] = 1;
  $receiptItem['amount'] = $receiptItem['price'] * $receiptItem['quantity'];
  $receiptItem['vat'] = 20;
  $receiptItem['method'] = 1;
  $receiptItem['object'] = 1;
  $receiptItem['measurementUnit'] = 'шт';

  array_push($receiptItems, $receiptItem);
}

// endregion

// region данные клиента

$phone = preg_replace('/[^0-9]/', '', $order->phone);

if (substr($phone, 0, 2) == '+7') {
  $phone = '8' . substr($phone, 1);
} elseif (substr($phone, 0, 1) == '7') {
  $phone = '8' . substr($phone, 1);
} elseif (substr($phone, 0, 1) == '9' && strlen($phone) == 10) {
  $phone = '89' . substr($phone, 1);
}

// @todo выпилить дадату

if (!empty($phone) and ($curl = curl_init())) {
  curl_setopt(
    $curl,
    CURLOPT_URL,
    'https://cleaner.dadata.ru/api/v1/clean/phone'
  );
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($curl, CURLOPT_POSTFIELDS, "[{$phone}]");
  curl_setopt($curl, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Accept: application/json',
    'Authorization: Token 64b75257b4ef513c8e21645a38f265759a822470',
    'X-Secret: 6b34b8448d958d22ee6044abcb8ec97104318fa5',
  ]);
  curl_setopt($curl, CURLOPT_POST, true);

  $responseDaData = json_decode(curl_exec($curl), true);

  curl_close($curl);

  if (
    !empty($responseDaData[0]['phone']) and
    $responseDaData[0]['type'] == 'Мобильный'
  ) {
    $phone_end = preg_replace('/[^0-9+]/', '', $responseDaData[0]['phone']);
  }
}

// endregion

// region запись результата создания платежа КП в заказ в РЦРМ

$response = $api->createInvoice(
  number_format($amount, 2, '.', ''),
  $order->number,
  $order->customer->id,
  $phone_end ? $phone_end : $order->phone,
  $receiptItems
);

if ($response) {
  $paymentUrl = $response['Model']['Url'];
  $paymentID = $response['Model']['Id'];

  $curlChangeOrder = new Curl(
    'https://b7w2x7a.retailcrm.ru/api/v5/orders/' . $orderId . '/edit'
  );

  $edit = [
    'customFields' => [
      'payment_link' => $paymentUrl,
      'payment_id' => $paymentID,
    ],
  ];

  $response = $curlChangeOrder->api(
    [
      'apiKey' => RCRM_TOKEN,
      'by' => 'id',
      'site' => $site,
      'order' => json_encode($edit),
    ],
    'post'
  );

  unset($curlChangeOrder);

  echo 'Ok';
}

// endregion