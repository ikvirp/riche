# coding utf-8

import retailcrm

client = retailcrm.v5('https://b7w2x7a.retailcrm.ru', '6Dt53oZM07hAggJtSmsFFsPSCqFygU8v')

order = {
  'firstName': 'John',
  'lastName': 'Doe',
  'phone': '+79000000000',
  'email': 'john@example.com',
  'orderMethod': 'riche-website',   # Источник заказа
  'countryIso': "RU",   # старана доставки
  'summ': 1248, # сумма заказа по товарам
  'totalSumm': 1798,  # сумма заказа с учетом доставки
  'site': "riche-shop",  # в какой магазин в RCRM его заводить 
  'customFields': { 'delivery_apiship_provider_key': "cdek", },   # сюда подставить 'apiship_point_id'
  'status': "prepay",   # Статус нужно ставить ему "prepay", в ожидании предоплаты
  'items': [
              {
              'bonusesChargeTotal': 0,
              'bonusesCreditTotal': 0,
              'markingCodes': [ ],
              'id': 2097220,
              'priceType': {
                'code': "base"
              },
              'initialPrice': 999,
              'discounts': [ ],
              'discountTotal': 0,
              'prices': [
              {
                'price': 999,
                'quantity': 1
              }
              ],
              'vatRate': "20.00",
              'quantity': 1,
              'status': "new",
              'offer': {
              'displayName': "Матирующий крем для лица Адаптогены + Центелла",
              'id': 4550,
              'externalId': "7294",
              'xmlId': "7294",
              'name': "Матирующий крем для лица Адаптогены + Центелла",
              'article': "FC/22/FC/BMA/50",
              'vatRate': "20.00",
              'properties': {
              'tnved': "3304990000",
              'volume': "50"
              },
              'unit': {
              'code': "pcs",
              'name': "Штука",
              'sym': "шт."
              }
              },
              'properties': [ ],
              'purchasePrice': 0,
              'ordering': 100
              }
              ],
  'payments': {
                1179972: {
                  'id': 1179972,
                  'status': "paid",
                  'type': "tcs",
                  'amount': 1698,
                  }
              },
'delivery': {
  'code': "apiship",
  'integrationCode': "apiship",
  'data': {
    'locked': 'true',
    'pickuppointAddress': "428018, Чувашия, Чебоксары, ул. Водопроводная, 22",
    'tariff': "53", # сюда подставить "tariff_id"
    'pickuppointId': "28910", # сюда подставить 'apiship_point_id'
    },
  'cost': 150, # Стоимость доставки 
  'address': {
    'countryIso': "RU",
    'region': "Чувашская Республика - Чувашия",
    'regionId': 80,
    'city': "Чебоксары",
    'cityId': 1474,
    'cityType': "г.",
    'street': "Водопроводная",
    'streetId': 1114270,
    'streetType': "ул.",
    'building': "22",
    'housing': "1",
    'text': "ул. Водопроводная, д. 22, корп. 1"
    }
  }
}

# for i in range(2):
result = client.order_create(order)