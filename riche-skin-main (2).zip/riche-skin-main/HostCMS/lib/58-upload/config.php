<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: *');
//header('Content-Disposition', 'inline; filename="files.json"');
//header('Content-Type', 'application/json; charset=utf-8');

//var_dump($_GET);
//var_dump($_POST);
//var_dump($_REQUEST);
// $aJSON = ['post' => $_POST, 'file' => $_FILES];

// Core::showJson($aJSON);
// exit();

$aJSON = null;

$token = Core_Array::getPost('token', false);
$action = Core_Array::getPost('action', false);
$aFileData = Core_Array::getFiles('file', null);

//var_dump($token);
//var_dump($action);
//var_dump($aFileData);
//exit();

if ($token && $action) {
	$oSiteuser = Core_Entity::factory('Siteuser')->getByGuid($token);
	if ($oSiteuser) {
		$oSiteuser_Person = null;
		$aSiteuser_People = $oSiteuser->Siteuser_People->findAll(false);
		if (isset($aSiteuser_People[0])) {
			$oSiteuser_Person = $aSiteuser_People[0];
		} else {
			$oSiteuser_Person = Core_Entity::factory('Siteuser_Person');
			$oSiteuser_Person->siteuser_id = $oSiteuser->id;
			$oSiteuser_Person->save();
		}

		switch ($action) {
			case 'avatar':
				if (
					// Поле файла существует
					!is_null($aFileData) &&
					// и передан файл
					intval($aFileData['size']) > 0
				) {
					if (
						Core_File::isValidExtension($aFileData['name'], [
							'JPG',
							'JPEG',
							'PNG',
						])
					) {
						$oSiteuser_Person->deleteImageFile();

						$fileExtension = Core_File::getExtension($aFileData['name']);
						$sImageName = 'image.' . $fileExtension;

						$param = [];
						// Путь к файлу-источнику большого изображения;
						$param['large_image_source'] = $aFileData['tmp_name'];
						// Оригинальное имя файла большого изображения
						$param['large_image_name'] = $aFileData['name'];

						// Путь к создаваемому файлу большого изображения;
						$param['large_image_target'] =
							$oSiteuser_Person->getPath() . $sImageName;

						// Использовать большое изображение для создания малого
						$param['create_small_image_from_large'] = false;

						// Значение максимальной ширины большого изображения
						$param['large_image_max_width'] = 300;

						// Значение максимальной высоты большого изображения
						$param['large_image_max_height'] = 300;

						// Сохранять пропорции изображения для большого изображения
						$param['large_image_preserve_aspect_ratio'] = false;

						// var_dump($aFileData);
						// var_dump($fileExtension);
						// var_dump($sImageName);
						// var_dump($param);
						// exit();

						// $result = Core_File::upload(
						// 	$aFileData['tmp_name'],
						// 	$oSiteuser_Person->getPath() . $sImageName
						// );
						$result = Core_File::adminUpload($param);

						// var_dump($result);
						// exit();

						//
						if ($result['large_image']) {
							$oSiteuser_Person->image = $sImageName;
							$oSiteuser_Person->save();

							$aJSON = [
								'file' => $oSiteuser_Person->getImageHref(),
							];
						}
					}
				}

				break;
		}
	} else {
		$aJSON = [
			'error' => 'Access denie',
		];
	}
}

Core::showJson($aJSON);
exit();
?>
