<?php

if (!Core_Auth::logged()) {
    header('Location: /');
    exit();
}

$action = Core_Array::getRequest('action', false);
if ($action) {
    $json = [
        'status' => 'error',
        'result' => [
            'title' => 'Данные не найдены',
            'body' =>
                '<div class="alert alert-danger alert-dismissible fade show">Данные отсутствуют<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>',
        ],
    ];
    if ($action == 'comment_answer') {
        $parentCommentId = Core_Array::getRequest('comment_id', false);
        $commentText = Core_Array::getRequest('text', false);
        if ($parentCommentId) {
            $parentComment = Core_Entity::factory('Comment', $parentCommentId);
            if (!is_null($parentComment) && $commentText) {

                $shopItem = $parentComment->Comment_Shop_Item->Shop_Item;

                $comment = Core_Entity::factory('Comment');
                $allowable_tags = '<b><strong><i><em><br><p><u><strike><ul><ol><li>';
                $comment->active = 1;
                $comment->grade = 0;
                $comment->text = nl2br(Core_Str::stripTags($commentText, $allowable_tags));

                $user = Core_Entity::factory('User')->getCurrent();
                if (!is_null($user)) {
                    $comment->user_id = $user->id;
                }

                $comment->parent_id = $parentComment->id;
                $comment->siteuser_id = 1;

                $shopItem
                    ->add($comment)
                    ->clearCache();

                $json['status'] = 'ok';
                $json['result'] = [
                    'title' => 'Ответ успешно добавлен',
                    'body' => '',
                ];
            }
        }
    }
    if ($action == 'comment_change_active') {
        $commentId = Core_Array::getRequest('comment_id', false);
        if ($commentId) {
            $comment = Core_Entity::factory('Comment', $commentId);
            if ($comment) {
                $comment->active = !$comment->active;
                $comment->save();

                $json['status'] = 'ok';
                $json['result'] = [
                    'title' => 'Активность успешно изменена',
                    'body' => '',
                ];
            }
        }
    }
    Core::showJson($json);
}