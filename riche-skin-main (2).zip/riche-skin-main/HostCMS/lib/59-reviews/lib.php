<?php

$limit = 20;
$page = intval(Core_Array::getGet('page', 0)) - 1;
if ($page < 0) {
  $page = 0;
}
$offset = $page * $limit;
$shopLink = 'https://riche.skin/product/';

$comment = Core_Entity::factory('Shop_Item_Comment');
Core_Entity::factory('Shop_Item_Comment')->getTableColumns();
$comment
    ->queryBuilder()
    ->sqlCalcFoundRows()
    ->where('comments.parent_id', '=', 0)
    ->where('comments.text', '!=', '')
    ->where('comments.deleted', '=', 0)
    ->limit($limit)
    ->offset($offset)
    ->clearOrderBy()
    ->orderBy('comments.datetime', 'DESC');

$filterShowActive = Core_Array::getGet('filter_show_active', 0);
if ($filterShowActive) {
    switch ($filterShowActive) {
        case 1:
            $comment
                ->queryBuilder()
                ->where('comments.active', '=', 1);
            break;
        case 2:
            $comment
                ->queryBuilder()
                ->where('comments.active', '=', 0);
            break;
    }
}

$filterShowAnswer = Core_Array::getGet('filter_show_answer', 0);
if ($filterShowAnswer) {
    switch ($filterShowAnswer) {
        case 1:
            $comment
                ->queryBuilder()
                ->leftJoin(['comments', 'answers'], 'comments.id', '=', 'answers.parent_id')
                ->having('COUNT(answers.id)', '>', 0)
                ->groupBy('comments.id');
            break;
        case 2:
            $comment
                ->queryBuilder()
                ->leftJoin(['comments', 'answers'], 'comments.id', '=', 'answers.parent_id')
                ->having('COUNT(answers.id)', '=', 0)
                ->groupBy('comments.id');
            break;
    }
}

$filterCommentWasEdit = Core_Array::getGet('filter_comment_was_edit', 0);
if ($filterCommentWasEdit) {
    $comment
        ->queryBuilder()
        ->leftJoin('property_value_ints', 'comments.id', '=', 'property_value_ints.entity_id')
        ->where('property_value_ints.value', 'IN', [1, '1'])
        ->where('property_value_ints.property_id', '=', 50)
        ->groupBy('comments.id');
}

$filterShopItemId = Core_Array::getGet('filter_shop_item_id', []);
if ($filterShopItemId) {
    $comment
        ->queryBuilder()
        ->leftJoin('comment_shop_items', 'comments.id', '=', 'comment_shop_items.comment_id')
        ->where('comment_shop_items.shop_item_id', 'IN', $filterShopItemId)
        ->groupBy('comments.id');
}

$commentsList = $comment->findAll(false);
$totalComments = Core_QueryBuilder::select()->getFoundRows();

$shopItemQueryBuilder = Core_QueryBuilder::select()
  ->from('shop_items')
  ->where('name', '!=', '')
  ->where('shop_id', '=', 1)
  ->where('marking', '!=', '')
  ->where('deleted', '=', 0);
$shopItems = $shopItemQueryBuilder->execute()->asAssoc()->result();
?>
<h3 class="mb-3">Отзывы покупателей</h3>
<form action="/manager/" method="get" enctype="multipart/form-data">
  <div class="row mb-3">
    <div class="col-3">
      <select class="selectpicker" data-style="form-select" multiple name="filter_shop_item_id[]" data-live-search="true" onchange="$(this).closest('form').submit()">
        <?php
        foreach ($shopItems as $shopItem)
        {
          $isSelected = '';
          if (in_array($shopItem['id'], $filterShopItemId)) {
              $isSelected = 'selected="selected"';
          }
        ?>
          <option <?=$isSelected; ?> value="<?=$shopItem['id']; ?>">[<?=$shopItem['marking']; ?>] <?=$shopItem['name']; ?></option>
        <?php } ?>
      </select>
    </div>
    <div class="col">
      <select class="form-select" name="filter_show_active" onchange="$(this).closest('form').submit()">
          <?php

          $filterShowActiveItems = [
              0 => 'Активные и неактивные отзывы',
              1 => 'Активные отзывы',
              2 => 'Неактивные отзывы',
          ];
          ?>

          <?php
          foreach ($filterShowActiveItems as $key => $filterShowActiveItem) {
              $selected = $filterShowActive == $key ? 'selected="selected"' : '';
              ?>
            <option value="<?=$key ?>" <?=$selected ?>><?=$filterShowActiveItem ?></option>
          <?php } ?>
      </select>
    </div>
    <div class="col">
      <select class="form-select" name="filter_show_answer" onchange="$(this).closest('form').submit()">
          <?php

          $filterShowAnswerItems = [
              0 => 'Отзывы с ответом и без ответа',
              1 => 'Отзывы с ответом',
              2 => 'Отзывы без ответа',
          ];
          ?>

          <?php
          foreach ($filterShowAnswerItems as $key => $filterShowAnswerItem) {
              $selected = $filterShowAnswer == $key ? 'selected="selected"' : '';
              ?>
            <option value="<?=$key ?>" <?=$selected ?>><?=$filterShowAnswerItem ?></option>
          <?php } ?>
      </select>
    </div>
    <div class="col">
      <input type="checkbox"
             class="btn-check"
             id="filter_comment_was_edit"
             autocomplete="off"
             name="filter_comment_was_edit"
             onchange="$(this).closest('form').submit()"
          <?= $filterCommentWasEdit ? 'checked="checked"' : ''?>
      >
      <label class="btn" for="filter_comment_was_edit">
        Изменённые отзывы
        <?= $filterCommentWasEdit ? '<i class="fa-solid fa-square-check ms-1"></i>' : ''?>
      </label>

      </div>
    </div>
  </div>
</form>
<table class="table table-hover small mb-5">
  <thead>
  <tr class="!small" bgcolor="#FAFAFA">
    <th scope="col">Дата и время</th>
    <th scope="col">Отзыв</th>
    <th scope="col">Товар</th>
    <th scope="col">Активность</th>
  </tr>
  </thead>
  <tbody>
  <?php

  foreach ($commentsList as $comment) {

      /* Текущий товар на который написан отзыв */
      $shopItem = $comment->Comment_Shop_Item->Shop_Item;

      $siteuserLogin = '';
      if ($comment->siteuser_id) {
          $siteuserLogin = $comment->Siteuser->login;
      }

      /* Получаем родительский товар для отзыва */
      if ($shopItem->modification_id != 0) {
          $shopItem = Core_Entity::factory('Shop_Item', $shopItem->modification_id);
      }

      /* Активность отзыва */
      $checkboxCheckedAttribute = '';
      if ($comment->active) {
          $checkboxCheckedAttribute = 'checked="checked"';
      }

      /* Ответы на отзыв */
      $parentComment = Core_Entity::factory('Shop_Item_Comment');
      $parentComment
          ->queryBuilder()
          ->where('parent_id', '=', $comment->id)
          ->clearOrderBy()
          ->orderBy('datetime', 'DESC');
      $parentCommentList = $parentComment->setMarksDeleted(NULL)->findAll(false);

      $classNameForAnswer = 'comment_answer_' . $comment->id;

      // Достоинства
      $propertyAdvantages = Core_Entity::factory('Property', 33);
      $propertyAdvantagesValues = $propertyAdvantages->getValues($comment->id);
      // Недостатки
      $propertyFlaws = Core_Entity::factory('Property', 36);
      $propertyFlawsValues = $propertyFlaws->getValues($comment->id);
      // Изменён
      $propertyCommentWasChanged = Core_Entity::factory('Property', 50);
      $propertyCommentWasChangedValues = $propertyCommentWasChanged->getValues($comment->id);

      $commentDatetime = new DateTimeImmutable($comment->datetime);

      $commentVoteRate = Vote_Controller::instance()->getRate('comment', $comment->id);

      ?>
    <tr data-deleted="<?=$comment->deleted ?>">
      <td style="width: 150px">
        <div><?=$commentDatetime->format('d.m.Y') ?></div>
        <div class="small text-muted"><?=$commentDatetime->format('H:i') ?></div>
      </td>
      <td class="w-50">
        <div class="fw-medium mb-1"><?=$comment->author; ?></div>
        <div class="text-muted small"><?=$siteuserLogin; ?></div>
        <?php if ($comment->grade) { ?>
            <div class="comment__rating mb-1">
              <?php
              for ($i = 1; $i <= 5; $i++) {
                  if ($i <= $comment->grade) { ?>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" class="star"><path fill-rule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clip-rule="evenodd"></path></svg>
                  <?php } else { ?>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" aria-hidden="true" class="star-empty"><path stroke-linecap="round" stroke-linejoin="round" d="M11.48 3.499a.562.562 0 011.04 0l2.125 5.111a.563.563 0 00.475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 00-.182.557l1.285 5.385a.562.562 0 01-.84.61l-4.725-2.885a.563.563 0 00-.586 0L6.982 20.54a.562.562 0 01-.84-.61l1.285-5.386a.562.562 0 00-.182-.557l-4.204-3.602a.563.563 0 01.321-.988l5.518-.442a.563.563 0 00.475-.345L11.48 3.5z"></path></svg>
                  <?php }
              }
              ?>
          </div>
        <?php } ?>
        <div class="small">
            <?=$comment->text ?>
            <?php if ($propertyCommentWasChangedValues) { ?>
            <div class="badge text-bg-warning">Изменён</div>
            <?php } ?>
            <?php if ($propertyAdvantagesValues && $propertyAdvantagesValues[0]->value != '') { ?>
              <div>Достоинства: <?=$propertyAdvantagesValues[0]->value ?></div>
            <?php } ?>
            <?php if ($propertyFlawsValues && $propertyFlawsValues[0]->value != '') { ?>
                <div>Недостатки: <?=$propertyFlawsValues[0]->value ?></div>
            <?php } ?>
        </div>

        <?php foreach ($parentCommentList as $parentComment) {
            $parentCommentDatetime = new DateTimeImmutable($parentComment->datetime);
          ?>
          <div class="small border-start ps-3 mt-2">
            <div class="text-muted">
                <?=$parentCommentDatetime->format('d.m.Y') ?>
            </div>
            <div>
              <?=$parentComment->text ?>
            </div>
          </div>
        <?php } ?>

        <a class="btn btn-sm btn-outline-primary mt-2 mb-2" data-bs-toggle="offcanvas" href="#<?=$classNameForAnswer ?>" style="--bs-btn-padding-y: .25rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .75rem;">Подробнее</a>
        <div class="offcanvas offcanvas-end" tabindex="-1" id="<?=$classNameForAnswer ?>" aria-labelledby="offcanvasExampleLabel" style="width: 100%; max-width: 650px">
          <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasExampleLabel">
              Отзыв на товар
            </h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
          </div>
          <div class="offcanvas-body">
            <h6>Общая информация</h6>
            <table class="table table-borderless">
              <tr>
                <td class="text-muted" style="width: 35%">Дата и время</td>
                <td>
                  <div><?=$commentDatetime->format('d.m.Y') ?> <span class="small text-muted">(<?=$commentDatetime->format('H:i') ?>)</span></div>
                </td>
              </tr>
              <tr>
                <td class="text-muted" style="width: 35%">Товар</td>
                <td>
                    <?php if (!is_null($shopItem->name)) { ?>
                      <a href="<?=$shopLink . $shopItem->path . '-'. $shopItem->id; ?>" target="_blank" class="link-offset-2 link-underline link-underline-opacity-0"><?=$shopItem->name ?></a>
                    <?php } ?>
                    <div class="small text-muted"><?=$shopItem->marking ?></div>
                </td>
              </tr>
              <tr>
                <td class="text-muted" style="width: 35%">Покупатель</td>
                <td>
                    <?=$comment->author ?>
                    <div class="text-muted small"><?=$siteuserLogin; ?></div>
                </td>
              </tr>
              <tr>
                <td class="text-muted" style="width: 35%">Оценка</td>
                <td>
                    <?php if ($comment->grade) { ?>
                      <div class="comment__rating mb-1">
                          <?php
                          for ($i = 1; $i <= 5; $i++) {
                              if ($i <= $comment->grade) { ?>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" class="star"><path fill-rule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clip-rule="evenodd"></path></svg>
                              <?php } else { ?>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" aria-hidden="true" class="star-empty"><path stroke-linecap="round" stroke-linejoin="round" d="M11.48 3.499a.562.562 0 011.04 0l2.125 5.111a.563.563 0 00.475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 00-.182.557l1.285 5.385a.562.562 0 01-.84.61l-4.725-2.885a.563.563 0 00-.586 0L6.982 20.54a.562.562 0 01-.84-.61l1.285-5.386a.562.562 0 00-.182-.557l-4.204-3.602a.563.563 0 01.321-.988l5.518-.442a.563.563 0 00.475-.345L11.48 3.5z"></path></svg>
                              <?php }
                          }
                          ?>
                      </div>
                    <?php } ?>
                </td>
              </tr>
            </table>
            <h6>Отзыв</h6>
            <table class="table table-borderless">
              <tr>
                <td class="text-muted" style="width: 35%">Достоинства</td>
                <td><?= $propertyAdvantagesValues && $propertyAdvantagesValues[0]->value != '' ? $propertyFlawsValues[0]->value : '—' ?></td>
              </tr>
              <tr>
                <td class="text-muted" style="width: 35%">Недостатки</td>
                <td><?= $propertyFlawsValues && $propertyFlawsValues[0]->value != '' ? $propertyFlawsValues[0]->value : '—' ?></td>
              </tr>
              <tr>
                <td class="text-muted" style="width: 35%">Комментарий</td>
                <td>
                    <?= $comment->text ?>
                </td>
              </tr>
              <tr>
                <td class="text-muted" style="width: 35%">Изменён</td>
                <td>
                    <?= $propertyCommentWasChangedValues ? 'да' : 'нет' ?>
                </td>
              </tr>
              <tr>
                <td class="text-muted" style="width: 35%">Оценки</td>
                <td>
                  <button type="button" class="btn btn-sm btn-outline-secondary" disabled>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="#333" aria-hidden="true" style="width: 16px"><path stroke-linecap="round" stroke-linejoin="round" d="M6.633 10.5c.806 0 1.533-.446 2.031-1.08a9.041 9.041 0 012.861-2.4c.723-.384 1.35-.956 1.653-1.715a4.498 4.498 0 00.322-1.672V3a.75.75 0 01.75-.75A2.25 2.25 0 0116.5 4.5c0 1.152-.26 2.243-.723 3.218-.266.558.107 1.282.725 1.282h3.126c1.026 0 1.945.694 2.054 1.715.045.422.068.85.068 1.285a11.95 11.95 0 01-2.649 7.521c-.388.482-.987.729-1.605.729H13.48c-.483 0-.964-.078-1.423-.23l-3.114-1.04a4.501 4.501 0 00-1.423-.23H5.904M14.25 9h2.25M5.904 18.75c.083.205.173.405.27.602.197.4-.078.898-.523.898h-.908c-.889 0-1.713-.518-1.972-1.368a12 12 0 01-.521-3.507c0-1.553.295-3.036.831-4.398C3.387 10.203 4.167 9.75 5 9.75h1.053c.472 0 .745.556.5.96a8.958 8.958 0 00-1.302 4.665c0 1.194.232 2.333.654 3.375z"></path>
                    </svg>
                    <span><?=$commentVoteRate['likes']; ?></span>
                  </button>
                  <button type="button" class="btn btn-sm btn-outline-secondary" disabled>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="#333" aria-hidden="true" style="width: 16px"><path stroke-linecap="round" stroke-linejoin="round" d="M7.5 15h2.25m8.024-9.75c.011.05.028.1.052.148.591 1.2.924 2.55.924 3.977a8.96 8.96 0 01-.999 4.125m.023-8.25c-.076-.365.183-.75.575-.75h.908c.889 0 1.713.518 1.972 1.368.339 1.11.521 2.287.521 3.507 0 1.553-.295 3.036-.831 4.398C20.613 14.547 19.833 15 19 15h-1.053c-.472 0-.745-.556-.5-.96a8.95 8.95 0 00.303-.54m.023-8.25H16.48a4.5 4.5 0 01-1.423-.23l-3.114-1.04a4.5 4.5 0 00-1.423-.23H6.504c-.618 0-1.217.247-1.605.729A11.95 11.95 0 002.25 12c0 .434.023.863.068 1.285C2.427 14.306 3.346 15 4.372 15h3.126c.618 0 .991.724.725 1.282A7.471 7.471 0 007.5 19.5a2.25 2.25 0 002.25 2.25.75.75 0 00.75-.75v-.633c0-.573.11-1.14.322-1.672.304-.76.93-1.33 1.653-1.715a9.04 9.04 0 002.86-2.4c.498-.634 1.226-1.08 2.032-1.08h.384"></path>
                    </svg>
                    <span><?=$commentVoteRate['dislikes']; ?></span>
                  </button>
                </td>
              </tr>
              <tr>
                <td class="text-muted" style="width: 35%">Активность</td>
                <td>
                  <div class="form-check form-switch">
                    <input type="checkbox" class="form-check-input" id="review__active__inside__<?=$comment->id; ?>" <?php echo $checkboxCheckedAttribute; ?> onchange="$.commentChangeActive(<?=$comment->id; ?>)"/>
                    <label class="form-check-label" for="review__active__inside__<?=$comment->id; ?>"></label>
                  </div>
                </td>
              </tr>
            </table>
            <?php if ($parentCommentList) { ?>
              <h6>Ответ на отзыв</h6>
                <table class="table table-borderless">
                    <?php foreach ($parentCommentList as $parentComment) {
                        $parentCommentDatetime = new DateTimeImmutable($parentComment->datetime);
                        ?>
                      <tr>
                        <td class="text-muted" style="width: 35%"><?=$commentDatetime->format('d.m.Y H:i') ?></td>
                        <td><?=$parentComment->text ?></td>
                      </tr>
                    <?php } ?>
                </table>
            <?php } ?>


            <div class="mb-3">

              <div class="row mb-2">
                <div class="col">
                  <label for="answer<?=$classNameForAnswer; ?>" class="form-label pt-2">Ответ</label>
                </div>
<!--                <div class="col d-flex justify-content-end">-->
<!--                  <div class="dropdown">-->
<!--                    <div class="btn-group">-->
<!--                      <button class="btn btn-outline-secondary btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">-->
<!--                        Шаблоны ответов-->
<!--                      </button>-->
<!--                      <ul class="dropdown-menu">-->
<!--                        <li><a class="dropdown-item" href="#">Шаблон 1</a></li>-->
<!--                        <li><a class="dropdown-item" href="#">Шаблон 2</a></li>-->
<!--                      </ul>-->
<!--                    </div>-->
<!--                  </div>-->
                </div>

              </div>
              <textarea class="form-control js-comment-answer-textarea" id="answer<?=$classNameForAnswer; ?>" rows="3"></textarea>
              <button class="btn btn-sm btn-success mt-2 mb-2"onclick="$.sendCommentAnswer('#answer<?=$classNameForAnswer ?>', <?=$comment->id ?>)">Сохранить ответ</button>
            </div>
          </div>
        </div>





      </td>
      <td class="w-25">
        <?php if (!is_null($shopItem->name)) { ?>
          <a href="<?=$shopLink . $shopItem->path . '-'. $shopItem->id; ?>" target="_blank" class="link-offset-2 link-underline link-underline-opacity-0"><?=$shopItem->name ?></a>
        <?php } ?>
        <div class="small text-muted"><?=$shopItem->marking ?></div>
      </td>
      <td>
        <div class="form-check form-switch">
          <input type="checkbox" class="form-check-input" id="review__active__<?=$comment->id; ?>" <?php echo $checkboxCheckedAttribute; ?> onchange="$.commentChangeActive(<?=$comment->id; ?>)"/>
          <label class="form-check-label" for="review__active__<?=$comment->id; ?>"></label>
        </div>
      </td>
    </tr>
  <?php } ?>
  </tbody>
</table>

<?php

$totalPages = ceil($totalComments / $limit);
$visiblePagesCount = 5;
$visiblePages = [];
$minPage = ($page - floor($visiblePagesCount / 2));
$maxPage = ($page + floor($visiblePagesCount / 2));

for ($i = $minPage; $i <= $maxPage; $i++) {
  if ($i > $totalPages - 1) {
  } elseif ($i == $page) {
      $visiblePages[$i] = 'current';
  } elseif ($i >= 0) {
      $visiblePages[$i] = $i;
  }
}

$url = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$parseUrl = parse_url($url);
if (isset($parseUrl['query'])) {
    parse_str(parse_url($url)['query'], $urlParams);
} else {
    $urlParams = [];
}

$urlForPageLink = './';
$urlForPageLink .= '?';

unset($urlParams['page']);
foreach ($urlParams as $param => $value) {
    if (is_array($value)) {
      foreach ($value as $key => $paramSubItem) {
          $urlForPageLink .=  $param . '[]=' . $paramSubItem;
          if ($key !== array_key_last($value)) {
              $urlForPageLink .=  '&';
          }
      }
    } else {
        $urlForPageLink .=  $param . '=' . $value;
    }
    if ($param !== array_key_last($urlParams)) {
        $urlForPageLink .=  '&';
    }
}

?>
<!--<div class="small text-muted text-center mb-3">-->
<!--    --><?php //=$page + 1;?><!-- из --><?php //=$totalPages?>
<!--</div>-->
<nav class="mb-3">
  <ul class="pagination justify-content-center">
    <?php if ($minPage > 0) { ?>
      <li class="page-item">
        <a class="page-link" href="<?=$urlForPageLink; ?>&page=<?=$page?>" aria-label="Предыдущая">
          <span aria-hidden="true">&laquo;</span>
        </a>
      </li>
    <?php } ?>
    <?php
    foreach ($visiblePages as $pageNumber => $visiblePage)
    {
      $activePageClass = '';
      $pageHref = $urlForPageLink;
      if ($visiblePage === 'current') {
        $activePageClass = 'active';
      }
      if ($pageNumber != 0) {
        $pageHref .= '&page=' . ($pageNumber + 1);
      }
    ?>
      <li class="page-item <?= $activePageClass;?>"><a class="page-link" href="<?=$pageHref; ?>"><?=$pageNumber + 1; ?></a></li>
    <?php } ?>
    <?php if ($maxPage < $totalPages - 1) { ?>
      <li class="page-item">
        <a class="page-link" href="<?=$urlForPageLink; ?>&page=<?=$page + 2?>" aria-label="Следующая">
          <span aria-hidden="true">&raquo;</span>
        </a>
      </li>
    <?php } ?>
  </ul>
</nav>
