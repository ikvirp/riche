<?php

class My_Shop_Item_Import_Cml_Controller extends Shop_Item_Import_Cml_Controller
{
  public function import()
  {
    Core_Event::notify('Shop_Item_Import_Cml_Controller.onBeforeImport', $this);

    if (is_null($this->iShopId)) {
      throw new Core_Exception(Core::_('Shop_Item.error_shop_id'));
    }

    if (is_null($this->iShopGroupId)) {
      throw new Core_Exception(Core::_('Shop_Item.error_parent_directory'));
    }

    /*
		 Удаляем товары/группы только при получении import.xml
		*/
    if (
      $this->importAction == 0 &&
      count((array) $this->_oSimpleXMLElement->Классификатор) &&
      count((array) $this->_oSimpleXMLElement->ПакетПредложений) == 0 &&
      count((array) $this->_oSimpleXMLElement->ИзмененияПакетаПредложений) == 0
    ) {
      Core_QueryBuilder::update('shop_groups')
        ->set('deleted', 1)
        ->where('shop_id', '=', $this->iShopId)
        ->execute();

      Core_QueryBuilder::update('shop_items')
        ->set('deleted', 1)
        ->where('shop_id', '=', $this->iShopId)
        ->execute();
    }

    $oShop = Core_Entity::factory('Shop', $this->iShopId);

    $timeout = Core::getmicrotime();

    // CML 2.x
    if (
      isset($this->_oSimpleXMLElement->attributes()->ВерсияСхемы) &&
      version_compare(
        strval($this->_oSimpleXMLElement->attributes()->ВерсияСхемы),
        '2.0',
        '>='
      )
    ) {
      $bCmlIdItemSearchFields = in_array('cml_id', $this->itemSearchFields);
      $bMarkingItemSearchFields = in_array('marking', $this->itemSearchFields);
      $bBarcodeItemSearchFields = in_array('barcode', $this->itemSearchFields);

      // Файл import.xml
      if (
        !isset($this->_oSimpleXMLElement->ПакетПредложений) &&
        !isset($this->_oSimpleXMLElement->ИзмененияПакетаПредложений)
      ) {
        Core_Session::start();
        $importPosition = Core_Array::getSession('importPosition', 0);

        $this->debug &&
          Core_Log::instance()
            ->clear()
            ->status(Core_Log::$MESSAGE)
            ->write(
              sprintf(
                '1С, обработка import.xml, получен importPosition %d',
                $importPosition
              )
            );

        Core_Session::close();

        if (
          isset($this->_oSimpleXMLElement->Классификатор) &&
          $importPosition == 0
        ) {
          $classifier = $this->_oSimpleXMLElement->Классификатор;

          // Импортируем группы товаров
          if ($this->importGroups) {
            // Наименования каталогов по умолчанию, если указано иное,
            // то в качестве корневой будет создана группа с тем названием
            if (
              !in_array(
                strval($this->_oSimpleXMLElement->Каталог->Наименование),
                $this->_aConfig['catalogName']
              )
            ) {
              $sCatalogId = strval($this->_oSimpleXMLElement->Каталог->Ид);
              $sCatalogName = strval(
                $this->_oSimpleXMLElement->Каталог->Наименование
              );

              if (strlen($sCatalogId)) {
                $oTmpGroup = $oShop->Shop_Groups->getByGuid($sCatalogId);

                if (is_null($oTmpGroup)) {
                  $oTmpGroup = Core_Entity::factory('Shop_Group');
                  $oTmpGroup->parent_id = $this->iShopGroupId;
                  $oTmpGroup->name = $sCatalogName;
                  $oTmpGroup->guid = $sCatalogId;
                  $oShop->add($oTmpGroup);
                }

                $this->iShopGroupId = $oTmpGroup->id;
              }
            }

            foreach ($this->xpath($classifier, 'Группы') as $Groups) {
              $this->_importGroups($Groups, $this->iShopGroupId);
            }
          }

          // Импортируем дополнительные свойства товаров
          $this->_importProperties($classifier);

          // CML 3.x: ТипыЦен/ТипЦены
          $this->_importSpecialPrices($classifier);

          // CML 3.x: Склады/Склад
          $this->_importWarehouses($classifier);

          // CML 3.x: ЕдиницыИзмерения/ЕдиницаИзмерения
          $this->_importMeasures($classifier);

          // Сохраняем классификатор
          $sJsonFilePath =
            $this->_tmpPath .
            Core_File::filenameCorrection(
              $this->_oSimpleXMLElement->Классификатор->Ид
            ) .
            '.json';

          Core_File::write(
            $sJsonFilePath,
            json_encode([
              '_aPropertyValues' => $this->_aPropertyValues,
              '_aBaseProperties' => $this->_aBaseProperties,
            ])
          );
        }
        // Классификатора не было, но указан его ИД
        elseif (isset($this->_oSimpleXMLElement->Каталог->ИдКлассификатора)) {
          $this->_loadJson(
            $this->_oSimpleXMLElement->Каталог->ИдКлассификатора
          );
        }

        $xPath =
          $importPosition == 0
            ? 'Товары/Товар'
            : 'Товары/Товар[position() > ' . $importPosition . ']';

        foreach (
          $this->xpath($this->_oSimpleXMLElement->Каталог, $xPath)
          as $oXmlItem
        ) {
          Core_Event::notify(
            'Shop_Item_Import_Cml_Controller.onBeforeImportShopItem',
            $this,
            [$oXmlItem]
          );

          // If onBeforeImportShopItem returned FALSE, skip item
          if (Core_Event::getLastReturn() === false) {
            continue;
          }

          $sGUID = strval($oXmlItem->Ид);
          $sGUIDmod = false;

          if (strpos($sGUID, '#') !== false) {
            $sTmp = explode('#', $sGUID);
            $sGUID = $sTmp[0];
            $sGUIDmod = $sTmp[1];
          }

          // Товар может быть идентифицирован произвольным (например GUID или внутрисистемным) идентификатором, Штрихкодом, Артикулом. Контрагент может использовать любой удобный с его точки зрения идентификатор - на выбор

          // Search by GUID
          $bCmlIdItemSearchFields &&
            ($oShopItem = $oShop->Shop_Items->getByGuid($sGUID, false));

          // Search by Barcode
          if (
            is_null($oShopItem) &&
            $bBarcodeItemSearchFields &&
            strlen($oXmlItem->Штрихкод)
          ) {
            $oTmpItemsByBarcode = $oShop->Shop_Items;
            $oTmpItemsByBarcode
              ->queryBuilder()
              ->select('shop_items.*')
              ->join(
                'shop_item_barcodes',
                'shop_item_barcodes.shop_item_id',
                '=',
                'shop_items.id'
              )
              ->where(
                'shop_item_barcodes.value',
                '=',
                strval($oXmlItem->Штрихкод)
              );

            $oShopItem = $oTmpItemsByBarcode->getFirst(false);
          }

          // Search by Marking
          if (
            is_null($oShopItem) &&
            $bMarkingItemSearchFields &&
            trim(strval($oXmlItem->Артикул)) != ''
          ) {
            $oShopItem = $oShop->Shop_Items->getByMarking(
              strval($oXmlItem->Артикул)
            );
          }

          $sItemName = strval($oXmlItem->Наименование);

          $this->_bNewShopItem = is_null($oShopItem);

          if ($this->_bNewShopItem) {
            // Не создавать товары, переходим к следующему
            if (!$this->createShopItems) {
              continue;
            }

            // Создаем товар
            $oShopItem = Core_Entity::factory('Shop_Item')->guid($sGUID);

            // Минимально необходимы данные
            $oShopItem->name = $sItemName;
            $oShopItem->path = '';
            $oShopItem->shop_id($this->iShopId)->save();
            $this->_aReturn['insertItemCount']++;
          } else {
            $this->_aReturn['updateItemCount']++;
          }

          // Если передан GUID модификации и товар, для которого загружается модификация, уже существует
          if (strlen($sGUIDmod) && $oShopItem->id) {
            $oModificationItem = $oShopItem->Modifications->getByGuid(
              $sGUIDmod,
              false
            );

            $this->_bNewShopItem = is_null($oModificationItem);
            // Модификация у товара не найдена, создаем ее
            if ($this->_bNewShopItem) {
              // Если товар - модификация, оставляем лишь базовые данные, название и идентификатор магазина/группы товаров
              $oModificationItem = Core_Entity::factory('Shop_Item')
                ->guid($sGUIDmod)
                ->modification_id($oShopItem->id)
                ->shop_id($oShop->id)
                ->shop_group_id(0)
                ->save();
            }

            // Подменяем товар на модификацию
            $oShopItem = $oModificationItem;
          }

          // Отключение товара после определения модификация или нет
          // $oAttributes = $oXmlItem->attributes();
          // if (isset($oAttributes['Статус']) && $oAttributes['Статус'] == 'Удален'
          // 	|| isset($oXmlItem->Статус) && strval($oXmlItem->Статус) == 'Удален')
          // {
          // 	$oShopItem->active = 0;
          // 	$oShopItem->save();
          // 	continue;
          // }

          $this->_checkUpdateField('name') && ($oShopItem->name = $sItemName);

          // Barcode
          if (
            $this->_checkUpdateField('barcode') &&
            strval($oXmlItem->Штрихкод)
          ) {
            $oShop_Item_Barcode = $oShopItem->Shop_Item_Barcodes->getByvalue(
              strval($oXmlItem->Штрихкод),
              false
            );

            if (is_null($oShop_Item_Barcode)) {
              $oShop_Item_Barcode = Core_Entity::factory('Shop_Item_Barcode');
              $oShop_Item_Barcode->value = strval($oXmlItem->Штрихкод);
              $oShop_Item_Barcode->setType();
              $oShopItem->add($oShop_Item_Barcode);
            }
          }

          // Marking
          $this->_checkUpdateField('marking') &&
            strval($oXmlItem->Артикул) != '' &&
            ($oShopItem->marking = strval($oXmlItem->Артикул));

          // GUID
          $this->_checkUpdateField('guid') &&
            strval($oXmlItem->Ид) != '' &&
            ($oShopItem->guid = strval($oXmlItem->Ид));

          // БазоваяЕдиница
          $this->_importBaseMeasure($oXmlItem, $oShopItem);

          if ($this->_checkUpdateField('shop_group_id')) {
            // Массив CML ID групп, в которые помещается товар
            $aGroupsCmlIDs = [];
            foreach ($this->xpath($oXmlItem, 'Группы/Ид') as $oXmlGroupId) {
              $aGroupsCmlIDs[] = strval($oXmlGroupId);
            }

            $firstGroupCmlId = count($aGroupsCmlIDs)
              ? array_shift($aGroupsCmlIDs)
              : null;

            // Остальные группы из массива обрабатываются ниже
            if (
              !is_null($firstGroupCmlId) &&
              !is_null(
                $oShop_Group = $oShop->Shop_Groups->getByGuid(
                  $firstGroupCmlId,
                  false
                )
              )
            ) {
              // Группа указана в файле и существует в магазине
              $sGUIDmod === false
                ? ($oShopItem->shop_group_id = $oShop_Group->id)
                : $oShopItem->Modification
                  ->shop_group_id($oShop_Group->id)
                  ->save();

              // see Shop_Item_Model::save()
              //$this->_bNewShopItem && $oShop_Group->incCountItems();
            } else {
              // Группа не указана в файле, размещаем в корне (iShopGroupId)
              $sGUIDmod === false
                ? ($oShopItem->shop_group_id = $this->iShopGroupId)
                : $oShopItem->Modification
                  ->shop_group_id($this->iShopGroupId)
                  ->save();
            }
          }

          $oShopItem->shop_id = $oShop->id;

          // check item path
          $oShopItem->path == '' && $oShopItem->makePath();

          $oSameShopItem = $oShop->Shop_Items->getByGroupIdAndPath(
            $oShopItem->shop_group_id,
            $oShopItem->path
          );

          if (
            !is_null($oSameShopItem) &&
            $oSameShopItem->id != $oShopItem->id
          ) {
            $oShopItem->path = Core_Guid::get();
          } else {
            $oSameShopGroup = Core_Entity::factory(
              'Shop',
              $this->iShopId
            )->Shop_Groups->getByParentIdAndPath(
              $oShopItem->shop_group_id,
              $oShopItem->path
            );

            if (!is_null($oSameShopGroup)) {
              $oShopItem->path = Core_Guid::get();
            }
          }

          if ($oShopItem->modification_id) {
            $oShopItem->shop_group_id = 0;
          }

          if (
            $oShopItem->id &&
            $this->importAction == 1 &&
            !is_null($oShopItem->name)
          ) {
            $oShopItem->save();
          } elseif (!is_null($oShopItem->name)) {
            is_null($oShopItem->path) && ($oShopItem->path = '');

            $oShopItem->save()->clearCache();
          } else {
            throw new Core_Exception(
              Core::_('Shop_Item.error_save_without_name')
            );
          }

          // В остальные группы помещается ярлык
          if (
            $this->_checkUpdateField('shop_group_id') &&
            count($aGroupsCmlIDs)
          ) {
            foreach ($aGroupsCmlIDs as $sGroupCmlID) {
              $oTmpShopGroup = $oShop->Shop_Groups->getByGuid(
                $sGroupCmlID,
                false
              );

              if (!is_null($oTmpShopGroup)) {
                $aShopItems = $oShop->Shop_Items;
                $aShopItems
                  ->queryBuilder()
                  ->where('shortcut_id', '=', $oShopItem->id)
                  ->where('shop_group_id', '=', $oTmpShopGroup->id)
                  ->limit(1);

                $iCountShortcuts = $aShopItems->getCount(false);

                if (!$iCountShortcuts) {
                  Core_Entity::factory('Shop_Item')
                    ->shop_group_id($oTmpShopGroup->id)
                    ->shortcut_id($oShopItem->id)
                    ->shop_id($oShop->id)
                    ->save();
                }
              }
            }
          }

          // Обрабатываем описание товара
          $sDescription = strval($oXmlItem->Описание);
          if ($sDescription != '') {
            if (
              $this->itemDescription == 'text' &&
              $this->_checkUpdateField('text')
            ) {
              $oShopItem->text = nl2br($sDescription);
            } elseif (
              $this->itemDescription == 'description' &&
              $this->_checkUpdateField('description')
            ) {
              $oShopItem->description = nl2br($sDescription);
            }
            $oShopItem->save();
          }

          // Обрабатываем "малое описание" товара (не соответствует стандарту)
          $sShortTag = $this->shortDescription;
          $sDescription = strval($oXmlItem->$sShortTag);
          if ($sDescription != '') {
            $oShopItem->description = nl2br($sDescription);
            $oShopItem->save();
          }

          // Картинки основного товара
          $this->_checkUpdateField('images') &&
            $this->importImages(
              $oShopItem,
              $this->xpath($oXmlItem, 'Картинка')
            );

          if ($this->_checkUpdateField('props')) {
            // Добавляем значения для общих свойств всех товаров
            foreach (
              $this->xpath($oXmlItem, 'ЗначенияСвойств/ЗначенияСвойства')
              as $ItemPropertyValue
            ) {
              $this->_importPropertyValues($oShopItem, $ItemPropertyValue);
            }

            foreach (
              $this->xpath(
                $oXmlItem,
                'ХарактеристикиТовара/ХарактеристикаТовара'
              )
              as $oItemProperty
            ) {
              $this->_importPropertyValues($oShopItem, $oItemProperty);
            }

            foreach (
              $this->xpath($oXmlItem, 'ЗначенияРеквизитов/ЗначениеРеквизита')
              as $oItemProperty
            ) {
              $this->_addPredefinedAdditionalProperty(
                $oShopItem,
                $oItemProperty,
                strval($oItemProperty->Значение)
              );
            }
          }

          // CML 3.x
          /* <Вес>999</Вес>
					<Ширина>10</Ширина>
					<Длина>20</Длина>
					<Высота>30</Высота> */
          strval($oXmlItem->Вес) != '' &&
            ($oShopItem->weight = strval($oXmlItem->Вес));

          strval($oXmlItem->Ширина) != '' &&
            ($oShopItem->width = strval($oXmlItem->Ширина));

          strval($oXmlItem->Длина) != '' &&
            ($oShopItem->length = strval($oXmlItem->Длина));

          strval($oXmlItem->Высота) != '' &&
            ($oShopItem->height = strval($oXmlItem->Высота));

          // Налоги
          if ($this->_checkUpdateField('taxes')) {
            foreach (
              $this->xpath($oXmlItem, 'СтавкиНалогов/СтавкаНалога')
              as $oTax
            ) {
              $oShopTax = $this->_addTax($oTax);
              $oShopItem->shop_tax_id = $oShopTax->id;
              $oShopItem->save();
            }
          }

          // Производитель у товаров
          if ($this->_checkUpdateField('shop_producer_id')) {
            if (isset($oXmlItem->ТорговаяМарка)) {
              $this->_setProducer(strval($oXmlItem->ТорговаяМарка), $oShopItem);
            } elseif (isset($oXmlItem->Изготовитель)) {
              $this->_setProducer(
                strval($oXmlItem->Изготовитель->Наименование),
                $oShopItem
              );
            }
          }

          // Fast filter
          if ($oShop->filter) {
            $oShop_Filter_Controller = new Shop_Filter_Controller($oShop);
            $oShop_Filter_Controller->fill($oShopItem);
          }

          // Indexation
          $this->searchIndexation && $oShopItem->index();

          Core_Event::notify(
            'Shop_Item_Import_Cml_Controller.onAfterImportShopItem',
            $this,
            [$oShopItem, $oXmlItem]
          );

          $importPosition++;

          // Прерываем этап импорта
          if (
            $this->timeout &&
            Core::getmicrotime() - $timeout + 2 > $this->timeout
          ) {
            Core_Session::start();
            $_SESSION['importPosition'] = $importPosition;

            $this->debug &&
              Core_Log::instance()
                ->clear()
                ->status(Core_Log::$MESSAGE)
                ->write(
                  sprintf(
                    '1С, обработка import.xml, сохранен importPosition %d',
                    $importPosition
                  )
                );
            Core_Session::close();

            $this->_aReturn['status'] = 'progress';
            return $this->_aReturn;
          }
        }
      }
      // Файл offers.xml
      elseif (
        (isset($this->_oSimpleXMLElement->ПакетПредложений) ||
          isset($this->_oSimpleXMLElement->ИзмененияПакетаПредложений)) &&
        !isset($this->_oSimpleXMLElement->Каталог)
      ) {
        Core_Session::start();
        $importPosition = Core_Array::getSession('importPosition', 0);

        $this->debug &&
          Core_Log::instance()
            ->clear()
            ->status(Core_Log::$MESSAGE)
            ->write(
              sprintf(
                '1С, обработка offers.xml, получен importPosition %d',
                $importPosition
              )
            );

        if ($importPosition > 0) {
          isset($_SESSION['_aShop_Warehouse_Inventory_Ids']) &&
            ($this->_aShop_Warehouse_Inventory_Ids =
              $_SESSION['_aShop_Warehouse_Inventory_Ids']);

          isset($_SESSION['_Shop_Price_Setting_Id']) &&
            ($this->_Shop_Price_Setting_Id =
              $_SESSION['_Shop_Price_Setting_Id']);
        }
        Core_Session::close();

        $packageOfProposals = isset($this->_oSimpleXMLElement->ПакетПредложений)
          ? $this->_oSimpleXMLElement->ПакетПредложений
          : $this->_oSimpleXMLElement->ИзмененияПакетаПредложений;

        if (isset($packageOfProposals->ИдКлассификатора)) {
          $this->_loadJson($packageOfProposals->ИдКлассификатора);
        }

        $classifier = $this->_oSimpleXMLElement->Классификатор;

        // Импортируем дополнительные свойства товаров
        //$this->_importProperties($classifier);

        // CML 2.x: ТипыЦен/ТипЦены
        $this->_importSpecialPrices($packageOfProposals);

        if ($importPosition == 0) {
          $this->_importWarehouses($packageOfProposals);
        }

        $xPath =
          $importPosition == 0
            ? 'Предложения/Предложение'
            : 'Предложения/Предложение[position() > ' . $importPosition . ']';

        // Обработка предложений
        foreach ($this->xpath($packageOfProposals, $xPath) as $oProposal) {
          Core_Event::notify(
            'Shop_Item_Import_Cml_Controller.onBeforeOffer',
            $this,
            [$oProposal]
          );

          // If onBeforeOffer returned FALSE, skip item
          if (Core_Event::getLastReturn() === false) {
            continue;
          }

          $sItemGUID = strval($oProposal->Ид);

          $sGUIDmod = false;
          if (strpos($sItemGUID, '#') !== false) {
            $aItemGUID = explode('#', $sItemGUID);
            $sItemGUID = $aItemGUID[0];
            $sGUIDmod = $aItemGUID[1];
          }

          // Товар может быть идентифицирован произвольным (например GUID или внутрисистемным) идентификатором, Штрихкодом, Артикулом. Контрагент может использовать любой удобный с его точки зрения идентификатор - на выбор

          // Основной товар (не модификация)
          $bCmlIdItemSearchFields &&
            ($oShopItem = $oShop->Shop_Items->getByGuid($sItemGUID, false));

          // Search by Barcode
          if (
            is_null($oShopItem) &&
            $bBarcodeItemSearchFields &&
            strval($oProposal->Штрихкод)
          ) {
            $oTmpItemsByBarcode = $oShop->Shop_Items;
            $oTmpItemsByBarcode
              ->queryBuilder()
              ->select('shop_items.*')
              ->join(
                'shop_item_barcodes',
                'shop_item_barcodes.shop_item_id',
                '=',
                'shop_items.id'
              )
              ->where(
                'shop_item_barcodes.value',
                '=',
                strval($oProposal->Штрихкод)
              );

            $oShopItem = $oTmpItemsByBarcode->getFirst(false);
          }

          // Search by Marking
          if (
            is_null($oShopItem) &&
            $bMarkingItemSearchFields &&
            strval($oProposal->Артикул)
          ) {
            $oShopItem = $oShop->Shop_Items->getByMarking(
              strval($oProposal->Артикул)
            );
          }

          if (!is_null($oShopItem)) {
            $this->_bNewShopItem = false;

            // Если передан GUID модификации
            if (strlen($sGUIDmod)) {
              $oModificationItem = $oShopItem->Modifications->getByGuid(
                $sGUIDmod,
                false
              );

              // Модификация у товара не найдена, создаем ее
              if (is_null($oModificationItem)) {
                $oModificationItem = Core_Entity::factory('Shop_Item')
                  ->guid($sGUIDmod)
                  ->modification_id($oShopItem->id)
                  ->shop_id($this->iShopId)
                  ->shop_group_id(0)
                  ->save();

                $this->_bNewShopItem = true;
              }

              // Подменяем товар на модификацию
              $oShopItem = $oModificationItem;

              // Для модификации обновляется название и артикул
              $this->_checkUpdateField('marking') &&
                strval($oProposal->Артикул) != '' &&
                ($oShopItem->marking = strval($oProposal->Артикул));

              $this->_checkUpdateField('name') &&
                ($this->_bNewShopItem ||
                  strval($oProposal->Наименование) != '') &&
                ($oShopItem->name = strval($oProposal->Наименование));
            }

            // Отключение товара после определения модификация или нет
            $oAttributes = $oProposal->attributes();
            if (
              (isset($oAttributes['Статус']) &&
                $oAttributes['Статус'] == 'Удален') ||
              (isset($oProposal->Статус) &&
                strval($oProposal->Статус) == 'Удален')
            ) {
              $oShopItem->active = 0;
              $oShopItem->save();
              continue;
            }

            // Товар найден, начинаем обновление
            // Данные указываются при импорте import.xml, из offers.xml не обновляются
            //$oShopItem->marking = strval($oProposal->Артикул);
            //$oShopItem->name = strval($oProposal->Наименование);

            // БазоваяЕдиница
            $this->_importBaseMeasure($oProposal, $oShopItem);

            // Картинки предложений (модификаций)
            $this->importImages(
              $oShopItem,
              $this->xpath($oProposal, 'Картинка')
            );

            // Добавляем значения для общих свойств всех товаров
            foreach (
              $this->xpath($oProposal, 'ЗначенияСвойств/ЗначенияСвойства')
              as $ItemPropertyValue
            ) {
              $this->_importPropertyValues($oShopItem, $ItemPropertyValue);
            }

            // Обработка характеристик товара из файла offers для совместимости с МойСклад
            foreach (
              $this->xpath(
                $oProposal,
                'ХарактеристикиТовара/ХарактеристикаТовара'
              )
              as $oItemProperty
            ) {
              $this->_importPropertyValues($oShopItem, $oItemProperty);
            }

            if ($this->_checkUpdateField('prices')) {
              foreach ($this->xpath($oProposal, 'Цены/Цена') as $oPrice) {
                Core_Event::notify(
                  get_class($this) . '.onBeforeImportShopItemPrice',
                  $this,
                  [$oShopItem, $packageOfProposals, $oProposal, $oPrice]
                );

                if (is_null(Core_Event::getLastReturn())) {
                  // Ищем цену
                  $oShop_Price = $oShop->Shop_Prices->getByGuid(
                    strval($oPrice->ИдТипаЦены),
                    false
                  );

                  if (
                    !is_null($oShop_Price) &&
                    $this->sShopDefaultPriceGUID != strval($oPrice->ИдТипаЦены)
                  ) {
                    $itemPrice = strval($oPrice->ЦенаЗаЕдиницу);

                    // Валюта товара в основной цене
                    $baseCurrencyNode = $this->xpath(
                      $oProposal,
                      "Цены/Цена[ИдТипаЦены='{$this->sShopDefaultPriceGUID}']"
                    );

                    if (isset($baseCurrencyNode[0])) {
                      // Валюта у цены по умолчанию
                      $sCurrency = strval($baseCurrencyNode[0]->Валюта);

                      // Валюта не указана у самого предложения, смотрим в ТипыЦен/ТипЦены
                      if (!strlen($sCurrency)) {
                        $topCurrencyNode = $this->xpath(
                          $packageOfProposals,
                          "ТипыЦен/ТипЦены[Ид='{$this->sShopDefaultPriceGUID}']"
                        );

                        is_object($topCurrencyNode) &&
                          ($sCurrency = strval($topCurrencyNode->Валюта));
                      }

                      // Указан числовой код валюты, получаем по нему
                      if (
                        is_numeric($sCurrency) &&
                        isset($this->_aCurrencyCodes[$sCurrency])
                      ) {
                        $sCurrency = $this->_aCurrencyCodes[$sCurrency];
                      }

                      $oItem_Shop_Currency = Core_Entity::factory(
                        'Shop_Currency'
                      )->getByLike($sCurrency, false);

                      // Валюта у самого товара
                      $sCurrency = strval($oPrice->Валюта);

                      // Валюта не указана у самого предложения, смотрим в ТипыЦен/ТипЦены
                      if (!strlen($sCurrency)) {
                        $topCurrencyNode = $this->xpath(
                          $packageOfProposals,
                          "ТипыЦен/ТипЦены[Ид='" .
                            strval($oPrice->ИдТипаЦены) .
                            "']"
                        );

                        is_object($topCurrencyNode) &&
                          ($sCurrency = strval($topCurrencyNode->Валюта));
                      }

                      // Указан числовой код валюты, получаем по нему
                      if (
                        is_numeric($sCurrency) &&
                        isset($this->_aCurrencyCodes[$sCurrency])
                      ) {
                        $sCurrency = $this->_aCurrencyCodes[$sCurrency];
                      }

                      // Валюта спеццены
                      $oPrice_Currency = Core_Entity::factory(
                        'Shop_Currency'
                      )->getByLike($sCurrency, false);

                      if (
                        !is_null($oItem_Shop_Currency) &&
                        !is_null($oPrice_Currency) &&
                        $oItem_Shop_Currency->exchange_rate &&
                        $oPrice_Currency->exchange_rate
                      ) {
                        $currencyCoefficient = Shop_Controller::instance()->getCurrencyCoefficientInShopCurrency(
                          $oPrice_Currency,
                          $oItem_Shop_Currency
                        );

                        $itemPrice *= $currencyCoefficient;
                      }
                    }

                    $oShop_Item_Price = $oShopItem->Shop_Item_Prices->getByPriceId(
                      $oShop_Price->id,
                      false
                    );

                    $old_price = !is_null($oShop_Item_Price)
                      ? $oShop_Item_Price->value
                      : $oShopItem->price;

                    if ($old_price != $itemPrice) {
                      $oShop_Price_Setting = $this->getPrices();

                      $oShop_Price_Setting_Item = Core_Entity::factory(
                        'Shop_Price_Setting_Item'
                      );
                      $oShop_Price_Setting_Item->shop_price_id =
                        $oShop_Price->id;
                      $oShop_Price_Setting_Item->shop_item_id = $oShopItem->id;
                      $oShop_Price_Setting_Item->old_price = $old_price;
                      $oShop_Price_Setting_Item->new_price = $itemPrice;
                      $oShop_Price_Setting->add($oShop_Price_Setting_Item);

                      /*if (is_null($oShop_Item_Price))
											{
												$oShop_Item_Price = Core_Entity::factory('Shop_Item_Price');
												$oShop_Item_Price->shop_item_id = $oShopItem->id;
												$oShop_Item_Price->shop_price_id = $oShop_Price->id;
											}
											$oShop_Item_Price->value = $itemPrice;

											$oShopItem->add($oShop_Item_Price);*/
                    }
                  } elseif (
                    $this->sShopDefaultPriceGUID == strval($oPrice->ИдТипаЦены)
                  ) {
                    $sCurrency = strval($oPrice->Валюта);

                    // Валюта не указана у самого предложения, смотрим в ТипыЦен/ТипЦены
                    if (!strlen($sCurrency)) {
                      $topCurrencyNode = $this->xpath(
                        $packageOfProposals,
                        "ТипыЦен/ТипЦены[Ид='" .
                          strval($oPrice->ИдТипаЦены) .
                          "']"
                      );

                      is_object($topCurrencyNode) &&
                        ($sCurrency = strval($topCurrencyNode->Валюта));
                    }

                    // Указан числовой код валюты, получаем по нему
                    if (
                      is_numeric($sCurrency) &&
                      isset($this->_aCurrencyCodes[$sCurrency])
                    ) {
                      $sCurrency = $this->_aCurrencyCodes[$sCurrency];
                    }

                    $oShop_Currency = Core_Entity::factory(
                      'Shop_Currency'
                    )->getByLike($sCurrency, false);

                    if (is_null($oShop_Currency)) {
                      $oShop_Currency = Core_Entity::factory('Shop_Currency');
                      $oShop_Currency->name = $sCurrency;
                      $oShop_Currency->sign = $sCurrency;
                      $oShop_Currency->code = $sCurrency;
                      $oShop_Currency->exchange_rate = 1;
                    }

                    $newPrice = Shop_Controller::instance()->convertPrice(
                      strval($oPrice->ЦенаЗаЕдиницу)
                    );

                    if ($newPrice != $oShopItem->price) {
                      $oShop_Price_Setting = $this->getPrices();

                      $oShop_Price_Setting_Item = Core_Entity::factory(
                        'Shop_Price_Setting_Item'
                      );
                      $oShop_Price_Setting_Item->shop_price_id = 0;
                      $oShop_Price_Setting_Item->shop_item_id = $oShopItem->id;
                      $oShop_Price_Setting_Item->old_price = $oShopItem->price;
                      $oShop_Price_Setting_Item->new_price = $newPrice;
                      $oShop_Price_Setting->add($oShop_Price_Setting_Item);

                      // $oShopItem->price = Shop_Controller::instance()->convertPrice(strval($oPrice->ЦенаЗаЕдиницу));
                    }

                    // Set ->shop_currency_id
                    $oShopItem->add($oShop_Currency);

                    // Налоги
                    if ($this->_checkUpdateField('taxes')) {
                      if (!is_null($this->_oTaxForBasePrice)) {
                        $oShopItem->add($this->_oTaxForBasePrice);
                        $this->_oTaxForBasePrice = null;
                      }
                    }

                    // Импортируется только через "БазоваяЕдиница"
                    /*if (($sMeasureName = strval($oPrice->Единица)) != '')
										{
											if (is_null($oShop_Measure = Core_Entity::factory('Shop_Measure')->getByName($sMeasureName, FALSE)))
											{
												$oShop_Measure = Core_Entity::factory('Shop_Measure')->name($sMeasureName)->save();
											}
											$oShopItem->add($oShop_Measure);
										}*/
                  }
                }
              }
            }

            if ($this->_checkUpdateField('warehouses')) {
              /*<Предложение>
							<Ид>c0eba50e-7385-11e8-8001-c4e98401fadf#1ff9c1e7-7388-11e8-8001-c4e98401fadf</Ид>
							<Остатки>
								<Остаток>
									<Склад>
										<Ид>547f1a9b-88c3-11e7-8035-c4e98401fadf</Ид>
										<Количество>0</Количество>
									</Склад>
								</Остаток>*/

              // CML 3.x: Остатки/Остаток/Склад в rests___xxx.xml
              if (isset($oProposal->Остатки)) {
                $aWarehouses = $this->xpath(
                  $oProposal->Остатки,
                  'Остаток/Склад'
                );

                foreach ($aWarehouses as $oWarehouseCount) {
                  if (
                    isset($oWarehouseCount->Ид) &&
                    isset($oWarehouseCount->Количество)
                  ) {
                    $sWarehouseGuid = strval($oWarehouseCount->Ид);
                    $newRest = strval($oWarehouseCount->Количество);

                    $this->_setWarehouseRest(
                      $oShopItem,
                      $sWarehouseGuid,
                      $newRest
                    );
                  }
                }
              } else {
                /* Новые версии: <Склад ИдСклада="xxx" КоличествоНаСкладе="10"></Склад>
                 <Склад ИдСклада="yyy" КоличествоНаСкладе="15"></Склад> */
                $aWarehouses = $this->xpath($oProposal, 'Склад');

                /* 2.07: <Склады ИдСклада="xxx" КоличествоНаСкладе="0"/>
                 <Склады ИдСклада="yyy" КоличествоНаСкладе="2"/> */
                !count($aWarehouses) &&
                  ($aWarehouses = $this->xpath($oProposal, 'Склады'));

                // Явно переданы остатки по каждому складу
                if (count($aWarehouses)) {
                  foreach ($aWarehouses as $oWarehouseCount) {
                    if (
                      isset($oWarehouseCount['ИдСклада']) &&
                      isset($oWarehouseCount['КоличествоНаСкладе'])
                    ) {
                      $sWarehouseGuid = strval($oWarehouseCount['ИдСклада']);
                      $newRest = strval($oWarehouseCount['КоличествоНаСкладе']);

                      $this->_setWarehouseRest(
                        $oShopItem,
                        $sWarehouseGuid,
                        $newRest
                      );
                    }
                  }
                }
                // Общее количество на складе по умолчанию
                else {
                  $iItemCount = isset($oProposal->Количество)
                    ? strval($oProposal->Количество)
                    : 0;

                  // если нет тега "Количество", ставим количество товара на главном складе равным нулю
                  // Ищем главный склад
                  $oWarehouse = Core_Entity::factory(
                    'Shop',
                    $this->iShopId
                  )->Shop_Warehouses->getByDefault('1', false);

                  if (is_null($oWarehouse)) {
                    // Склад не обнаружен
                    $oWarehouse = Core_Entity::factory('Shop_Warehouse');
                    $oWarehouse->name = Core::_(
                      'Shop_Warehouse.warehouse_default_name'
                    );
                    $oWarehouse->active = 1;
                    $oWarehouse->default = 1;
                    $oWarehouse->shop_id = $this->iShopId;
                    $oWarehouse->save();
                  }

                  $rest = $oWarehouse->getRest($oShopItem->id);
                  $newRest = floatval($iItemCount);

                  if (is_null($rest) || $rest != $newRest) {
                    $oShop_Warehouse_Inventory = $this->getInventory(
                      $oWarehouse->id
                    );

                    $oShop_Warehouse_Inventory_Item = Core_Entity::factory(
                      'Shop_Warehouse_Inventory_Item'
                    );
                    $oShop_Warehouse_Inventory_Item->shop_item_id =
                      $oShopItem->id;
                    $oShop_Warehouse_Inventory_Item->count = $newRest;
                    $oShop_Warehouse_Inventory->add(
                      $oShop_Warehouse_Inventory_Item
                    );

                    /*$oShop_Warehouse_Item = $oWarehouse->Shop_Warehouse_Items->getByShopItemId($oShopItem->id, FALSE);
										if (is_null($oShop_Warehouse_Item))
										{
											$oShop_Warehouse_Item = Core_Entity::factory('Shop_Warehouse_Item')
												->shop_warehouse_id($oWarehouse->id)
												->shop_item_id($oShopItem->id);
										}

										$oShop_Warehouse_Item->count(floatval($iItemCount))->save();*/
                  }
                }
              }
            }

            // Производитель у товров и модификаций
            if ($this->_checkUpdateField('shop_producer_id')) {
              if (isset($oProposal->ТорговаяМарка)) {
                $this->_setProducer(
                  strval($oProposal->ТорговаяМарка),
                  $oShopItem
                );
              } elseif (isset($oProposal->Изготовитель)) {
                $this->_setProducer(
                  strval($oProposal->Изготовитель->Наименование),
                  $oShopItem
                );
              }
            }

            $oShopItem->save()->clearCache();

            // Fast filter
            if ($oShop->filter) {
              $oShop_Filter_Controller = new Shop_Filter_Controller($oShop);
              $oShop_Filter_Controller->fill($oShopItem);
            }

            $this->_aReturn['updateItemCount']++;

            Core_Event::notify(
              'Shop_Item_Import_Cml_Controller.onAfterOffersShopItem',
              $this,
              [$oShopItem, $oProposal]
            );
          }

          $importPosition++;

          // Прерываем этап импорта
          if (
            $this->timeout &&
            Core::getmicrotime() - $timeout + 2 > $this->timeout
          ) {
            Core_Session::start();

            $this->debug &&
              Core_Log::instance()
                ->clear()
                ->status(Core_Log::$MESSAGE)
                ->write(
                  sprintf(
                    '1С, обработка offers.xml, сохранен importPosition %d',
                    $importPosition
                  )
                );

            $_SESSION['importPosition'] = $importPosition;
            $_SESSION['_aShop_Warehouse_Inventory_Ids'] =
              $this->_aShop_Warehouse_Inventory_Ids;
            $_SESSION['_Shop_Price_Setting_Id'] = $this->_Shop_Price_Setting_Id;
            Core_Session::close();

            $this->_aReturn['status'] = 'progress';
            return $this->_aReturn;
          }
        }
      }
    }
    // Файл 1C v.7.xx
    elseif (count((array) $this->_oSimpleXMLElement->Каталог)) {
      $catalog = $this->_oSimpleXMLElement->Каталог;

      foreach ($this->xpath($catalog, 'Свойство') as $oXmlProperty) {
        $oShop_Item_Property_List = Core_Entity::factory(
          'Shop_Item_Property_List',
          $this->iShopId
        );
        $oProperty = $oShop_Item_Property_List->Properties->getByGuid(
          strval($oXmlProperty->attributes()->Идентификатор),
          false
        );

        if (is_null($oProperty)) {
          $oProperty = Core_Entity::factory('Property');
          $oProperty->name = strval($oXmlProperty->attributes()->Наименование);
          $oProperty->type = 1;
          $oProperty->tag_name = Core_Str::transliteration(
            strval($oXmlProperty->attributes()->Наименование)
          );
          $oProperty->guid = strval($oXmlProperty->attributes()->Идентификатор);
          $oShop_Item_Property_List->add($oProperty);
        }
      }

      $aGroupList = $aGroupListTree = [];
      foreach ($this->xpath($catalog, 'Группа') as $oXmlGroup) {
        $sParentGUID =
          strval($oXmlGroup->attributes()->Родитель) == ''
            ? 0
            : strval($oXmlGroup->attributes()->Родитель);
        $aGroupList[
          strval($oXmlGroup->attributes()->Идентификатор)
        ] = $oXmlGroup;
        $aGroupListTree[$sParentGUID][] = strval(
          $oXmlGroup->attributes()->Идентификатор
        );
      }
      $aStack = [0 => 0];
      while (count($aStack) > 0) {
        $sStackEnd = end($aStack);
        unset($aStack[count($aStack) - 1]);
        if (isset($aGroupListTree[$sStackEnd])) {
          foreach ($aGroupListTree[$sStackEnd] as $sGroupGUID) {
            $oShopGroup = Core_Entity::factory(
              'Shop',
              $this->iShopId
            )->Shop_Groups->getByGuid($sGroupGUID, false);
            if (is_null($oShopGroup)) {
              $oShopGroup = Core_Entity::factory('Shop_Group');
              $oShopGroup->guid = strval(
                $aGroupList[$sGroupGUID]->attributes()->Идентификатор
              );
              $oShopGroup->shop_id = $this->iShopId;
              $this->_aReturn['insertDirCount']++;
            } else {
              $this->_aReturn['updateDirCount']++;
            }
            is_null($oShopGroup->path) && ($oShopGroup->path = '');
            $oShopGroup->name = strval(
              $aGroupList[$sGroupGUID]->attributes()->Наименование
            );
            $oShopGroup->parent_id =
              $sStackEnd === 0
                ? 0
                : Core_Entity::factory(
                  'Shop',
                  $this->iShopId
                )->Shop_Groups->getByGuid($sStackEnd, false)->id;
            $oShopGroup->save();
            $aStack[count($aStack)] = $sGroupGUID;
          }
        }
      }

      foreach ($this->xpath($catalog, 'Товар') as $oXmlItem) {
        $oShopItem = $oShop->Shop_Items->getByGuid(
          strval($oXmlItem->attributes()->Идентификатор),
          false
        );

        if (is_null($oShopItem)) {
          // Создаем товар
          $oShopItem = Core_Entity::factory('Shop_Item')->guid(
            strval($oXmlItem->attributes()->Идентификатор)
          );

          $oShopItem->shop_id = $this->iShopId;
          $oShopItem->guid = strval($oXmlItem->attributes()->Идентификатор);
          $this->_aReturn['insertItemCount']++;
        } else {
          $this->_aReturn['updateItemCount']++;
        }
        is_null($oShopItem->path) && ($oShopItem->path = '');

        $oShopItem->name = strval($oXmlItem->attributes()->Наименование);

        $oShopItem->marking = strval(
          $oXmlItem->attributes()->ИдентификаторВКаталоге
        );

        $oShopGroup = Core_Entity::factory(
          'Shop',
          $this->iShopId
        )->Shop_Groups->getByGuid(
          strval($oXmlItem->attributes()->Родитель),
          false
        );

        if (is_null($oShopGroup)) {
          $oShopGroup = Core_Entity::factory('Shop_Group', 0);
        }

        $oShopItem->shop_group_id = $oShopGroup->id;

        $oShop_Measure = Core_Entity::factory('Shop_Measure')->getByName(
          strval($oXmlItem->attributes()->Единица),
          false
        );

        !is_null($oShop_Measure) &&
          ($oShopItem->shop_measure_id = $oShop_Measure->id);

        $oShopItem->save();

        foreach (
          $this->xpath($oXmlItem, 'ЗначениеСвойства')
          as $oXmlPropertyValue
        ) {
          $oShop_Item_Property_List = Core_Entity::factory(
            'Shop_Item_Property_List',
            $this->iShopId
          );
          $oProperty = $oShop_Item_Property_List->Properties->getByGuid(
            strval($oXmlPropertyValue->attributes()->ИдентификаторСвойства),
            false
          );

          if (
            !is_null($oProperty) /*&& $oProperty->type != 2*/ &&
            $oProperty->type != 3
          ) {
            $sValue = strval($oXmlPropertyValue->attributes()->Значение);

            if (
              is_null(
                Core_Entity::factory(
                  'Shop',
                  $this->iShopId
                )->Shop_Item_Property_For_Groups->getByShopItemPropertyIdAndGroupId(
                  $oProperty->Shop_Item_Property->id,
                  $oShopItem->shop_group_id
                )
              )
            ) {
              Core_Entity::factory('Shop_Item_Property_For_Group')
                ->shop_group_id($oShopItem->shop_group_id)
                ->shop_item_property_id($oProperty->Shop_Item_Property->id)
                ->shop_id($this->iShopId)
                ->save();
            }

            $aPropertyValues = $oProperty->getValues($oShopItem->id, false);

            // File
            if ($oProperty->type == 2) {
              /*if ($oProperty->multiple)
							{
								$oProperty_Value = $oProperty->createNewValue($oShopItem->id);
							}
							else
							{*/
              $oProperty_Value = isset($aPropertyValues[0])
                ? $aPropertyValues[0]
                : $oProperty->createNewValue($oShopItem->id);
              //}

              // Папка назначения
              $sDestinationFolder = $oShopItem->getItemPath();

              // Файл-источник
              $sSourceFile = Core_File::pathCorrection($sValue);

              $sSourceFileBaseName = basename($sSourceFile, '');

              if (
                Core_File::isValidExtension(
                  $sSourceFile,
                  Core::$mainConfig['availableExtension']
                )
              ) {
                // Создаем папку назначения
                $oShopItem->createDir();

                $sSourceFile =
                  CMS_FOLDER .
                  $this->sPicturesPath .
                  ltrim($sSourceFile, '/\\');

                if (!$oShop->change_filename) {
                  $sTargetFileName = $sSourceFileBaseName;
                } else {
                  $sTargetFileExtension = Core_File::getExtension(
                    $sSourceFileBaseName
                  );
                  $sTargetFileExtension =
                    $sTargetFileExtension == '' ||
                    strlen($sTargetFileExtension) > 5
                      ? '.jpg'
                      : ".{$sTargetFileExtension}";

                  $oProperty_Value->save();
                  $sTargetFileName = "shop_property_file_{$oShopItem->id}_{$oProperty_Value->id}{$sTargetFileExtension}";
                  //$sTargetFileName = "shop_property_file_{$oShopItem->id}_{$oProperty->id}{$sTargetFileExtension}";
                }

                // Создаем массив параметров для загрузки картинок элементу
                $aPicturesParam = [];
                $aPicturesParam['large_image_source'] = $sSourceFile;
                $aPicturesParam['large_image_name'] = $sSourceFileBaseName;
                $aPicturesParam['large_image_target'] =
                  $sDestinationFolder . $sTargetFileName;
                $aPicturesParam[
                  'watermark_file_path'
                ] = $oShop->getWatermarkFilePath();
                $aPicturesParam['watermark_position_x'] =
                  $oShop->watermark_default_position_x;
                $aPicturesParam['watermark_position_y'] =
                  $oShop->watermark_default_position_y;
                $aPicturesParam['large_image_preserve_aspect_ratio'] =
                  $oShop->preserve_aspect_ratio;
                //$aPicturesParam['large_image_max_width'] = $oShop->image_large_max_width;
                $aPicturesParam['large_image_max_width'] =
                  $oProperty->image_large_max_width;
                //$aPicturesParam['large_image_max_height'] = $oShop->image_large_max_height;
                $aPicturesParam['large_image_max_height'] =
                  $oProperty->image_large_max_height;
                $aPicturesParam['large_image_watermark'] =
                  $oShop->watermark_default_use_large_image;

                // Малое изображение не передано
                $aPicturesParam['create_small_image_from_large'] = true;
                $aPicturesParam['small_image_source'] =
                  $aPicturesParam['large_image_source'];
                $aPicturesParam['small_image_name'] =
                  $aPicturesParam['large_image_name'];
                $aPicturesParam['small_image_target'] =
                  $sDestinationFolder . "small_{$sTargetFileName}";

                $sSourceFileSmall = null;

                $aPicturesParam['small_image_max_width'] =
                  $oProperty->image_small_max_width;
                $aPicturesParam['small_image_max_height'] =
                  $oProperty->image_small_max_height;
                $aPicturesParam['small_image_watermark'] =
                  $oShop->watermark_default_use_small_image;
                $aPicturesParam['small_image_preserve_aspect_ratio'] =
                  $aPicturesParam['large_image_preserve_aspect_ratio'];

                // Удаляем старое большое изображение
                if ($oProperty_Value->file != '') {
                  if (
                    $sDestinationFolder . $oProperty_Value->file !=
                    $sSourceFile
                  ) {
                    try {
                      Core_File::delete(
                        $sDestinationFolder . $oProperty_Value->file
                      );
                    } catch (Exception $e) {
                    }
                  }
                }

                // Удаляем старое малое изображение
                if ($oProperty_Value->file_small != '') {
                  if (
                    $sDestinationFolder . $oProperty_Value->file_small !=
                    $sSourceFileSmall
                  ) {
                    try {
                      Core_File::delete(
                        $sDestinationFolder . $oProperty_Value->file_small
                      );
                    } catch (Exception $e) {
                    }
                  }
                }

                try {
                  Core_Event::notify(
                    'Shop_Item_Import_Cml_Controller.oBeforeAdminUpload',
                    $this,
                    [$aPicturesParam]
                  );
                  $aTmpReturn = Core_Event::getLastReturn();
                  is_array($aTmpReturn) && ($aPicturesParam = $aTmpReturn);
                  $aResult = Core_File::adminUpload($aPicturesParam);
                } catch (Exception $e) {
                  Core_Message::show($e->getMessage(), 'error');

                  $aResult = ['large_image' => false, 'small_image' => false];
                }

                if ($aResult['large_image']) {
                  $oProperty_Value->file = $sTargetFileName;
                  $oProperty_Value->file_name = '';
                }

                if ($aResult['small_image']) {
                  $oProperty_Value->file_small = "small_{$sTargetFileName}";
                  $oProperty_Value->file_small_name = '';
                }

                $oProperty_Value->save();
              }
            } else {
              $oProperty_Value = isset($aPropertyValues[0])
                ? $aPropertyValues[0]
                : $oProperty->createNewValue($oShopItem->id);

              $oProperty_Value->setValue($sValue);
              $oProperty_Value->save();
            }
          }
        }
      }

      $offers = $this->_oSimpleXMLElement->ПакетПредложений;
      foreach ($this->xpath($offers, 'Предложение') as $oXmlOffer) {
        $oShopItem = $oShop->Shop_Items->getByGuid(
          strval($oXmlOffer->attributes()->ИдентификаторТовара),
          false
        );

        if (!is_null($oShopItem)) {
          $newPrice = Shop_Controller::instance()->convertPrice(
            strval($oXmlOffer->attributes()->Цена)
          );
          if ($oShopItem->price != $newPrice) {
            $oShop_Price_Setting = $this->getPrices();

            $oShop_Price_Setting_Item = Core_Entity::factory(
              'Shop_Price_Setting_Item'
            );
            $oShop_Price_Setting_Item->shop_price_id = 0;
            $oShop_Price_Setting_Item->shop_item_id = $oShopItem->id;
            $oShop_Price_Setting_Item->old_price = $oShopItem->price;
            $oShop_Price_Setting_Item->new_price = $newPrice;
            $oShop_Price_Setting->add($oShop_Price_Setting_Item);

            // $oShopItem->price = Shop_Controller::instance()->convertPrice(strval($oXmlOffer->attributes()->Цена));
          }

          if (
            !is_null(
              $oShop_Currency = Core_Entity::factory(
                'Shop_Currency'
              )->getByLike(strval($oXmlOffer->attributes()->Валюта), false)
            )
          ) {
            $oShopItem->shop_currency_id = $oShop_Currency->id;
          }

          $oShopItem->save();

          $oWarehouse = Core_Entity::factory(
            'Shop',
            $this->iShopId
          )->Shop_Warehouses->getByDefault(1, false);
          if (!is_null($oWarehouse)) {
            $rest = $oWarehouse->getRest($oShopItem->id);
            $newRest = strval($oXmlOffer->attributes()->Количество);

            if (is_null($rest) || $rest != $newRest) {
              $oShop_Warehouse_Inventory = $this->getInventory($oWarehouse->id);

              $oShop_Warehouse_Inventory_Item = Core_Entity::factory(
                'Shop_Warehouse_Inventory_Item'
              );
              $oShop_Warehouse_Inventory_Item->shop_item_id = $oShopItem->id;
              $oShop_Warehouse_Inventory_Item->count = $newRest;
              $oShop_Warehouse_Inventory->add($oShop_Warehouse_Inventory_Item);

              /*$oShop_Warehouse_Item = $oWarehouse->Shop_Warehouse_Items->getByShopItemId($oShopItem->id, FALSE);
							if (is_null($oShop_Warehouse_Item))
							{
								$oShop_Warehouse_Item = Core_Entity::factory('Shop_Warehouse_Item')
									->shop_warehouse_id($oWarehouse->id)
									->shop_item_id($oShopItem->id);
							}
							$oShop_Warehouse_Item->count(strval($oXmlOffer->attributes()->Количество))->save();*/
            }
          }
        }
      }
    }

    Core_Session::start();
    $_SESSION['importPosition'] = 0;
    $_SESSION['_aShop_Warehouse_Inventory_Ids'] = $_SESSION[
      '_Shop_Price_Setting_Id'
    ] = [];
    Core_Session::close();

    // Пересчет количества товаров в группах
    $oShop->recount();

    // Fast filter
    if ($oShop->filter) {
      $Shop_Filter_Group_Controller = new Shop_Filter_Group_Controller($oShop);
      $Shop_Filter_Group_Controller->rebuild();
    }

    // Post all
    $this->postAll();

    Core_Event::notify('Shop_Item_Import_Cml_Controller.onAfterImport', $this);

    return $this->_aReturn;
  }
}

@ini_set('display_errors', 1);
error_reporting(E_ALL);

// Временная директория
$currentMonth = date('n');
$sTemporaryDirectory = TMP_DIR . '1c_exchange_files/';
$sMonthTemporaryDirectory =
  $sTemporaryDirectory . 'month-' . $currentMonth . '/';
$sCmsFolderTemporaryDirectory = CMS_FOLDER . $sMonthTemporaryDirectory;

// Магазин для выгрузки
$oShop = Core_Entity::factory('Shop')->find(
  Core_Array::get(Core_Page::instance()->libParams, 'shopId')
);

// Размер блока выгружаемых данных (10000000 = 10 мБ). Для "Мой склад" устанавливать (1000000 = 1 мБ)
$iFileLimit = 10000000;

// Логировать обмен
$bDebug = true;

// Время на шаг, секунд
$iTimeout = 25;

// bugfix
usleep(10);

$BOM = "\xEF\xBB\xBF";

// Решение проблемы авторизации при PHP в режиме CGI
if (
  isset($_REQUEST['authorization']) ||
  (isset($_SERVER['argv'][0]) &&
    empty($_SERVER['PHP_AUTH_USER']) &&
    empty($_SERVER['PHP_AUTH_PW']))
) {
  $authorization_base64 = isset($_REQUEST['authorization'])
    ? $_REQUEST['authorization']
    : mb_substr($_SERVER['argv'][0], 14);

  $authorization = base64_decode(mb_substr($authorization_base64, 6));
  $authorization_explode = explode(':', $authorization);

  if (count($authorization_explode) == 2) {
    list(
      $_SERVER['PHP_AUTH_USER'],
      $_SERVER['PHP_AUTH_PW'],
    ) = $authorization_explode;
  }

  unset($authorization);
}

if (!isset($_SERVER['PHP_AUTH_USER'])) {
  header('WWW-Authenticate: Basic realm="HostCMS"');
  header('HTTP/1.0 401 Unauthorized');
  exit();
} elseif (isset($_SERVER['PHP_AUTH_USER']) && isset($_SERVER['PHP_AUTH_PW'])) {
  Core_Auth::setRegenerateId(false);
  $answr = Core_Auth::login($_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW']);

  Core_Auth::setCurrentSite();

  if (!Core_Auth::logged()) {
    Core_Log::instance()
      ->clear()
      ->status(Core_Log::$ERROR)
      //->notify(FALSE)
      ->write(Core::_('Core.error_log_authorization_error'));
  }

  $oUser = Core_Entity::factory('User')->getByLogin($_SERVER['PHP_AUTH_USER']);

  if ($answr !== true || (!is_null($oUser) && $oUser->read_only)) {
    $bDebug &&
      Core_Log::instance()
        ->clear()
        ->status(Core_Log::$MESSAGE)
        ->write('1С, ошибка авторизации');

    // авторизация не пройдена
    exit('Authentication failed!');
  }
} else {
  exit();
}

$sType = Core_Array::getGet('type', '', 'str');
$sMode = Core_Array::getGet('mode', '', 'str');

if (($sType == 'catalog' || $sType == 'sale') && $sMode == 'checkauth') {
  clearstatcache();

  if ($sType == 'catalog') {
    $bDebug &&
      Core_Log::instance()
        ->clear()
        ->status(Core_Log::$MESSAGE)
        ->write('1С, удаление директорий предыдущих месяцев');

    // Удаление директорий обмена за предыдущие месяцы
    for ($i = 1; $i <= 12; $i++) {
      if ($currentMonth != $i) {
        $sTmpDir = CMS_FOLDER . $sTemporaryDirectory . 'month-' . $i;

        // Удаляем файлы предыдущего месяца
        if (is_dir($sTmpDir) && Core_File::deleteDir($sTmpDir) === false) {
          echo "{$BOM}failure\nCan't delete temporary folder {$sTmpDir}";
          die();
        }
      }
    }

    // Удаление XML файлов
    if (is_dir($sCmsFolderTemporaryDirectory)) {
      try {
        clearstatcache();

        if ($dh = @opendir($sCmsFolderTemporaryDirectory)) {
          while (($file = readdir($dh)) !== false) {
            if ($file != '.' && $file != '..') {
              $pathName = $sCmsFolderTemporaryDirectory . $file;

              if (
                Core_File::getExtension($pathName) == 'xml' &&
                is_file($pathName)
              ) {
                $bDebug &&
                  Core_Log::instance()
                    ->clear()
                    ->status(Core_Log::$MESSAGE)
                    ->write(
                      '1С, удаление XML-файла предыдущего обмена ' . $pathName
                    );

                Core_File::delete($pathName);
              }
            }
          }

          closedir($dh);
          clearstatcache();
        }
      } catch (Exception $exc) {
        echo sprintf("{$BOM}failure\n%s", $exc /*->getMessage()*/);
      }
    }
  }

  Core_Session::start();
  Core_Session::regenerateId(true);
  echo sprintf("{$BOM}success\n%s\n%s", session_name(), session_id());
} elseif (($sType == 'catalog' || $sType == 'sale') && $sMode == 'init') {
  $bDebug &&
    Core_Log::instance()
      ->clear()
      ->status(Core_Log::$MESSAGE)
      ->write('1С, mode=init');

  echo sprintf("{$BOM}zip=no\nfile_limit=%s", $iFileLimit);
} elseif (
  $sType == 'catalog' &&
  $sMode == 'file' &&
  ($sFileName = Core_Array::get($_SERVER, 'REQUEST_URI')) != ''
) {
  parse_str($sFileName, $_myGet);
  $sFileName = $_myGet['filename'];

  $sFullFileName = $sCmsFolderTemporaryDirectory . $sFileName;
  Core_File::mkdir(dirname($sFullFileName), CHMOD, true);

  clearstatcache();

  if (is_file($sFullFileName)) {
    $filesize = filesize($sFullFileName);
    $blocks = $filesize / $iFileLimit;
    $blocksDelta = ceil($blocks) - $blocks;

    // Накопленная разница между размером файла и размерами блока больше, чем 10% или прошло 5 минут с даты последнего изменения
    if ($blocksDelta > 0.1 || filemtime($sFullFileName) + 60 * 5 < time()) {
      $bDebug &&
        Core_Log::instance()
          ->clear()
          ->status(Core_Log::$MESSAGE)
          ->write(
            '1С, DELETE previous file, type=catalog, mode=file, destination=' .
              $sFullFileName .
              ', filesize: ' .
              $filesize .
              ', fileLimit: ' .
              $iFileLimit .
              ', blocksDelta: ' .
              sprintf('%.3f', $blocksDelta) .
              ', time: ' .
              filemtime($sFullFileName) .
              ', current: ' .
              time()
          );

      Core_File::delete($sFullFileName);
    }
  }

  $content = file_get_contents('php://input');

  if (
    file_put_contents($sFullFileName, $content, FILE_APPEND) !== false &&
    @chmod($sFullFileName, CHMOD_FILE)
  ) {
    echo "{$BOM}success";
  } else {
    echo "{$BOM}failure\nCan't save incoming data to file: {$sFullFileName}";
  }

  clearstatcache();

  $bDebug &&
    Core_Log::instance()
      ->clear()
      ->status(Core_Log::$MESSAGE)
      ->write(
        '1С, type=catalog, mode=file, destination=' .
          $sFullFileName .
          ', contentSize=' .
          strlen($content) .
          ', fileSize=' .
          filesize($sFullFileName)
      );
} elseif (
  $sType == 'catalog' &&
  $sMode == 'import' &&
  !is_null($sFileName = Core_Array::getGet('filename'))
) {
  $bDebug &&
    Core_Log::instance()
      ->clear()
      ->status(Core_Log::$MESSAGE)
      ->write(
        '1С, type=catalog, mode=import, file=' .
          $sFileName .
          ', session_id=' .
          session_id()
      );

  try {
    $sFullPath =
      $sCmsFolderTemporaryDirectory . Core_File::filenameCorrection($sFileName);

    // $oShop_Item_Import_Cml_Controller = new Shop_Item_Import_Cml_Controller(
    //   $sFullPath
    // );
    $oShop_Item_Import_Cml_Controller = new My_Shop_Item_Import_Cml_Controller(
      $sFullPath
    );

    $oShop_Item_Import_Cml_Controller->iShopId = $oShop->id;
    $oShop_Item_Import_Cml_Controller->itemDescription = 'text';
    $oShop_Item_Import_Cml_Controller->iShopGroupId = 0;
    $oShop_Item_Import_Cml_Controller->sPicturesPath = $sMonthTemporaryDirectory;
    $oShop_Item_Import_Cml_Controller->importAction = 1;
    $oShop_Item_Import_Cml_Controller->sShopDefaultPriceName = defined(
      'DEFAULT_CML_PRICE_NAME'
    )
      ? DEFAULT_CML_PRICE_NAME
      : 'Розничная';

    // GUID основной цены
    $oShop_Item_Import_Cml_Controller->sShopDefaultPriceGUID =
      'ff52c963-dde4-11ed-b291-00505601248f';
    //$oShop_Item_Import_Cml_Controller->updateFields = array('marking', 'name', 'shop_group_id', 'text', 'description', 'images', 'taxes', 'shop_producer_id');
    //$oShop_Item_Import_Cml_Controller->skipProperties = array('Свойство1');
    $oShop_Item_Import_Cml_Controller->debug = $bDebug;
    $oShop_Item_Import_Cml_Controller->timeout = $iTimeout;
    // Событийная индексация
    //$oShop_Item_Import_Cml_Controller->searchIndexation = TRUE;

    //importGroups & createShopItems
    $oShop_Item_Import_Cml_Controller
      ->importGroups(false)
      ->createShopItems(false);

    $oShop_Item_Import_Cml_Controller->skipProperties = [
      'ВидНоменклатуры',
      'ТипНоменклатуры',
      'Полное наименование',
      'Ширина',
      'Высота',
      'Название на английском',
      'Штрихкод WB',
      'Срок поставки',
    ];

    //массив полей товара, которые необходимо обновлять при импорте CML товара
    $oShop_Item_Import_Cml_Controller->updateFields([
      //'marking',
      'guid',
      'prices',
      'warehouses',
    ]);

    $oShop_Item_Import_Cml_Controller->itemSearchFields([
      //'cml_id',
      'marking',
      //'barcode',
    ]);

    $aReturn = $oShop_Item_Import_Cml_Controller->import();

    $bDebug &&
      Core_Log::instance()
        ->clear()
        ->status(Core_Log::$MESSAGE)
        ->write(
          '1С, status: ' .
            $aReturn['status'] .
            ', timeout: ' .
            $oShop_Item_Import_Cml_Controller->timeout .
            ', type=catalog, mode=import, file=' .
            $sFileName .
            ', size=' .
            Core_File::filesize($sFullPath)
        );

    if ($aReturn['status'] == 'success') {
      $bDebug &&
        Core_Log::instance()
          ->clear()
          ->status(Core_Log::$MESSAGE)
          ->write('1С, Delete file: ' . $sFileName);

      // Перед удалением делаем копию файла для отладки
      //Core_File::copy($sFullPath, $sFullPath . time());

      Core_File::delete($sFullPath);
    }

    echo $BOM . $aReturn['status'];
  } catch (Exception $exc) {
    echo sprintf("{$BOM}failure\n%s", $exc /*->getMessage()*/);
  }
} elseif ($sType == 'sale' && $sMode == 'query') {
  $bDebug &&
    Core_Log::instance()
      ->clear()
      ->status(Core_Log::$MESSAGE)
      ->write('1С, type=sale, mode=query');

  $oXml = new Core_SimpleXMLElement(
    sprintf(
      "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<КоммерческаяИнформация ВерсияСхемы=\"2.08\" ДатаФормирования=\"%s\"></КоммерческаяИнформация>",
      date('Y-m-d')
    )
  );

  if ($oShop->shop_company_id && method_exists($oShop->Company, 'addCml')) {
    $oShop->Company->addCml($oXml);
  }

  // Get Max Order Id
  $oCore_QueryBuilder_Select = Core_QueryBuilder::select(['MAX(id)', 'max_id']);
  $oCore_QueryBuilder_Select
    ->from('shop_orders')
    ->where('shop_orders.shop_id', '=', $oShop->id)
    ->where('shop_orders.unloaded', '=', 0)
    ->where('shop_orders.deleted', '=', 0);

  $aRow = $oCore_QueryBuilder_Select
    ->execute()
    ->asAssoc()
    ->current();

  $maxId = $aRow['max_id'];

  $iFrom = 0;
  $onStep = 500;
  $iCounter = 0;

  do {
    $oShop_Orders = $oShop->Shop_Orders;
    $oShop_Orders
      ->queryBuilder()
      ->where('shop_orders.id', 'BETWEEN', [$iFrom + 1, $iFrom + $onStep]);

    $aShop_Orders = $oShop_Orders->getAllByUnloaded(0);

    foreach ($aShop_Orders as $oShop_Order) {
      $oShop_Order->addCml($oXml);
      $oShop_Order->unloaded = 1;
      $oShop_Order->save();
    }

    $iCounter += count($aShop_Orders);

    $iFrom += $onStep;
  } while ($iFrom < $maxId);

  $bDebug &&
    Core_Log::instance()
      ->clear()
      ->status(Core_Log::$MESSAGE)
      ->write(
        '1С, type=sale, mode=query. Completed, found ' . $iCounter . ' orders'
      );

  header('Content-type: text/xml; charset=UTF-8');
  echo $BOM;
  echo $oXml->asXML();

  /*$dom = dom_import_simplexml($oXml)->ownerDocument;
	$dom->formatOutput = TRUE;
	echo $dom->saveXML(NULL, LIBXML_NOEMPTYTAG);*/
} elseif ($sType == 'sale' && $sMode == 'success') {
  $bDebug &&
    Core_Log::instance()
      ->clear()
      ->status(Core_Log::$MESSAGE)
      ->write('1С, type=sale, mode=success');

  /*$aShopOrders = $oShop->Shop_Orders->getAllByUnloaded(0);

	foreach($aShopOrders as $oShopOrder)
	{
		$oShopOrder->unloaded = 1;
		$oShopOrder->save();
	}*/

  echo "{$BOM}success\n";
} elseif (
  $sType == 'sale' &&
  $sMode == 'file' &&
  ($sFileName = Core_Array::get($_SERVER, 'REQUEST_URI')) != ''
) {
  parse_str($sFileName, $_myGet);
  $sFileName = $_myGet['filename'];

  $sFullFileName =
    $sCmsFolderTemporaryDirectory . Core_File::filenameCorrection($sFileName);
  Core_File::mkdir(dirname($sFullFileName), CHMOD, true);

  $bDebug &&
    Core_Log::instance()
      ->clear()
      ->status(Core_Log::$MESSAGE)
      ->write('1С, type=sale, mode=file, destination=' . $sFullFileName);

  if (
    file_put_contents(
      $sFullFileName,
      file_get_contents('php://input'),
      FILE_APPEND
    ) !== false &&
    @chmod($sFullFileName, CHMOD_FILE)
  ) {
    echo "{$BOM}success";
  } else {
    echo "{$BOM}failure\nCan't save incoming data to file: {$sFullFileName}";
  }
} elseif (
  $sType == 'sale' &&
  $sMode == 'import' &&
  !is_null($sFileName = Core_Array::getGet('filename'))
) {
  $bDebug &&
    Core_Log::instance()
      ->clear()
      ->status(Core_Log::$MESSAGE)
      ->write('1С, type=sale, mode=import, file=' . $sFileName);

  $sFullFileName =
    $sCmsFolderTemporaryDirectory . Core_File::filenameCorrection($sFileName);

  try {
    $oShop_Item_Import_Cml_Controller = new Shop_Item_Import_Cml_Controller(
      $sFullFileName
    );
    $oShop_Item_Import_Cml_Controller->iShopId = $oShop->id;
    $oShop_Item_Import_Cml_Controller->debug = $bDebug;
    //$oShop_Item_Import_Cml_Controller->itemDescription = 'text';
    $oShop_Item_Import_Cml_Controller->importOrders();

    is_file($sFullFileName) && Core_File::delete($sFullFileName);

    echo "{$BOM}success";
  } catch (Exception $exc) {
    echo sprintf("{$BOM}failure\n%s", $exc /*->getMessage()*/);
  }
}

die();
