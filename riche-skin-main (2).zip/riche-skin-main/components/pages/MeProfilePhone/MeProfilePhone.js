import { Alert, Button, Lnk } from '@/components/ui';
import styles from '@/styles/pages/MeProfilePage.module.css';
import { getData } from '@/utils/fetcher';
import { Listbox, Transition } from '@headlessui/react';
import {
	CheckBadgeIcon,
	CheckIcon,
	ChevronUpDownIcon,
} from '@heroicons/react/24/outline';
import { signOut } from 'next-auth/react';
import { Fragment, useState } from 'react';
import { useForm } from 'react-hook-form';

const MeProfilePhone = ({ profile }) => {
	//console.log(orders.items);

	const [answerUpdate, setAnswerUpdate] = useState(null);
	const [alertShow, setAlertShow] = useState(false);

	const startStatus = profile.statuses_tawk.find(
		(el) => el.id == profile.profile.status_tawk,
	);
	const [listStatuses, setListStatuses] = useState(profile.statuses_tawk);
	const [selectedStatus, setSelectedStatus] = useState(startStatus);

	const {
		register,
		handleSubmit,
		formState: { errors, isDirty, isValid },
	} = useForm({
		mode: 'all',
	});

	const onSubmitUpdate = async (data) => {
		setAnswerUpdate('');
		setAlertShow(false);

		const oData = {
			token: profile.profile.token,
			phone: profile.profile.phone,
			name: data.name,
			surname: data.surname,
			email: data.email,
			status_tawk: selectedStatus.id,
		};
		//alert(JSON.stringify(oData));

		const result = await getData(`/me/update/`, 'POST', oData);

		if (result.profile) {
			setAnswerUpdate(`Данные обновлены`);
			setAlertShow(true);
		}
	};

	return (
		<>
			<div className="flex-1 order-2 max-w-2xl">
				{/* <div>{JSON.stringify(profile)}</div> */}
				<h1 className="text-2xl lg:text-3xl">Мои данные</h1>

				{alertShow && (
					<Alert variant="success" active close>
						{answerUpdate}
					</Alert>
				)}

				<div className="pb-3">
					<label
						className="text-gray-500 pb-1 px-2 block text-sm"
						htmlFor="phone"
					>
						Телефон
					</label>
					<div className="relative">
						<input
							className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14"
							type="text"
							id="phone"
							name="phone"
							placeholder="+7XXXXXXXXXX"
							value={profile.profile.phone}
							disabled
						/>
						<div className="absolute right-3 top-4">
							<CheckBadgeIcon className="w-6 h-6 text-green-600" />
						</div>
					</div>
				</div>

				<div className="pt-6">
					<form
						onSubmit={handleSubmit(onSubmitUpdate)}
						className="flex flex-col gap-y-6"
					>
						<div className={styles.inputlist}>
							<div>
								<label
									className="text-gray-500 pb-1 px-2 block text-sm"
									htmlFor="surname"
								>
									Фамилия
								</label>
								<input
									className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14"
									type="text"
									id="surname"
									name="surname"
									placeholder="Фамилия"
									defaultValue={profile.profile.surname}
									{...register('surname', {
										required: true,
									})}
								/>
								{errors.surname?.type === 'required' && (
									<div
										className="text-xs pt-1.5 px-2 text-red-600"
										role="alert"
									>
										Фамилия обязателена
									</div>
								)}
							</div>
							<div>
								<label
									className="text-gray-500 pb-1 px-2 block text-sm"
									htmlFor="name"
								>
									Имя
								</label>
								<input
									className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14"
									type="text"
									id="name"
									name="name"
									placeholder="Имя"
									defaultValue={profile.profile.name}
									{...register('name', {
										required: true,
									})}
								/>
								{errors.name?.type === 'required' && (
									<div
										className="text-xs pt-1.5 px-2 text-red-600"
										role="alert"
									>
										Имя обязателено
									</div>
								)}
							</div>

							<div>
								<label
									className="text-gray-500 pb-1 px-2 block text-sm"
									htmlFor="status"
								>
									Статус общения
								</label>
								<Listbox value={selectedStatus} onChange={setSelectedStatus}>
									<div className="relative mt-1">
										<Listbox.Button className="relative w-full cursor-pointer rounded-xl bg-white px-2 pl-4 pr-10 text-left text-sm border h-14 grow">
											<span className="block truncate">
												{selectedStatus.name}
											</span>
											<span className="absolute inset-y-0 right-0 flex items-center justify-end w-12 pr-2 text-gray-400 hover:text-black transition-colors">
												<ChevronUpDownIcon className="w-6 h-6" />
											</span>
										</Listbox.Button>
									</div>
									<Transition
										as={Fragment}
										leave="transition ease-in duration-100"
										leaveFrom="opacity-100"
										leaveTo="opacity-0"
									>
										<Listbox.Options className="relative m-0 p-0">
											<div className="absolute mt-1 max-h-60 overflow-auto rounded-xl bg-white py-2 border shadow-lg z-50 w-full flex flex-col gap-0.5 text-sm">
												{listStatuses.map((el, i) => {
													return (
														<Listbox.Option
															key={i}
															className={({ active }) =>
																`relative cursor-default select-none py-2 pl-8 pr-4 ${
																	active
																		? 'bg-gray-100 text-black'
																		: 'text-gray-900'
																}`
															}
															value={el}
														>
															{({ selected }) => (
																<>
																	<span
																		className={`block truncate pl-0 ${
																			selected ? 'font-bold' : 'font-normal'
																		}`}
																	>
																		{el.name}
																	</span>
																	{selected ? (
																		<span className="absolute inset-y-0 left-0 flex items-center pl-3 text-black">
																			<CheckIcon
																				className="h-4 w-4"
																				aria-hidden="true"
																			/>
																		</span>
																	) : null}
																</>
															)}
														</Listbox.Option>
													);
												})}
											</div>
										</Listbox.Options>
									</Transition>
								</Listbox>
							</div>
							<div>
								<label
									className="text-gray-500 pb-1 px-2 block"
									htmlFor="email"
								>
									Email
								</label>
								<input
									className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14"
									type="email"
									id="email"
									name="email"
									placeholder="ваша@эл.почта"
									defaultValue={profile.profile.email}
									{...register('email', {
										required: true,
										pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
									})}
								/>
								{errors.email?.type === 'required' && (
									<div
										className="text-xs pt-1.5 px-2 text-red-600"
										role="alert"
									>
										Email обязателен
									</div>
								)}
								{errors.email?.type === 'pattern' && (
									<div
										className="text-xs pt-1.5 px-2 text-red-600"
										role="alert"
									>
										Не похоже на Email
									</div>
								)}
							</div>
						</div>

						<div className="text-sm">
							Нажимая на кнопку Сохранить, я принимаю условия{' '}
							<Lnk
								href="/info/politika-v-otnoshenii-personalnyx-dannyx-3"
								title="Политика в отношении персональных данных"
								className="underline"
								target="_blank"
							>
								политики обработки персональных данных
							</Lnk>{' '}
							и условия{' '}
							<Lnk
								href="/info/publichnaya-oferta-2"
								title="Публичная оферта"
								className="underline"
								target="_blank"
							>
								публичной оферты
							</Lnk>
						</div>

						<div className="pt-3">
							<Button
								variant="black"
								size="normal"
								className="w-full h-14"
								type="submit"
								disabled={!isDirty && !isValid}
							>
								Сохранить
							</Button>
						</div>

						<div className="pt-12">
							<Button
								variant="transparentgray"
								size="normal"
								className="w-full h-14"
								type="button"
								onClick={(e) => {
									e.preventDefault();
									signOut({ callbackUrl: `/`, redirect: true });
								}}
							>
								Выйти из кабинета
							</Button>
						</div>
					</form>
				</div>
			</div>
		</>
	);
};

export default MeProfilePhone;
