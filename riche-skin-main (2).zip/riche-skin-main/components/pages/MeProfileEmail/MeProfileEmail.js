import { Alert, Button, Lnk } from '@/components/ui';
import styles from '@/styles/pages/MeProfilePage.module.css';
import { getData } from '@/utils/fetcher';
import { validatePassword } from '@/utils/prepare';
import { EyeIcon, EyeSlashIcon } from '@heroicons/react/24/outline';
import { useSession } from 'next-auth/react';
import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';

const MeProfileEmail = ({ profile }) => {
	//console.log(orders.items);

	const { data: session } = useSession();
	const [answerUpdate, setAnswerUpdate] = useState(null);
	const [alertShow, setAlertShow] = useState(false);

	const [showPass, setShowPass] = useState(false);
	const [passVal, setPassVal] = useState('');
	const [passValid, setPassValid] = useState(false);

	useEffect(() => {
		const vl = validatePassword(passVal);
		setPassValid(vl);
	}, [passVal]);

	const {
		register,
		handleSubmit,
		formState: { errors, isDirty, isValid },
	} = useForm({
		mode: 'all',
	});

	const onSubmitPassword = async (data) => {
		setAnswerUpdate('');
		setAlertShow(false);

		// alert(
		//   JSON.stringify({
		//     token: session.token,
		//     password: passVal,
		//   })
		// );

		const result = await getData(`/me/password/`, 'POST', {
			token: session.token,
			password: passVal,
		});

		//alert(JSON.stringify(result));

		if (result.profile) {
			setAnswerUpdate(`Пароль обновлен`);
			setAlertShow(true);
		}
	};

	const onSubmitUpdate = async (data) => {
		setAnswerUpdate('');
		setAlertShow(false);

		// alert(
		//   JSON.stringify({
		//     token: session.token,
		//     phone: data.phone,
		//     name: data.name,
		//     surname: data.surname,
		//   })
		// );

		const result = await getData(`/me/update/`, 'POST', {
			token: session.token,
			phone: data.phone,
			name: data.name,
			surname: data.surname,
		});

		if (result.profile) {
			setAnswerUpdate(`Данные обновлены`);
			setAlertShow(true);
		}
	};

	const eye = !showPass ? (
		<EyeIcon className="w-6 h-6" />
	) : (
		<EyeSlashIcon className="w-6 h-6" />
	);

	return (
		<>
			<div className="flex-1 order-2 max-w-2xl">
				<h1>Мои данные</h1>

				{alertShow && (
					<Alert variant="success" active close>
						{answerUpdate}
					</Alert>
				)}

				<div className="pb-3">
					<label
						className="text-gray-500 pb-1 px-2 block text-sm"
						htmlFor="email"
					>
						Email
					</label>
					<input
						className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14"
						type="email"
						id="email"
						name="email"
						disabled
						placeholder="ваша@эл.почта"
						value={profile.profile.email}
					/>
				</div>

				<div className="pb-12">
					<label
						className="text-gray-500 pb-1 px-2 block text-sm"
						htmlFor="email"
					>
						Пароль
					</label>
					<div className="flex flex-col gap-3 lg:flex-row">
						<div className="relative grow">
							<input
								className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14 pr-12"
								type={showPass ? 'text' : 'password'}
								id="password"
								name="password"
								placeholder="Пароль"
								value={passVal}
								onChange={(e) => setPassVal(e.target.value)}
							/>
							{!passValid && (
								<div className="text-xs pt-1.5 px-2 text-red-600" role="alert">
									Пароль должен содержать 1&nbsp;строчную, 1&nbsp;заглавную
									букву, цифру и&nbsp;спецсимвол (#@$!%?&amp;+\-_), длина более
									6&nbsp;символов
								</div>
							)}
							<div className="absolute top-3 right-3 lg:shrink">
								<Button
									variant="action"
									aria-label={showPass ? 'Скрыть пароль' : 'Показать пароль'}
									title={showPass ? 'Скрыть пароль' : 'Показать пароль'}
									onClick={() => {
										setShowPass(!showPass);
									}}
								>
									{eye}
								</Button>
							</div>
						</div>

						<div>
							<Button
								variant="black"
								size="normal"
								className="w-full h-14"
								disabled={!passValid}
								onClick={onSubmitPassword}
							>
								Изменить пароль
							</Button>
						</div>
					</div>
				</div>

				<div>
					<form
						onSubmit={handleSubmit(onSubmitUpdate)}
						className="flex flex-col gap-y-6"
					>
						<div>
							<label
								className="text-gray-500 pb-1 px-2 block text-sm "
								htmlFor="phone"
							>
								Телефон
							</label>
							<input
								className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14"
								type="text"
								id="phone"
								name="phone"
								placeholder="+7XXXXXXXXXX"
								defaultValue={profile.profile.phone}
								{...register('phone', {
									required: true,
									pattern:
										/(^\+7)((\d{10})|(\s\(\d{3}\)\s\d{3}\s\d{2}\s\d{2}))/i,
								})}
							/>
							{errors.phone?.type === 'required' && (
								<div className="text-xs pt-1.5 px-2 text-red-600" role="alert">
									Телефон обязателен
								</div>
							)}
							{errors.phone?.type === 'pattern' && (
								<div className="text-xs pt-1.5 px-2 text-red-600" role="alert">
									Не похоже на телефон
								</div>
							)}
						</div>
						<div className={styles.inputlist}>
							<div>
								<label
									className="text-gray-500 pb-1 px-2 block text-sm"
									htmlFor="surname"
								>
									Фамилия
								</label>
								<input
									className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14"
									type="text"
									id="surname"
									name="surname"
									placeholder="Фамилия"
									defaultValue={profile.profile.surname}
									{...register('surname', {
										required: true,
									})}
								/>
								{errors.surname?.type === 'required' && (
									<div
										className="text-xs pt-1.5 px-2 text-red-600"
										role="alert"
									>
										Фамилия обязателена
									</div>
								)}
							</div>
							<div>
								<label
									className="text-gray-500 pb-1 px-2 block text-sm"
									htmlFor="name"
								>
									Имя
								</label>
								<input
									className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14"
									type="text"
									id="name"
									name="name"
									placeholder="Имя"
									defaultValue={profile.profile.name}
									{...register('name', {
										required: true,
									})}
								/>
								{errors.name?.type === 'required' && (
									<div
										className="text-xs pt-1.5 px-2 text-red-600"
										role="alert"
									>
										Имя обязателено
									</div>
								)}
							</div>
						</div>

						<div className="text-sm">
							Нажимая на кнопку Сохранить, я принимаю условия{' '}
							<Lnk
								href="/info/politika-v-otnoshenii-personalnyx-dannyx-3"
								title="Политика в отношении персональных данных"
								className="underline"
								target="_blank"
							>
								политики обработки персональных данных
							</Lnk>{' '}
							и условия{' '}
							<Lnk
								href="/info/publichnaya-oferta-2"
								title="Публичная оферта"
								className="underline"
								target="_blank"
							>
								публичной оферты
							</Lnk>
						</div>

						<div className="pt-3">
							<Button
								variant="black"
								size="normal"
								className="w-full h-14"
								type="submit"
								disabled={!isDirty && !isValid}
							>
								Сохранить
							</Button>
						</div>
					</form>
				</div>
			</div>
		</>
	);
};

export default MeProfileEmail;
