export { default as IconTg } from './IconTg';
export { default as IconVk } from './IconVk';
export { default as IconYt } from './IconYt';
