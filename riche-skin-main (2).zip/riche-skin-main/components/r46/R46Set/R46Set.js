import useR46Set from '../useR46Set';

const R46Set = ({ className, ...props }) => {
  const { r46Active } = useR46Set();

  return null;
};

export default R46Set;
