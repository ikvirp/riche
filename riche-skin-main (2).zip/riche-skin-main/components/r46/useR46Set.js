import { getData } from '@/utils/fetcher';
import { useSession } from 'next-auth/react';
import { useEffect } from 'react';

const R46Proc = process.env.NEXT_PUBLIC_R46;

const useR46Set = () => {
	const { data: session } = useSession();

	const r46Active =
		typeof R46Proc !== 'undefined' && R46Proc != 0 ? true : false;

	useEffect(() => {
		setUser();
	}, [session]);

	const setUser = () => {
		if (r46Active && session) {
			const fetchData = async () => {
				const data = await getData(`/r46/profile/?token=${session.token}`);
				if (data) {
					r46('profile', 'set', {
						id: data.profile.id,
						email: data.profile.email,
						bought_something: data.profile.bought_something,
					});
				}
			};
			fetchData();
		}
	};

	return {
		r46Active,
		setUser,
	};
};

export default useR46Set;
