const R46Proc = process.env.NEXT_PUBLIC_R46;

const R46Init = () => {
  const r46Active =
    typeof R46Proc !== 'undefined' && R46Proc != 0 ? true : false;

  if (r46Active) {
    const scriptInjectorHTML = `
   (function(r){window.r46=window.r46||function(){(r46.q=r46.q||[]).push(arguments)};var s=document.getElementsByTagName(r)[0],rs=document.createElement(r);rs.async=1;rs.src='//cdn.rees46.ru/v3.js';s.parentNode.insertBefore(rs,s);})('script');
  `;
    return (
      <script
        dangerouslySetInnerHTML={{
          __html: `
            ${scriptInjectorHTML}
            window.r46('init', '${R46Proc}');
      `,
        }}
      />
    );
  }

  return null;
};

export default R46Init;
