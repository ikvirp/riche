
const R46Proc = process.env.NEXT_PUBLIC_R46;

const useR46Subscription = () => {
  const r46Active =
    typeof R46Proc !== 'undefined' && R46Proc != 0 ? true : false;

  // https://reference.api.rees46.com/?javascript#subscriptions
  const manageSubscription = (obj) => {
    if (r46Active && obj) {
      r46('subscription', 'manage', obj);
    }
  };

  return {
    r46Active,
    manageSubscription,
  };
};

export default useR46Subscription;
