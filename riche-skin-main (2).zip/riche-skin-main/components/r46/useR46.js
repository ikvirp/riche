import { getData } from '@/utils/fetcher';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';

const R46Proc = process.env.NEXT_PUBLIC_R46;

const useR46 = () => {
	const r46Active =
		typeof R46Proc !== 'undefined' && R46Proc != 0 ? true : false;

	const router = useRouter();

	useEffect(() => {
		fetchData();
	}, [router]);

	const [itemsFromReccommedations, setItemsFromReccommedations] = useState([]);

	const [status, setStatus] = useState({
		r46Active: r46Active,
		loading: true,
		title: null,
		items: null,
		error: null,
	});

	const fetchData = async () => {
		//setLoading(true);
		const oStatus = status;

		if (itemsFromReccommedations.length > 0) {
			const data = await getData(
				`/r46/recommend/?items=${itemsFromReccommedations.join(',')}`,
			);
			if (data) {
				oStatus.items = data.items;
				oStatus.error = null;
			} else {
				//oStatus.error = 'No items for reccomedation';
			}
			oStatus.loading = false;
			setStatus({ ...oStatus });
		} else {
			//oStatus.error = 'No items for reccomedation';
		}
		setStatus({ ...oStatus });
	};

	useEffect(() => {
		const oStatus = status;

		if (r46Active) {
			fetchData();
		}
	}, [itemsFromReccommedations]);

	// https://reference.api.rees46.com/?javascript#product-recommendations
	const getReccomendations = (id, title = null, obj = null) => {
		const oStatus = status;
		if (r46Active && id) {
			const oObjR46 = obj ? obj : {};
			r46(
				'recommend',
				id,
				oObjR46,
				function (response) {
					// the functionality of rendering a block of product recommendations

					if (typeof response.recommends != 'undefined') {
						setItemsFromReccommedations(response.recommends);
					} else {
						oStatus.error = response.message;
						oStatus.loading = false;
					}

					//setStatus({ ...oStatus, title: title });
				},
				function (error) {
					// when something went wrong
					let message = error.code;
					if (error.code == 404) {
						message = `Recommender "${id}" not found`;
					}
					oStatus.error = messagee;
					oStatus.loading = false;
					setStatus({ ...oStatus });
				},
			);
		}
	};

	return { ...status, getReccomendations };
};

export default useR46;
