const R46Proc = process.env.NEXT_PUBLIC_R46;

const useR46Track = () => {
	const r46Active =
		typeof R46Proc !== 'undefined' && R46Proc != 0 ? true : false;

	// https://reference.api.rees46.com/?javascript#user-viewed-a-product
	const trackProduct = (obj) => {
		if (r46Active && obj) {
			r46('track', 'view', obj);
		}
	};

	// https://reference.api.rees46.com/?javascript#user-viewed-a-category
	const trackCategory = (id) => {
		if (r46Active && id >= 0) {
			r46('track', 'category', id);
		}
	};

	// https://reference.api.rees46.com/?javascript#user-searched-something
	const trackSearch = (query) => {
		if (r46Active && query && query.length > 0) {
			r46('track', 'search', query);
		}
	};

	// https://reference.api.rees46.com/?javascript#user-added-product-to-cart
	const trackCartAdd = (obj) => {
		if (r46Active && obj) {
			r46('track', 'cart', obj);
		}
	};

	// https://reference.api.rees46.com/?javascript#user-removed-product-from-cart
	const trackCartRemove = (id) => {
		if (r46Active && id) {
			r46('track', 'remove_from_cart', id);
		}
	};

	// https://reference.api.rees46.com/?javascript#user-purchased-products
	const trackPurchase = (obj) => {
		if (r46Active && obj) {
			r46('track', 'purchase', obj);
		}
	};

	// https://reference.api.rees46.com/?javascript#user-added-product-to-favorites
	const trackFavAdd = (id) => {
		if (r46Active && id) {
			r46('track', 'wish', id);
		}
	};

	// https://reference.api.rees46.com/?javascript#user-removed-product-from-favorites
	const trackFavRemove = (id) => {
		if (r46Active && id) {
			r46('track', 'remove_wish', id);
		}
	};

	// https://reference.api.rees46.com/?javascript#user-removed-product-from-favorites
	const trackCustom = (name, obj) => {
		if (r46Active && query && query.length > 0 && obj) {
			r46('track', name, obj);
		}
	};

	return {
		r46Active,
		trackProduct,
		trackCategory,
		trackSearch,
		trackCartAdd,
		trackCartRemove,
		trackPurchase,
		trackFavAdd,
		trackFavRemove,
		trackCustom,
	};
};

export default useR46Track;
