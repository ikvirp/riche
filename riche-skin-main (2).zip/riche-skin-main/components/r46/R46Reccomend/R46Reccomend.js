import { ProductCard, ProductCardSame } from '@/components/ui';
import cn from 'classnames';
import { useEffect } from 'react';
import useR46 from '../useR46';
import styles from './R46Reccomend.module.css';

const R46Reccomend = ({
	id,
	pt0 = false,
	title = null,
	variant = null,
	centertitle = false,
	listClassName,
	obj = null,
	className,
	...props
}) => {
	const rootClassName = cn(styles.root, className, pt0 ? styles.pt0 : null);
	const titleClass = cn(styles.title, centertitle ? styles.center : null);
	const listClass = cn(styles.list, listClassName);
	const itemClass = cn(styles.item);

	const { r46Active, loading, items, error, getReccomendations } = useR46();

	useEffect(() => {
		if (r46Active) {
			getReccomendations(id, title, obj);
		}
	}, [obj]);

	if (!r46Active) {
		return null;
	}

	if (error) {
		<div>ERROR: {error}</div>;
	}

	if (items && items.length > 0) {
		return (
			<div className={rootClassName}>
				{title && <div className={titleClass}>{title}</div>}
				<div className={listClass}>
					{items.map((el, i) => {
						const sCard =
							variant == 'same' ? (
								<ProductCardSame
									className={itemClass}
									hrefPostfix={`recommended_by=dynamic&recommended_code=${id}`}
									variant={variant}
									data={el}
									key={i}
								/>
							) : (
								<ProductCard
									className={itemClass}
									hrefPostfix={`recommended_by=dynamic&recommended_code=${id}`}
									variant={variant}
									data={el}
									key={i}
								/>
							);

						return sCard;
					})}
				</div>
			</div>
		);
	}

	return null;
};

export default R46Reccomend;
