import { Button, CatalogProductCardList, Lnk } from '@/components/ui';
import { searchbar__close } from '@/store/actions/searchbar';
import { getData } from '@/utils/fetcher';
import { Transition } from '@headlessui/react';
import { MagnifyingGlassIcon } from '@heroicons/react/24/outline';
import cn from 'classnames';
import { Fragment, useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import styles from './Searchbar.module.css';
import useR46Track from '@/components/r46/useR46Track';

const NEXT_PUBLIC_API_URL = process.env.NEXT_PUBLIC_API_URL;

const Searchbar = ({ groups = null, className, ...props }) => {
	const rootClassName = cn(styles.root, className);

	if (groups) {
		groups.sort((a, b) => a.sorting - b.sorting);
	}

	const groupsClassName = cn(styles.list);
	const groupsShow = !groups ? null : (
		<div className={groupsClassName}>
			{groups.map((el, i) => {
				return (
					<div key={i}>
						<Lnk
							href={`/catalog/${el.slug}`}
							className={styles.lnk}
							title={el.name}
						>
							{el.name}
						</Lnk>
					</div>
				);
			})}
		</div>
	);

	const dispatch = useDispatch();
	const [query, setQuery] = useState('');
	const [allItems, setAllItems] = useState([]);

	useEffect(() => {
		setQuery('');
		setAllItems([]);
		//dispatch(catalogSearch__close());
	}, []);

	const { trackSearch } = useR46Track();

	useEffect(() => {
		if (query.length > 2) {
			const apiUrlFetch = `${NEXT_PUBLIC_API_URL}/catalog/?search=${query}`;

			trackSearch(query);

			// fetch(apiUrlFetch)
			//   .then((res) => res.json())
			//   .then((data) => {
			//     const aItemsFiltred = data.items.map((el, i) => {
			//       if (el.parent) {
			//         //el.name = el.parent.name;
			//         return el;
			//       } else {
			//         return el;
			//       }
			//     });

			//     setAllItems(aItemsFiltred);
			//   });

			const fetchData = async () => {
				const data = await getData(`/catalog/?search=${query}`);
				if (data) {
					const aItemsFiltred = data.items.map((el, i) => {
						if (el.parent) {
							//el.name = el.parent.name;
							return el;
						} else {
							return el;
						}
					});

					setAllItems(aItemsFiltred);
				}
			};
			fetchData();
		} else {
			setAllItems([]);
		}
	}, [query]);

	const emptyText =
		query.length > 2 && allItems.length == 0 ? (
			<div className={styles.empty}>К сожалению ничего не нашлось</div>
		) : null;

	return (
		<Transition.Child
			as={Fragment}
			enter="ease-out duration-300"
			enterFrom="opacity-0"
			enterTo="opacity-100"
			leave="ease-in duration-200"
			leaveFrom="opacity-100"
			leaveTo="opacity-0"
		>
			<div className={rootClassName} {...props}>
				<div className={styles.form}>
					<span
						className={cn(
							styles.icon,
							query.length > 0 ? styles.iconactive : '',
						)}
					>
						<MagnifyingGlassIcon className="w-4 h-4" />
					</span>
					<input
						className={styles.input}
						type="text"
						id="search"
						placeholder="Поиск по каталогу"
						onChange={(event) => setQuery(event.target.value)}
						value={query}
						ref={(input) => input && input.focus()}
					/>
					<Button
						variant="transparent"
						onClick={() => dispatch(searchbar__close())}
					>
						Закрыть
					</Button>
				</div>
				{groupsShow}
				{emptyText}
				{allItems.length > 0 && (
					<div className={styles.result}>
						<CatalogProductCardList items={allItems} />
					</div>
				)}
			</div>
		</Transition.Child>
	);
};

export default Searchbar;
