import { MeFastMenu, MeFastProfile } from '@/components/ui';
import cn from 'classnames';
import styles from './ContentMe.module.css';

const ContentMe = ({
	aside = false,
	variant = null,
	bg = null,
	className,
	children,
	...props
}) => {
	const bgClass = bg == 'gray' ? styles.bgg : '';

	const rootClassName = cn(
		styles.root,
		{
			[styles.sm]: variant === 'sm',
			[styles.md]: variant === 'md',
			[styles.sm]: variant === 'sm',
			[styles.lg]: variant === 'lg',
			[styles.xl]: variant === 'xl',
		},

		{
			[styles.aside]: aside,
		},

		className,
	);

	return (
		<div {...props} className={bgClass}>
			<MeFastProfile />
			<MeFastMenu />
			{children}
			{/* <div className={rootClassName}>{children}</div> */}
		</div>
	);
};

export default ContentMe;
