import { IconTg, IconVk } from '@/components/icons';
import { FooterSection, Lnk, Logo, Onbd } from '@/components/ui';

import config from '@/config/root.json';
import cn from 'classnames';
import styles from './Footer.module.css';

const NEXT_PUBLIC_API_URL = process.env.NEXT_PUBLIC_API_URL;

const Footer = ({ popular, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  let aSections = [
    {
      title: 'Популярное',
      items: [
        // {
        //   name: 'Мягкая энзимная пудра для умывания Прополис + Матча',
        //   slug: '/product/1',
        // },
        // {
        //   name: 'Термозащитный спрей для волос Аминокислоты + Веганский кератин',
        //   slug: '/product/2',
        // },
        // {
        //   name: 'Сыворотка для лица с ниацинамидом 20% против акне и черных точек',
        //   slug: '/product/3',
        // },
        // {
        //   name: 'Питательная лифтинг маска для лица Мед + Церамиды',
        //   slug: '/product/4',
        // },
      ],
    },
    {
      title: 'Компания',
      items: [
        {
          name: 'Уход за волосами',
          slug: '/catalog/hair-1',
        },
        {
          name: 'Уход за лицом',
          slug: '/catalog/face-2',
        },
        {
          name: 'Уход за телом',
          slug: '/catalog/body-4',
        },
        // {
        //   name: 'Блог',
        //   slug: '/blog',
        // },
        {
          name: 'О бренде',
          slug: '/about',
        },
      ],
    },
    {
      title: 'Покупателям',
      items: [
        {
          name: 'Оплата',
          slug: '/info/oplata-5',
        },
        {
          name: 'Доставка',
          slug: '/info/dostavka-4',
        },
        {
          name: 'Возврат и обмен',
          slug: '/info/vozvrat-i-obmen-6',
        },
        {
          name: 'Сертификаты',
          slug: '/certificates',
        },
      ],
    },
  ];

  aSections[0].items = popular;

  // const [aPopular, setAPopular] = useState(popular);
  // const [aSection, setASection] = useState(aSections);

  // const router = useRouter();

  // useEffect(() => {
  //   const apiUrlFetch = `${NEXT_PUBLIC_API_URL}/catalog/?popular=1`;
  //   fetch(apiUrlFetch)
  //     .then((res) => res.json())
  //     .then((data) => {
  //       const aItemsItems = data.items.map((el, i) => {
  //         return {
  //           name: el.name,
  //           slug: `/product/${el.slug}`,
  //         };
  //       });
  //       setAPopular(aItemsItems);
  //     });
  // }, [router]);

  // useEffect(() => {
  //   const aCur = aSection;
  //   aCur[0].items = [...aPopular];
  //   setASection(aCur);
  // }, [aPopular, aSection]);

  return (
    <div className={rootClassName} {...props}>
      {/* {JSON.stringify(aSection)} */}
      <div className={styles.top}>
        <div className={styles.section}>
          <div>
            <Logo variant='nolink' />
          </div>
          <div className={styles.hd}>
            <div
              dangerouslySetInnerHTML={{ __html: config.work_hours }}
              className='text-xs'
            ></div>
            <div>
              <Lnk
                href={`mailto:${config.email}`}
                title={`Написать письмо ${config.email}`}
              >
                {config.email}
              </Lnk>
            </div>
            <div className={styles.phone}>
              <Lnk
                href={`tel:${config.phone.tel}`}
                title={`Позвонить ${config.phone.tel}`}
              >
                {config.phone.value}
              </Lnk>
            </div>
          </div>
          <div className={styles.social}>
            <Lnk
              href='https://vk.com/richescrub'
              target='_blank'
              rel='nofollow noopener'
              aria-label='RICHE во вКонтакте'
              title='RICHE во вКонтакте'
            >
              <IconVk />
            </Lnk>
            <Lnk
              href='https://t.me/richeskin'
              target='_blank'
              rel='nofollow noopener'
              aria-label='RICHE в Телеграм'
              title='RICHE в Телеграм'
            >
              <IconTg />
            </Lnk>
            {/* <Lnk
              href='https://www.youtube.com/@RICHEME'
              target='_blank'
              rel='nofollow noopener'
              aria-label='RICHE на Youtube'
              title='RICHE на Youtube'
            >
              <IconYt />
            </Lnk> */}
          </div>
        </div>
        {aSections.map((el, i) => (
          <FooterSection data={el} key={i} />
        ))}
      </div>

      <div className={styles.bottom}>
        <div className={styles.phonebottom}>
          <Lnk
            href={`tel:${config.phone.tel}`}
            title={`Позвонить ${config.phone.tel}`}
          >
            {config.phone.value}
          </Lnk>
        </div>
        <div
          className={styles.cr}
          dangerouslySetInnerHTML={{ __html: config.company_info }}
        ></div>
        <div className={styles.crlist}>
          <Lnk
            href='/info/politika-v-otnoshenii-personalnyx-dannyx-3'
            title='Политика в отношении персональных данных'
          >
            Политика конфиденциальности
          </Lnk>
          <Lnk href='/info/publichnaya-oferta-2' title='Публичная оферта'>
            Публичная оферта
          </Lnk>
        </div>
      </div>

      <div className={styles.onbd}>
        <Onbd />
      </div>
    </div>
  );
};

export default Footer;
