import { Footer, Header, Searchbar, Sidebar } from '@/components/common';
import {
	Breadcrumbs,
	CookiePopup,
	Seen,
	SidebarCart,
	SidebarMenu,
	SubscribeShort,
} from '@/components/ui';
import { cart__load } from '@/store/actions/cart';
import { searchbar__close } from '@/store/actions/searchbar';
import { sidebar__close } from '@/store/actions/sidebar';
import { YaUserParams } from '@/utils/metrika';
import { Transition } from '@headlessui/react';
import cn from 'classnames';
import { useRouter } from 'next/router';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import styles from './Layout.module.css';

const Layout = ({
	variant,
	seen = null,
	menu = null,
	breadcrumbs = null,
	phone = true,
	children,
	className,
	...props
}) => {
	const router = useRouter();
	const dispatch = useDispatch();
	const variantSide = useSelector((state) => state.sidebar.variant);

	const closeVariant = variantSide == 'cart' ? 'cart' : 'menu';

	const rootClassName = cn(
		styles.root,
		{
			[styles.checkout]: variant == 'checkout',
		},
		className,
	);

	const searchbarNow = useSelector((state) => state.searchbar.open);
	const sidebarNow = useSelector((state) => state.sidebar.open);
	const sidebarVariant = useSelector((state) => state.sidebar.variant);

	useEffect(() => {
		dispatch(searchbar__close());
		dispatch(sidebar__close(closeVariant));
		dispatch(cart__load(false));
	}, [router, dispatch]);

	useEffect(() => {
		document.body.classList.add('overflow-hidden');

		if (!sidebarNow) {
			document.body.classList.remove('overflow-hidden');
		}
	}, [sidebarNow]);

	useEffect(() => {
		document.body.classList.add('overflow-hidden');

		if (!searchbarNow) {
			document.body.classList.remove('overflow-hidden');
		}
	}, [searchbarNow]);

	return (
		<>
			<div className={rootClassName} {...props}>
				<header id="header" className={styles.header}>
					<Header
						variant={variant}
						menu={menu.menu.pages}
						groups={menu.menu.groups}
						phone={phone}
					/>
				</header>
				<main className={styles.main}>
					{variant != 'checkout' && breadcrumbs && (
						<Breadcrumbs data={breadcrumbs} />
					)}
					<div className={styles.page}>
						{children}
						{/* {seen && <Seen />} */}

						{typeof menu.menu.subscribe &&
							menu.menu.subscribe &&
							variant != 'checkout' && <SubscribeShort />}

						{variant != 'checkout' && <Seen />}
					</div>
				</main>

				{variant != 'checkout' && (
					<footer className={styles.footer}>
						<Footer popular={menu.menu.popular} />
					</footer>
				)}

				<CookiePopup />

				<Transition show={sidebarNow} appear>
					<Sidebar>
						{sidebarVariant === 'cart' && <SidebarCart />}
						{sidebarVariant === 'menu' && (
							<SidebarMenu menu={menu.menu.pages} groups={menu.menu.groups} />
						)}
					</Sidebar>
				</Transition>

				<Transition show={searchbarNow} appear>
					<Searchbar groups={menu.menu.groups} />
				</Transition>
				<YaUserParams />
			</div>
		</>
	);
};

export default Layout;
