import { sidebar__close } from '@/store/actions/sidebar';
import { Transition } from '@headlessui/react';
import cn from 'classnames';
import { useRouter } from 'next/router';
import { Fragment } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import styles from './Sidebar.module.css';

const Sidebar = ({ children, className, ...props }) => {
  const openNow = useSelector((state) => state.sidebar.open);
  const variant = useSelector((state) => state.sidebar.variant);
  const dispatch = useDispatch();

  const closeVariant = variant == 'cart' ? 'cart' : 'menu';

  const router = useRouter();

  // useEffect(() => {
  //   dispatch(sidebar__close());
  // }, [dispatch, router]);

  // useEffect(() => {
  //   const escFunction = (event) => {
  //     if (event.key === 'Escape') {
  //       dispatch(sidebar__close(closeVariant));
  //     }
  //   };
  //   document.addEventListener('keydown', escFunction, false);
  // }, [dispatch, closeVariant]);

  const rootClassName = cn(styles.root, className);
  const sectionClassName = cn(
    styles.section,
    {
      [styles.right]: variant == 'cart',
      [styles.left]: variant == 'menu',
    },

    // activeClasses,
    className
  );

  const tFrom = variant == 'cart' ? 'translate-x-full' : '-translate-x-full';
  const tTo = variant == 'cart' ? 'translate-x-0' : 'translate-x-0';

  return (
    <div className={rootClassName}>
      <div className={styles.cnt}>
        <Transition.Child
          as={Fragment}
          enter='ease-out duration-300'
          enterFrom='opacity-0'
          enterTo='opacity-100'
          leave='ease-in duration-200'
          leaveFrom='opacity-100'
          leaveTo='opacity-0'
        >
          <div
            className={styles.backdrop}
            onClick={() => dispatch(sidebar__close(closeVariant))}
          />
        </Transition.Child>

        <Transition.Child
          as={Fragment}
          enter='ease-out duration-300'
          enterFrom={`opacity-0 ${tFrom}`}
          enterTo={`opacity-100 ${tTo}`}
          leave='ease-in duration-200'
          leaveFrom={`opacity-100 ${tTo}`}
          leaveTo={`opacity-0 ${tFrom}`}
        >
          <section className={sectionClassName}>
            <div className={styles.sectioncnt}>
              <div className={styles.sidebar}>{children}</div>
            </div>
          </section>
        </Transition.Child>
      </div>
    </div>
  );
};

export default Sidebar;
