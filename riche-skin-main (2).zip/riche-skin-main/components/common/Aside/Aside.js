import cn from 'classnames';
import styles from './Aside.module.css';

const Aside = ({ children, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  return (
    <div className={rootClassName} {...props}>
      {children}
    </div>
  );
};

export default Aside;
