export { default } from './Aside';
