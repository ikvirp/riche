import { Button, Lnk, Logo, SiginModal } from '@/components/ui';
import config from '@/config/root.json';
import { searchbar__toggle } from '@/store/actions/searchbar';
import { sidebar__toggle } from '@/store/actions/sidebar';
import {
  Bars2Icon,
  HeartIcon,
  MagnifyingGlassIcon,
  ShoppingBagIcon,
  UserIcon,
} from '@heroicons/react/24/outline';
import cn from 'classnames';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useReadLocalStorage } from 'usehooks-ts';
import styles from './Header.module.css';

const Header = ({
  variant,
  phone = true,
  menu = null,
  groups = null,
  className,
}) => {
  const cartCount = useSelector((state) => state.cart.total.total_quantity);
  const realList = useReadLocalStorage('favList');
  const [favCount, setFavCount] = useState(0);

  useEffect(() => {
    realList && setFavCount(realList.length);
  }, [realList]);

  const rootClassName = cn(
    styles.root,
    { [styles.checkout]: variant == 'checkout' },
    { [styles.nophone]: !phone },
    className
  );
  const groupsClassName = cn(styles.list);

  if (menu) {
    menu.sort((a, b) => a.sorting - b.sorting);
  }
  if (groups) {
    groups.sort((a, b) => a.sorting - b.sorting);
  }

  const groupsShow = !groups ? null : (
    <div className={groupsClassName}>
      {groups.map((el, i) => {
        return (
          <div key={i}>
            <Lnk
              href={`/catalog/${el.slug}`}
              className={styles.lnk}
              title={el.name}
            >
              {el.name}
            </Lnk>
          </div>
        );
      })}
    </div>
  );

  const router = useRouter();
  const dispatch = useDispatch();
  const { status: session_status } = useSession();

  const [showModal, setShowModal] = useState(false);

  const menuItems = !menu ? null : (
    <div className={styles.mn}>
      {menu.map((el, i) => {
        if (el.action == 'sidebar') {
          return (
            <Lnk
              href={el.slug}
              title={el.name}
              key={i}
              className='outline-none'
              onClick={(event) => {
                event.preventDefault();
                dispatch(sidebar__toggle('menu'));
              }}
            >
              {el.name}
            </Lnk>
          );
        } else {
          return (
            <Lnk
              href={el.slug}
              title={el.name}
              key={i}
              className='outline-none'
            >
              {el.name}
            </Lnk>
          );
        }
      })}
    </div>
  );

  // https://github.com/nextauthjs/next-auth/issues/101
  const profileButton =
    session_status === 'authenticated' ? (
      <Button
        className='lg:hidden'
        variant='action'
        aria-label='Мой профиль'
        title='Мой профиль'
        //onClick={() => router.push('/me')}
        Component='a'
        href='/me'
      >
        <UserIcon className='w-6 h-6' />
      </Button>
    ) : (
      <>
        <Button
          className='lg:hidden'
          variant='action'
          aria-label='Мой профиль'
          title='Мой профиль'
          onClick={() => {
            if (router.asPath != '/signin') {
              setShowModal(true);
            }
          }}
        >
          <UserIcon className='w-6 h-6' />
        </Button>
        <SiginModal show={showModal} onClose={() => setShowModal(false)} />
      </>
    );

  if (variant == 'checkout') {
    return (
      <>
        {/* {JSON.stringify(phone)} */}
        <div className={rootClassName}>
          <div className={styles.logo_checkout}>
            <Logo />
          </div>
          {phone && (
            <div className={styles.tel}>
              <Lnk
                href={`tel:${config.phone.tel}`}
                title={`Позвонить ${config.phone.tel}`}
              >
                {config.phone.value}
              </Lnk>
            </div>
          )}
        </div>
      </>
    );
  }
  return (
    <>
      <div className={rootClassName}>
        <div className={styles.menu}>
          {menuItems}
          <span className={styles.hiddenlg}>
            <Button
              variant='action'
              aria-label='Меню'
              title='Меню'
              onClick={(event) => {
                event.preventDefault();
                dispatch(sidebar__toggle('menu'));
              }}
            >
              <Bars2Icon className='w-6 h-6' />
            </Button>
            <Button
              variant='action'
              aria-label='Поиск по каталогу'
              title='Поиск по каталогу'
              onClick={(event) => {
                event.preventDefault();
                dispatch(searchbar__toggle());
              }}
            >
              <MagnifyingGlassIcon className='w-6 h-6' />
            </Button>
          </span>
        </div>
        <div className={styles.logo}>
          <Logo />
        </div>
        <div className={styles.actions}>
          <span className={styles.visiblelg}>
            <Button
              className='lg:hidden'
              variant='action'
              aria-label='Поиск по каталогу'
              title='Поиск по каталогу'
              onClick={(event) => {
                event.preventDefault();
                dispatch(searchbar__toggle());
              }}
            >
              <MagnifyingGlassIcon className='w-6 h-6' />
            </Button>
          </span>
          {profileButton}
          <Button
            Component='a'
            variant='action'
            aria-label='Избранные товары'
            title='Избранные товары'
            href='/fav'
            badge={favCount}
            onClick={() => {
              favCount && router.push('/fav');
            }}
          >
            <HeartIcon className='w-6 h-6' />
          </Button>
          <Button
            variant='action'
            aria-label='Корзина'
            title='Корзина'
            badge={cartCount}
            onClick={() => {
              cartCount && dispatch(sidebar__toggle('cart'));
            }}
          >
            <ShoppingBagIcon className='w-6 h-6' />
          </Button>
        </div>
      </div>
      {groupsShow}
    </>
  );
};

export default Header;
