import cn from 'classnames';
import styles from './Content.module.css';

const Content = ({ aside = false, variant = null, className, ...props }) => {
  const rootClassName = cn(
    styles.root,
    {
      [styles.sm]: variant === 'sm',
      [styles.md]: variant === 'md',
      [styles.sm]: variant === 'sm',
      [styles.lg]: variant === 'lg',
      [styles.xl]: variant === 'xl',
    },

    {
      [styles.aside]: aside,
    },
    className
  );

  return <div className={rootClassName} {...props}></div>;
};

export default Content;
