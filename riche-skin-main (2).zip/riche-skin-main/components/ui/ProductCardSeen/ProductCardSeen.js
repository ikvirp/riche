import { Img, Lnk } from '@/components/ui';
import cn from 'classnames';
import styles from './ProductCardSeen.module.css';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const ProductCardSeen = ({ data, className, ...props }) => {
  const rootClassName = cn(
    styles.root,

    className
  );

  const imageUrl = data.thumb
    ? `${NEXT_PUBLIC_DATA_DOMAIN}${data.thumb.file}`
    : `/i/thumb.png`;

  const realUrl = {
    pathname: `/product/[slug]`,
    query: { slug: `${data.slug}` },
  };

  return (
    <div className={rootClassName} {...props}>
      <Lnk href={realUrl} className={styles.link} title={data.name}>
        <Img
          alt={data.name}
          title={data.name}
          src={imageUrl}
          className={styles.img}
          //placeholder='blur'
          width='350'
          height='350'
        />
      </Lnk>
    </div>
  );
};

export default ProductCardSeen;
