export { default } from './ProductCardSeen';
