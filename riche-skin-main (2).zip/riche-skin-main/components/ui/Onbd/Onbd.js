import { Lnk } from '@/components/ui';
import cn from 'classnames';
import styles from './Onbd.module.css';

const Onbd = ({ className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  return (
    <div className={rootClassName} {...props}>
      Создание сайта —{' '}
      <Lnk
        href='https://onbd.ru'
        className={styles.link}
        title='Бюро дизайна'
        target='_blank'
      >
        onbd.ru
      </Lnk>
    </div>
  );
};

export default Onbd;
