import useR46Track from '@/components/r46/useR46Track';
import { Button, Img, Lnk } from '@/components/ui';
import { numberFormat } from '@/utils/prepare';
import { HeartIcon, MinusIcon, PlusIcon } from '@heroicons/react/24/outline';
import { HeartIcon as HeartIconSolid } from '@heroicons/react/24/solid';
import cn from 'classnames';
import { useEffect, useState } from 'react';
import { useLocalStorage } from 'usehooks-ts';
import styles from './CartCard.module.css';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const CartCard = ({ actionPlus, actionMinus, data, className, ...props }) => {
	const rootClassName = cn(styles.root, className);

	const [favList, setFavList] = useLocalStorage('favList', []);
	const [isFav, setIsFav] = useState(null);

	useEffect(() => {
		if (favList) {
			const filtred = favList.find((el) => el == data.id);

			if (filtred) {
				setIsFav(data.id);
			}
		}
	}, [favList, data.id]);

	const handleClickFav = (id) => {
		const aCur = favList ? favList : [];

		const filtred = aCur.find((el) => el == id);

		if (filtred) {
			const aNew = aCur.filter((el) => el != id);
			setFavList(aNew);
			setIsFav(null);
		} else {
			const aNew = [...aCur, id];
			setIsFav(id);
			setFavList(aNew);
		}
	};

	const heartIcon = isFav ? (
		<HeartIconSolid className="h-6 w-6 fill-red-600" />
	) : (
		<HeartIcon className="w-6 h-6" />
	);

	const sPrice =
		data.price.current != data.price.old ? (
			<div className="flex gap-3 items-center leading-none">
				<span className="text-base font-bold">{`${numberFormat(
					data.price.current,
				)} ${data.price.currency}`}</span>
				<span className="text-sm text-gray-500 line-through">
					{`${numberFormat(data.price.old)} ${data.price.currency}`}
				</span>
			</div>
		) : (
			<div className="flex gap-2 items-center  leading-none">
				<span className="text-base font-bold">{`${numberFormat(
					data.price.current,
				)} ${data.price.currency}`}</span>
			</div>
		);

	// {numberFormat(data.quantity * data.price.current, '₽')}

	const sSubtotal =
		data.price.current != data.price.old ? (
			<>
				<div className="text-xs font-normal text-right text-red-600 absolute right-0 -mt-3.5">{`скидка ${numberFormat(
					data.cart.discount,
				)} ${data.cart.currency}`}</div>
				<div className="text-right">
					{`${numberFormat(data.cart.amount)} ${data.cart.currency}`}
				</div>
			</>
		) : (
			<div className="text-right">
				{`${numberFormat(data.cart.amount)} ${data.cart.currency}`}
			</div>
		);

	const imageUrl = data.thumb
		? `${NEXT_PUBLIC_DATA_DOMAIN}${data.thumb.file}`
		: `/i/thumb.png`;

	const { trackCartAdd, trackCartRemove } = useR46Track();

	return (
		<div className={rootClassName} {...props}>
			<div className={styles.thumb}>
				<Lnk href={`/product/${data.slug}`} title={data.name}>
					<Img
						className="rounded-md"
						src={imageUrl}
						alt={data.name}
						title={data.name}
						width={300}
						height={300}
					/>
				</Lnk>
			</div>
			<div className={styles.summary}>
				<div className="flex gap-3 items-start ">
					<div className="flex-1 flex flex-col gap-1">
						<div>{sPrice}</div>
						<div className="text-base leading-tight">
							<Lnk href={`/product/${data.slug}`} title={data.name}>
								{data.name}
							</Lnk>
						</div>
						<div className="text-xs text-gray-500">{data.marking}</div>
					</div>

					<Button
						variant="action"
						onClick={(e) => {
							handleClickFav(data.id);
						}}
					>
						{heartIcon}
					</Button>
				</div>
				<div className="flex items-end justify-between gap-3">
					<div className={styles.action}>
						<Button
							variant="action"
							onClick={(e) => {
								actionMinus(data.id);
								trackCartRemove(data.id);
							}}
						>
							<MinusIcon className="w-6 h-6" />
						</Button>
						<div className={styles.quantity}>
							{numberFormat(data.cart.quantity)}
						</div>

						<Button
							variant="action"
							onClick={(e) => {
								actionPlus(data.id);
								trackCartAdd(data.id);
							}}
						>
							<PlusIcon className="w-6 h-6" />
						</Button>
					</div>
					<div className="font-bold text-lg relative grow">{sSubtotal}</div>
				</div>
			</div>
		</div>
	);
};

export default CartCard;
