import cn from 'classnames';
import BlogCard from '../BlogCard/BlogCard';
import Lnk from '../Lnk/Lnk';
import styles from './MainBlockBlog.module.css';

const MainBlockBlog = ({ data, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  if (data.blog_items.length) {
    return (
      <div className={rootClassName} {...props}>
        <div className={styles.title}>
          <Lnk href='/blog' title={data.name}>
            {data.name}
          </Lnk>
        </div>
        <div className={styles.list}>
          {data.blog_items.map((item, index) => {
            return <BlogCard className={styles.item} data={item} key={index} />;
          })}
        </div>
      </div>
    );
  }
  return null;
};

export default MainBlockBlog;
