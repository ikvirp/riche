export { default } from './ProductCardMedia';
