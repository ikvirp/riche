import { Img } from '@/components/ui';
import cn from 'classnames';
import { useRef, useState } from 'react';
import styles from './ProductCardMedia.module.css';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const ProductCardMedia = ({
  labels,
  discount,
  name,
  data,
  className,
  ...props
}) => {
  const rootClassName = cn(styles.root, className);

  const [activeIndex, setActiveIndex] = useState(0);

  let aItemsBig = [];
  let aItemsSmall = [];

  data.forEach((el) => {
    aItemsBig.push({
      name: name,
      thumb: `${NEXT_PUBLIC_DATA_DOMAIN}${el.original.file}`,
      width: el.original.width,
      height: el.original.height,
    });

    aItemsSmall.push({
      name: name,
      thumb: `${NEXT_PUBLIC_DATA_DOMAIN}${el.thumb.file}`,
      width: el.thumb.width,
      height: el.thumb.height,
    });
  });

  const handleClickScroll = (index) => {
    setActiveIndex(index);
    const element = document.getElementById(`section-${index}`);
    if (element) {
      // 👇 Will scroll smoothly to the top of the next section
      element.scrollIntoView({
        behavior: 'smooth',
        //block: 'end',
        inline: 'nearest',
      });
    }
  };

  const labelsShow =
    labels && labels.length > 0 ? (
      <span className={styles.labels}>
        {labels.map((el, i) => {
          //const styleColor = el.color != '' ? `${el.color}` : '';
          return (
            <div key={i}>
              <span className={styles.label}>{el.name}</span>
            </div>
          );
        })}
      </span>
    ) : null;

  const discountShow = discount ? (
    <span className={styles.discount}>{discount}</span>
  ) : null;

  return (
    <div className={rootClassName} {...props}>
      <div className={styles.preview}>
        {aItemsBig.map((el, i) => {
          return (
            <div key={i} className={styles.section} id={`section-${i}`}>
              <Img
                alt={el.name}
                title={el.name}
                src={el.thumb}
                className={styles.prev}
                //placeholder='blur'
                width={el.width}
                height={el.height}
              />
            </div>
          );
        })}
        {labelsShow}
        {discountShow}
      </div>
      <div className={styles.thumbs}>
        {aItemsSmall.map((el, i) => {
          return (
            <Img
              alt={el.name}
              title={el.name}
              src={el.thumb}
              className={cn(styles.thumb, {
                [styles.active]: activeIndex == i,
              })}
              //placeholder='blur'
              width={el.width}
              height={el.height}
              key={i}
              onClick={() => {
                handleClickScroll(i);
              }}
            />
          );
        })}
      </div>
    </div>
  );
};

export default ProductCardMedia;
