export { default } from './OrderCardShort';
