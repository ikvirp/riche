import { Img, Lnk } from '@/components/ui';
import { numberFormat, prepareDate } from '@/utils/prepare';
import cn from 'classnames';
import styles from './OrderCardShort.module.css';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const OrderCardShort = ({ data, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  const date = prepareDate(data.datetime);
  const paid = data.paid ? (
    <span className='bg-green-600 text-white px-1 py-0.5 rounded-md block'>
      Оплачен
    </span>
  ) : (
    <span className='bg-red-600 text-white px-1 py-0.5  rounded-md block'>
      Неоплачен
    </span>
  );

  const aGoods = data.goods.filter((el) => el.type == 0);

  const grouped = aGoods.reduce((group, product) => {
    const { marking } = product;
    group[marking] = group[marking] ?? [];
    group[marking].push(product);
    return group;
  }, {});

  //console.log(grouped);

  let aItems = [];
  for (const [key, value] of Object.entries(grouped)) {
    //console.log(`${key}: ${value}`);

    const quantity = value.length;
    const item = value[0];
    item.quantity = quantity;
    aItems.push(item);
  }

  // return (
  //   <div>
  //     <div>{JSON.stringify(aItems)}</div>
  //   </div>
  // );

  const showStatuses = data.canceled ? (
    <div className={styles.canceled}>Отменён</div>
  ) : (
    <>
      <div className={styles.paid}>{paid}</div>
      <div
        className={styles.nm}
        style={{ background: data.status.color, color: '#fff' }}
      >
        {data.status.name}
      </div>
    </>
  );

  return (
    <Lnk href={`/me/orders/${data.guid}`}>
      {/* <div>{JSON.stringify(grouped)}</div> */}

      <div className={rootClassName} {...props}>
        <div className={styles.data}>
          <div className={styles.invoice}>{data.invoice}</div>
          <div className={styles.date}>{date}</div>
        </div>
        <div className={styles.thumbs}>
          {/* {aGoods.map((el, i) => { */}
          {aItems.map((el, i) => {
            const imageUrl = el.thumb
              ? `${NEXT_PUBLIC_DATA_DOMAIN}${el.thumb.file}`
              : `/i/thumb.png`;

            return (
              <div className={styles.thumb} key={i}>
                <Img
                  className='rounded-md w-12 h-12 border-2 border-white'
                  src={imageUrl}
                  alt={el.name}
                  title={el.name}
                  width={300}
                  height={300}
                />
                <span className={styles.quantity}>
                  {numberFormat(el.quantity)}
                </span>
              </div>
            );
          })}
        </div>
        <div className={styles.status}>{showStatuses}</div>
      </div>
    </Lnk>
  );
};

export default OrderCardShort;
