export { default } from './LogoSymbol';
