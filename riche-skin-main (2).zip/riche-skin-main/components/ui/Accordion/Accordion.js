import { ChevronDownIcon, ChevronUpIcon } from '@heroicons/react/24/outline';
import cn from 'classnames';
import { useState } from 'react';
import styles from './Accordion.module.css';

const Accordion = ({
  open = false,
  variant,
  first,
  name,
  children,
  className,
  ...props
}) => {
  const rootClassName = cn(styles.root, { [styles.first]: first }, className);

  const [isOpen, setIsOpen] = useState(open);

  const toggleOpen = (e) => {
    e.preventDefault();
    setIsOpen(!isOpen);
  };

  const icon = isOpen ? (
    <ChevronDownIcon className='w-4 h-4' />
  ) : (
    <ChevronUpIcon className='w-4 h-4' />
  );
  const summaryClassName = cn(styles.summary, {
    [styles.small]: variant == 'small',
  });
  return (
    <details className={rootClassName} {...props} open={isOpen}>
      <summary className={summaryClassName} onClick={toggleOpen}>
        <span dangerouslySetInnerHTML={{ __html: name }} />

        {icon}
      </summary>
      <div className={styles.content}>{children}</div>
    </details>
  );
};

export default Accordion;
