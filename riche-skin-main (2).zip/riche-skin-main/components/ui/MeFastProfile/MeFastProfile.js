import { Lnk, MeAvatar } from '@/components/ui';
import useUser from '@/utils/useUser';
import cn from 'classnames';
import styles from './MeFastProfile.module.css';

const MeFastProfile = ({ className, ...props }) => {
	const rootClassName = cn(styles.root, className);
	const { token, profile, avatar } = useUser();

	// useEffect(() => {
	// 	if (session) {
	// 		setProfile(session.profile);
	// 		setToken(session.token);
	// 	}
	// }, [session]);

	const realName = profile
		? profile.name.length > 0
			? profile.name
			: profile.login
		: 'Пользователь';
	// 48 Конфиг аватара

	return (
		<>
			<div className={rootClassName} {...props}>
				{/* 
				<div>{JSON.stringify(token)}</div> */}
				<div className={styles.cnt}>
					<MeAvatar token={token} />

					<div className={styles.summary}>
						<div className={styles.name}>{realName}</div>
						<div className={styles.link}>
							<Lnk href="/me/profile">Управление профилем</Lnk>
						</div>
						{/* <div>{JSON.stringify(profile)}</div>
					<div>{JSON.stringify(oConfig)}</div> */}
					</div>
				</div>
			</div>
		</>
	);
};

export default MeFastProfile;
