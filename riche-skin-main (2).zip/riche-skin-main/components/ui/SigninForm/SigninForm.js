import { SigninFormEmail, SigninFormPhone } from '@/components/ui';
import cn from 'classnames';
import styles from './SigninForm.module.css';

const NEXT_PUBLIC_API_URL = process.env.NEXT_PUBLIC_API_URL;
const NEXT_PUBLIC_DATA_METRIKA_ID = process.env.NEXT_PUBLIC_DATA_METRIKA_ID;
const NEXT_PUBLIC_AUTH_MODE = process.env.NEXT_PUBLIC_AUTH_MODE;

const SigninForm = ({ redirect = false, className, ...props }) => {
	const rootClassName = cn(styles.root, className);

	if (NEXT_PUBLIC_AUTH_MODE == 'phone') {
		return <SigninFormPhone redirect={redirect} className={className} />;
	}

	return <SigninFormEmail redirect={redirect} className={className} />;
};

export default SigninForm;
