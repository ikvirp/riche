import { getData } from '@/utils/fetcher';
import { XMarkIcon } from '@heroicons/react/24/outline';
import cn from 'classnames';
import { useSession } from 'next-auth/react';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import Button from '../Button/Button';
import Lnk from '../Lnk/Lnk';
import Loader from '../Loader/Loader';
import styles from './CommentWrite.module.css';

const CommentWrite = ({ className, commentid, item_id, ...props }) => {
  const rootClassName = cn(styles.root, className);

  const [loading, setLoading] = useState(false);
  const [needText, setNeedText] = useState(false);
  const [answerSuccess, setAnswerSuccess] = useState(null);
  const [answerDanger, setAnswerDanger] = useState(null);
  const { data: session } = useSession();

  const sButton = loading ? (
    <>
      <Loader variant='cart' /> Отправка
    </>
  ) : (
    `Отправить`
  );

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isDirty, isValid },
  } = useForm({
    mode: 'all',
  });

  const onSubmit = async (data) => {
    setAnswerSuccess(null);
    setAnswerDanger(null);
    setLoading(true);

    const oData = {
      item_id: item_id, //!
      parent_id: commentid, //!
      rate: null,
      advantages: null,
      flaws: null,
      text: data.text,
      token: session.token,
    };

    const result = await getData(`/comment_add/`, 'POST', oData);

    if (typeof result.error == 'undefined') {
      // result
      // message

      if (result) {
        setAnswerSuccess(result.message);
        reset({ text: '' });
      } else {
        setAnswerDanger(result.message);
      }
    }

    setLoading(false);

    //alert(JSON.stringify(oData));
  };

  return (
    <div className={rootClassName} {...props}>
      {answerSuccess && (
        <div className='mb-4 rounded-md px-3 py-2 leading-snug flex justify-between items-center bg-green-100 text-green-700'>
          {answerSuccess}
          <Button
            variant='action'
            aria-label='Закрыть'
            title='Закрыть'
            onClick={() => setAnswerSuccess(null)}
          >
            <XMarkIcon className='w-4 h-4' />
          </Button>
        </div>
      )}
      {answerDanger && (
        <div className='mb-4 rounded-md px-3 py-2 leading-snug flex justify-between items-center bg-red-200 text-red-600'>
          {answerDanger}
          <Button
            variant='action'
            aria-label='Закрыть'
            title='Закрыть'
            onClick={() => setAnswerDanger(null)}
          >
            <XMarkIcon className='w-4 h-4' />
          </Button>
        </div>
      )}

      <form onSubmit={handleSubmit(onSubmit)} className='flex flex-col gap-6 '>
        <div>
          <label className='text-gray-500 pb-1 px-2 block' htmlFor='text'>
            Ваш комментарий
          </label>
          <textarea
            className='block w-full h-48 rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 '
            id='text'
            name='text'
            //placeholder='Ваш ответ'
            {...register('text')}
          />

          {needText && (
            <div className='text-xs pt-1.5 px-2 text-red-600' role='alert'>
              Комментарий обязателен
            </div>
          )}
        </div>

        <div className='text-xs text-center'>
          Нажимая &laquo;Отправить&raquo; я&nbsp;соглашаюсь с&nbsp;
          <Lnk
            href='/info/pravila-publikaczii-kommentariev-1155'
            title='Правила публикации'
            className='underline'
            target='_blank'
          >
            правилами публикации
          </Lnk>
        </div>

        <div>
          <Button
            variant='black'
            size='normal'
            className='w-full h-14'
            type='submit'
            disabled={!isDirty && !isValid}
          >
            {sButton}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default CommentWrite;
