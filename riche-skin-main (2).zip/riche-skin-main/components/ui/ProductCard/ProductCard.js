import useR46Track from '@/components/r46/useR46Track';
import { Button, Img, Lnk } from '@/components/ui';
import { cart__load } from '@/store/actions/cart';
import { numberFormat } from '@/utils/prepare';
import { HeartIcon, ShoppingBagIcon } from '@heroicons/react/24/outline';
import { HeartIcon as HeartIconSolid } from '@heroicons/react/24/solid';
import cn from 'classnames';
import { useEffect, useRef, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useHover, useLocalStorage } from 'usehooks-ts';
import styles from './ProductCard.module.css';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;
const NEXT_PUBLIC_DATA_METRIKA_ID = process.env.NEXT_PUBLIC_DATA_METRIKA_ID;

const ProductCard = ({
	hrefPostfix = null,
	showAction = true,
	variant,
	data,
	className,
	...props
}) => {
	const dispatch = useDispatch();

	const { trackFavAdd, trackFavRemove, trackCartAdd } = useR46Track();

	const [favList, setFavList] = useLocalStorage('favList', []);
	const [cartList, setCartList] = useLocalStorage('cartList', []);
	const [isFav, setIsFav] = useState(null);

	useEffect(() => {
		if (favList) {
			const filtred = favList.find((el) => el == data.id);
			if (filtred) {
				setIsFav(data.id);
			}
		}
	}, [favList, data.id]);

	const handleClickFav = (id) => {
		const aCur = favList ? favList : [];

		const filtred = aCur.find((el) => el == id);

		if (filtred) {
			const aNew = aCur.filter((el) => el != id);
			setFavList(aNew);
			setIsFav(null);
			trackFavRemove(id);
		} else {
			const aNew = [...aCur, id];
			setIsFav(id);
			setFavList(aNew);
			trackFavAdd(id);
		}
	};

	const handleClickCart = (obj) => {
		const aCur = cartList ? cartList : [];

		trackCartAdd(obj.id);

		// metrika — Добавление товара в корзину
		if (NEXT_PUBLIC_DATA_METRIKA_ID > 0) {
			window.dataLayer = window.dataLayer || [];
			window.dataLayer.push({
				ecommerce: {
					currencyCode: 'RUB',
					add: {
						products: [
							{
								id: obj.id,
								name: obj.name,
								price: obj.price,
								quantity: 1,
								group: obj.group,
							},
						],
					},
				},
			});
		}

		const found = aCur.find((el) => el.id == obj.id);

		const timestamp = Math.floor(Date.now() / 1000);

		let aNew = [];
		if (!found) {
			aNew = [...aCur, { ...obj, timestamp }];
		} else {
			//alert(found.quantity);

			const filtred = aCur.filter((el) => el.id != obj.id);
			found.quantity++;
			found.timestamp = timestamp;

			aNew = [...filtred, found];
		}

		aNew.sort(function (a, b) {
			// Turn your strings into dates, and then subtract them
			// to get a value that is either negative, positive, or zero.
			return b.timestamp - a.timestamp;
		});

		setCartList(aNew);

		dispatch(cart__load('show'));
		//dispatch(sidebar__toggle('cart'));
		//console.log(cartList);
	};

	const hoverRef = useRef(null);
	const hoverRef2 = useRef(null);
	const isHover = useHover(hoverRef);
	const isHover2 = useHover(hoverRef2);

	const rootClassName = cn(
		styles.root,
		{ [styles.fixed]: variant == 'fix' },
		className,
	);

	const imageUrl = data.thumb
		? `${NEXT_PUBLIC_DATA_DOMAIN}${data.thumb.file}`
		: `/i/thumb.png`;

	const realUrl = {
		pathname: `/product/[slug]`,
		query: { slug: `${data.slug}` },
	};

	const realPrice =
		data.price.current != data.price.old ? (
			<>
				<span className={styles.pcurrent}>{`${numberFormat(
					data.price.current,
				)} ${data.price.currency}`}</span>
				<span className={styles.pold}>{`${numberFormat(data.price.old)} ${
					data.price.currency
				}`}</span>
			</>
		) : (
			<span className={styles.pcurrent}>{`${numberFormat(data.price.current)} ${
				data.price.currency
			}`}</span>
		);

	const labels =
		data.labels.length > 0 ? (
			<span className={styles.labels}>
				{data.labels.map((el, i) => {
					//const styleColor = el.color != '' ? `${el.color}` : '';
					return (
						<div key={i}>
							<span className={styles.label}>{el.name}</span>
						</div>
					);
				})}
			</span>
		) : null;

	const discount =
		data.price.current != data.price.old ? (
			<span className={styles.discount}>{`-${numberFormat(
				data.price.discount_percent,
			)}%`}</span>
		) : null;

	const heartIcon = isFav ? (
		<HeartIconSolid className="h-6 w-6 fill-red-600" />
	) : (
		<HeartIcon className="w-6 h-6" />
	);

	const minRest =
		typeof data.min_rest_add != 'undefined' ? data.min_rest_add : 0;

	const postfix =
		hrefPostfix && hrefPostfix.length > 0 ? `?${hrefPostfix}` : '';

	const addCartButton =
		data.rest > minRest ? (
			<Button
				variant="product"
				className="w-full"
				onClick={(e) => {
					const val = {
						id: data.id,
						quantity: 1,
						name: data.name,
						price: data.price.current,
						group: data.group_name,
					};
					handleClickCart(val);
				}}
			>
				<ShoppingBagIcon className="w-6 h-6" /> В корзину
			</Button>
		) : (
			<Button
				variant="product"
				className="w-full"
				disabled
				// onClick={(e) => {
				//   const val = {
				//     id: data.id,
				//     quantity: 1,
				//   };
				//   handleClickCart(val);
				// }}
			>
				Недоступно
			</Button>
		);

	return (
		<div className={rootClassName} {...props}>
			{/* {JSON.stringify(favList)} */}
			<div className={styles.main}>
				<div
					//className={cn(styles.thumb, isHover2 ? `opacity-60` : ``)}
					className={styles.thumb}
					ref={hoverRef}
				>
					<Lnk
						href={`/product/${data.slug}${postfix}`}
						className={cn(styles.link, isHover2 ? `opacity-60` : ``)}
						title={data.name}
					>
						<Img
							alt={data.name}
							title={data.name}
							src={imageUrl}
							className={styles.img}
							//placeholder='blur'
							width="350"
							height="350"
						/>
					</Lnk>
					{labels}
					{/* {discount} */}
					{/* {data.rest < 1 && (
            <span className='text-xs absolute right-2 bottom-2'>
              временно недоступно
            </span>
          )} */}
					<span className={styles.fav}>
						<Button
							variant="action"
							aria-label="Избранные товары"
							title="Избранные товары"
							onClick={() => {
								handleClickFav(data.id);
							}}
						>
							{heartIcon}
						</Button>
					</span>
				</div>

				{/* <div className={cn(styles.price, data.rest < 1 ? 'opacity-50' : '')}>
          {realPrice}
        </div> */}
				<div className={styles.price}>{realPrice}</div>
				<div className={styles.name} ref={hoverRef2}>
					<Lnk
						href={`/product/${data.slug}${postfix}`}
						className={isHover ? `opacity-60` : ``}
						title={data.name}
					>
						{data.name}
					</Lnk>
				</div>
				{data.description != '' && (
					<div
						className={styles.description}
						dangerouslySetInnerHTML={{ __html: data.description }}
					></div>
				)}
			</div>
			{showAction && <div className={styles.action}>{addCartButton}</div>}
		</div>
	);
};

export default ProductCard;
