import { Img, Lnk } from '@/components/ui';
import { ArrowRightIcon } from '@heroicons/react/24/outline';
import cn from 'classnames';
import styles from './CatalogGroupCard.module.css';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const CatalogGroupCard = ({ data, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  const imageUrl = data.thumb
    ? `${NEXT_PUBLIC_DATA_DOMAIN}${data.thumb.file}`
    : null;

  const realUrl = {
    pathname: `/catalog/[slug]`,
    query: { slug: `${data.slug}` },
  };

  return (
    <div className={rootClassName} {...props}>
      {imageUrl && (
        <Img
          alt={data.name}
          title={data.name}
          src={imageUrl}
          className={styles.img}
          //placeholder='blur'
          width={data.thumb.width}
          height={data.thumb.height}
        />
      )}
      <div className={styles.summary}>
        <div className={styles.title}>
          <Lnk href={realUrl} title={data.title} className={styles.lnk}>
            {data.title}
          </Lnk>
        </div>
        <div className={styles.round}>
          <ArrowRightIcon className='w-6 h-6' />
        </div>
      </div>
    </div>
  );
};

export default CatalogGroupCard;
