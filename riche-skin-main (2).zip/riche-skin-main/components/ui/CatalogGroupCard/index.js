export { default } from './CatalogGroupCard';
