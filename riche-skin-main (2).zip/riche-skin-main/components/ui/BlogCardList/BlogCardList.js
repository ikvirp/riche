import { BlogCard } from '@/components/ui';
import cn from 'classnames';
import styles from './BlogCardList.module.css';

const BlogCardList = ({ items, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  return (
    <div className={rootClassName} {...props}>
      {items.map((el, i) => (
        <BlogCard data={el} key={i} className={styles.item} />
      ))}
    </div>
  );
};

export default BlogCardList;
