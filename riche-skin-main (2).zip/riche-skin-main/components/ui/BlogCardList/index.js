export { default } from './BlogCardList';
