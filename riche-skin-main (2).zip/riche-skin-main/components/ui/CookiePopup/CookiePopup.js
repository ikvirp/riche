import { Button } from '@/components/ui';
import cn from 'classnames';
import styles from './CookiePopup.module.css';

import { useAcceptCookies } from '@/utils/useAcceptCookies';

const active = {
  false: 'translate-y-0 opacity-100',
  true: 'translate-y-full opacity-0',
};

const CookiePopup = ({ className, action = null }) => {
  const { acceptedCookies, onAcceptCookies } = useAcceptCookies();
  let activeClasses = active[acceptedCookies];

  if (!acceptedCookies) {
    return (
      <div className={cn(styles.root, activeClasses, className)}>
        <div className={styles.wrap}>
          <div className={styles.text}>
            Продолжая использовать сайт, вы подтверждаете своё согласие на
            использование «cookie».
          </div>
          <div className={styles.action}>
            <Button variant='cookie' onClick={() => onAcceptCookies()}>
              Хорошо
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return null;
};

export default CookiePopup;
