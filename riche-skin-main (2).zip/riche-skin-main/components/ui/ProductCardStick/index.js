export { default } from './ProductCardStick';
