export { default } from './ProductCardPromo';
