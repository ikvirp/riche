import { AccordionGroup, Button, Img } from '@/components/ui';
import cn from 'classnames';
import styles from './ProductCardPromo.module.css';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const ProductCardPromo = ({ data, odd, className, ...props }) => {
  const rootClassName = cn(styles.root, className);
  const thumbClassName = cn(styles.thumb, { [styles.odd]: odd });

  const imageUrl =
    data.media.length > 0
      ? `${NEXT_PUBLIC_DATA_DOMAIN}${data.media[0].original.file}`
      : `/i/thumb.png`;

  const videoUrl = data.video
    ? `${NEXT_PUBLIC_DATA_DOMAIN}/upload/video/${data.video}`
    : null;

  const realThumb = videoUrl ? (
    <>
      {/* <Img
        alt={data.name}
        title={data.name}
        src={imageUrl}
        className={styles.img}
        //placeholder='blur'
        width='1000'
        height='1000'
      /> */}
      <div className={styles.video}>
        <video
          poster={imageUrl}
          autoPlay={true}
          loop={true}
          muted={true}
          className={styles.video_itm}
        >
          <source src={videoUrl} type='video/mp4' />
        </video>
      </div>
    </>
  ) : (
    <Img
      alt={data.name}
      title={data.name}
      src={imageUrl}
      className={styles.img}
      //placeholder='blur'
      width='1000'
      height='1000'
    />
  );

  return (
    <div className={rootClassName} {...props}>
      <div className={thumbClassName}>{realThumb}</div>
      <div className={styles.text}>
        <div
          className={styles.title}
          dangerouslySetInnerHTML={{ __html: data.name }}
        ></div>
        {data.description != '' && (
          <div
            className={styles.description}
            dangerouslySetInnerHTML={{ __html: data.description }}
          ></div>
        )}

        {data.link.href && data.link.href != '' && (
          <div className={styles.action}>
            <Button Component='a' href={data.link.href}>
              {data.link.title}
            </Button>
          </div>
        )}

        {data.faq.length > 0 && (
          <div className={styles.faq}>
            <AccordionGroup variant='small' list={data.faq} />
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductCardPromo;
