import { prepareDate2 } from '@/utils/prepare';
import cn from 'classnames';
import { useState } from 'react';
import Button from '../Button';
import CommentAnswer from '../CommentAnswer';
import CommentModalForm from '../CommentModalForm';
import Img from '../Img';
import Modal from '../Modal';
import Stars from '../Stars';
import styles from './MeComment.module.css';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const MeComment = ({ data, token, className, ...props }) => {
	const [showWriteModal, setShowWriteModal] = useState(false);

	const rootClassName = cn(styles.root, className);
	const date = prepareDate2(data.datetime);

	const item_id = data.item.id;

	const item_data = data.item;

	const imageUrl = data.item
		? `${NEXT_PUBLIC_DATA_DOMAIN}${data.item.thumb.file}`
		: null;

	return (
		<>
			<div className={rootClassName} {...props}>
				<div className={styles.iteminfo}>
					<div className={styles.itm}>
						{imageUrl && (
							<div className={styles.itmthumb}>
								<Img
									alt={data.item.name}
									title={data.item.name}
									src={imageUrl}
									className={styles.img}
									//placeholder='blur'
									width={data.item.thumb.width}
									height={data.item.thumb.height}
								/>
							</div>
						)}

						<div className={styles.itmname}>{data.item.name}</div>
					</div>
					<div className={styles.dt}>
						<Stars rating={data.grade} />
						<div className={styles.date}>{date}</div>
					</div>
				</div>

				{/* <div>{JSON.stringify(data.list)}</div> */}
				<div className={styles.comment}>
					{/* <div className={styles.info}>
					<div className={styles.nd}>
						<Stars rating={data.grade} />
						<div className={styles.date}>{date}</div>
					</div>
					<div className={styles.author}>{data.author}</div>

					{data.from && (
						<div className={styles.from}>
							<span className={styles.fromcnt}>
								{' '}
								<CheckIcon className="w-4 h-4 text-primary" /> Товар куплен на{' '}
								<span className={styles.fromname}>{data.from.name}</span>
							</span>
						</div>
					)}
				</div> */}

					<div className={styles.textcnt}>
						{data.advantages && data.advantages.length > 1 && (
							<div className={styles.group}>
								<div className={styles.name}>Достоинства</div>
								<div
									className={styles.text}
									dangerouslySetInnerHTML={{ __html: data.advantages }}
								></div>
							</div>
						)}

						{data.flaws && data.flaws.length > 1 && (
							<div className={styles.group}>
								<div className={styles.name}>Недостатки</div>
								<div
									className={styles.text}
									dangerouslySetInnerHTML={{ __html: data.flaws }}
								></div>
							</div>
						)}

						{data.text && data.text.length > 1 && (
							<div className={styles.group}>
								<div className={styles.name}>Комментарий</div>
								<div
									className={styles.text}
									dangerouslySetInnerHTML={{ __html: data.text }}
								></div>
							</div>
						)}
						{/* <div className={styles.group}>
            <div className={styles.name}>Комментарий</div>
            <div
              className={styles.text}
              dangerouslySetInnerHTML={{ __html: data.text }}
            ></div>
          </div> */}

						{typeof data.edited != 'undefined' && !data.edited && (
							<div className={styles.group}>
								<div>
									<Button
										variant="smallgray2"
										onClick={() => setShowWriteModal(true)}
									>
										Редактировать отзыв
									</Button>
								</div>
								<Modal
									redirect={false}
									onClose={() => setShowWriteModal(false)}
									show={showWriteModal}
									title={`Написать отзыв`}
								>
									<CommentModalForm
										item_id={item_id}
										comment_id={data.id}
										item_data={item_data}
									/>
								</Modal>
							</div>
						)}

						{data.list.length > 0 && (
							<div className={styles.answers}>
								{data.list.map((el, i) => {
									return <CommentAnswer data={el} key={i} item_id={item_id} />;
								})}
							</div>
						)}
					</div>
				</div>
			</div>
		</>
	);
};

export default MeComment;
