import { ProductCard } from '@/components/ui';
import cn from 'classnames';
import styles from './MainBlockShop.module.css';

const MainBlockShop = ({ data, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  //return <div>1</div>;

  if (data.shop_items.length) {
    return (
      <div className={rootClassName} {...props}>
        <div className={styles.title}>{data.name}</div>
        <div className={styles.list}>
          {data.shop_items.map((item, index) => {
            return (
              <ProductCard className={styles.item} data={item} key={index} />
            );
          })}
        </div>
      </div>
    );
  }
  return null;
};

export default MainBlockShop;
