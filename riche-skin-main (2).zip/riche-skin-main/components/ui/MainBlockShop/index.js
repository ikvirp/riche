export { default } from './MainBlockShop';
