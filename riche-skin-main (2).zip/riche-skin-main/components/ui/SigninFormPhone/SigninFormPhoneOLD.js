import { Button, Lnk } from '@/components/ui';
import { getData } from '@/utils/fetcher';
import { ClockIcon, XMarkIcon } from '@heroicons/react/24/outline';
import cn from 'classnames';
import { signIn, signOut } from 'next-auth/react';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import InputMask from 'react-input-mask';
import { useCountdown } from 'usehooks-ts';
import styles from './SigninFormPhone.module.css';

const NEXT_PUBLIC_API_URL = process.env.NEXT_PUBLIC_API_URL;
const NEXT_PUBLIC_DATA_METRIKA_ID = process.env.NEXT_PUBLIC_DATA_METRIKA_ID;
const NEXT_PUBLIC_AUTH_MODE = process.env.NEXT_PUBLIC_AUTH_MODE;

const SigninFormPhoneOLD = ({ redirect = false, className, ...props }) => {
	const rootClassName = cn(styles.root, className);

	const router = useRouter();

	const [showPhone, setShowPhone] = useState(true);
	const [saveSms, setSaveSms] = useState(true);

	const [answerSignin, setAnswerSignin] = useState(null);
	const [formValid, setFormValid] = useState(false);
	const [phoneValid, setPhoneValid] = useState(false);

	const [realRedirect, setRealRedirect] = useState(redirect);
	const [realRedirectUrl, setRealRedirectUrl] = useState('/me');

	const [intervalValue, setIntervalValue] = useState(1000);
	const [count, { startCountdown, stopCountdown, resetCountdown }] =
		useCountdown({
			countStart: 180,
			intervalMs: intervalValue,
		});

	const smsButton =
		count > 0 ? (
			<div className="inline-flex gap-1.5 justify-center items-center w-full h-14 ">
				<ClockIcon className="w-4 h-4" />{' '}
				{`Отправить код повторно через ${count} сек`}
			</div>
		) : (
			<Button
				variant="transparent"
				size="normal"
				className="w-full h-14"
				type="button"
				onClick={() => onResend()}
			>
				Отправить код повторно
			</Button>
		);

	const {
		register,
		control,
		getValues,
		handleSubmit,
		reset,
		formState: { errors, isDirty, isValid },
	} = useForm({
		mode: 'all',
	});

	const valuesForm = getValues();

	useEffect(() => {
		const realPhone = valuesForm.phone
			? `+${valuesForm.phone.match(/\d/g).join('')}`
			: '';

		const realCode = valuesForm.code ? valuesForm.code : 0;

		if (realPhone != '' && realPhone.length == 12) {
			setPhoneValid(true);
		} else {
			setPhoneValid(false);
		}

		if (realPhone != '' && realPhone.length == 12 && realCode != 0) {
			setFormValid(true);
		} else {
			setFormValid(false);
		}
	}, [valuesForm]);

	const hOKeyUp = (code) => {
		const realPhone = valuesForm.phone
			? `${valuesForm.phone.match(/\d/g).join('')}`
			: '';

		const realCode = code ? code : 0;

		//console.log(realPhone, realCode);
		setAnswerSignin(null);
		if (code.length >= 4) {
			//console.log(true, realPhone, realCode);
			const fetchData = async () => {
				const data = await getData(`/codeauth/check`, 'POST', {
					username: realPhone,
					code: realCode,
				});
				if (data.result) {
					//alert(JSON.stringify(data));
					const fObj = {
						redirect: realRedirect, // ??? из API
						username: realPhone,
						code: realCode,
						callbackUrl: realRedirectUrl,
					};
					//alert(JSON.stringify(fObj));
					signIn('phone-login', fObj);

					//console.log(result);
				} else {
					setAnswerSignin(data.message);
				}
			};
			fetchData();
		}
	};

	const onSubmitSignin = async (data) => {
		const dt = {
			username: data.phone.match(/\d/g).join(''),
			code: data.code,
		};

		//alert(JSON.stringify(dt));

		setAnswerSignin(null);

		const fetchData = async () => {
			const data = await getData(`/codeauth/check`, 'POST', {
				username: dt.username,
				code: dt.code,
			});
			if (data.result) {
				//alert(JSON.stringify(data));
				const fObj = {
					redirect: realRedirect, // ??? из API
					username: dt.username,
					code: dt.code,
					callbackUrl: realRedirectUrl,
				};
				//alert(JSON.stringify(fObj));
				signIn('phone-login', fObj);

				//console.log(result);
			} else {
				setAnswerSignin(data.message);
			}
		};
		fetchData();

		// const result = await signIn('phone-login', {
		// 	redirect: realRedirect, // ??? из API
		// 	username: dt.username,
		// 	code: dt.code,
		// 	callbackUrl: realRedirectUrl,
		// });
	};

	const onTogglePhone = () => {
		const cur = showPhone;

		setShowPhone(!cur);
		signOut({ callbackUrl: router.asPath, redirect: false });

		if (cur) {
			//alert('send sms');

			const realPhone = formState.phone;

			//alert(realPhone);

			const fetchData = async () => {
				const data = await getData(`/codeauth/register`, 'POST', {
					phone: realPhone,
				});
				if (data) {
					setRealRedirect(true);
					setRealRedirectUrl('/me/profile');

					resetCountdown();
					startCountdown();
				}
			};
			fetchData();

			setRealRedirect(true);
			setRealRedirectUrl('/me/profile');
		} else {
			resetCountdown();
			setRealRedirect(redirect);
			setRealRedirectUrl('/me');
		}
	};

	const onReset = () => {
		setAnswerSignin(null);
		reset({ phone: '', code: '' });
		onTogglePhone();
		//setValue({ phone: '' });
	};

	const onResend = () => {
		setAnswerSignin(null);

		const realPhone = valuesForm.phone
			? `${valuesForm.phone.match(/\d/g).join('')}`
			: '';

		//alert(realPhone);

		if (realPhone != '') {
			//reset({ code: '' });
			const fetchData = async () => {
				const data = await getData(`/codeauth/register`, 'POST', {
					phone: realPhone,
				});
				if (data) {
					resetCountdown();
					startCountdown();
				}
			};
			fetchData();
		}

		//setValue({ phone: '' });
	};

	const sMessage = {
		false: (
			<div className="pb-6">
				Мы отправим на номер SMS-сообщение с кодом подтверждения.
			</div>
		),
		true: (
			<div className="pb-6">
				<div>Отправили SMS-сообщение на номер:</div>
				<div>
					<span className="text-xl">{valuesForm.phone}</span> &nbsp;
					<span
						className="underline cursor-pointer font-bold"
						onClick={() => onReset()}
					>
						Изменить
					</span>
				</div>
			</div>
		),
	};

	let activeMessage = sMessage[!showPhone];

	return (
		<div className={rootClassName} {...props}>
			{/* <div>realRedirect: {JSON.stringify(realRedirect)}</div>
			<div>realRedirectUrl: {JSON.stringify(realRedirectUrl)}</div>
			 */}
			{/* <div>valuesForm: {JSON.stringify(valuesForm)}</div>
			<div>formValid: {JSON.stringify(formValid)}</div> */}
			{activeMessage}
			{/* {count} */}

			{answerSignin && (
				<div className="mb-4 rounded-md px-3 py-2 leading-snug flex justify-between items-center bg-red-200 text-red-600">
					{answerSignin}
					<Button
						variant="action"
						aria-label="Закрыть"
						title="Закрыть"
						onClick={() => setAnswerSignin(null)}
					>
						<XMarkIcon className="w-4 h-4" />
					</Button>
				</div>
			)}

			<form
				onSubmit={handleSubmit(onSubmitSignin)}
				className="flex flex-col gap-6 "
			>
				{showPhone && (
					<>
						<div>
							<label className="text-gray-500 pb-1 px-2 block" htmlFor="phone">
								Мобильный телефон
							</label>
							<Controller
								control={control}
								name="phone"
								//defaultValue='+7 912 779-94-42'
								rules={{
									required: true,
									pattern:
										/.+(7|8).(90[0-6]|90[8-9]|91[0-9]|92[0-9]|93[0-4]|93[6-9]|941|95[0-6]|958|96[0-9]|970|971|977|978|98[0-9]|99[1-7]|999).(\d{3}).(\d{2}).(\d{2})/i,
								}}
								render={({ field: { onChange, onBlur, ref } }) => {
									return (
										<div>
											<InputMask
												className="block w-full rounded-xl bg-white border border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14 px-3"
												mask="+7 999 999-99-99"
												onBlur={onBlur}
												onChange={onChange}
												inputRef={ref}
												alwaysShowMask={true}
											/>
										</div>
									);
								}}
							/>

							{errors.username?.type === 'pattern' && (
								<div className="text-xs pt-1.5 px-2 text-red-600" role="alert">
									Не похоже на мобильный телефон
								</div>
							)}
						</div>
						<div>
							<Button
								variant="black"
								size="normal"
								className="w-full h-14"
								type="button"
								disabled={!phoneValid}
								onClick={() => onTogglePhone()}
							>
								Продолжить
							</Button>
						</div>

						<div className="font-bold">
							<label className="inline-flex items-center">
								<input
									type="checkbox"
									className="
                      w-[18px] h-[18px]
                          rounded-md
                          bg-gray-200
                          border-transparent
                          focus:border-transparent focus:bg-gray-200
                          text-black
                          focus:ring-1 focus:ring-offset-2 focus:ring-gray-500
                        "
									checked={saveSms}
									onChange={() => setSaveSms(!saveSms)}
								/>
								<span className="ml-2">
									Соглашаюсь получать новости и специальные предложения
								</span>
							</label>
						</div>
						<div>
							<div className="text-sm">
								Нажимая на кнопку Продолжить, я принимаю условия{' '}
								<Lnk
									href="/info/politika-v-otnoshenii-personalnyx-dannyx-3"
									title="Политика в отношении персональных данных"
									className="underline"
									target="_blank"
								>
									политики обработки персональных данных
								</Lnk>{' '}
								и условия{' '}
								<Lnk
									href="/info/publichnaya-oferta-2"
									title="Публичная оферта"
									className="underline"
									target="_blank"
								>
									публичной оферты
								</Lnk>
							</div>
						</div>
					</>
				)}

				{!showPhone && (
					<>
						<div>
							<label className="text-gray-500 pb-1 px-2 block" htmlFor="code">
								Код из смс
							</label>
							<input
								className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14 text-2xl"
								type="text"
								id="code"
								name="code"
								placeholder="Код из смс"
								//pattern="[0-9]*"
								inputMode="numeric"
								autoComplete="one-time-code"
								onKeyUp={(e) => {
									//console.log(e.target.value);
									hOKeyUp(e.target.value);
								}}
								{...register('code', {
									required: true,
									pattern: /^\d+$/,
								})}
							/>
							{/* {errors.code?.type === 'required' && (
						<div className="text-xs pt-1.5 px-2 text-red-600" role="alert">
							Код из смс обязателен
						</div>
					)}
					 */}
							{errors.code?.type === 'pattern' && (
								<div className="text-xs pt-1.5 px-2 text-red-600" role="alert">
									Не похоже на код из смс
								</div>
							)}
						</div>

						<div>
							<Button
								variant="black"
								size="normal"
								className="w-full h-14"
								type="submit"
								disabled={!formValid}
							>
								Войти
							</Button>
						</div>
						<div>{smsButton}</div>
					</>
				)}
			</form>
		</div>
	);
};

export default SigninFormPhoneOLD;
