import { Button, Lnk, Loader } from '@/components/ui';
import { getData } from '@/utils/fetcher';
import { ClockIcon, XMarkIcon } from '@heroicons/react/24/outline';
import cn from 'classnames';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/router';
import { useState } from 'react';
import InputMask from 'react-input-mask';
import { useCountdown } from 'usehooks-ts';
import styles from './SigninFormPhone.module.css';

const NEXT_PUBLIC_API_URL = process.env.NEXT_PUBLIC_API_URL;
const NEXT_PUBLIC_DATA_METRIKA_ID = process.env.NEXT_PUBLIC_DATA_METRIKA_ID;
const NEXT_PUBLIC_AUTH_MODE = process.env.NEXT_PUBLIC_AUTH_MODE;

const SigninFormPhone = ({ redirect = false, className, ...props }) => {
	const rootClassName = cn(styles.root, className);

	const router = useRouter();

	const [showPhone, setShowPhone] = useState(true);
	const [saveSms, setSaveSms] = useState(true);

	const [answerSignin, setAnswerSignin] = useState(null);
	const [phoneValid, setPhoneValid] = useState(false);
	const [codeValid, setCodeValid] = useState(false);

	const [realRedirect, setRealRedirect] = useState(redirect);
	const [realRedirectUrl, setRealRedirectUrl] = useState('/me');
	const [loading, setLoading] = useState(false);

	const [intervalValue, setIntervalValue] = useState(1000);
	const [count, { startCountdown, stopCountdown, resetCountdown }] =
		useCountdown({
			countStart: 120,
			intervalMs: intervalValue,
		});

	const defState = {
		phoneFull: '',
		phone: '',
		code: '',
	};

	const [formState, setFormState] = useState(defState);

	const smsButton =
		count > 0 ? (
			<div className="inline-flex gap-1.5 justify-center items-center w-full h-14 ">
				<ClockIcon className="w-4 h-4" />{' '}
				{`Отправить код повторно через ${count} сек`}
			</div>
		) : (
			<Button
				variant="transparent"
				size="normal"
				className="w-full h-14"
				type="button"
				onClick={() => onResend()}
			>
				Отправить код повторно
			</Button>
		);

	const sMessage = {
		false: (
			<div className="pb-6">
				Мы отправим на номер SMS-сообщение с кодом подтверждения.
			</div>
		),
		true: (
			<div className="pb-6">
				<div>Отправили SMS-сообщение на номер:</div>
				<div>
					<span className="text-xl">{formState.phoneFull}</span> &nbsp;
					<span
						className="underline cursor-pointer font-bold"
						onClick={() => onReset()}
					>
						Изменить
					</span>
				</div>
			</div>
		),
	};

	let activeMessage = sMessage[!showPhone];

	const fetchDataSigIn = async (phone, code) => {
		setLoading(true);
		if (code.length >= 4) {
			const data = await getData(`/codeauth/check`, 'POST', {
				username: phone,
				code: code,
			});
			if (data.result) {
				//alert(JSON.stringify(data));
				// const fObj = {
				// 	redirect: realRedirect, // ??? из API
				// 	username: phone,
				// 	password: code,
				// 	type: 'phone',
				// 	callbackUrl: realRedirectUrl,
				// };
				//alert(JSON.stringify(fObj));
				setCodeValid(true);
				setAnswerSignin(null);
				//signIn('credentials', fObj);

				const result = await signIn('credentials', {
					redirect: realRedirect, // ??? из API
					username: phone,
					password: code,
					type: 'phone',
					callbackUrl: realRedirectUrl,
				});

				if (data.new) {
					if (NEXT_PUBLIC_DATA_METRIKA_ID > 0) {
						ym(NEXT_PUBLIC_DATA_METRIKA_ID, 'reachGoal', 'NEW_USER');
					}
				}
				// if (!result.ok) {
				// 	setAnswerSignin('Неверные данные входа');
				// }

				//console.log(result);
			} else {
				setLoading(false);
				setCodeValid(false);
				setAnswerSignin(data.message);
			}
		} else {
			setLoading(false);
			setCodeValid(false);
			setAnswerSignin(null);
		}
	};

	const onChangePhone = (val) => {
		const cur = formState;
		const realPhone = val ? `${val.match(/\d/g).join('')}` : '';
		setFormState({ ...cur, phone: realPhone, phoneFull: val });
		// 79127799442
		if (realPhone.length == 11) {
			setPhoneValid(true);
		} else {
			setPhoneValid(false);
		}
	};

	const onChangeCode = (val) => {
		const cur = formState;
		const realPhone = cur.phone;
		const realCode = val;
		setFormState({ ...cur, code: realCode });
		fetchDataSigIn(realPhone, realCode);
	};

	const onSubmitPhone = () => {
		const cur = showPhone;

		setShowPhone(!cur);

		//signOut({ callbackUrl: router.asPath, redirect: false });

		if (cur) {
			//alert('send sms');

			const realPhone = formState.phone;

			//alert(realPhone);

			const fetchData = async () => {
				const data = await getData(`/codeauth/register`, 'POST', {
					phone: realPhone,
				});
				if (data) {
					setRealRedirect(true);
					setRealRedirectUrl('/me/profile');

					resetCountdown();
					startCountdown();
				}
			};
			fetchData();

			setRealRedirect(true);
			setRealRedirectUrl('/me/profile');
		} else {
			resetCountdown();
			setRealRedirect(redirect);
			setRealRedirectUrl('/me');
		}
	};

	const onReset = () => {
		setAnswerSignin(null);
		setFormState(defState);
		onTogglePhone();
		//setValue({ phone: '' });
	};

	const onResend = () => {
		setAnswerSignin(null);

		const realPhone = formState.phone;

		//alert(realPhone);

		if (realPhone != '') {
			//reset({ code: '' });
			const fetchData = async () => {
				const data = await getData(`/codeauth/register`, 'POST', {
					phone: realPhone,
				});
				if (data) {
					resetCountdown();
					startCountdown();
				}
			};
			fetchData();
		}

		//setValue({ phone: '' });
	};

	const onSubmitSignin = async () => {
		const cur = formState;
		const realPhone = cur.phone;
		const realCode = cur.code;
		fetchDataSigIn(realPhone, realCode);
	};

	return (
		<div className={rootClassName} {...props}>
			{activeMessage}

			{answerSignin && (
				<div className="mb-4 rounded-md px-3 py-2 leading-snug flex justify-between items-center bg-red-200 text-red-600">
					{answerSignin}
					<Button
						variant="action"
						aria-label="Закрыть"
						title="Закрыть"
						onClick={() => setAnswerSignin(null)}
					>
						<XMarkIcon className="w-4 h-4" />
					</Button>
				</div>
			)}

			<div className="flex flex-col gap-6">
				{/* <div>
					<div>formState: {JSON.stringify(formState)}</div>
					<div>phoneValid: {JSON.stringify(phoneValid)}</div>
					<div>codeValid: {JSON.stringify(codeValid)}</div>
					<div>count: {JSON.stringify(count)}</div>
				</div> */}
				{showPhone && (
					<form onSubmit={onSubmitPhone} className="flex flex-col gap-6">
						<div>
							<label className="text-gray-500 pb-1 px-2 block" htmlFor="phone">
								Мобильный телефон
							</label>
							<InputMask
								className="block w-full rounded-xl bg-white border border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14 px-3"
								mask="+7 999 999-99-99"
								value={formState.phoneFull}
								alwaysShowMask={true}
								onChange={(e) => {
									const val = e.target.value;
									onChangePhone(val);
								}}
							/>
						</div>
						<div>
							<Button
								variant="black"
								size="normal"
								className="w-full h-14"
								type="submit"
								disabled={!phoneValid}
								onClick={() => onSubmitPhone()}
							>
								Продолжить
							</Button>
						</div>

						<div className="font-bold">
							<label className="inline-flex items-center">
								<input
									type="checkbox"
									className="
                      w-[18px] h-[18px]
                          rounded-md
                          bg-gray-200
                          border-transparent
                          focus:border-transparent focus:bg-gray-200
                          text-black
                          focus:ring-1 focus:ring-offset-2 focus:ring-gray-500
                        "
									checked={saveSms}
									onChange={() => setSaveSms(!saveSms)}
								/>
								<span className="ml-2">
									Соглашаюсь получать новости и специальные предложения
								</span>
							</label>
						</div>
						<div>
							<div className="text-sm">
								Нажимая на кнопку Продолжить, я принимаю условия{' '}
								<Lnk
									href="/info/politika-v-otnoshenii-personalnyx-dannyx-3"
									title="Политика в отношении персональных данных"
									className="underline"
									target="_blank"
								>
									политики обработки персональных данных
								</Lnk>{' '}
								и условия{' '}
								<Lnk
									href="/info/publichnaya-oferta-2"
									title="Публичная оферта"
									className="underline"
									target="_blank"
								>
									публичной оферты
								</Lnk>
							</div>
						</div>
					</form>
				)}

				{!showPhone && (
					<form onSubmit={onSubmitSignin} className="flex flex-col gap-6">
						<div>
							<label className="text-gray-500 pb-1 px-2 block" htmlFor="code">
								Код из смс
							</label>
							<div className="relative">
								<input
									className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14 text-2xl"
									value={formState.code}
									onChange={(e) => {
										const val = e.target.value;
										onChangeCode(val);
									}}
									type="text"
									id="code"
									name="code"
									placeholder="Код из смс"
									//pattern="[0-9]*"
									inputMode="numeric"
									autoComplete="one-time-code"
								/>
								{loading && (
									<div className="absolute right-3 top-4">
										<Loader variant="cart" />
									</div>
								)}
							</div>
						</div>

						{/* <div>
							<Button
								variant="black"
								size="normal"
								className="w-full h-14"
								type="submit"
								disabled={!codeValid}
							>
								Войти
							</Button>
						</div> */}
						<div>{smsButton}</div>
					</form>
				)}
			</div>
		</div>
	);
};

export default SigninFormPhone;
