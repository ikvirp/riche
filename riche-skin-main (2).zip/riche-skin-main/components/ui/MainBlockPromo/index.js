export { default } from './MainBlockPromo';
