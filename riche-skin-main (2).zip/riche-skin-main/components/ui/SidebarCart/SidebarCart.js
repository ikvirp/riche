import {
  Button,
  CartCard,
  Loader,
  SidebarHeader,
  SiginModal,
} from '@/components/ui';
import { cart__load } from '@/store/actions/cart';
import { sidebar__close } from '@/store/actions/sidebar';
import { numberFormat } from '@/utils/prepare';
import { Transition } from '@headlessui/react';
import { ChevronRightIcon, ShoppingBagIcon } from '@heroicons/react/24/outline';
import cn from 'classnames';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useLocalStorage } from 'usehooks-ts';
import styles from './SidebarCart.module.css';

const NEXT_PUBLIC_DATA_METRIKA_ID = process.env.NEXT_PUBLIC_DATA_METRIKA_ID;

const SidebarCart = ({ className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  const router = useRouter();
  const dispatch = useDispatch();
  const { status: session_status } = useSession();
  const [showModal, setShowModal] = useState(false);
  const [cartList, setCartList] = useLocalStorage('cartList', []);
  const cartFull = useSelector((state) => state.cart);

  const [couponInputVal, setCouponInputVal] = useState('');
  const [coupon, setCoupon] = useLocalStorage('coupon', '');

  useEffect(() => {
    dispatch(cart__load(false));
  }, [dispatch, cartList]);

  const handleClickPlus = (id) => {
    const aCur = cartList ? cartList : [];

    //alert(id);

    const found = aCur.find((el) => el.id == id);

    //alert(JSON.stringify(found));

    if (found) {
      // metrika — Добавление товара в корзину
      if (NEXT_PUBLIC_DATA_METRIKA_ID > 0) {
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({
          ecommerce: {
            currencyCode: 'RUB',
            add: {
              products: [
                {
                  id: found.id,
                  name: found.name,
                  price: found.price,
                  quantity: 1,
                  group: found.group,
                },
              ],
            },
          },
        });
      }

      const filtred = aCur.filter((el) => el.id != id);
      found.quantity++;

      const aNew = [...filtred, found];

      aNew.sort(function (a, b) {
        // Turn your strings into dates, and then subtract them
        // to get a value that is either negative, positive, or zero.
        return b.timestamp - a.timestamp;
      });

      setCartList(aNew);
    }
  };
  const handleClickMinus = (id) => {
    const aCur = cartList ? cartList : [];

    const found = aCur.find((el) => el.id == id);

    if (found) {
      // metrika — Добавление товара в корзину
      if (NEXT_PUBLIC_DATA_METRIKA_ID > 0) {
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({
          ecommerce: {
            currencyCode: 'RUB',
            remove: {
              products: [
                {
                  id: found.id,
                  name: found.name,
                  price: found.price,
                  quantity: 1,
                  group: found.group,
                },
              ],
            },
          },
        });
      }

      const filtred = aCur.filter((el) => el.id != id);
      found.quantity--;

      let aNew = [];
      if (found.quantity == 0) {
        aNew = [...filtred];
      } else {
        aNew = [...filtred, found];
      }

      aNew.sort(function (a, b) {
        // Turn your strings into dates, and then subtract them
        // to get a value that is either negative, positive, or zero.
        return b.timestamp - a.timestamp;
      });

      setCartList(aNew);
    }
  };

  const handleClickCoupon = (coupon) => {
    setCoupon(couponInputVal);
    dispatch(cart__load());
  };

  useEffect(() => {
    setCouponInputVal(coupon);
  }, [coupon]);

  // return <div>{JSON.stringify(items)}</div>;

  const relItems =
    cartFull.cart.length > 0 ? (
      cartFull.cart.map((el, i) => {
        //alert(JSON.stringify(el));
        return (
          <CartCard
            data={el}
            key={i}
            actionPlus={handleClickPlus}
            actionMinus={handleClickMinus}
          />
        );
      })
    ) : (
      <>
        <div className={styles.empty}>
          <div>
            <ShoppingBagIcon className='w-16 h-16' />
          </div>
          <div>Корзина пуста</div>
        </div>
      </>
    );

  const checkoutButton =
    session_status === 'authenticated' ? (
      <Button
        className='w-full'
        aria-label='Оформить заказ'
        title='Оформить заказ'
        onClick={() => router.push('/checkout')}
      >
        Оформить заказ
      </Button>
    ) : (
      <>
        <Button
          className='w-full'
          aria-label='Авторизоваться и оформить заказ'
          title='Авторизоваться и оформить заказ'
          onClick={() => {
            if (router.asPath != '/signin') {
              setShowModal(true);
            } else {
              dispatch(sidebar__close('cart'));
            }
          }}
        >
          Авторизоваться и оформить
        </Button>
        <SiginModal show={showModal} onClose={() => setShowModal(false)} />
      </>
    );

  return (
    <div className={rootClassName} {...props}>
      <SidebarHeader>
        <div className='flex items-center gap-3'>
          <span>Корзина</span>

          <Transition
            show={cartFull.isLoading}
            enter='ease-out duration-300'
            enterFrom='opacity-0'
            enterTo='opacity-100'
            leave='ease-in duration-200'
            leaveFrom='opacity-100'
            leaveTo='opacity-0'
          >
            <Loader variant='cart' />
          </Transition>
        </div>
      </SidebarHeader>
      <div className={styles.container}>
        <div className={styles.main}>
          {/* <div>{JSON.stringify(isLoading)}</div>
          {isLoading && <span>Pfuheprf</span>} */}
          {/* <div>{JSON.stringify(couponInputVal)}</div>
          <div>{JSON.stringify(oDop)}</div> */}

          {relItems}
        </div>
        {cartFull.cart.length > 0 && cartFull.total.total_quantity > 0 && (
          <div className={styles.footer}>
            {/* <div>{JSON.stringify(cartTotal)}</div> */}
            <div className={styles.total}>
              <div className={styles.subtotal}>
                <span>{`Стоимость товаров (${numberFormat(
                  cartFull.total.total_quantity
                )})`}</span>
                <span>
                  {`${numberFormat(cartFull.total.total_amount_items)} ${
                    cartFull.total.currency
                  }`}
                </span>
              </div>

              {cartFull.total.total_discount_items > 0 && (
                <div className={styles.subtotal}>
                  <span>Скидки</span>
                  <span>
                    {`-${numberFormat(cartFull.total.total_discount_items)} ${
                      cartFull.total.currency
                    }`}
                  </span>
                </div>
              )}

              {cartFull.total.total_discount_order > 0 && (
                <div className={styles.subtotal}>
                  <span>Дополнительные скидки</span>
                  <span>
                    {`-${numberFormat(cartFull.total.total_discount_order)} ${
                      cartFull.total.currency
                    }`}
                  </span>
                </div>
              )}
            </div>

            <div className={styles.promo}>
              <input
                className={styles.input}
                type='text'
                id='promocode'
                name='promocode'
                placeholder='ПРОМОКОД'
                value={couponInputVal}
                onChange={(e) => {
                  setCouponInputVal(e.target.value);
                }}
              />
              <span className={styles.act}>
                <Button
                  variant='action'
                  aria-label='Применить промокод'
                  title='Применить промокод'
                  onClick={(e) => {
                    handleClickCoupon(e.target.value);
                  }}
                >
                  <ChevronRightIcon className='w-6 h-6' />
                </Button>
              </span>
            </div>
            <div className={styles.total}>
              <div className={styles.subtotal}>
                <span>Итого</span>
                <span>
                  {`${numberFormat(cartFull.total.total_amount)} ${
                    cartFull.total.currency
                  }`}
                </span>
              </div>
            </div>

            {checkoutButton}
          </div>
        )}

        <Transition
          show={cartFull.isLoading}
          enter='ease-out duration-300'
          enterFrom='opacity-0'
          enterTo='opacity-100'
          leave='ease-in duration-200'
          leaveFrom='opacity-100'
          leaveTo='opacity-0'
        >
          <div className='absolute inset-0 bg-white/50 z-30'></div>
        </Transition>
      </div>
    </div>
  );
};

export default SidebarCart;
