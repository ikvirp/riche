import { Lnk } from '@/components/ui';
import cn from 'classnames';
import styles from './GroupTag.module.css';

const GroupTag = ({ current, data, className, ...props }) => {
  const rootClassName = cn(
    styles.root,
    {
      [styles.active]: current == data.id,
    },
    className
  );

  const realUrl = {
    pathname: `/catalog/[slug]`,
    query: { slug: `${data.slug}` },
  };

  if (current == data.id) {
    return (
      <span
        title={data.name}
        href={realUrl}
        className={rootClassName}
        {...props}
      >
        {data.name}
      </span>
    );
  }
  return (
    <Lnk title={data.name} href={realUrl} className={rootClassName} {...props}>
      {data.name}
    </Lnk>
  );
};

export default GroupTag;
