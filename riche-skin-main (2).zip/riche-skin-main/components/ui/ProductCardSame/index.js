export { default } from './ProductCardSame';
