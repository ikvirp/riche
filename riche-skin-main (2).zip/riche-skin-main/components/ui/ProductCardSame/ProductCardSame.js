import { Img, Lnk } from '@/components/ui';
import { numberFormat } from '@/utils/prepare';
import { HeartIcon } from '@heroicons/react/24/outline';
import { HeartIcon as HeartIconSolid } from '@heroicons/react/24/solid';
import cn from 'classnames';
import { useEffect, useRef, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useHover, useLocalStorage } from 'usehooks-ts';
import styles from './ProductCardSame.module.css';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const ProductCardSame = ({ hrefPostfix = null, data, className, ...props }) => {
	const dispatch = useDispatch();

	const [favList, setFavList] = useLocalStorage('favList', []);
	const [cartList, setCartList] = useLocalStorage('cartList', []);
	const [isFav, setIsFav] = useState(null);

	useEffect(() => {
		if (favList) {
			const filtred = favList.find((el) => el == data.id);
			if (filtred) {
				setIsFav(data.id);
			}
		}
	}, [favList, data.id]);

	const hoverRef = useRef(null);
	const hoverRef2 = useRef(null);
	const isHover = useHover(hoverRef);
	const isHover2 = useHover(hoverRef2);

	const rootClassName = cn(
		styles.root,

		className,
	);

	const imageUrl = data.thumb
		? `${NEXT_PUBLIC_DATA_DOMAIN}${data.thumb.file}`
		: `/i/thumb.png`;

	const realUrl = {
		pathname: `/product/[slug]`,
		query: { slug: `${data.slug}` },
	};

	const realPrice =
		data.price.current != data.price.old ? (
			<>
				<span className={styles.pcurrent}>{`${numberFormat(
					data.price.current,
				)} ${data.price.currency}`}</span>
				<span className={styles.pold}>{`${numberFormat(data.price.old)} ${
					data.price.currency
				}`}</span>
			</>
		) : (
			<span className={styles.pcurrent}>{`${numberFormat(data.price.current)} ${
				data.price.currency
			}`}</span>
		);

	const labels =
		data.labels.length > 0 ? (
			<span className={styles.labels}>
				{data.labels.map((el, i) => {
					//const styleColor = el.color != '' ? `${el.color}` : '';
					return (
						<div key={i}>
							<span className={styles.label}>{el.name}</span>
						</div>
					);
				})}
			</span>
		) : null;

	const discount =
		data.price.current != data.price.old ? (
			<span className={styles.discount}>{`-${numberFormat(
				data.price.discount_percent,
			)}%`}</span>
		) : null;

	const heartIcon = isFav ? (
		<HeartIconSolid className="h-6 w-6 fill-red-600" />
	) : (
		<HeartIcon className="w-6 h-6" />
	);

	const postfix =
		hrefPostfix && hrefPostfix.length > 0 ? `?${hrefPostfix}` : '';

	return (
		<div className={rootClassName} {...props}>
			{/* {JSON.stringify(data.rest)} */}
			<div className={styles.main}>
				<div
					//className={cn(styles.thumb, isHover2 ? `opacity-60` : ``)}
					className={styles.thumb}
					ref={hoverRef}
				>
					<Lnk
						href={`/product/${data.slug}${postfix}`}
						className={cn(styles.link, isHover2 ? `opacity-60` : ``)}
						title={data.name}
					>
						<Img
							alt={data.name}
							title={data.name}
							src={imageUrl}
							className={styles.img}
							//placeholder='blur'
							width="350"
							height="350"
						/>
					</Lnk>
					{/* {discount} */}
					{/* {data.rest < 1 && (
            <span className='text-[10px] absolute left-1 top-1 leading-none opacity-50'>
              временно
              <br />
              недоступно
            </span>
          )} */}
				</div>

				<div className={styles.inf}>
					{/* <div className={cn(styles.price, data.rest < 1 ? 'opacity-50' : '')}>
            {realPrice}
          </div> */}
					<div className={styles.price}>{realPrice}</div>
					<div className={styles.name} ref={hoverRef2}>
						<Lnk
							href={`/product/${data.slug}${postfix}`}
							className={isHover ? `opacity-60` : ``}
							title={data.name}
						>
							{data.name}
						</Lnk>
					</div>
					{/* {data.description != '' && (
            <div
              className={styles.description}
              dangerouslySetInnerHTML={{ __html: data.description }}
            ></div>
          )} */}
				</div>
			</div>
		</div>
	);
};

export default ProductCardSame;
