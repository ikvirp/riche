export { default } from './LogoText';
