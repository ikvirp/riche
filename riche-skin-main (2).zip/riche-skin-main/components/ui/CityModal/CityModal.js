import { Modal } from '@/components/ui';
import { city_default } from '@/config/city_default';
import { getData } from '@/utils/fetcher';
import { CheckIcon } from '@heroicons/react/24/outline';
import cn from 'classnames';
import { useEffect, useState } from 'react';
import { useLocalStorage } from 'usehooks-ts';
import styles from './CityModal.module.css';

const CityModal = ({ show, onClose }) => {
  const [userCity, setUserCity] = useLocalStorage('city', city_default);

  const [query, setQuery] = useState('');
  const [items, setItems] = useState([]);

  useEffect(() => {
    setQuery('');
  }, [show]);

  useEffect(() => {
    const fetchData = async () => {
      const data = await getData(`/city/`);
      setItems(data.items);
    };
    fetchData();
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      const data = await getData(`/city/?query=${query}`);

      setItems(data.items);
    };
    fetchData();
  }, [query]);

  const rootClassName = cn(styles.root);

  const itemsList =
    items.length > 0 ? (
      <div className='flex flex-col gap-0.5'>
        {items.map((el, i) => {
          const itemClassName = cn(
            'rounded-md cursor-pointer hover:bg-gray-100 py-1.5 px-2 flex gap-2 items-center justify-between',
            {
              ['bg-gray-100 cursor-default']: el.id == userCity.id,
            }
          );

          return (
            <div
              key={i}
              className={itemClassName}
              onClick={() => {
                setUserCity(el);
                onClose();
              }}
            >
              <div>
                {el.city_name}
                <div className='text-xs text-gray-500'>{el.region_name}</div>
              </div>
              {el.id == userCity.id && <CheckIcon className='w-4 h-4' />}
            </div>
          );
        })}
      </div>
    ) : (
      <div className='text-center text-xl'>К сожалению ничего не нашлось</div>
    );

  return (
    <>
      <Modal onClose={onClose} show={show} title='Выбор города'>
        <div className='p-0 pb-3 flex flex-col gap-3'>
          <div>
            <input
              className='block w-full rounded-xl bg-gray-100 border-transparent focus:border-gray-900 focus:bg-white focus:ring-0 h-14'
              name='city'
              id='city'
              type='text'
              placeholder='Ваш город'
              onChange={(e) => setQuery(e.target.value)}
              value={query}
            />
          </div>
          {itemsList}
          {/* <div>{JSON.stringify(items)}</div> */}
        </div>
      </Modal>
    </>
  );
};

export default CityModal;
