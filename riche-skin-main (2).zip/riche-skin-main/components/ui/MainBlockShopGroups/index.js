export { default } from './MainBlockShopGroups';
