import cn from 'classnames';
import CatalogGroupCard from '../CatalogGroupCard/CatalogGroupCard';
import styles from './MainBlockShopGroups.module.css';

const MainBlockShopGroups = ({ data, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  if (data.shop_groups.length) {
    return (
      <div className={rootClassName} {...props}>
        {data.shop_groups.map((item, index) => {
          return (
            <CatalogGroupCard className={styles.item} data={item} key={index} />
          );
        })}
      </div>
    );
  }
  return null;
};

export default MainBlockShopGroups;
