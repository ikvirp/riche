import { Button, Loader, Modal } from '@/components/ui';
import { getData } from '@/utils/fetcher';
import {
	ChevronRightIcon,
	PencilSquareIcon,
	XMarkIcon,
} from '@heroicons/react/24/outline';
import { PlusCircleIcon } from '@heroicons/react/24/solid';
import cn from 'classnames';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { AddressSuggestions } from 'react-dadata';
import styles from './MeAddresses.module.css';

const defState = {
	id: null,
	city: {
		id: null,
		name: null,
	},
	postcode: null,
	address: null,
};

const MeAddresses = ({ data, token, className, ...props }) => {
	const rootClassName = cn(styles.root, className);

	const router = useRouter();

	const [showModal, setShowModal] = useState(false);
	const [obj, setObj] = useState(defState);
	const [list, setList] = useState(data);

	const [fullAddress, setFullAddress] = useState('');
	const [valAddress, setValAddress] = useState('');

	const [curCity, setCurCity] = useState(null);
	const [query, setQuery] = useState('');
	const [items, setItems] = useState([]);
	const [disabled, setDisabled] = useState(true);
	const [loading, setLoading] = useState(false);
	// const [valPostcode, setPostcode] = useState('');

	const title = !obj.id ? `Добавление адреса` : `Редактирование адреса`;

	const itemsList =
		items.length > 0 ? (
			<div className="flex flex-col gap-0.5">
				{items.map((el, i) => {
					const itemClassName = cn(
						'rounded-md cursor-pointer hover:bg-gray-100 py-1.5 px-2 flex gap-2 items-center justify-between',
					);

					return (
						<div
							key={i}
							className={itemClassName}
							onClick={() => {
								setCurCity(el);
								setQuery(el.city_name);
								setFullAddress(`${el.city_name}, ${el.region_name}`);

								//onClose();
							}}
						>
							<div>
								{el.city_name}
								<div className="text-xs text-gray-500">{el.region_name}</div>
							</div>
						</div>
					);
				})}
			</div>
		) : null;

	const onCloseAction = () => {
		setObj(defState);

		setCurCity(null);
		setFullAddress(null);
		//setIdCity(null);

		setValAddress('');

		setShowModal(false);
	};

	const onAdd = () => {
		setObj(defState);
		setShowModal(true);
	};

	const onEdit = (obj) => {
		setObj(obj);
		setShowModal(true);
	};

	const onSave = () => {
		const oObj = {
			token: token,
			address: valAddress,
			city: curCity.id,
			address_id: obj.id,
		};

		//alert(JSON.stringify(oObj));

		const fetchData2 = async () => {
			setLoading(true);
			const data = await getData(`/address_add/`, 'POST', oObj);

			//console.log(data);

			if (data) {
				router.reload();
			}
			setLoading(false);
		};
		fetchData2();
	};

	useEffect(() => {
		if (curCity && valAddress.length > 0) {
			setDisabled(false);
		} else {
			setDisabled(true);
		}
	}, [curCity, valAddress]);

	const onChangeCity = (val) => {
		setQuery(val);

		const fetchData = async () => {
			const data = await getData(`/city/?query=${query}`);

			setItems(data.items);
		};
		fetchData();
	};

	const handleInputChange = (event) => {
		setFullAddress(
			`${curCity.city_name}, ${curCity.region_name}, ${event.target.value}`,
		);
	};

	return (
		<>
			<div className={rootClassName} {...props}>
				<div className={styles.item2} onClick={() => onAdd()}>
					<div className={styles.action}>
						<PlusCircleIcon className="w-6 h-6" />
					</div>
					<div className={styles.summary}>
						<div className={styles.name}>Добавить новый адрес</div>
					</div>
					<div className={styles.action}>
						<ChevronRightIcon className="w-6 h-6" />
					</div>
				</div>

				{list.map((el, i) => {
					return (
						<div key={i} className={styles.item}>
							<div className={styles.summary}>
								<div className={styles.name}>{el.address}</div>
								<div className={styles.city}>{el.city.name}</div>
							</div>
							<div className={styles.action}>
								<Button
									variant="action"
									aria-label="Редактировать"
									title="Редактировать"
									onClick={() =>
										onEdit({
											id: el.id,
											city: {
												id: el.city.id,
												name: el.city.name,
											},
											address: el.address,
										})
									}
								>
									<PencilSquareIcon className="w-6 h-6" />
								</Button>
							</div>
						</div>
					);
				})}
			</div>

			<Modal
				redirect={false}
				onClose={() => onCloseAction()}
				show={showModal}
				title={title}
			>
				<div className="p-0 pb-3 flex flex-col gap-3">
					{/* <div>{JSON.stringify(obj)}</div>
					<hr />
					<div>curCity: {JSON.stringify(curCity)}</div>
					<div>fullAddress: {JSON.stringify(fullAddress)}</div>
					<div>valAddress: {JSON.stringify(valAddress)}</div> */}
					{/* <div>idCity: {JSON.stringify(idCity)}</div>
					<div>valCity: {JSON.stringify(valCity)}</div>
					<div>valPostcode: {JSON.stringify(valPostcode)}</div>
					<div>valAddress: {JSON.stringify(valAddress)}</div> */}

					{obj.id && (
						<>
							<div className={styles.summary}>
								<div className={styles.name}>{obj.address}</div>
								<div className={styles.city}>{obj.city.name}</div>
							</div>
							<hr />
						</>
					)}

					{/* <div>{JSON.stringify(obj)}</div> */}
					<div className="flex flex-col gap-6 ">
						{curCity && (
							<div>
								<label className="text-gray-500 pb-1  block" htmlFor="city">
									Полный адрес
								</label>
								<div className="flex items-start  gap-3">
									<div>{fullAddress}</div>
									<Button
										variant="action"
										onClick={() => {
											setCurCity(null);
											setFullAddress(null);
											setQuery('');
											setItems([]);
										}}
									>
										<XMarkIcon className="w-6 h-6" />
									</Button>
								</div>
							</div>
						)}
						{!curCity && (
							<>
								<div>
									<label
										className="text-gray-500 pb-1 px-2 block"
										htmlFor="city"
									>
										Ваш город
									</label>
									<input
										className="block w-full rounded-xl bg-gray-100 border-transparent focus:border-gray-900 focus:bg-white focus:ring-0 h-14"
										type="text"
										id="city"
										name="city"
										placeholder="ваш город"
										onChange={(e) => onChangeCity(e.target.value)}
										value={query}
									/>
								</div>

								{itemsList}
							</>
						)}

						{curCity && (
							<>
								<div>
									<label
										className="text-gray-500 pb-1 px-2 block"
										htmlFor="city"
									>
										Адрес
									</label>
									<AddressSuggestions
										token="64b75257b4ef513c8e21645a38f265759a822470"
										//value={valueData}
										count={3}
										value={valAddress}
										onChange={(e) => {
											let postalCode = '';
											if (e.data.postal_code) {
												postalCode = e.data.postal_code;
											}

											//console.log(e.data);
											//setValPostcode(postalCode);
											setValAddress(e.value);
											setFullAddress(
												`${curCity.city_name}, ${curCity.region_name}, ${e.value}`,
											);
											// setValueIndex(postalCode);
											// reset({
											// 	address: e.value,
											// });
										}}
										//ref={suggestionsRef}
										filterLocations={[{ city: curCity.city_name }]}
										filterRestrictValue={true}
										inputProps={{
											onChange: handleInputChange,
											placeholder: 'адрес',
										}}
										selectOnBlur
									/>
								</div>

								<div>
									<Button
										//variant="action"
										aria-label="Сохранить"
										title="Сохранить"
										className="w-full h-14"
										//onClick={() => alert('asdas')}
										disabled={disabled}
										onClick={() => onSave()}
									>
										{loading && <Loader variant="cart" />} Сохранить
									</Button>
								</div>
							</>
						)}
					</div>
				</div>
			</Modal>
		</>
	);
};

export default MeAddresses;
