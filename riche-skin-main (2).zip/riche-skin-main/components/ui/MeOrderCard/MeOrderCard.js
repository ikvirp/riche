import { Button, CommentModalForm, Img, Modal } from '@/components/ui';
import { getData } from '@/utils/fetcher';
import {
	num_word,
	numberFormat,
	numberFormat2,
	prepareDate,
} from '@/utils/prepare';
import cn from 'classnames';
import { useSession } from 'next-auth/react';
import { useEffect, useState } from 'react';
import styles from './MeOrderCard.module.css';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const MeOrderCard = ({ data, className, ...props }) => {
	const [realData, setRealData] = useState(data);

	const rootClassName = cn(styles.root, className);

	const date = prepareDate(realData.datetime);
	const paid = realData.paid ? `Оплачен` : `Ожидает оплаты`;
	const amount =
		realData.amount > 0
			? `${numberFormat2(realData.amount)} ${realData.currency}`
			: ``;

	const countCanComments = (items) => {
		let count = 0;

		items.forEach((element) => {
			if (element.cancomment) {
				count++;
			}
		});

		//console.log(count);

		if (count) {
			return true;
		}
		return false;
	};

	const canCommentItems = countCanComments(realData.comments.items);

	console.log(`canCommentItems: ${canCommentItems}`);

	const canCommentOrder = realData.comments.order;
	const showComment = canCommentItems || canCommentOrder ? true : false;

	const [showWriteModal, setShowWriteModal] = useState(false);
	const [itemId, setItemId] = useState(null);
	const [itemData, setItemData] = useState(null);

	useEffect(() => {
		if (realData.comments.items.length) {
			setItemId(realData.comments.items[0].id);
			setItemData(realData.comments.items[0]);
		}
	}, [realData]);

	const { data: session, status: session_status } = useSession();

	const onSend = async () => {
		if (session) {
			const repoMeOrders = await getData(`/me/orders`, 'POST', {
				token: session.token,
				guid: realData.guid,
			});
			if (repoMeOrders) {
				setRealData(repoMeOrders.orders[0]);
			}
		}
	};

	const anumClass = cn(
		styles.anum,
		realData.paid ? styles.paid : styles.nopaid,
	);

	return (
		<div className={rootClassName} {...props}>
			<a href={`/me/orders/${realData.guid}`} className="block">
				<div className={styles.summary}>
					<div className={styles.invoice}>
						<div className={styles.inumber}>{realData.invoice}</div>
						<div className={styles.idate}>{date}</div>
					</div>
					<div className={styles.amount}>
						<div className={anumClass}>{amount}</div>
						<div className={styles.apaid}>{paid}</div>
					</div>
				</div>
				<div className={styles.delivery}>
					<div className={styles.dname}>{realData.delivery.name}</div>
					<div className={styles.daddress}>{realData.address.address.full}</div>
					<div
						className={styles.dstatus}
						style={{ color: realData.status.color }}
					>
						{realData.status.name}
					</div>
				</div>
			</a>
			{showComment && (
				<div className={styles.comments}>
					{canCommentItems && (
						<Button onClick={(e) => setShowWriteModal(true)}>
							Оценить товары
						</Button>
					)}
					{canCommentOrder && <Button variant="gray">Оценить заказ</Button>}

					{/* <div>{JSON.stringify(showComment)}</div>
					<div>{JSON.stringify(data.comments)}</div> */}

					<Modal
						redirect={false}
						onClose={() => {
							onSend();
							setShowWriteModal(false);
						}}
						show={showWriteModal}
						title={`Написать отзыв`}
					>
						<div className="flex flex-col gap-1.5 pb-6">
							<div className="">
								{`${numberFormat(realData.comments.items.length)} ${num_word(
									realData.comments.items.length,
									['товар', 'товара', 'товаров'],
								)} ждут вашей оценки`}
							</div>
							<div className={styles.list}>
								{realData.comments.items.map((el, i) => {
									const imageUrl = el.thumb
										? `${NEXT_PUBLIC_DATA_DOMAIN}${el.thumb.file}`
										: `/i/thumb.png`;

									const itemClass = cn(
										el.id == itemId
											? 'border p-[1px] rounded-xl border-primary '
											: 'border p-[1px] border-transparent rounded-xl cursor-pointer hover:opacity-60 transition-all',
									);

									return (
										<div
											key={i}
											className={itemClass}
											onClick={() => {
												if (el.id != itemId) {
													setItemId(el.id);
													setItemData(el);
												}
											}}
										>
											<Img
												alt={el.name}
												title={el.name}
												src={imageUrl}
												className="rounded-md w-16 h-16 "
												//placeholder='blur'
												width="350"
												height="350"
											/>
										</div>
									);
								})}
							</div>
						</div>
						<CommentModalForm
							item_id={itemId}
							item_data={itemData}
							onSend={onSend}
						/>
					</Modal>
				</div>
			)}
		</div>
	);
};

export default MeOrderCard;
