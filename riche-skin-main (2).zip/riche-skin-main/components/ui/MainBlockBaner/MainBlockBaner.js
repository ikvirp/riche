import { Button, Img, Lnk } from '@/components/ui';
import cn from 'classnames';
import styles from './MainBlockBaner.module.css';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const MainBlockBaner = ({ data, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  const imageUrl = data.thumb
    ? `${NEXT_PUBLIC_DATA_DOMAIN}${data.thumb.file}`
    : `/i/thumb.png`;

  const actionLink =
    data.link && data.link != '' ? (
      <div className={styles.action}>
        <Button Component='a' href={data.link} title={data.name}>
          {data.name}
        </Button>
      </div>
    ) : null;

  let aImages = [];
  if (data?.media[0]?.original) {
    aImages.push(data.media[0].original);
  }
  if (data?.media[0]?.thumb) {
    aImages.push(data.media[0].thumb);
  }

  const imagesShow =
    aImages.length > 0
      ? aImages.map((el, i) => {
          const imageUrl = el.file
            ? `${NEXT_PUBLIC_DATA_DOMAIN}${el.file}`
            : null;

          const wh = el.file
            ? {
                width: el.width,
                height: el.height,
              }
            : null;

          if (data.link && data.link != '') {
            return (
              <Lnk
                href={data.link}
                className={styles.link}
                title={data.name}
                key={i}
              >
                <Img
                  alt={data.name}
                  title={data.name}
                  src={imageUrl}
                  className={styles.img}
                  //placeholder='blur'
                  width={wh.width}
                  height={wh.height}
                  priority
                />
              </Lnk>
            );
          } else {
            return (
              <Img
                alt={data.name}
                title={data.name}
                src={imageUrl}
                className={styles.img}
                //placeholder='blur'
                width={wh.width}
                height={wh.height}
                key={i}
                priority
              />
            );
          }
        })
      : null;

  return (
    <div className={rootClassName} {...props}>
      {aImages.length > 0 > 0 && (
        <div className={styles.thumb}>{imagesShow}</div>
      )}

      <div className={styles.part}>
        <div
          className={styles.text}
          dangerouslySetInnerHTML={{ __html: data.description }}
        ></div>
        {actionLink}
      </div>
    </div>
  );
};

export default MainBlockBaner;
