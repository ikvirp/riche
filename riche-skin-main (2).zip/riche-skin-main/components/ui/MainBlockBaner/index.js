export { default } from './MainBlockBaner';
