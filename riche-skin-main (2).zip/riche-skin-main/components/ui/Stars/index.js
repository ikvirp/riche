export { default } from './Stars';
