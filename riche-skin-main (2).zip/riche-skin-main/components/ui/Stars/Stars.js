import { StarIcon } from '@heroicons/react/24/outline';
import { StarIcon as StarIconSolid } from '@heroicons/react/24/solid';
import cn from 'classnames';
import styles from './Stars.module.css';

const Stars = ({ rating, variant, className, ...props }) => {
  const rootClassName = cn(styles.root, className);
  const starClassName = cn(styles.star, { [styles.small]: variant == 'sm' });

  const fullStars = Math.floor(rating);
  const halfStars = Math.round(rating) - fullStars;
  const emptyStars = 5 - fullStars - halfStars;
  const stars = [];

  const howFull = parseInt((rating - fullStars) * 100);
  const howEmpty = 100 - howFull;

  for (let i = 0; i < fullStars; i++) {
    stars.push(<StarIconSolid className={starClassName} key={i} />);
  }

  for (let i = 0; i < halfStars; i++) {
    const starHalf = (
      <span className={cn(starClassName, styles.half)} key={i + fullStars}>
        <i className={styles.solid} style={{ width: `${howFull}%` }}>
          <StarIconSolid className={starClassName} />
        </i>
        <i className={styles.outline} style={{ width: `${howEmpty}%` }}>
          <StarIcon className={starClassName} />
        </i>
      </span>

      // <span className={cn(starClassName, styles.half)} key={i + fullStars}>
      //   <i className={styles.solid}>
      //     <StarIconSolid className={starClassName} />
      //   </i>
      //   <i className={styles.outline}>
      //     <StarIcon className={starClassName} />
      //   </i>
      // </span>
    );

    stars.push(starHalf);
  }

  for (let i = 0; i < emptyStars; i++) {
    stars.push(
      <StarIcon className={starClassName} key={i + fullStars + halfStars} />
    );
  }

  return (
    <div className={rootClassName} {...props}>
      {/* <div>
        <div>fullStars: {fullStars}</div>
        <div>halfStars: {halfStars}</div>
        <div>emptyStars: {emptyStars}</div>
        <div>howHalf: {howFull}</div>
        <div>howUnHalf: {howEmpty}</div>
      </div> */}
      {stars}
    </div>
  );
};

export default Stars;
