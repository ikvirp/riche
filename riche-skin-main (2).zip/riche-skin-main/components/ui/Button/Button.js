import { Lnk } from '@/components/ui';
import cn from 'classnames';
import styles from './Button.module.css';

const Button = ({
	className,
	variant = null,
	size = null,
	children,
	disabled = false,
	style = {},
	Component = 'button',
	badge = null,
	...props
}) => {
	const rootClassName = cn(
		styles.root,
		{
			[styles.action]: variant === 'action',
			[styles.gray]: variant === 'gray',
			[styles.round]: variant === 'round',
			[styles.roundbig]: variant === 'roundbig',
			[styles.product]: variant === 'product',
			[styles.productpage]: variant === 'productpage',
			[styles.cookie]: variant === 'cookie',
			[styles.white]: variant === 'white',
			[styles.transparent]: variant === 'transparent',
			[styles.transparentgray]: variant === 'transparentgray',
			[styles.smallgray]: variant === 'smallgray',
			[styles.smallgray2]: variant === 'smallgray2',
			[styles.smalltransparent]: variant === 'smalltransparent',
			[styles.disabled]: disabled,
		},
		{
			[styles.normal]: size === 'normal',
		},
		className,
	);

	if (Component == 'a') {
		return (
			<Lnk {...props} className={rootClassName}>
				{children}
				{parseInt(badge) > 0 && <span className={styles.badge}>{badge}</span>}
			</Lnk>
		);
	}

	return (
		<Component className={rootClassName} disabled={disabled} {...props}>
			{children}
			{parseInt(badge) > 0 && <span className={styles.badge}>{badge}</span>}
		</Component>
	);
};

export default Button;
