export { default } from './Lnk';
