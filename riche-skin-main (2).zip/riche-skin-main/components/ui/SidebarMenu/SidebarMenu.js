import { IconTg, IconVk, IconYt } from '@/components/icons';
import {
  Button,
  CityModal,
  Lnk,
  Logo,
  SidebarHeader,
  SiginModal,
} from '@/components/ui';
import { city_default } from '@/config/city_default';
import config from '@/config/root.json';
import { sidebar__close } from '@/store/actions/sidebar';
import {
  MapPinIcon,
  QuestionMarkCircleIcon,
} from '@heroicons/react/24/outline';
import cn from 'classnames';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useReadLocalStorage } from 'usehooks-ts';
import styles from './SidebarMenu.module.css';

const SidebarMenu = ({ menu = null, groups = null, className, ...props }) => {
  menu.sort((a, b) => a.sorting - b.sorting);
  groups.sort((a, b) => a.sorting - b.sorting);

  const dispatch = useDispatch();

  const rootClassName = cn(styles.root, className);

  const router = useRouter();
  const { status: session_status } = useSession();
  const [showModal, setShowModal] = useState(false);

  const userCityLocal = useReadLocalStorage('city');
  const [userCity, setUserCity] = useState(city_default);

  useEffect(() => {
    userCityLocal && setUserCity(userCityLocal);
  }, [userCityLocal]);

  const [showModalCity, setShowModalCity] = useState(false);

  const cityItem = userCity ? (
    <div className={styles.item}>
      <div
        className={styles.city}
        title={userCity.city_name}
        onClick={() => setShowModalCity(true)}
      >
        <MapPinIcon className='w-6 h-6' />
        <span>{userCity.city_name}</span>

        <CityModal
          show={showModalCity}
          onClose={() => setShowModalCity(false)}
        />
      </div>
    </div>
  ) : null;

  const groupItems = !groups
    ? null
    : groups.map((el, i) => {
        return (
          <div className={styles.item} key={i}>
            <Lnk
              href={`/catalog/${el.slug}`}
              className={styles.link}
              title={el.name}
            >
              {el.name}
            </Lnk>
          </div>
        );
      });

  const menuItems = !menu
    ? null
    : menu.map((el, i) => {
        if (el.in_sidebar) {
          return (
            <div className={styles.item} key={i}>
              <Lnk href={`${el.slug}`} className={styles.link} title={el.name}>
                {el.name}
              </Lnk>
            </div>
          );
        }
      });

  const profileButton =
    session_status === 'authenticated' ? (
      <Button
        className='w-full'
        aria-label='Мой профиль'
        title='Мой профиль'
        Component='a'
        href='/me'
        // onClick={(e) => {
        //   e.preventDefault();
        //   router.push('/me');
        // }}
      >
        Мой профиль
      </Button>
    ) : (
      <>
        <Button
          className='w-full'
          aria-label='Мой профиль'
          title='Мой профиль'
          onClick={() => {
            if (router.asPath != '/signin') {
              setShowModal(true);
            } else {
              dispatch(sidebar__close('menu'));
            }
          }}
        >
          Мой профиль
        </Button>
        <SiginModal show={showModal} onClose={() => setShowModal(false)} />
      </>
    );

  return (
    <div className={rootClassName} {...props}>
      <SidebarHeader>
        <Logo />
      </SidebarHeader>
      <div className={styles.container}>
        <div className={styles.main}>
          {cityItem}
          {groupItems}
          {menuItems}
        </div>
        <div className={styles.footer}>
          {profileButton}
          <div className={styles.bb}>
            <div className={styles.phone}>
              <Lnk
                href={`tel:${config.phone.tel}`}
                title={`Позвонить ${config.phone.tel}`}
              >
                {config.phone.value}
              </Lnk>
            </div>
            <div dangerouslySetInnerHTML={{ __html: config.work_hours }}></div>
          </div>
          <div className={styles.bb2}>
            <Button
              variant='gray'
              Component='a'
              href='/info'
              title='Покупателям'
              className='py-4'
            >
              <QuestionMarkCircleIcon className='w-6 h-6' /> Покупателям
            </Button>
            <div className={styles.social}>
              <Button
                variant='round'
                Component='a'
                href='https://vk.com/richescrub'
                target='_blank'
                rel='nofollow noopener'
                aria-label='RICHE во вКонтакте'
                title='RICHE во вКонтакте'
              >
                <IconVk />
              </Button>
              <Button
                variant='round'
                Component='a'
                href='https://t.me/richeskin'
                target='_blank'
                rel='nofollow noopener'
                aria-label='RICHE в Телеграм'
                title='RICHE в Телеграм'
              >
                <IconTg />
              </Button>
              {/* <Button
                variant='round'
                Component='a'
                href='https://www.youtube.com/@RICHEME'
                target='_blank'
                rel='nofollow noopener'
                aria-label='RICHE на Youtube'
                title='RICHE на Youtube'
              >
                <IconYt />
              </Button> */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SidebarMenu;
