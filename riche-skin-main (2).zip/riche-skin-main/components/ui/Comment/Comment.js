import { Stars } from '@/components/ui';
import { prepareDate } from '@/utils/prepare';
import cn from 'classnames';
import Image from 'next/image';
import styles from './Comment.module.css';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const Comment = ({ canThumb, data, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  const date = prepareDate(data.datetime);

  const imageUrl = data.from
    ? `${NEXT_PUBLIC_DATA_DOMAIN}${data.from.image}`
    : null;

  return (
    <div className={rootClassName} {...props}>
      <div className={styles.comment}>
        <div className={styles.info}>
          <div className={styles.nd}>
            <div className={styles.author}>{data.author}</div>
            <div className={styles.date}>{date}</div>
          </div>
          <div>
            <Stars rating={data.grade} />
          </div>
          {data.from && imageUrl && (
            <div className={styles.image}>
              <Image
                src={imageUrl}
                className={styles.img}
                title={`Источник отзыва: ${data.from.name}`}
                alt={`Источник отзыва: ${data.from.name}`}
                fill
              />
            </div>
          )}
        </div>

        <div
          className={styles.text}
          dangerouslySetInnerHTML={{ __html: data.text }}
        ></div>
      </div>
      {/* <div className={styles.thumbs}>
        <div className={styles.info}></div>
        <div className={styles.text2}>
          <div className='text-xs text-gray-500'>Вам помог этот отзыв?</div>
          <div className={styles.action}>
            <Button variant='smallgray'>{`Да 0`}</Button>
            <Button variant='smallgray'>{`Нет 0`}</Button>

            {JSON.stringify(canThumb)}
          </div>
        </div>
      </div> */}
    </div>
  );
};

export default Comment;
