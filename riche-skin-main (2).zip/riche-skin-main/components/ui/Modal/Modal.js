import { Button } from '@/components/ui';
import { Dialog, Transition } from '@headlessui/react';
import { XMarkIcon } from '@heroicons/react/24/outline';
import cn from 'classnames';
import { Fragment } from 'react';

const variantClass = {
  map: {
    content: 'p-0 md:p-3 h-full',
    dialog: 'max-w-full md:rounded-2xl p-3 md:p-6',
  },
  standart: {
    content: 'max-w-xl p-3',
    dialog: 'rounded-2xl p-6',
  },
};

const Modal = ({
  show = false,
  onClose,
  title = null,
  description = null,
  children,
  className = 'max-w-xl',
  variant = 'standart',
  ...props
}) => {
  let varClasses = variantClass[variant];

  return (
    <Transition appear show={show} as={Fragment}>
      <Dialog as='div' className='relative z-modal ' onClose={onClose}>
        <Transition.Child
          as={Fragment}
          enter='ease-out duration-300'
          enterFrom='opacity-0'
          enterTo='opacity-100'
          leave='ease-in duration-200'
          leaveFrom='opacity-100'
          leaveTo='opacity-0'
        >
          <div className='fixed inset-0 bg-black bg-opacity-25' />
        </Transition.Child>

        <div className='fixed inset-0 overflow-y-auto'>
          <div
            className={cn(
              // 'flex min-h-full items-center justify-center  text-center',
              'flex min-h-full items-center justify-center  text-center mx-auto',
              varClasses.content
            )}
          >
            <Transition.Child
              as={Fragment}
              enter='ease-out duration-300'
              enterFrom='opacity-0 scale-95'
              enterTo='opacity-100 scale-100'
              leave='ease-in duration-200'
              leaveFrom='opacity-100 scale-100'
              leaveTo='opacity-0 scale-95'
            >
              <Dialog.Panel
                className={cn(
                  'w-full  transform overflow-hidden  bg-white  text-left align-middle shadow-xl transition-all',
                  varClasses.dialog
                )}
              >
                <Dialog.Title className='p-0 pb-4 m-0 flex justify-between shrink-0'>
                  {title}

                  <Button
                    variant='action'
                    aria-label='Закрыть'
                    title='Закрыть'
                    onClick={onClose}
                  >
                    <XMarkIcon className='w-6 h-6' />
                  </Button>
                </Dialog.Title>
                {description && (
                  <Dialog.Description>{description}</Dialog.Description>
                )}
                {children}
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition>
  );
};

export default Modal;
