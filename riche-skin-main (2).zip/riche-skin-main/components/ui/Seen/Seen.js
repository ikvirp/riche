import { Content } from '@/components/common';
import { ProductCardSeen } from '@/components/ui';
import { getData } from '@/utils/fetcher';
import { parseSlug } from '@/utils/prepare';
import cn from 'classnames';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { useLocalStorage } from 'usehooks-ts';
import styles from './Seen.module.css';

const Seen = ({ className, ...props }) => {
  const rootClassName = cn(styles.root, className);
  const router = useRouter();

  const [seenList, setSeenList] = useLocalStorage('seenList', []);
  const [pagelist, setPageList] = useState([]);

  useEffect(() => {
    const url = router.asPath;
    const preUrl = url.substr(1);
    if (preUrl.length) {
      const aUrl = preUrl.split('/');

      const oView = {
        type: null,
        id: 0,
      };

      if (aUrl.length == 2 && aUrl[0] == 'product') {
        oView.type = 'shop';
      }

      if (aUrl.length == 2 && aUrl[0] == 'blog') {
        oView.type = 'info';
      }

      if (oView.type) {
        const id = parseSlug(aUrl[1]);
        if (id) {
          // push view in CMS
          oView.id = id;
          const fetchData = async () => {
            const repoView = await getData(`/view/`, 'POST', oView);

            if (oView.type == 'shop') {
              const filtred = seenList.filter((el) => el.id != repoView.id);

              const obj = {
                id: repoView.id,
                name: repoView.name,
                slug: repoView.slug,
                thumb: repoView.thumb,
              };

              const aNew = [...filtred, obj];
              //let popped = aNew.pop();
              const reversed = aNew.reverse();

              const reversedShort = reversed.slice(0, 20);

              setSeenList(reversedShort);
            }
          };
          // call the function
          fetchData()
            // make sure to catch any error
            .catch(console.error);
        }
      }
    }
  }, [router]);

  useEffect(() => {
    setPageList(seenList);
  }, [seenList]);

  if (pagelist.length > 0) {
    return (
      <Content>
        <div className={rootClassName} {...props}>
          <div className={styles.title}>Недавно смотрели</div>
          <div className={styles.list}>
            {pagelist.map((el, i) => (
              <ProductCardSeen data={el} key={i} />
            ))}
          </div>
        </div>
      </Content>
    );
  }

  return null;
};

export default Seen;
