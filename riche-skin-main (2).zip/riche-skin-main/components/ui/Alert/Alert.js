import { XMarkIcon } from '@heroicons/react/24/outline';
import cn from 'classnames';
import { useState } from 'react';
import Button from '../Button/Button';
import styles from './Alert.module.css';

const Alert = ({
  variant,
  children,
  close,
  active = false,
  className,
  ...props
}) => {
  const rootClassName = cn(
    styles.root,
    {
      [styles.danger]: variant == 'danger',
      [styles.info]: variant == 'info',
      [styles.success]: variant == 'success',
    },
    className
  );

  const [show, setShow] = useState(active);

  if (show) {
    return (
      <div className={rootClassName} {...props}>
        {children}
        {close && (
          <Button
            variant='action'
            aria-label='Закрыть'
            title='Закрыть'
            onClick={() => setShow(null)}
          >
            <XMarkIcon className='w-4 h-4' />
          </Button>
        )}
      </div>
    );
  }

  return null;
};

export default Alert;
