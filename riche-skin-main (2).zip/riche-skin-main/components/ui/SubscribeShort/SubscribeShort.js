import useR46Subscription from '@/components/r46/useR46Subscription';
import { Button, Lnk } from '@/components/ui';
import cn from 'classnames';
import Image from 'next/image';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import styles from './SubscribeShort.module.css';

const SubscribeShort = ({ className, ...props }) => {
	const rootClassName = cn(styles.root, className);

	const { r46Active, manageSubscription } = useR46Subscription();

	const obj = {
		email: null,
		result: false,
	};

	const [loading, isLoading] = useState(false);
	const [answerEmail, setAnswerEmail] = useState(obj);

	const {
		register: registerEmail,
		handleSubmit: handleSubmitEmail,
		formState: {
			errors: errorsEmail,
			isDirty: isDirtyEmail,
			isValid: isValidEmail,
		},
	} = useForm({
		mode: 'all',
	});

	const onSubmitEmail = async (data) => {
		setAnswerEmail(obj);
		isLoading(true);

		const oObjR46 = {
			email: data.email,
			//phone: "+100000000000",
			email_bulk: true,
			email_chain: true,
			//email_transactional: true,
			//sms_bulk: true,
			//sms_chain: true,
			//sms_transactional: true,
		};
		manageSubscription(oObjR46);

		// const res = await getData(`/subscribe/`, 'POST', {
		// 	email: data.email,
		// });
		// setAnswerEmail({ ...res });
		// if (!res.ok) {
		// 	setAnswerEmail({ ...res, showalert: true });
		// }

		setAnswerEmail({ email: data.email, result: true });
		isLoading(false);
	};

	if (answerEmail.email && answerEmail.result) {
		return (
			<div className="px-0 lg:px-10 pt-24 ">
				<div
					className="bg-gray-100 p-6 rounded-xl flex flex-col justify-between items-center lg:block overflow-hidden relative"
					{...props}
				>
					<div className="text-center text-lg">
						🥳 Ура! Ваш емаил ({answerEmail.email}) — подписан на рассылку
					</div>
				</div>
			</div>
		);
	}
	return (
		<div className="px-0 lg:px-10 pt-24">
			<div className={rootClassName} {...props}>
				<div className={styles.img}>
					<Image
						width={600}
						height={600}
						src="/i/subscribe.png"
						alt=""
						title=""
					/>
				</div>
				<form
					onSubmit={handleSubmitEmail(onSubmitEmail)}
					className="flex flex-col items-center  lg:flex-row lg:items-center  lg:justify-between gap-6  p-6 pb-0 lg:px-12 lg:pb-6 z-20 relative"
				>
					<div className="max-w-[340px] text-center lg:text-left">
						<div className="flex flex-col gap-2">
							<div className="text-2xl font-bold">
								Новинки, акции и&nbsp;эксклюзивный контент
							</div>
							<div>
								Подпишитесь на&nbsp;рассылку от&nbsp;RICHE и&nbsp;читайте самое
								интересное
							</div>
						</div>
					</div>
					<div className="max-w-[300px] flex flex-col gap-3">
						<div>
							<input
								className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 text-center  focus:bg-white focus:ring-0 h-12"
								type="email"
								id="email"
								name="email"
								placeholder="ваша@эл.почта"
								{...registerEmail('email', {
									required: true,
									pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
								})}
							/>
						</div>

						<div>
							<Button
								variant="black"
								size="normal"
								className="w-full h-12"
								type="submit"
								//disabled={!isValidEmail}
							>
								Подписаться
							</Button>
						</div>
						<div className="text-xs text-center">
							Нажимая «Подписаться», вы соглашаетесь с&nbsp;
							<Lnk
								href="/info/politika-v-otnoshenii-personalnyx-dannyx-3"
								className="underline"
							>
								политикой конфиденциальности
							</Lnk>
						</div>
					</div>
				</form>

				{/* {answerEmail.email && <div>{answerEmail.result ? 'yes' : 'no'}</div>}
      <div></div> */}
			</div>
		</div>
	);
};

export default SubscribeShort;
