export { default } from './ProductCardCatalogList';
