import { ProductCard } from '@/components/ui';
import cn from 'classnames';
import styles from './ProductCardCatalogList.module.css';

const ProductCardCatalogList = ({ title, items, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  if (items.length) {
    return (
      <div className={rootClassName} {...props}>
        {title && title.length > 0 && (
          <div className={styles.title}>{title}</div>
        )}
        {!title && (
          <div className={styles.title}>
            <i className='font-accent'>Вам</i> понравиться
          </div>
        )}

        <div className={styles.list}>
          {items.map((item, index) => {
            return (
              <ProductCard className={styles.item} data={item} key={index} />
            );
          })}
        </div>
      </div>
    );
  }

  return null;
};

export default ProductCardCatalogList;
