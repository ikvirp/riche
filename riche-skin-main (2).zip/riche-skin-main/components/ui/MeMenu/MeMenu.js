import { Lnk } from '@/components/ui';
import cn from 'classnames';
import { signOut } from 'next-auth/react';
import styles from './MeMenu.module.css';

const MeMenu = ({ className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  const items = [
    {
      name: 'Кабинет',
      slug: '/me',
    },
    {
      name: 'История заказов',
      slug: '/me/orders',
    },
    {
      name: 'Мои данные',
      slug: '/me/profile',
    },
  ];

  return (
    <nav className={rootClassName} {...props}>
      {items.map((el, i) => {
        return (
          <div key={i} className={styles.item}>
            <Lnk href={el.slug} title={el.name}>
              {el.name}
            </Lnk>
          </div>
        );
      })}
      <div className={styles.item}>
        <Lnk
          href='/'
          title='Выйти'
          onClick={(e) => {
            e.preventDefault();
            signOut({ callbackUrl: `/`, redirect: true });
          }}
        >
          Выйти
        </Lnk>
      </div>
    </nav>
  );
};

export default MeMenu;
