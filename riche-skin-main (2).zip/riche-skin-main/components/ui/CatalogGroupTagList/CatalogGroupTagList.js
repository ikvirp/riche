import { GroupTag } from '@/components/ui';
import cn from 'classnames';
import styles from './CatalogGroupTagList.module.css';

const CatalogGroupTagList = ({ current, items, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  if (items.length) {
    items.sort((a, b) => a.sorting - b.sorting);

    return (
      <div className={rootClassName} {...props}>
        {items.map((item, index) => {
          return (
            <GroupTag
              className={styles.gt}
              data={item}
              key={index}
              current={current}
            />
          );
        })}
      </div>
    );
  }

  return null;
};

export default CatalogGroupTagList;
