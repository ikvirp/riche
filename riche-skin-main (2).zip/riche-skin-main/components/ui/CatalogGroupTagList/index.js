export { default } from './CatalogGroupTagList';
