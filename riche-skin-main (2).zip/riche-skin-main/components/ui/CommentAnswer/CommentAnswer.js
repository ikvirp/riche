import { CommentAction } from '@/components/ui';
import { prepareDate2 } from '@/utils/prepare';
import { CheckBadgeIcon } from '@heroicons/react/24/solid';
import cn from 'classnames';
import styles from './CommentAnswer.module.css';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const CommentAnswer = ({ item_id, data, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  const date = prepareDate2(data.datetime);

  const imageUrl = data.from
    ? `${NEXT_PUBLIC_DATA_DOMAIN}${data.from.image}`
    : null;

  const author =
    data.author == '' ? (
      <span className={styles.riche}>
        RICHE <CheckBadgeIcon className='w-4 h-4 text-primary' />
      </span>
    ) : (
      data.author
    );

  return (
    <>
      <div className={rootClassName} {...props}>
        {/* {JSON.stringify(item_id)} */}
        {/* <div>{JSON.stringify(data)}</div> */}
        <div className={styles.comment}>
          <div className={styles.info}>
            <div className={styles.author}>{author}</div>
            <div className={styles.date}>{date}</div>
          </div>

          <div className={styles.textcnt}>
            <div className={styles.group}>
              <div
                className={styles.text}
                dangerouslySetInnerHTML={{ __html: data.text }}
              ></div>
            </div>

            <div className={styles.group}>
              {/* <div className={styles.name}>Вам помог этот отзыв?</div> */}
              <CommentAction data={data.vote} id={data.id} item_id={item_id} />
            </div>
          </div>
        </div>
      </div>
      {data.list.length > 0 && (
        <div className={styles.answers}>
          {data.list.map((el, i) => {
            return <CommentAnswer data={el} key={i} item_id={item_id} />;
          })}
        </div>
      )}
    </>
  );
};

export default CommentAnswer;
