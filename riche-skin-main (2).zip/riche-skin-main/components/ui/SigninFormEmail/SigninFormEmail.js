import { Button, Lnk } from '@/components/ui';
import { getData } from '@/utils/fetcher';
import { Tab } from '@headlessui/react';
import { EyeIcon, EyeSlashIcon, XMarkIcon } from '@heroicons/react/24/outline';
import cn from 'classnames';
import { signIn } from 'next-auth/react';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import styles from './SigninFormEmail.module.css';

const NEXT_PUBLIC_API_URL = process.env.NEXT_PUBLIC_API_URL;
const NEXT_PUBLIC_DATA_METRIKA_ID = process.env.NEXT_PUBLIC_DATA_METRIKA_ID;
const NEXT_PUBLIC_AUTH_MODE = process.env.NEXT_PUBLIC_AUTH_MODE;

const SigninFormEmail = ({ redirect = false, className, ...props }) => {
	const rootClassName = cn(styles.root, className);

	const [showPass, setShowPass] = useState(false);

	const eyeIcon = !showPass ? (
		<EyeIcon className="w-6 h-6" />
	) : (
		<EyeSlashIcon className="w-6 h-6" />
	);

	const [answerSignin, setAnswerSignin] = useState(null);
	const [answerSignup, setAnswerSignup] = useState(null);
	const [answerRestore, setAnswerRestore] = useState(null);

	const {
		register,
		handleSubmit,
		formState: { errors, isDirty, isValid },
	} = useForm({
		mode: 'all',
	});

	const {
		register: register2,
		handleSubmit: handleSubmit2,
		formState: { errors: errors2, isDirty: isDirty2, isValid: isValid2 },
	} = useForm({
		mode: 'all',
	});

	const {
		register: register3,
		handleSubmit: handleSubmit3,
		formState: { errors: errors3, isDirty: isDirty3, isValid: isValid3 },
	} = useForm({
		mode: 'all',
	});

	const onSubmitSignin = async (data) => {
		setAnswerSignin(null);
		const result = await signIn('credentials', {
			redirect: redirect,
			username: data.username,
			password: data.password,
			type: 'email',
			callbackUrl: '/me',
		});
		if (!result.ok) {
			setAnswerSignin('Неверные данные входа');
		}
	};

	const onSubmitSignup = async (data) => {
		setAnswerSignin(null);

		const result = await getData(`/signup/`, 'POST', {
			username: data.usernamenew,
		});

		if (NEXT_PUBLIC_DATA_METRIKA_ID > 0) {
			ym(NEXT_PUBLIC_DATA_METRIKA_ID, 'reachGoal', 'NEW_USER');
		}

		if (result.message) {
			setAnswerSignup(`${result.message} (${result.request.username})`);
		}
	};

	const onSubmitRestore = async (data) => {
		setAnswerRestore(null);

		const result = await getData(`/restore/`, 'POST', {
			username: data.usernamerestore,
		});
		// alert(JSON.stringify({ username: signupValues.username }));
		//alert(JSON.stringify(result));

		if (result.message) {
			setAnswerRestore(`${result.message} (${result.request.username})`);
		}
	};

	return (
		<div className={rootClassName} {...props}>
			<Tab.Group>
				<Tab.List className={styles.list}>
					<Tab
						className={({ selected }) =>
							cn(styles.tab, selected ? styles.active : '')
						}
					>
						Авторизация
					</Tab>
					<Tab
						className={({ selected }) =>
							cn(styles.tab, selected ? styles.active : '')
						}
					>
						Регистрация
					</Tab>
					<Tab
						className={({ selected }) =>
							cn(styles.tab, selected ? styles.active : '')
						}
					>
						Напомнить пароль
					</Tab>
				</Tab.List>
				<Tab.Panels>
					<Tab.Panel className={styles.panel}>
						{answerSignin && (
							<div className="mb-4 rounded-md px-3 py-2 leading-snug flex justify-between items-center bg-red-200 text-red-600">
								{answerSignin}
								<Button
									variant="action"
									aria-label="Закрыть"
									title="Закрыть"
									onClick={() => setAnswerSignin(null)}
								>
									<XMarkIcon className="w-4 h-4" />
								</Button>
							</div>
						)}

						<form
							onSubmit={handleSubmit(onSubmitSignin)}
							className="flex flex-col gap-6 "
						>
							<div>
								<label
									className="text-gray-500 pb-1 px-2 block"
									htmlFor="username"
								>
									Email
								</label>
								<input
									className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14"
									type="email"
									id="username"
									name="username"
									placeholder="ваша@эл.почта"
									{...register('username', {
										required: true,
										pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
									})}
								/>
								{errors.username?.type === 'required' && (
									<div
										className="text-xs pt-1.5 px-2 text-red-600"
										role="alert"
									>
										Email обязателен
									</div>
								)}
								{errors.username?.type === 'pattern' && (
									<div
										className="text-xs pt-1.5 px-2 text-red-600"
										role="alert"
									>
										Не похоже на Email
									</div>
								)}
							</div>
							<div>
								<label
									className="text-gray-500 pb-1 px-2 block"
									htmlFor="password"
								>
									Пароль
								</label>
								<div className="relative">
									<input
										className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14 pr-12"
										type={showPass ? 'text' : 'password'}
										id="password"
										name="password"
										placeholder="ваш пароль"
										{...register('password', { required: true })}
									/>
									<span className="absolute right-3 top-3">
										<Button
											variant="action"
											aria-label="Показать пароль"
											title="Показать пароль"
											onClick={() => setShowPass(!showPass)}
										>
											{eyeIcon}
										</Button>
									</span>
									{errors.password?.type === 'required' && (
										<div
											className="text-xs pt-1.5 px-2 text-red-600"
											role="alert"
										>
											Пароль обязателен
										</div>
									)}
								</div>
							</div>

							<div>
								<Button
									variant="black"
									size="normal"
									className="w-full h-14"
									type="submit"
									disabled={!isDirty && !isValid}
								>
									Войти
								</Button>
							</div>
						</form>
					</Tab.Panel>
					<Tab.Panel className={styles.panel}>
						{answerSignup && (
							<div className="mb-4 rounded-md px-3 py-2 leading-snug flex justify-between items-center bg-green-100 text-green-700">
								{answerSignup}
								<Button
									variant="action"
									aria-label="Закрыть"
									title="Закрыть"
									onClick={() => setAnswerSignup(null)}
								>
									<XMarkIcon className="w-4 h-4" />
								</Button>
							</div>
						)}

						<form
							onSubmit={handleSubmit2(onSubmitSignup)}
							className="flex flex-col gap-6 "
						>
							<div>
								<label
									className="text-gray-500 pb-1 px-2 block"
									htmlFor="username"
								>
									Email
								</label>
								<input
									className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14"
									type="email"
									id="usernamenew"
									name="usernamenew"
									placeholder="ваша@эл.почта"
									{...register2('usernamenew', {
										required: true,
										pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
									})}
								/>
								{errors2.usernamenew?.type === 'required' && (
									<div
										className="text-xs pt-1.5 px-2 text-red-600"
										role="alert"
									>
										Email обязателен
									</div>
								)}
								{errors2.usernamenew?.type === 'pattern' && (
									<div
										className="text-xs pt-1.5 px-2 text-red-600"
										role="alert"
									>
										Не похоже на Email
									</div>
								)}
							</div>

							<div className="text-sm">
								Нажимая на кнопку Зарегистрироваться, я принимаю условия{' '}
								<Lnk
									href="/info/politika-v-otnoshenii-personalnyx-dannyx-3"
									title="Политика в отношении персональных данных"
									className="underline"
									target="_blank"
								>
									политики обработки персональных данных
								</Lnk>{' '}
								и условия{' '}
								<Lnk
									href="/info/publichnaya-oferta-2"
									title="Публичная оферта"
									className="underline"
									target="_blank"
								>
									публичной оферты
								</Lnk>
							</div>

							<div>
								<Button
									variant="black"
									size="normal"
									className="w-full h-14"
									type="submit"
									disabled={!isDirty2 && !isValid2}
								>
									Зарегистрироваться
								</Button>
							</div>
						</form>
					</Tab.Panel>
					<Tab.Panel className={styles.panel}>
						{answerRestore && (
							<div className="mb-4 rounded-md px-3 py-2 leading-snug flex justify-between items-center bg-green-100 text-green-700">
								{answerRestore}
								<Button
									variant="action"
									aria-label="Закрыть"
									title="Закрыть"
									onClick={() => setAnswerRestore(null)}
								>
									<XMarkIcon className="w-4 h-4" />
								</Button>
							</div>
						)}

						<form
							onSubmit={handleSubmit3(onSubmitRestore)}
							className="flex flex-col gap-6 "
						>
							<div>
								<label
									className="text-gray-500 pb-1 px-2 block"
									htmlFor="username"
								>
									Email
								</label>
								<input
									className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14"
									type="email"
									id="usernamerestore"
									name="usernamerestore"
									placeholder="ваша@эл.почта"
									{...register3('usernamerestore', {
										required: true,
										pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
									})}
								/>
								{errors3.usernamerestore?.type === 'required' && (
									<div
										className="text-xs pt-1.5 px-2 text-red-600"
										role="alert"
									>
										Email обязателен
									</div>
								)}
								{errors3.usernamerestore?.type === 'pattern' && (
									<div
										className="text-xs pt-1.5 px-2 text-red-600"
										role="alert"
									>
										Не похоже на Email
									</div>
								)}
							</div>

							<div>
								<Button
									variant="black"
									size="normal"
									className="w-full h-14"
									type="submit"
									disabled={!isDirty3 && !isValid3}
								>
									Отправить на почту
								</Button>
							</div>
						</form>
					</Tab.Panel>
				</Tab.Panels>
			</Tab.Group>
		</div>
	);
};

export default SigninFormEmail;
