export { default } from './CatalogProductCardList';
