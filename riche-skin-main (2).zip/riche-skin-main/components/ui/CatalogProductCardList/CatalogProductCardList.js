import { Button, ProductCard } from '@/components/ui';
import cn from 'classnames';
import styles from './CatalogProductCardList.module.css';

const CatalogProductCardList = ({
	showAction = true,
	items,
	className,
	...props
}) => {
	const rootClassName = cn(styles.root, className);

	if (items.length) {
		return (
			<div className={rootClassName} {...props}>
				{items.map((item, index) => {
					return (
						<ProductCard showAction={showAction} data={item} key={index} />
					);
				})}
			</div>
		);
	}

	return (
		<div className={styles.empty}>
			{/* <div className={styles.title}></div> */}
			<div className={styles.summary}>
				<p>Тут ничего нет</p>
				<p> Попробуйте вернуться назад или поищите что-нибудь другое.</p>
			</div>
			<div className={styles.action}>
				<Button Component="a" href="/catalog" title="Каталог">
					Перейти в каталог
				</Button>
			</div>
		</div>
	);
};

export default CatalogProductCardList;
