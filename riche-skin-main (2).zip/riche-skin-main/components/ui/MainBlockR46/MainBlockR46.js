import { R46Reccomend } from '@/components/r46';
import cn from 'classnames';
import styles from './MainBlockR46.module.css';

const MainBlockR46 = ({ data, className, ...props }) => {
	const rootClassName = cn(styles.root, className);

	if (data.id) {
		return (
			<R46Reccomend
				id={data.id}
				title={data.title}
				centertitle={true}

				//variant="same"
			/>
		);
	}
};

export default MainBlockR46;
