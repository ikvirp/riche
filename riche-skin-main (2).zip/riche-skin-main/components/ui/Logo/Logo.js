import { Lnk, LogoSymbol, LogoText } from '@/components/ui';
import cn from 'classnames';
import { useRouter } from 'next/router';
import styles from './Logo.module.css';

import config from '@/config/seo.json';

const Logo = ({ variant = null, className, ...props }) => {
  const router = useRouter();

  const linkClassName = cn(styles.link, {
    [styles.active]: router.asPath == '/',
  });

  if (variant == 'nolink') {
    return (
      <div className={cn(styles.root, className)} {...props}>
        <span className={linkClassName}>
          <span className={styles.symbol}>
            <LogoSymbol className='text-white' />
          </span>
          <span className={styles.text}>
            <LogoText className='text-white' />
          </span>
        </span>
      </div>
    );
  }
  return (
    <div className={cn(styles.root, className)} {...props}>
      <Lnk className={linkClassName} href='/' title={config.title}>
        <span className={styles.symbol}>
          <LogoSymbol />
        </span>
        <span className={styles.text}>
          <LogoText />
        </span>
      </Lnk>
    </div>
  );
};

export default Logo;
