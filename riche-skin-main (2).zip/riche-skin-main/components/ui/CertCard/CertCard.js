import { Img, Lnk } from '@/components/ui';
import cn from 'classnames';
import styles from './CertCard.module.css';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const CertCard = ({ fancybox, data, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  const imageUrl = data.thumb
    ? `${NEXT_PUBLIC_DATA_DOMAIN}${data.thumb.file}`
    : `/i/thumb.png`;

  const originalUrl = data?.media[0]?.original?.file
    ? `${NEXT_PUBLIC_DATA_DOMAIN}${data.media[0].original.file}`
    : `/i/thumb.png`;

  return (
    <div className={rootClassName} {...props}>
      <Lnk
        href={originalUrl}
        className={styles.link}
        title={data.name}
        data-fancybox={fancybox}
      >
        <Img
          alt={data.name}
          title={data.name}
          src={imageUrl}
          className={styles.img}
          //placeholder='blur'
          width={data.thumb.width}
          height={data.thumb.height}
        />
      </Lnk>
    </div>
  );
};

export default CertCard;
