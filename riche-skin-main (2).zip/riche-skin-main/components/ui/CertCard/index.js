export { default } from './CertCard';
