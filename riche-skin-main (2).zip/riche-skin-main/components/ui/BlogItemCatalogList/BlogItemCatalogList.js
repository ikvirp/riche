import { ProductCard } from '@/components/ui';
import cn from 'classnames';
import styles from './BlogItemCatalogList.module.css';

const BlogItemCatalogList = ({ items, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  if (items.length) {
    return (
      <div className={rootClassName} {...props}>
        <div className={styles.title}>Средства из блога</div>

        <div className={styles.list}>
          {items.map((item, index) => {
            return (
              <ProductCard className={styles.item} data={item} key={index} />
            );
          })}
        </div>
      </div>
    );
  }

  return null;
};

export default BlogItemCatalogList;
