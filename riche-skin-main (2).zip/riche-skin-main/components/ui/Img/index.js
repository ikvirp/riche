export { default } from './Img';
