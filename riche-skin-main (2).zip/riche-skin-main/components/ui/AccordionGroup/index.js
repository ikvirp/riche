export { default } from './AccordionGroup';
