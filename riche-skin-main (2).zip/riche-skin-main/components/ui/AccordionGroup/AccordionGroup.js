import { Accordion } from '@/components/ui';
import cn from 'classnames';
import styles from './AccordionGroup.module.css';

const AccordionGroup = ({ variant, list, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  return (
    <div className={rootClassName} {...props}>
      {list.map((el, i) => {
        const first = i == 0 ? true : false;
        const classNm = el.name == 'Состав' ? 'text-xs' : null;

        return (
          <Accordion
            name={el.name}
            open={first}
            first={first}
            variant={variant}
            key={i}
          >
            <div
              className={classNm}
              dangerouslySetInnerHTML={{ __html: el.description }}
            ></div>
          </Accordion>
        );
      })}
    </div>
  );
};

export default AccordionGroup;
