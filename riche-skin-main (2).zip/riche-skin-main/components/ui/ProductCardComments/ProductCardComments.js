import { Button, CommentNew, Loader, Stars } from '@/components/ui';
import { getData } from '@/utils/fetcher';
import { numberFormat } from '@/utils/prepare';
import cn from 'classnames';
import { useSession } from 'next-auth/react';
import { useEffect, useState } from 'react';
import styles from './ProductCardComments.module.css';

// https://codesandbox.io/s/so-question-63501087-ds2fg?file=/src/App.tsx

const ProductCardComments = ({
	item_id,
	comments,
	item_data,
	rate,
	className,
	...props
}) => {
	const rootClassName = cn(styles.root, className);

	const [commentList, setCommentList] = useState(comments || []);
	const [commentShowMore, setCommentShowMore] = useState(false);
	const [commentPage, setCommentPage] = useState(1);
	const commentsCount = rate.comments_count || 0;

	const [loading, setLoading] = useState(false);

	const { data: session, status: session_status } = useSession();
	const canThumb = session_status === 'authenticated' ? true : false;

	const [canWrite, setCanWrite] = useState(false);
	const [showWriteModal, setShowWriteModal] = useState(false);
	const [showSignModal, setShowSignModal] = useState(false);

	useEffect(() => {
		// const can = session_status === 'authenticated' ? true : false;
		// setCanThumb(can);

		if (session_status === 'authenticated') {
			//alert(JSON.stringify(session_status));
			setCanWrite(true);
			setShowWriteModal(false);
			setShowSignModal(false);
		}
	}, [session_status]);

	useEffect(() => {
		const commentShowMoreStart =
			commentList.length < commentsCount ? true : false;
		setCommentShowMore(commentShowMoreStart);
	}, [commentList.length, commentsCount]);

	const paginationHandler = () => {
		setLoading(true);
		const newPage = commentPage + 1;

		const fetchData = async () => {
			const data = await getData(
				`/product_comments/${item_id}/?page=${newPage}`,
			);
			const aComments = commentList;
			setCommentList([...aComments, ...data.list]);
			setCommentPage(newPage);
			setLoading(false);
		};
		fetchData();
	};

	const clickWrite = () => {
		if (canWrite) {
			setShowWriteModal(true);
		} else {
			setShowSignModal(true);
		}
	};

	return (
		<div className={rootClassName} {...props}>
			{/* {JSON.stringify(item_id)} */}
			<div className={styles.taction}>
				<div className={styles.title}>Отзывы о товаре</div>
				<div className="text-gray-500  lg:hidden">
					Отзывы могут оставлять только&nbsp;те, кто купил товар. Так
					мы&nbsp;формируем честный рейтинг
				</div>

				{/* <div className={styles.action}>
          <Button onClick={(e) => clickWrite()}>Написать отзыв </Button>
          

          <Modal
            redirect={false}
            onClose={() => setShowWriteModal(false)}
            show={showWriteModal}
            title={`Написать отзыв`}
          >
            <CommentModalForm item_id={item_id} item_data={item_data} />
          </Modal>
          <SiginModal
            show={showSignModal}
            onClose={() => setShowSignModal(false)}
          />
        </div> */}
			</div>

			<div className={styles.rate}>
				<div>
					<div className={styles.stars}>
						{parseFloat(rate.comments_grade_count) > 0 && (
							<div className={styles.rating}>
								{parseFloat(rate.comments_average_grade)}
							</div>
						)}
						<Stars rating={rate.comments_average_grade} />
					</div>
					{parseFloat(rate.comments_grade_count) > 0 && (
						<div>Средний рейтинг</div>
					)}
				</div>

				{parseFloat(rate.comments_grade_count) > 0 && (
					<div>
						<div className={styles.rating}>
							{numberFormat(rate.comments_grade_count)}
						</div>
						<div className={styles.ratecount}>Всего отзывов</div>
					</div>
				)}

				<div className="text-gray-500  grow hidden lg:block">
					<div className="max-w-[400px] ml-auto">
						Отзывы могут оставлять только&nbsp;те, кто купил товар. Так
						мы&nbsp;формируем честный рейтинг
					</div>
				</div>
			</div>

			{commentList.length > 0 && (
				<div>
					{commentList.map((el, i) => (
						<CommentNew data={el} key={i} item_id={item_id} />
					))}
				</div>
			)}
			{commentShowMore && (
				<div className="pt-12 flex items-center justify-center">
					<Button variant="gray" onClick={paginationHandler}>
						{loading && <Loader variant="cart" />}
						Показать больше отзывов
					</Button>
				</div>
			)}
		</div>
	);
};

export default ProductCardComments;
