import {
	Button,
	CommentWrite,
	Loader,
	Modal,
	SiginModal,
} from '@/components/ui';
import { getData } from '@/utils/fetcher';
import {
	HandThumbDownIcon,
	HandThumbUpIcon,
} from '@heroicons/react/24/outline';
import cn from 'classnames';
import { useSession } from 'next-auth/react';
import { useEffect, useState } from 'react';
import styles from './CommentAction.module.css';

const CommentAction = ({ className, item_id, id, data, ...props }) => {
	const rootClassName = cn(styles.root, className);

	const [loading, setLoading] = useState(false);
	const [likes, setLikes] = useState(data.likes);
	const [dislikes, setDislikes] = useState(data.dislikes);

	const [showSignModal, setShowSignModal] = useState(false);
	const [showWriteModal, setShowWriteModal] = useState(false);

	const { data: session, status: session_status } = useSession();
	const canThumb = session_status === 'authenticated' ? true : false;

	const [canWrite, setCanWrite] = useState(false);
	const [commentId, setCommentId] = useState(0);

	useEffect(() => {
		// const can = session_status === 'authenticated' ? true : false;
		// setCanThumb(can);

		if (session_status === 'authenticated') {
			//alert(JSON.stringify(session_status));
			setCanWrite(true);
			setShowSignModal(false);
		}
	}, [session_status]);

	const clickThumb = async (vote, id) => {
		if (canWrite) {
			setLoading(true);
			const oData = {
				id: id,
				vote: vote,
				token: session.token,
			};

			//alert(JSON.stringify(oData));

			const result = await getData(`/comment_vote/`, 'POST', {
				id: id,
				vote: vote,
				token: session.token,
			});

			if (typeof result.error == 'undefined') {
				setLikes(result.likes);
				setDislikes(result.dislikes);

				//alert(JSON.stringify(result));
			}
			setLoading(false);

			//alert(JSON.stringify(oData));
		} else {
			setShowSignModal(true);
		}
	};

	const clickWrite = (id) => {
		setCommentId(0);
		if (canWrite) {
			setCommentId(id);
			setShowWriteModal(true);
		} else {
			setShowSignModal(true);
		}
	};

	return (
		<>
			<div className={rootClassName} {...props}>
				{/* {JSON.stringify(item_id)} */}
				{/* {JSON.stringify(canThumb)}
      {JSON.stringify(id)} */}

				{/* {JSON.stringify(canWrite)} */}
				<Button variant="smallgray" onClick={(e) => clickThumb(true, id)}>
					<HandThumbUpIcon className="w-4 h-4" />
					{likes}
				</Button>
				<Button variant="smallgray" onClick={(e) => clickThumb(false, id)}>
					<HandThumbDownIcon className="w-4 h-4" />
					{dislikes}
				</Button>
				{/* <Button variant='smalltransparent' onClick={(e) => clickWrite(id)}>
          Ответить
        </Button> */}
				{loading && <Loader variant="cart" />}
			</div>
			<Modal
				redirect={false}
				onClose={() => setShowWriteModal(false)}
				show={showWriteModal}
				title={`Написать ответ`}
			>
				<CommentWrite commentid={commentId} id={id} item_id={item_id} />
			</Modal>
			<SiginModal
				show={showSignModal}
				onClose={() => setShowSignModal(false)}
			/>
		</>
	);
};

export default CommentAction;
