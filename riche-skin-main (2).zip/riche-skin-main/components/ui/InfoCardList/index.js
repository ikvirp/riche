export { default } from './InfoCardList';
