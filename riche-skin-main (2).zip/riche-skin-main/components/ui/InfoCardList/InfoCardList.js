import { InfoCard } from '@/components/ui';
import cn from 'classnames';
import styles from './InfoCardList.module.css';

const InfoCardList = ({ items, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  return (
    <div className={rootClassName} {...props}>
      {items.map((el, i) => (
        <InfoCard data={el} key={i} />
      ))}
    </div>
  );
};

export default InfoCardList;
