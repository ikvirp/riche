import { HomeIcon } from '@heroicons/react/24/outline';
import cn from 'classnames';
import { BreadcrumbJsonLd } from 'next-seo';
import { useRouter } from 'next/router';
import Lnk from '../Lnk';
import styles from './Breadcrumbs.module.css';

const NEXT_PUBLIC_DOMAIN = process.env.NEXT_PUBLIC_DOMAIN;

const Breadcrumbs = ({ data, className, ...props }) => {
	const rootClassName = cn(styles.root, className);

	const router = useRouter();

	const aPath = router.asPath.split('/');
	const foundMe = aPath.find((el) => el == 'me');
	// console.log(aPath);
	// console.log(foundMe);

	const aLdBread = [];
	if (!foundMe) {
		return (
			<div className={rootClassName} {...props} aria-label="Хлебные крошки">
				<ol>
					<li>
						<Lnk
							href="/"
							title="Главная страница"
							aria-label="Главная страница"
						>
							<span>
								<HomeIcon className="w-4 h-4" />
							</span>
						</Lnk>
					</li>
					{data.map((el, i, row) => {
						aLdBread.push({
							position: i + 1,
							name: el.name,
							item: `${NEXT_PUBLIC_DOMAIN}${el.slug}`,
						});

						if (i + 1 === row.length) {
							return (
								<li key={i}>
									<span>{el.name}</span>
								</li>
							);
						} else {
							return (
								<li key={i}>
									<Lnk
										href={el.slug}
										title={el.name}
										itemProp="item"
										aria-label={el.name}
									>
										<span>{el.name}</span>
									</Lnk>
								</li>
							);
						}
					})}
				</ol>
				<BreadcrumbJsonLd itemListElements={aLdBread} />
			</div>
		);
	}

	return null;
};

export default Breadcrumbs;
