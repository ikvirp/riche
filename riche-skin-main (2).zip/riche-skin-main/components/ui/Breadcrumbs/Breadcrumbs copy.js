import { HomeIcon } from '@heroicons/react/24/outline';
import cn from 'classnames';
import { BreadcrumbJsonLd } from 'next-seo';
import { useRouter } from 'next/router';
import Lnk from '../Lnk';
import styles from './Breadcrumbs.module.css';

const NEXT_PUBLIC_DOMAIN = process.env.NEXT_PUBLIC_DOMAIN;

const Breadcrumbs = ({ data, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  const router = useRouter();

  const aLdBread = [];

  return (
    <div className={rootClassName} {...props} aria-label='Хлебные крошки'>
      <ol itemScope itemType='https://schema.org/BreadcrumbList'>
        <li
          itemProp='itemListElement'
          itemScope
          itemType='https://schema.org/ListItem'
        >
          <Lnk href='/' title='Главная страница' aria-label='Главная страница'>
            <span itemProp='name'>
              <HomeIcon className='w-4 h-4' />
            </span>
          </Lnk>
        </li>
        {data.map((el, i, row) => {
          aLdBread.push({
            position: i + 1,
            name: el.name,
            item: `${NEXT_PUBLIC_DOMAIN}${el.slug}`,
          });

          if (i + 1 === row.length) {
            return (
              <li
                itemProp='itemListElement'
                itemScope
                itemType='https://schema.org/ListItem'
                key={i}
              >
                <span itemProp='name'>{el.name}</span>
              </li>
            );
          } else {
            return (
              <li
                itemProp='itemListElement'
                itemScope
                itemType='https://schema.org/ListItem'
                key={i}
              >
                <Lnk
                  href={el.slug}
                  title={el.name}
                  itemProp='item'
                  aria-label={el.name}
                >
                  <span itemProp='name'>{el.name}</span>
                </Lnk>
              </li>
            );
          }
        })}
      </ol>
      <BreadcrumbJsonLd itemListElements={aLdBread} />
    </div>
  );
};

export default Breadcrumbs;
