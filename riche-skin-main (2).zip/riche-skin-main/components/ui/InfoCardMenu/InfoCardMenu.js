import { Lnk } from '@/components/ui';
import cn from 'classnames';
import styles from './InfoCardMenu.module.css';

const InfoCardMenu = ({ items, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  return (
    <nav className={rootClassName} {...props}>
      {items.map((el, i) => {
        const realUrl = {
          pathname: `/info/[slug]`,
          query: { slug: `${el.slug}` },
        };
        return (
          <div key={i} className={styles.item}>
            <Lnk href={realUrl} title={el.name}>
              {el.name}
            </Lnk>
          </div>
        );
      })}
    </nav>
  );
};

export default InfoCardMenu;
