export { default } from './InfoCardMenu';
