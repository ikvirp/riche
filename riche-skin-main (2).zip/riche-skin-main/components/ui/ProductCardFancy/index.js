export { default } from './ProductCardFancy';
