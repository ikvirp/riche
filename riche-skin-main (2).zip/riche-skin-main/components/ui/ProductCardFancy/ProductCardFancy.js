import FancyboxWrapper from '@/utils/fancybox';
import { numberFormat } from '@/utils/prepare';
import cn from 'classnames';
import { useState } from 'react';
import { useWindowSize } from 'usehooks-ts';
import Img from '../Img/Img';
import Lnk from '../Lnk/Lnk';
import styles from './ProductCardFancy.module.css';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const ProductCardFancy = ({
  labels,
  discount,
  name,
  data,
  className,
  ...props
}) => {
  const rootClassName = cn(styles.root, className);

  const [activeIndex, setActiveIndex] = useState(0);
  const { width, height } = useWindowSize();

  const [scrollPosition, setScrollPosition] = useState(0);

  const handleScroll = (event) => {
    const { scrollLeft, clientWidth } = event.target;
    const scroll = clientWidth - scrollLeft;

    // setScrollPosition({
    //   scrollLeft,
    //   clientWidth,
    //   ss: Math.round(scrollLeft / clientWidth),
    // });

    setActiveIndex(Math.round(scrollLeft / clientWidth));
  };

  let aItemsBig = [];
  let aItemsSmall = [];

  data.forEach((el) => {
    if (typeof el.original !== 'undefined') {
      aItemsBig.push({
        name: name,
        thumb: `${NEXT_PUBLIC_DATA_DOMAIN}${el.original.file}`,
        width: el.original.width,
        height: el.original.height,
      });
    }

    if (typeof el.original !== 'undefined') {
      aItemsSmall.push({
        name: name,
        thumb: `${NEXT_PUBLIC_DATA_DOMAIN}${el.thumb.file}`,
        width: el.thumb.width,
        height: el.thumb.height,
      });
    }
  });

  const handleClickScroll = (index) => {
    setActiveIndex(index);
    const element = document.getElementById(`section-${index}`);

    if (element) {
      // 👇 Will scroll smoothly to the top of the next section
      element.scrollIntoView({
        behavior: 'smooth',
        block: 'end',
        inline: 'nearest',
      });
    }
  };

  // useEffect(() => {
  //   const element = document.getElementById(`section-${activeIndex}`);
  //   if (element) {
  //     // 👇 Will scroll smoothly to the top of the next section
  //     element.scrollIntoView({
  //       behavior: 'smooth',
  //       block: 'end',
  //       inline: 'nearest',
  //     });
  //   }
  // }, [width]);

  const labelsShow =
    labels && labels.length > 0 ? (
      <span className={styles.labels}>
        {labels.map((el, i) => {
          //const styleColor = el.color != '' ? `${el.color}` : '';
          return (
            <div key={i}>
              <span className={styles.label}>{el.name}</span>
            </div>
          );
        })}
      </span>
    ) : null;

  const discountShow = discount ? (
    <span className={styles.discount}>{`-${numberFormat(discount)}%`}</span>
  ) : null;

  return (
    <>
      {/* <div>{JSON.stringify(scrollPosition)}</div> */}
      <FancyboxWrapper
        options={{
          compact: false,
          idle: false,
          animated: true,
          showClass: false,
          hideClass: false,
          dragToClose: false,
          Images: {
            zoom: true,
          },
          Toolbar: {
            display: {
              left: [],
              middle: ['infobar'],
              right: ['close'],
            },
          },
          Thumbs: {
            type: 'modern',
          },
        }}
      >
        <div className={rootClassName} {...props}>
          <div className={styles.glr}>
            <div className={styles.list} onScroll={(e) => handleScroll(e)}>
              {aItemsBig.map((el, i) => {
                return (
                  <div key={i} className={styles.sc} id={`section-${i}`}>
                    <Lnk
                      href={el.thumb}
                      className={styles.link}
                      title={el.name}
                      data-fancybox='gallery'
                      key={i}
                    >
                      <Img
                        alt={el.name}
                        title={el.name}
                        src={el.thumb}
                        className={styles.prev}
                        //placeholder='blur'
                        width={el.width}
                        height={el.height}
                        priority
                      />
                    </Lnk>
                  </div>
                );
              })}
            </div>
            {labelsShow}
            {/* {discountShow} */}
          </div>

          <div className={styles.thumbs}>
            {aItemsSmall.map((el, i) => {
              return (
                <Img
                  alt={el.name}
                  title={el.name}
                  src={el.thumb}
                  className={cn(styles.thumb, {
                    [styles.active]: activeIndex == i,
                  })}
                  //placeholder='blur'
                  width={el.width}
                  height={el.height}
                  key={i}
                  onClick={() => {
                    handleClickScroll(i);
                  }}
                  priority
                />
              );
            })}
          </div>
          <div className={styles.dots}>
            {aItemsSmall.map((el, i) => {
              return (
                <span
                  className={cn(styles.dot, {
                    [styles.dotactive]: activeIndex == i,
                  })}
                  key={i}
                  onClick={() => {
                    handleClickScroll(i);
                  }}
                />
              );
            })}
          </div>
        </div>
      </FancyboxWrapper>
    </>
  );
};

export default ProductCardFancy;
