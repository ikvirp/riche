import {
	MainBlockBaner,
	MainBlockBlog,
	MainBlockPromo,
	MainBlockR46,
	MainBlockShop,
	MainBlockShopGroups,
} from '@/components/ui';
import cn from 'classnames';
import styles from './MainBlock.module.css';

const MainBlock = ({ data, className, ...props }) => {
	const rootClassName = cn(styles.root, className);

	//console.log(data);

	switch (data.type) {
		case 'shop':
			return <MainBlockShop data={data} />;
			break;

		case 'shop_groups':
			return <MainBlockShopGroups data={data} />;
			break;

		case 'promo':
			return <MainBlockPromo data={data} />;
			break;

		case 'blog':
			return <MainBlockBlog data={data} />;
			break;

		case 'baner':
			return <MainBlockBaner data={data} />;
			break;

		case 'reccomendR46':
			return <MainBlockR46 data={data} />;
			break;

		default:
			return null;
	}
};

export default MainBlock;
