import { Lnk } from '@/components/ui';
import cn from 'classnames';
import { signOut } from 'next-auth/react';
import { useRouter } from 'next/router';
import styles from './MeFastMenu.module.css';

const MeFastMenu = ({ className, ...props }) => {
	const rootClassName = cn(styles.root, className);
	const router = useRouter();

	const items = [
		{
			name: 'Мои заказы',
			slug: '/me',
		},
		{
			name: 'Избранное',
			slug: '/me/fav',
		},
		{
			name: 'Мои отзывы',
			slug: '/me/comments',
		},
		{
			name: 'Мои адреса',
			slug: '/me/addresses',
		},
	];

	return (
		<nav className={rootClassName} {...props}>
			<div className={styles.cnt}>
				<div className={styles.list}>
					{items.map((el, i) => {
						const itemClass = cn(
							styles.item,
							el.slug == router.asPath ? styles.active : '',
						);

						return (
							<Lnk href={el.slug} title={el.name} className={itemClass} key={i}>
								{el.name}
							</Lnk>
						);
					})}
					{/* <Lnk
						href="/"
						title="Выйти"
						className={styles.item}
						onClick={(e) => {
							e.preventDefault();
							signOut({ callbackUrl: `/`, redirect: true });
						}}
					>
						Выйти
					</Lnk> */}
				</div>
			</div>
		</nav>
	);
};

export default MeFastMenu;
