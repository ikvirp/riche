import { Button, MeOrderCard } from '@/components/ui';
import cn from 'classnames';
import styles from './MeOrderList.module.css';

const MeOrderList = ({ data, className, ...props }) => {
	const rootClassName = cn(styles.root, className);

	const ordersList = data ? data.orders : [];

	if (ordersList && ordersList.length > 0) {
		return (
			<div className={rootClassName} {...props}>
				<div>
					<h1 className="pb-0  text-2xl  lg:text-3xl">Все заказы</h1>
					{/* <div className="lg:text-xl">
						Заказы отображаются только за последний месяц
					</div> */}
				</div>
				<div className={styles.list}>
					{ordersList.map((el, i) => (
						<MeOrderCard data={el} key={i} />
					))}
				</div>
			</div>
		);
	}
	return (
		<div className="flex flex-col gap-6 text-center lg:text-left lg:max-w-xs ">
			<div>
				<h1 className="text-2xl  lg:text-3xl">
					Самое время сделать свой первый заказ
				</h1>
				<div className="lg:text-xl">
					Подробная информация обо всех ваших заказах RICHE будет доступна
					здесь.
				</div>
			</div>
			<div>
				<Button Component="a" href="/catalog" title="Перейти в каталог">
					За покупками
				</Button>
			</div>
		</div>
	);
};

export default MeOrderList;
