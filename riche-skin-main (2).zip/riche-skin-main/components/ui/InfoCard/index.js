export { default } from './InfoCard';
