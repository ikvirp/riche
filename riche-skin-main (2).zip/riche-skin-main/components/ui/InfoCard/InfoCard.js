import { Img, Lnk } from '@/components/ui';
import cn from 'classnames';
import styles from './InfoCard.module.css';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const InfoCard = ({ data, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  const imageUrl = data.thumb
    ? `${NEXT_PUBLIC_DATA_DOMAIN}${data.thumb.file}`
    : //: `/i/img.png`;
      null;

  const realUrl = {
    pathname: `/info/[slug]`,
    query: { slug: `${data.slug}` },
  };

  return (
    <div className={rootClassName} {...props}>
      {imageUrl && (
        <div className={styles.thumb}>
          <Lnk href={realUrl} title={data.name} className={styles.link}>
            <Img
              src={imageUrl}
              className={styles.image}
              title={data.name}
              alt={data.name}
              width='1024'
              height='620'
            />
          </Lnk>
        </div>
      )}
      <div className={styles.summary}>
        <div className={styles.title}>
          <Lnk href={realUrl} title={data.name}>
            {data.name}
          </Lnk>
        </div>
        {data.description != '' && (
          <div
            className={styles.description}
            dangerouslySetInnerHTML={{ __html: data.description }}
          ></div>
        )}
      </div>
    </div>
  );
};

export default InfoCard;
