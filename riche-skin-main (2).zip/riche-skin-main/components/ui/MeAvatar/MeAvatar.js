import { Loader } from '@/components/ui';
import { getData, uploadAvatar } from '@/utils/fetcher';
import { CameraIcon } from '@heroicons/react/24/solid';
import cn from 'classnames';
import Image from 'next/image';
import { useEffect, useRef, useState } from 'react';
import styles from './MeAvatar.module.css';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const MeAvatar = ({ token, className, ...props }) => {
	const rootClassName = cn(styles.root, className);

	const [realAvatar, setRealAvatar] = useState('/i/avatar.png');
	const [loading, setLoading] = useState(false);

	const inputFile = useRef(null);

	const fetchData = async () => {
		//setLoading(true);
		const data = await getData(`/me/`, 'POST', {
			token: token,
			orders: false,
			//pass: true,
		});
		if (data) {
			//setDt(data);
			//console.log(data);
			setRealAvatar(`${NEXT_PUBLIC_DATA_DOMAIN}${data.profile.avatar}`);
		}
		//setLoading(false);
	};

	useEffect(() => {
		//alert('asdas');
		if (token) {
			fetchData();
		}
	}, [token]);

	const uploadFile = async (file) => {
		setLoading(true);

		const data = await uploadAvatar(token, file);

		if (data) {
			//setRealAvatar(data.file);
			fetchData();
		}
		//console.log(`data:`, data);

		setLoading(false);
	};

	const handleOnChange = (e) => {
		const file = e.target.files[0];
		//console.log(file);
		if (file.size && file.size > 5000000) {
			alert('Размер файла не должен превышать 5Мб');
		} else {
			//setFile(file);
			uploadFile(file);
		}
	};

	const getFile = () => {
		inputFile.current.click();
	};

	// const imageUrl = realAvatar
	// 	? `${NEXT_PUBLIC_DATA_DOMAIN}${realAvatar}`
	// 	: `/i/avatar.png`;

	return (
		<>
			{/* <div>{JSON.stringify(dt)}</div> */}
			<div className={rootClassName} {...props}>
				<Image
					src={realAvatar}
					width={300}
					height={300}
					alt="Аватар"
					title="Аватар"
				/>
				<div className={styles.updater} onClick={() => getFile()}>
					<CameraIcon className="w-4 h-4" />
					<div className={styles.title}>обновить</div>
				</div>
				{loading && (
					<div className={styles.status}>
						<Loader variant="cart" />
					</div>
				)}
			</div>
			<input
				className="hidden"
				type="file"
				ref={inputFile}
				onChange={handleOnChange}
				accept=".jpg,.jpeg,.png"
				size={5000000}
			/>
			{/* <div>{JSON.stringify(token)}</div>
			<div>{JSON.stringify(avatar)}</div> */}
		</>
	);
};

export default MeAvatar;
