import { Button } from '@/components/ui';
import { sidebar__close } from '@/store/actions/sidebar';
import { XMarkIcon } from '@heroicons/react/24/outline';
import cn from 'classnames';
import { useDispatch, useSelector } from 'react-redux';
import styles from './SidebarHeader.module.css';

const SidebarHeader = ({ children, className, ...props }) => {
  const dispatch = useDispatch();

  const rootClassName = cn(styles.root, className);

  const variant = useSelector((state) => state.sidebar.variant);
  const realVariant = variant == 'cart' ? 'cart' : '';

  return (
    <div className={rootClassName} {...props}>
      <div className={styles.content}>{children}</div>
      <Button
        variant='action'
        aria-label='Закрыть'
        onClick={(event) => {
          event.preventDefault();
          dispatch(sidebar__close(realVariant));
        }}
      >
        <XMarkIcon className='w-6 h-6' />
      </Button>
    </div>
  );
};

export default SidebarHeader;
