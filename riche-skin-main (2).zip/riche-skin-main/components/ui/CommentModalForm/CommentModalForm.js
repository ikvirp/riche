import { Button, Lnk, Loader } from '@/components/ui';
import { InformationCircleIcon, XMarkIcon } from '@heroicons/react/24/outline';
import cn from 'classnames';
import { useSession } from 'next-auth/react';
import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import styles from './CommentModalForm.module.css';

import { getData } from '@/utils/fetcher';
import { prepareDate } from '@/utils/prepare';
import { StarIcon } from '@heroicons/react/24/outline';
import { StarIcon as StarIconSolid } from '@heroicons/react/24/solid';

//https://react-uploady.org

const NEXT_PUBLIC_API_URL = process.env.NEXT_PUBLIC_API_URL;
const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

// const dataSticky = {
//   id: data.id,
//   name: data.name,
//   marking: data.marking,
//   thumb: data.thumb,
//   slug: data.slug,
//   rest: data.rest,
//   price: data.price,
//   labels: data.labels,
//   seo: data.seo,
// `${NEXT_PUBLIC_DOMAIN}/product/${data.slug}

//   rate: data.comments.rate,
// };

const filterBySize = (file) => {
	//filter out images larger than 5MB
	return file.size <= 5242880;
};

const CommentFalse = ({ date }) => {
	const sDate = date ? (
		<div>{`Последний раз вы оценивали его ${prepareDate(date)}`}</div>
	) : null;

	return (
		<div className="border bg-primarygray p-3 flex gap-3 rounded-xl mb-6">
			<div>
				<InformationCircleIcon className="w-6 h-6" />
			</div>
			<div className="flex flex-col gap-1.5">
				<div className="font-bold text-lg leading-tight">
					Отзыв на&nbsp;продукт можно оставить один раз в&nbsp;3&nbsp;месяца.
				</div>
				{sDate}
			</div>
		</div>
	);
};

const CommentModalForm = ({
	redirect = false,
	comment_id = null,
	onSend = false,
	item_id,
	item_data,
	className,
	...props
}) => {
	const rootClassName = cn(styles.root, className);

	const [loading, setLoading] = useState(false);
	const [answerSuccess, setAnswerSuccess] = useState(null);
	const [answerDanger, setAnswerDanger] = useState(null);

	const [rating, setRating] = useState(0);
	const [hover, setHover] = useState(0);

	const [formText, setFormText] = useState(false);
	const [canSend, setCanSend] = useState(false);
	const [showAlert, setShowAlert] = useState(false);

	const { data: session, status: session_status } = useSession();

	const sButton = loading ? (
		<>
			<Loader variant="cart" /> Отправка
		</>
	) : (
		`Отправить`
	);

	const {
		register,
		watch,
		handleSubmit,
		reset,
		formState: { errors, isDirty, isValid },
	} = useForm({
		mode: 'all',
	});

	const watchAllFields = watch();

	useEffect(() => {
		setCanSend(false);
		if (formText && rating > 0) {
			setCanSend(true);
		}
	}, [formText, rating]);

	useEffect(() => {
		setFormText(false);
		if (
			typeof watchAllFields.advantages != 'undefined' ||
			typeof watchAllFields.flaws != 'undefined' ||
			typeof watchAllFields.text != 'undefined'
		) {
			if (
				watchAllFields.advantages.length > 0 ||
				watchAllFields.flaws.length > 0 ||
				watchAllFields.text.length > 0
			) {
				setFormText(true);
			} else {
			}
		}
	}, [watchAllFields]);

	useEffect(() => {
		reset({ advantages: '', flaws: '', text: '' });
		setRating(0);
		setHover(0);

		if (!comment_id) {
			if (item_data.cancomment) {
				setShowAlert(false);
			} else {
				setShowAlert(true);
			}
		} else {
			setShowAlert(false);
		}
	}, [item_id]);

	const onSubmit = async (data) => {
		setAnswerSuccess(null);
		setAnswerDanger(null);

		const oData = {
			item_id: item_id, //!
			parent_id: 0, //!
			rate: rating,
			advantages: data.advantages,
			flaws: data.flaws,
			text: data.text,
			token: session.token,
			comment_id: comment_id,
		};

		//alert(JSON.stringify(oData));

		setLoading(true);
		const result = await getData(`/comment_add/`, 'POST', oData);

		if (typeof result.error == 'undefined') {
			// result
			// message

			if (result) {
				setAnswerSuccess(result.message);
				reset({ advantages: '', flaws: '', text: '' });
				setRating(0);
				setHover(0);
			} else {
				setAnswerDanger(result.message);
			}
		}

		if (onSend) {
			onSend();
		}
		setLoading(false);

		//alert(JSON.stringify(oData));
	};

	const alertClass = cn(
		'text-xs pt-1.5 px-2 text-red-600',
		formText ? 'opacity-0' : 'opacity-100',
	);

	const imageUrl = item_data.thumb
		? `${NEXT_PUBLIC_DATA_DOMAIN}${item_data.thumb.file}`
		: `/i/thumb.png`;

	return (
		<div className={rootClassName} {...props}>
			{/* {JSON.stringify(canSend)} */}
			{/* {JSON.stringify(showAlert)}
			<hr />
			{JSON.stringify(item_data.cancomment)}
			<hr />
			{JSON.stringify(item_data.lastadd)} */}

			{answerSuccess && (
				<div className="mb-4 rounded-md px-3 py-2 leading-snug flex justify-between items-center bg-green-100 text-green-700">
					{answerSuccess}
					<Button
						variant="action"
						aria-label="Закрыть"
						title="Закрыть"
						onClick={() => setAnswerSuccess(null)}
					>
						<XMarkIcon className="w-4 h-4" />
					</Button>
				</div>
			)}
			{answerDanger && (
				<div className="mb-4 rounded-md px-3 py-2 leading-snug flex justify-between items-center bg-red-200 text-red-600">
					{answerDanger}
					<Button
						variant="action"
						aria-label="Закрыть"
						title="Закрыть"
						onClick={() => setAnswerDanger(null)}
					>
						<XMarkIcon className="w-4 h-4" />
					</Button>
				</div>
			)}

			<div className={styles.item}>
				{/* <div
					//className={cn(styles.thumb, isHover2 ? `opacity-60` : ``)}
					className={styles.thumb}
				>
					<Img
						alt={item_data.name}
						title={item_data.name}
						src={imageUrl}
						className={styles.img}
						//placeholder='blur'
						width="350"
						height="350"
					/>
				
				</div> */}
				<div className={styles.name}>{item_data.name}</div>
			</div>

			{/* <div>
        <Uploady
          fileFilter={filterBySize}
          maxGroupSize={5}
          accept='image/*'
          destination={{ url: 'my-server.com/upload' }}
        >
          <div className={styles.listimg}>
            <UploadPreview />
            <UploadButton className={styles.button}>
              <PlusIcon className='w-6 h-6' />
            </UploadButton>
          </div>
        </Uploady>
      </div> */}

			{showAlert && <CommentFalse date={item_data.lastadd} />}

			{!showAlert && (
				<form
					onSubmit={handleSubmit(onSubmit)}
					className="flex flex-col gap-6 "
				>
					<div>
						<label className="text-gray-500 pb-1 px-1 block">Ваша оценка</label>
						<div className={styles.stars}>
							{[...Array(5)].map((star, index) => {
								index += 1;

								const Icon =
									index <= (hover || rating) ? (
										<i className={styles.solid}>
											<StarIconSolid className={styles.on} />
										</i>
									) : (
										<i className={styles.outline}>
											<StarIcon className={styles.off} />
										</i>
									);
								return (
									<button
										type="button"
										key={index}
										// className={
										//   index <= (hover || rating) ? styles.on : styles.off
										// }
										onClick={() => setRating(index)}
										onMouseEnter={() => setHover(index)}
										onMouseLeave={() => setHover(rating)}
									>
										{Icon}
									</button>
								);
							})}
						</div>
						{rating <= 0 && (
							<div className="text-xs pt-1.5 px-2 text-red-600" role="alert">
								Оценка обязательна
							</div>
						)}
					</div>
					<div>
						<label
							className="text-gray-500 pb-1 px-2 block"
							htmlFor="advantages"
						>
							Достоинства
						</label>
						<textarea
							className="block w-full h-18 rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 "
							id="advantages"
							name="advantages"
							placeholder="Что вам понравилось в продукте?"
							{...register('advantages', {
								onChange: (e) => {
									setFormText(e.value);
								},
							})}
						/>
					</div>

					<div>
						<label className="text-gray-500 pb-1 px-2 block" htmlFor="flaws">
							Недостатки
						</label>
						<textarea
							className="block w-full h-18 rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 "
							id="flaws"
							name="flaws"
							placeholder="Что вам не понравилось в продукте?"
							{...register('flaws')}
						/>
					</div>

					<div>
						<label className="text-gray-500 pb-1 px-2 block" htmlFor="text">
							Комментарий
						</label>
						<textarea
							className="block w-full h-18 rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 "
							id="text"
							name="text"
							placeholder="Расскажите про историю покупки"
							{...register('text')}
						/>

						<div className={alertClass} role="alert">
							Заполните хотя-бы одно поле
						</div>
					</div>

					<div className="text-xs text-center">
						Нажимая &laquo;Отправить&raquo; я&nbsp;соглашаюсь с&nbsp;
						<Lnk
							href="/info/pravila-publikaczii-kommentariev-1155"
							title="Правила публикации"
							className="underline"
							target="_blank"
						>
							правилами публикации
						</Lnk>
					</div>

					<div>
						<Button
							variant="black"
							size="normal"
							className="w-full h-14"
							type="submit"
							disabled={!canSend}
						>
							{sButton}
						</Button>
					</div>
				</form>
			)}
		</div>
	);
};

export default CommentModalForm;
