import { Button, Modal } from '@/components/ui';
import cn from 'classnames';
import styles from './MapModal.module.css';

import { useEffect, useState } from 'react';

import {
  FullscreenControl,
  GeolocationControl,
  Map,
  ObjectManager,
  TypeSelector,
  YMaps,
  ZoomControl,
} from '@pbe/react-yandex-maps';

const mapState = {
  center: [55.751574, 37.573856],
  zoom: 5,
};

// https://codesandbox.io/s/xjw8xyx26w?file=/src/index.js

const MapModal = ({ points, show, onClose }) => {
  const rootClassName = cn(styles.root);
  const [myMap, setMyMap] = useState(null);
  const [manager, setManager] = useState(null);
  const [allItems, setAllItems] = useState([]);

  const [curObject, setCurObject] = useState({});

  useEffect(() => {
    if (manager) {
      setAllItems(manager.objects.getAll());
      setCurObject({});

      const onObjectClick = (e) => {
        // objectId – идентификатор объекта, на котором произошло событие.
        var objectId = e.get('objectId');

        const filtred = points.features.find((el) => el.id == objectId);
        //alert(JSON.stringify(objectId));
        //alert(JSON.stringify(filtred));
        //alert(JSON.stringify(store));
        setCurObject(filtred);

        //alert(objectId);
      };

      // <Placemark
      //   instanceRef={(ref) => {
      //     ref &&
      //       ref.events.add('balloonopen', (e) => {
      //         console.log(
      //           'Кликнули по точке',
      //           e.originalEvent.currentTarget.properties._data.item
      //         );
      //       });
      //   }}
      //   properties={{ tem: item }}
      // />;

      manager.objects.events.add('balloonopen', onObjectClick);
    }
  }, [manager, points]);

  const ItemInfo = ({ data }) => {
    if (data?.code) {
      return (
        <div className='flex flex-row md:flex-col gap-3'>
          <div className='flex flex-col gap-3 justify-between'>
            <div className='flex flex-col gap-1'>
              <div className='font-bold'>{data.name}</div>
            </div>

            <div className='pt-4 grow flex flex-col justify-end flex-1'>
              <Button
                variant='black'
                className='w-full'
                onClick={(e) =>
                  onClose(`[${data.id}] — ${data.name} (${data.address})`)
                }
              >
                Доставить сюда
              </Button>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className='flex flex-col gap-3'>
        <div className='text-xl'>Выберите пункт выдачи на карте</div>
      </div>
    );
  };

  return (
    <>
      <Modal
        onClose={onClose}
        show={show}
        variant='map'
        className='max-w-full '
        title='Выбор пункта'
      >
        <div className='p-0 pb-3 flex flex-col gap-3'>
          {/* <div>{JSON.stringify(oList.features.length)}</div>
          <div>{JSON.stringify(city)}</div>
          <div>{JSON.stringify(loading)}</div>
          {JSON.stringify(points.length)} */}
          <div className='storemap'>
            <div className='map'>
              <YMaps>
                <Map
                  width='100%'
                  height='100%'
                  defaultState={mapState}
                  instanceRef={(ref) => {
                    if (ref) {
                      setMyMap(ref);
                    }
                  }}
                >
                  <GeolocationControl />
                  <ZoomControl />
                  <FullscreenControl />

                  <TypeSelector />
                  {/* <SearchControl /> */}

                  {/* {ItemsList} */}

                  <ObjectManager
                    options={{
                      //clusterize: true,
                      gridSize: 32,
                      clusterDisableClickZoom: false,
                    }}
                    objects={{
                      openBalloonOnClick: true,
                      preset: 'islands#darkGreenCircleIcon',
                    }}
                    clusters={{
                      preset: 'islands#darkGreenClusterIcons',
                    }}
                    //filter={(object) => object.id % 2 === 0}
                    defaultFeatures={points}
                    modules={[
                      'objectManager.addon.objectsBalloon',
                      'objectManager.addon.objectsHint',
                      'objectManager.addon.clustersBalloon',
                      'objectManager.addon.clustersHint',
                    ]}
                    instanceRef={(ref) => {
                      if (ref) {
                        setManager(ref);

                        if (myMap) {
                          myMap.setBounds(ref.getBounds(), {
                            checkZoomRange: true,
                            callback: function () {
                              myMap.getZoom() > 10 && myMap.setZoom(10);
                            },
                          });

                          // myMap.events.add('click', function () {
                          //   myMap.balloon.close();
                          //   setCurObject(null);
                          // });
                        }
                      }
                    }}
                    // onLoad={(ympasInstance) => {
                    //   if (ympasInstance) {
                    //     //alert('ready');

                    //   }
                    // }}
                  />
                </Map>
              </YMaps>
            </div>
          </div>
          <div className='flex flex-col md:flex-row gap-3 '>
            <div className='md:w-3/4'></div>
            <div className='md:w-1/4'>
              <ItemInfo data={curObject} />
            </div>
          </div>
        </div>
      </Modal>
    </>
  );
};

export default MapModal;
