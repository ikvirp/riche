import { Modal } from '@/components/ui';
import cn from 'classnames';
import styles from './MapModal.module.css';

import { providers } from '@/config/city_default';
import { Map, ObjectManager, YMaps } from '@pbe/react-yandex-maps';
import { useState } from 'react';

const mapState = {
  center: [55.751574, 37.573856],
  zoom: 5,
};

// https://codesandbox.io/s/react-yandex-maps-issue-130-forked-r44j5x?file=/src/index.js
// https://github.com/gribnoysup/react-yandex-maps/issues

const MapModal = ({ points, show, onClose }) => {
  const rootClassName = cn(styles.root);
  const [mapLoaded, setMapLoaded] = useState(false);
  const [myMap, setMyMap] = useState(null);

  window.myFunc = function (x) {
    onClose(x);
  };

  const aObjects = points.map((point, id) => {
    const providerData = providers.find((el) => el.key == point.providerKey);

    const body = `
                                    <div class="map_body">
                                    <div class="map__title ">${providerData.name}: ${point.name}</div>
                                    <div class="map__address">${point.address}</div>
                                    <div class="map__action"><input type="button" class="map__button" onclick="window.myFunc(${point.id});"value="Доставить сюда"/></div>
                                    </div>
                                `;

    const icon = providerData.icon
      ? providerData.icon
      : 'islands#blackCircleDotIcon';

    return {
      id: point.id,
      name: `${providerData.name}`,
      type: 'Feature',
      geometry: {
        type: 'Point',
        coordinates: [point.lat, point.lng],
      },
      options: { preset: icon },

      properties: {
        balloonContent: body,

        //clusterCaption: `${providerData.name}: ${point.code}`,
        iconContent: `${providerData.name}`,
        hintContent: `${providerData.name}`,
      },
    };
  });

  return (
    <>
      <Modal onClose={onClose} show={show} variant='map' title='Выбор пункта'>
        <div className='p-0 pb-3 flex flex-col gap-3'>
          <div className='storemap'>
            <div className='map'>
              <YMaps query={{ lang: 'ru_RU', load: 'package.full' }}>
                <Map
                  width='100%'
                  height='100%'
                  defaultState={mapState}
                  modules={['control.ZoomControl', 'control.FullscreenControl']}
                  instanceRef={(ref) => {
                    if (ref) {
                      setMyMap(ref);
                    }
                  }}
                  onLoad={() => setMapLoaded(true)}
                >
                  <ObjectManager
                    objects={{
                      openBalloonOnClick: true,
                      //preset: 'islands#darkGreenCircleDotIcon',
                      balloonPanelMaxMapArea: Infinity,
                    }}
                    clusters={{
                      preset: 'islands#darkGreenClusterIcons',
                      balloonPanelMaxMapArea: Infinity,
                    }}
                    options={{
                      clusterize: false,
                      gridSize: 32,
                    }}
                    defaultFeatures={{
                      type: 'FeatureCollection',
                      features: aObjects,
                    }}
                    modules={[
                      'objectManager.addon.objectsBalloon',
                      'objectManager.addon.clustersBalloon',
                    ]}
                    instanceRef={(ref) => {
                      if (ref) {
                        if (myMap && mapLoaded) {
                          myMap.controls.remove('geolocationControl');
                          myMap.controls.remove('searchControl');
                          myMap.controls.remove('trafficControl');

                          const oZoomControl =
                            myMap.controls.get('zoomControl');
                          oZoomControl.options.set({
                            float: 'none',
                            position: {
                              top: '10px',
                              left: '10px',
                            },
                          });

                          myMap.setBounds(ref.getBounds(), {
                            checkZoomRange: true,
                            callback: function () {
                              myMap.getZoom() > 10 && myMap.setZoom(10);
                            },
                          });
                          setMapLoaded(false);
                        }
                      }
                    }}
                  />
                </Map>
              </YMaps>
            </div>
          </div>
        </div>
      </Modal>
    </>
  );
};

export default MapModal;
