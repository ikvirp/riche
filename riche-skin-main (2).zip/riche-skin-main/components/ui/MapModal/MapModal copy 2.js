import { Modal } from '@/components/ui';
import cn from 'classnames';
import styles from './MapModal.module.css';

import { Map, ObjectManager, YMaps } from '@pbe/react-yandex-maps';
import { useEffect, useState } from 'react';

const mapState = {
  center: [55.751574, 37.573856],
  zoom: 5,
};

// https://codesandbox.io/s/react-yandex-maps-issue-130-forked-r44j5x?file=/src/index.js
// https://github.com/gribnoysup/react-yandex-maps/issues

const MapModal = ({ points, show, onClose }) => {
  const rootClassName = cn(styles.root);
  const [myMap, setMyMap] = useState(null);
  const [manager, setManager] = useState(null);
  const [selectedPoint, setSelectedPoint] = useState(null);
  const [allItems, setAllItems] = useState([]);
  const [curObject, setCurObject] = useState({});

  const onPlacemarkClick = (point) => () => {
    setSelectedPoint(point);
  };

  useEffect(() => {
    if (manager) {
      setAllItems(manager.objects.getAll());
      setCurObject({});

      const onObjectClick = (e) => {
        // objectId – идентификатор объекта, на котором произошло событие.
        var objectId = e.get('objectId');

        const filtred = points.find((el) => el.id == objectId);
        //alert(JSON.stringify(objectId));
        //alert(JSON.stringify(filtred));
        //alert(JSON.stringify(store));
        setCurObject(filtred);

        //alert(objectId);
      };

      // <Placemark
      //   instanceRef={(ref) => {
      //     ref &&
      //       ref.events.add('balloonopen', (e) => {
      //         console.log(
      //           'Кликнули по точке',
      //           e.originalEvent.currentTarget.properties._data.item
      //         );
      //       });
      //   }}
      //   properties={{ tem: item }}
      // />;

      manager.objects.events.add(['click'], onObjectClick);
    }
  }, [manager, points]);

  return (
    <>
      <Modal
        onClose={onClose}
        show={show}
        variant='map'
        className='max-w-full '
        title='Выбор пункта'
      >
        <div className='p-0 pb-3 flex flex-col gap-3'>
          {/* <div>{JSON.stringify(oList.features.length)}</div>
          <div>{JSON.stringify(city)}</div>
          <div>{JSON.stringify(loading)}</div>
          {JSON.stringify(points.length)} */}

          <div className='flex flex-col lg:flex-row gap-3 '>
            <div className='lg:w-3/4'>
              <div className='storemap'>
                <div className='map'>
                  <YMaps query={{ lang: 'ru_RU', load: 'package.full' }}>
                    <Map
                      width='100%'
                      height='100%'
                      defaultState={mapState}
                      modules={[
                        'control.ZoomControl',
                        'control.FullscreenControl',
                      ]}
                      instanceRef={(ref) => {
                        if (ref) {
                          setMyMap(ref);
                        }
                      }}
                    >
                      <ObjectManager
                        objects={{
                          openBalloonOnClick: true,
                          preset: 'islands#darkGreenCircleIcon',
                          balloonpanelmaxmaparea: Infinity,
                        }}
                        clusters={{
                          preset: 'islands#darkGreenClusterIcons',
                          balloonpanelmaxmaparea: Infinity,
                        }}
                        options={{
                          clusterize: false,
                          gridSize: 32,
                        }}
                        defaultFeatures={{
                          type: 'FeatureCollection',
                          features: points.map((point, id) => {
                            return {
                              id: point.id,
                              type: 'Feature',
                              geometry: {
                                type: 'Point',
                                coordinates: [point.lat, point.lng],
                              },
                              properties: {
                                balloonContent: `
                      <p>Информация о метке №${id + 1}.</p>
                      <p>
                        <a href="#${id}">Больше информации...</a>
                      </p>
                  `,
                                clusterCaption: `Метка №${id + 1}`,
                              },
                            };
                          }),
                        }}
                        modules={[
                          'objectManager.addon.objectsBalloon',
                          'objectManager.addon.clustersBalloon',
                        ]}
                        instanceRef={(ref) => {
                          if (ref) {
                            setManager(ref);

                            if (myMap) {
                              myMap.setBounds(ref.getBounds(), {
                                checkZoomRange: true,
                                callback: function () {
                                  myMap.getZoom() > 10 && myMap.setZoom(10);
                                },
                              });

                              // myMap.events.add('click', function () {
                              //   myMap.balloon.close();
                              //   setCurObject(null);
                              // });
                            }
                          }
                        }}
                      />
                      {/* <Clusterer
                    options={{
                      preset: 'islands#darkGreenClusterIcons',
                      groupByCoordinates: false,
                      balloonPanelMaxMapArea: Infinity,
                    }}
                  >
                    {points.map((point, index) => {
                      const boby = `<div class='flex flex-col gap-0 text-sm'><div>${point.city}</div><div>${point.address}</div></div>`;

                      return (
                        <Placemark
                          modules={[
                            'geoObject.addon.balloon',
                            'geoObject.addon.hint',
                          ]}
                          key={index}
                          geometry={[point.lat, point.lng]}
                          onClick={onPlacemarkClick(point)}
                          properties={{
                            item: index,
                            balloonContentHeader: `${point.providerKey} — ${point.name}`,
                            balloonContentBody: boby,
                            balloonContentFooter: `<input type="button" onclick="window.myFunc(${index});"value="Считать кроликов!"/>`,
                          }}
                          options={{
                            balloonPanelMaxMapArea: Infinity,
                            preset: 'islands#darkGreenCircleIcon',
                            openBalloonOnClick: true,
                          }}
                        />
                      );
                    })}
                  </Clusterer> */}
                    </Map>
                  </YMaps>
                </div>
              </div>
            </div>
            <div className='lg:w-1/4'>{JSON.stringify(curObject)}</div>
          </div>
        </div>
      </Modal>
    </>
  );
};

export default MapModal;
