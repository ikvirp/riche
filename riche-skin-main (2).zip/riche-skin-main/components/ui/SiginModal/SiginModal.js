import { Modal, SigninForm } from '@/components/ui';
const NEXT_PUBLIC_AUTH_MODE = process.env.NEXT_PUBLIC_AUTH_MODE;

const SiginModal = ({ redirect = false, show, onClose }) => {
	const title =
		NEXT_PUBLIC_AUTH_MODE == 'phone'
			? 'Войти или зарегистрироваться'
			: 'Личный кабинет';

	return (
		<>
			<Modal redirect={redirect} onClose={onClose} show={show} title={title}>
				<div className="p-0 pb-3">
					<SigninForm />
				</div>
			</Modal>
		</>
	);
};

export default SiginModal;
