import { MinusIcon, PlusIcon } from '@heroicons/react/24/outline';
import cn from 'classnames';
import { useState } from 'react';
import Lnk from '../Lnk/Lnk';
import styles from './FooterSection.module.css';

const FooterSection = ({ data, className, ...props }) => {
  const [isOpen, setIsOpen] = useState(false);

  const rootClassName = cn(styles.root, className);
  const listClassName = cn(styles.list, {
    [styles.open]: isOpen,
  });

  const realIcon = isOpen ? (
    <MinusIcon className={styles.icon} />
  ) : (
    <PlusIcon className={styles.icon} />
  );

  if (data.items.length) {
    return (
      <div className={rootClassName} {...props}>
        <div className={styles.title} onClick={() => setIsOpen(!isOpen)}>
          <span>{data.title}</span>
          {realIcon}
        </div>
        <div className={listClassName}>
          {data.items.map((el, i) => {
            return (
              <div className={styles.item} key={i}>
                <Lnk href={el.slug} title={el.name}>
                  {el.name}
                </Lnk>
              </div>
            );
          })}
        </div>
      </div>
    );
  }
  return <div className={rootClassName} {...props}></div>;
};

export default FooterSection;
