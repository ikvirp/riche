import { Img } from '@/components/ui';
import cn from 'classnames';
import styles from './CatalogGroupHeader.module.css';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const CatalogGroupHeader = ({ data, className, ...props }) => {
  const rootClassName = cn(styles.root, className);

  const imageUrl =
    data.media.length && data?.media[0]?.original
      ? `${NEXT_PUBLIC_DATA_DOMAIN}${data.media[0].original.file}`
      : null;

  return (
    <div className={rootClassName} {...props}>
      {imageUrl && (
        <div className={styles.thumb}>
          <Img
            variant='groupthumb'
            alt={data.name}
            title={data.name}
            src={imageUrl}
            className={styles.img}
            //placeholder='blur'
            width={data.media[0].original.width}
            height={data.media[0].original.height}
            priority
          />
        </div>
      )}
      <div className={styles.summary}>
        <h1 className={styles.title}>{data.title}</h1>
        {data.description != '' && (
          <div
            className={styles.description}
            dangerouslySetInnerHTML={{ __html: data.description }}
          ></div>
        )}
      </div>
    </div>
  );
};

export default CatalogGroupHeader;
