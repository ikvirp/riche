export { default } from './CatalogGroupHeader';
