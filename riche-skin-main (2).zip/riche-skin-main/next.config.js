/** @type {import('next').NextConfig} */

const NEXT_PUBLIC_IMG_HOST = process.env.NEXT_PUBLIC_IMG_HOST;

const path = require('path');
const redirectList = require('./config/redirects');
// const config = require('./config/api');

const nextConfig = {
	reactStrictMode: true,
	sassOptions: {
		includePaths: [path.join(__dirname, 'styles')],
	},
	images: {
		unoptimized: true,
		domains: [NEXT_PUBLIC_IMG_HOST],
	},

	async redirects() {
		return redirectList.list;
		// return [
		//   {
		//     source: '/admin',
		//     destination: NEXT_PUBLIC_ADMIN_URL,
		//     permanent: true,
		//   },
		// ];
	},

	async headers() {
		return [
			{
				source: '/i/font/TTHoves-Regular.woff',
				headers: [
					{
						key: 'Cache-Control',
						value: 'public, max-age=31536000, immutable',
					},
				],
			},
			{
				source: '/i/font/TTHoves-Medium.woff2',
				headers: [
					{
						key: 'Cache-Control',
						value: 'public, max-age=31536000, immutable',
					},
				],
			},
		];
	},
};

module.exports = nextConfig;
