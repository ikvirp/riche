const NEXT_PUBLIC_ADMIN_URL = process.env.NEXT_PUBLIC_ADMIN_URL;

const redirectList = {
	list: [
		// www -> non-www
		{
			source: '/:path*',
			has: [{ type: 'host', value: 'www.riche.skin' }],
			destination: 'https://riche.skin/:path*',
			permanent: true,
		},

		// hostCMS
		{
			source: '/admin',
			destination: NEXT_PUBLIC_ADMIN_URL,
			permanent: true,
		},

		//dynamic-sitemap
		// {
		//   source: '/dynamic-sitemap.xml',
		//   destination: '/dynamic-sitemap',
		//   permanent: true,
		// },
		// {
		//   source: '/dynamic-sitemap-:page.xml',
		//   destination: '/dynamic-sitemap/:page',
		//   permanent: true,
		// },

		// legasy remove 2023-06-07
		// {
		//   source: '/priz:path*',
		//   destination: 'https://old.riche.skin/priz/:path*',
		//   permanent: true,
		// },
		//.htaccess

		// remove 2023-06-19
		// {
		//   source: '/qr/:path*',
		//   destination: 'https://t.me/richeQRproduct_bot',
		//   permanent: true,
		// },

		// vk redirects
		/* {
      source: '/vk/:path*',
      destination: '/:path*',
      permanent: true,
    }, */
		{
			source: '/vk',
			destination: '/?utm_source=vkontakte&utm_medium=group_richescrub',
			permanent: true,
		},
		{
			source: '/inst',
			destination: '/?utm_source=instagram&utm_medium=group_profile',
			permanent: true,
		},

		//RICHEONBD-12
		{
			source: '/tg',
			destination:
				'/?utm_source=telegram&utm_medium=messenger&utm_campaign=link',
			permanent: true,
		},

		// shop_items redirects
		{
			source: '/package/telo/12979/:path*',
			destination:
				'/product/xolodnoe-anticzellyulitnoe-obertyvanie-s-golubym-retinolom-23',
			permanent: true,
		},
		{
			source: '/package/telo/12980/:path*',
			destination:
				'/product/goryachee-anticzellyulitnoe-obertyvanie-s-niaczinamidom-i-myodom-22',
			permanent: true,
		},
		{
			source: '/package/telo/24340/:path*',
			destination: '/catalog/body-4',
			permanent: true,
		},
		{
			source: '/package/telo/12983/:path*',
			destination: '/product/shokoladno-kremovyj-skrab-s-orexovymi-maslami-21',
			permanent: true,
		},
		{
			source: '/package/telo/12981/:path*',
			destination:
				'/product/enzimnyj-skrab-dlya-tela-mango-ananas-razglazhivayushhij-rastyazhki-20',
			permanent: true,
		},
		{
			source: '/package/telo/12982/:path*',
			destination: '/catalog/body-4',
			permanent: true,
		},
		{
			source: '/package/litso-i-guby/7292:path*',
			destination:
				'/product/uvlazhnyayushhij-krem-dlya-licza-hyaluronic-cream-6',
			permanent: true,
		},
		{
			source: '/package/litso-i-guby/7294:path*',
			destination: '/product/matiruyushhij-krem-dlya-licza-anti-acne-cream-7',
			permanent: true,
		},
		{
			source: '/package/litso-i-guby/7293:path*',
			destination:
				'/product/omolazhivayushhij-krem-dlya-licza-anti-age-cream-8',
			permanent: true,
		},
		{
			source: '/package/litso-i-guby/21119:path*',
			destination: '/product/solnczezashhitnyj-krem-dlya-licza-c-spf-30-9',
			permanent: true,
		},
		{
			source: '/package/volosy/12985:path*',
			destination:
				'/product/pitatelnaya-lifting-maska-dlya-licza-med-czeramidy-4',
			permanent: true,
		},
		{
			source: '/package/volosy/12984:path*',
			destination:
				'/product/ochishhayushhaya-detoks-maska-dlya-licza-shpinat-spirulina-5',
			permanent: true,
		},
		{
			source: '/package/lico/12986/:path*',
			destination: '/catalog/face-2',
			permanent: true,
		},
		{
			source: '/package/volosy/12977:path*',
			destination:
				'/product/shampun-r-plex-s-inulinom-dlya-berezhnogo-ochishheniya-vsex-tipov-volos-31',
			permanent: true,
		},
		{
			source: '/package/volosy/12978:path*',
			destination:
				'/product/maska-r-plex-s-peptidami-dlya-vosstanovleniya-povrezhdennyx-volos-32',
			permanent: true,
		},
		{
			source: '/package/litso-i-guby/20332/:path*',
			//destination: '/catalog/face-2',
			// 2023-07-07
			destination:
				'/product/myagkaya-enzimnaya-pudra-dlya-umyvaniya-propolis-matcha-3',
			permanent: true,
		},
		{
			source: '/package/telo/16921/:path*',
			destination:
				'/product/anticzellyulitnoe-maslo-dlya-tela-zhozhoba-ekstrakt-krasnogo-percza-25',
			permanent: true,
		},
		{
			source: '/package/telo/17713/:path*',
			destination:
				'/product/effektivnoe-maslo-dlya-profilaktiki-rastyazhek-mama-oil-26',
			permanent: true,
		},
		{
			source: '/package/volosy/17447/:path*',
			destination:
				'/product/maslo-dlya-volos-s-amloj-vosstanovlenie-i-pitanie-30',
			permanent: true,
		},
		{
			source: '/package/volosy/17819/:path*',
			destination:
				'/product/termozashhitnyj-sprej-dlya-volos-21-v-1-prokeratin-i-proteiny-34',
			permanent: true,
		},
		{
			source: '/package/volosy/17820:path*',
			destination:
				'/product/proteinovyj-tonik-sprej-s-vitaminami-dlya-rosta-volos-33',
			permanent: true,
		},
		{
			source: '/package/telo/6379/:path*',
			destination:
				'/product/kokosovoe-molochko-dlya-berezhnogo-umyvaniya-licza-s-inulinom-1',
			permanent: true,
		},
		{
			source: '/package/volosy/6378/:path*',
			destination:
				'/product/enzimnyj-gel-dlya-umyvaniya-licza-zelyonyj-chaj-kale-2',
			permanent: true,
		},
		{
			source: '/package/volosy/13106/:path*',
			destination: '/catalog/hair-1',
			permanent: true,
		},
		{
			source: '/package/volosy/6956/:path*',
			destination: '/catalog/hair-1',
			permanent: true,
		},
		{
			source: '/package/volosy/17:path*',
			destination:
				'/product/kofejnyj-skrab-dlya-tela-mandarin-anticzellyulitnyj-17',
			permanent: true,
		},
		{
			source: '/package/volosy/18:path*',
			destination:
				'/product/kofejnyj-skrab-dlya-tela-kokos-elastichnost-kozhi-18',
			permanent: true,
		},
		{
			source: '/package/volosy/339/:path*',
			destination: '/product/kofejnyj-skrab-dlya-tela-shokoladnoe-pechene-19',
			permanent: true,
		},
		{
			source: '/package/lico/12988/:path*',
			destination:
				'/product/syvorotka-dlya-licza-s-niaczinamidom-20-protiv-akne-i-chernyx-tochek-10',
			permanent: true,
		},
		{
			source: '/package/lico/12972/:path*',
			destination: '/product/fruktovyj-obnovlyayushhij-piling-dlya-licza-13',
			permanent: true,
		},
		{
			source: '/package/lico/2878/:path*',
			destination:
				'/product/uvlazhnyayushhaya-antivozrastnaya-syvorotka-s-ekstraktom-krov-drakona-11',
			permanent: true,
		},
		{
			source: '/package/lico/12974/:path*',
			destination: '/catalog/face-2',
			permanent: true,
		},
		{
			source: '/package/volosy/24366/:path*',
			destination: '/product/shampun-dlya-okrashennyx-volos-color-r-plex-35',
			permanent: true,
		},
		{
			source: '/package/volosy/24367/:path*',
			destination: '/product/maska-dlya-okrashennyx-volos-color-r-plex-36',
			permanent: true,
		},
	],
};

module.exports = redirectList;
