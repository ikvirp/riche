import { cartReducer } from '@/store/reducers/cart';
import { searchbarReducer } from '@/store/reducers/searchbar';
import { sidebarReducer } from '@/store/reducers/sidebar';
import { combineReducers } from 'redux';

// COMBINED REDUCERS
const reducers = {
  cart: cartReducer,
  sidebar: sidebarReducer,
  searchbar: searchbarReducer,
};

export default combineReducers(reducers);
