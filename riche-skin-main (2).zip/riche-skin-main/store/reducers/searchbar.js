import { SEARCHBAR_CLOSE, SEARCHBAR_TOGGLE } from '../types';

const initialState = {
  open: false,
};

export const searchbarReducer = (state = initialState, { type, payload }) => {
  //alert(action.payload);

  switch (type) {
    case SEARCHBAR_TOGGLE:
      const openVal = state.open;

      return {
        open: !openVal,
      };

      break;
    case SEARCHBAR_CLOSE:
      return {
        open: false,
      };

      break;

    default:
      return state;
  }
};
