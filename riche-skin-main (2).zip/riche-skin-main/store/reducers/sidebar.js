import { SIDEBAR_CLOSE, SIDEBAR_TOGGLE } from '../types';

const initialState = {
  open: false,
  variant: 'menu',
};

export const sidebarReducer = (state = initialState, { type, payload }) => {
  //alert(action.payload);

  switch (type) {
    case SIDEBAR_TOGGLE:
      const openVal = state.open;

      return {
        open: !openVal,
        variant: payload ? payload : 'menu',
      };

      break;
    case SIDEBAR_CLOSE:
      return {
        open: false,
        variant: payload ? payload : 'menu',
      };

      break;

    default:
      return state;
  }
};
