import { CART_EMPTY, CART_LOAD, CART_LOADING } from '../types';

const initialState = {
  isLoading: true,
  user: null,
  coupon: '',
  cart: [],
  total: {
    total_amount_items: 0,
    total_quantity: 0,
    total_discount_items: 0,
    total_discount_order: 0,
    total_amount: 0,
    tax: 0,
    total_weight: 0,
    currency: '',
  },
};

export const cartReducer = (state = initialState, { type, payload }) => {
  //console.log(type, payload);

  switch (type) {
    case CART_LOAD:
      //alert('asdasd');

      return {
        ...state,
        ...payload,
        isLoading: false,
      };
      break;

    case CART_LOADING:
      //alert('asdasd');

      return {
        ...state,
        isLoading: true,
      };
      break;

    case CART_EMPTY:
      //alert('asdasd');

      return {
        ...initialState,
        isLoading: false,
      };
      break;

    default:
      return state;
  }
};
