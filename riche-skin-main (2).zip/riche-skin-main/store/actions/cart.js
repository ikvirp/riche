import { getData } from '@/utils/fetcher';
import { getStorLocal, setStorLocal } from '@/utils/localStorage';
import { CART_EMPTY, CART_LOAD, CART_LOADING } from '../types';
import { sidebar__toggle } from './sidebar';

export const cart__load = (show = false) => {
  return async (dispatch, getState) => {
    try {
      const cartList = JSON.parse(getStorLocal('cartList')) || [];
      const coupon = JSON.parse(getStorLocal('coupon')) || '';

      //console.log(cartList, coupon);

      dispatch(cart__loading());

      const oDop = { coupon: coupon };

      let preCartList = [];

      //console.log('cartList', JSON.stringify(cartList));

      if (cartList.length > 0) {
        cartList.forEach((el) => {
          if (el.quantity > 0) {
            preCartList.push(el);
          }
        });
      }

      //console.log('preCartList', JSON.stringify(preCartList));

      if (cartList.length > 0) {
        const oRequest = {
          token: null,
          ...oDop,
          items: [...preCartList],
        };

        //console.log('oRequest', JSON.stringify(oRequest));

        const repoCart = await getData(`/cart`, 'POST', oRequest);

        let aCartFromApi = [];
        repoCart.cart.forEach((el) => {
          if (el.cart.quantity > 0) {
            aCartFromApi.push({
              id: el.cart.id,
              quantity: el.cart.quantity,
              name: el.name,
              price: el.cart.price,
              group: el.group_name,
              timestamp: el.cart.timestamp,
            });
          }
        });

        //console.log('aCartFromApi', aCartFromApi);
        // записываем в корзину результат из API
        setStorLocal('cartList', JSON.stringify(aCartFromApi));
        // if (aCartFromApi.length > 0) {
        //   setStorLocal('cartList', JSON.stringify(aCartFromApi));
        //   //alert('sdadsa');
        // } else {
        //   //setStorLocal('cartList', JSON.stringify([]));
        // }

        // alert(JSON.stringify(oRequest));
        // alert(JSON.stringify(repoCart));

        dispatch({
          type: CART_LOAD,
          payload: repoCart,
        });

        if (show) {
          dispatch(sidebar__toggle('cart'));
        }
      } else {
        //setStorLocal('cartList', []);
        //setStorLocal('coupon', '');
        dispatch({
          type: CART_EMPTY,
          payload: true,
        });
      }
    } catch (error) {
      console.log(error);
    }
  };
};

export const cart__loading = () => {
  return {
    type: CART_LOADING,
    payload: true,
  };
};

export const cart__empty = () => {
  //setStorLocal('cartList', []);
  //setStorLocal('coupon', '');

  return {
    type: CART_EMPTY,
    payload: true,
  };
};
