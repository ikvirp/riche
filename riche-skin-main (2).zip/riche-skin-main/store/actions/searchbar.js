import { SEARCHBAR_CLOSE, SEARCHBAR_TOGGLE } from '../types';

export const searchbar__toggle = () => {
  return {
    type: SEARCHBAR_TOGGLE,
  };
};

export const searchbar__close = () => {
  return {
    type: SEARCHBAR_CLOSE,
  };
};
