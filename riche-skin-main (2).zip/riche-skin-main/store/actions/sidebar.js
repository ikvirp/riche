import { SIDEBAR_CLOSE, SIDEBAR_TOGGLE } from '../types';

export const sidebar__toggle = (variant = 'menu') => {
  return async (dispatch, getState) => {
    dispatch({
      type: SIDEBAR_TOGGLE,
      payload: variant,
    });
  };
};

export const sidebar__close = (variant = 'menu') => {
  return {
    type: SIDEBAR_CLOSE,
    payload: variant,
  };
};
