import config from '@/config/seo.json';
import { useStore } from '@/store';
import { SessionProvider } from 'next-auth/react';
import { DefaultSeo } from 'next-seo';
import NextHead from 'next/head';
import { Provider } from 'react-redux';

import '@/styles/about.css';
import '@/styles/fancy.css';
import '@/styles/globals.css';
import '@/styles/react-dadata.css';
import '@/styles/typo.css';

//import NextNprogress from 'nextjs-progressbar';

import { R46Set } from '@/components/r46';
import localFont from 'next/font/local';
import { useRouter } from 'next/router';

const hoves = localFont({
	subsets: ['cyrillic'],
	variable: '--font-hoves',
	display: 'swap',
	src: [
		{
			path: '../public/i/font/TTHoves-Regular.woff2',
			weight: '400',
			style: 'normal',
		},
		{
			path: '../public/i/font/TTHoves-Medium.woff2',
			weight: '500',
			style: 'bold',
		},
	],
});

const NEXT_PUBLIC_DATA_WEBMASTER = process.env.NEXT_PUBLIC_DATA_WEBMASTER;
const NEXT_PUBLIC_DOMAIN = process.env.NEXT_PUBLIC_DOMAIN;
const defaultCard = `${NEXT_PUBLIC_DOMAIN}${config.openGraph.images[0].url}`;

const App = ({ Component, pageProps: { session, ...pageProps } }) => {
	const getLayout = Component.getLayout ?? ((page) => page);

	const store = useStore(pageProps.initialReduxState);
	const router = useRouter();
	const pth = router.asPath == '/' ? '' : router.asPath;

	config.openGraph.url = `${NEXT_PUBLIC_DOMAIN}${pth}`;
	config.openGraph.images[0].url = defaultCard;

	return (
		<div className={`${hoves.variable} font-sans `}>
			<style jsx global>{`
				:root {
					--font-hoves: ${hoves.style.fontFamily};
				}
			`}</style>
			<SessionProvider session={session}>
				<Provider store={store}>
					{getLayout(
						<>
							<DefaultSeo {...config} />
							<NextHead>
								<meta
									name="viewport"
									content="width=device-width, initial-scale=1"
								/>
								<link
									rel="apple-touch-icon"
									sizes="180x180"
									href="/i/favicon/apple-touch-icon.png"
								/>
								<link
									rel="icon"
									type="image/png"
									sizes="32x32"
									href="/i/favicon/favicon-32x32.png"
								/>
								<link
									rel="icon"
									type="image/png"
									sizes="16x16"
									href="/i/favicon/favicon-16x16.png"
								/>
								<link rel="manifest" href="/site.webmanifest" />
								<link
									rel="mask-icon"
									href="/i/favicon/safari-pinned-tab.svg"
									color="#000"
								/>
								<meta name="apple-mobile-web-app-title" content="RICHE" />
								<meta name="application-name" content="RICHE" />
								<meta name="msapplication-TileColor" content="#fff" />
								<meta name="theme-color" content="#fff" />
								<meta
									name="yandex-verification"
									content={NEXT_PUBLIC_DATA_WEBMASTER}
								/>
							</NextHead>
							<R46Set />
							<Component {...pageProps} />
						</>,
						pageProps,
					)}
				</Provider>
			</SessionProvider>
		</div>
	);
};

export default App;
