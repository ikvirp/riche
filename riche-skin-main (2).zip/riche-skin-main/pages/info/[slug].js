import { Aside, Content, Layout } from '@/components/common';
import { InfoCardMenu } from '@/components/ui';
import { getData } from '@/utils/fetcher';
import { prepareText } from '@/utils/prepare';
import { NextSeo } from 'next-seo';

const InfoItemPage = ({ info, list }) => {
  const itemName = info.entity.name;
  const itemDescription = info.entity.description;
  const seo = info.entity.seo;

  const output = prepareText(info.entity.text);

  return (
    <>
      <NextSeo title={seo.title} description={seo.description} />
      <Content aside>
        <div className='flex-1 order-2'>
          <h1>{itemName}</h1>
          {/* {itemDescription != '' && (
            <div
              className='lead'
              dangerouslySetInnerHTML={{ __html: itemDescription }}
            >
              {}
            </div>
          )} */}
          {output}
        </div>
        <Aside>
          <InfoCardMenu items={list.items} />
        </Aside>
      </Content>
    </>
  );
};

InfoItemPage.getLayout = function getLayout(page, pageProps) {
  const currentItem = pageProps.info.entity;

  const breadcrumbs = [
    {
      name: 'Покупателям',
      slug: '/info',
    },
    {
      name: currentItem.name,
      slug: currentItem.slug,
    },
  ];

  return (
    <Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
      {page}
    </Layout>
  );
};

export default InfoItemPage;

export async function getStaticPaths() {
  const repoItems = await getData('/info?list=1');

  const paths = repoItems.groups.map((item, index) => {
    return { params: { slug: item } };
  });

  return { paths, fallback: 'blocking' };
}

export async function getStaticProps({ params }) {
  const { slug } = params;

  const repoInfo = await getData(`/info/${slug}`);

  if (!repoInfo?.entity?.name) {
    return {
      notFound: true,
    };
  }

  const repoInfoList = await getData(`/info`);

  const repoMenu = await getData(`/menu`);

  return {
    props: { menu: repoMenu, info: repoInfo, list: repoInfoList },
    revalidate: 10,
  };
}
