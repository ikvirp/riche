import { Aside, Content, Layout } from '@/components/common';
import { InfoCardList } from '@/components/ui';
import { getData } from '@/utils/fetcher';
import { prepareText } from '@/utils/prepare';
import { NextSeo } from 'next-seo';

const InfoPage = ({ info }) => {
  const groupName = info.entity.name;
  const groupDescription = info.entity.description;
  const seo = info.entity.seo;

  const aGroups = info.groups;

  return (
    <>
      <NextSeo title={seo.title} description={seo.description} />
      <Content aside>
        <div className='flex-1 order-2'>
          <h1>{groupName}</h1>
          {groupDescription != '' && (
            <div
              className='lead'
              dangerouslySetInnerHTML={{ __html: groupDescription }}
            >
              {}
            </div>
          )}
          <InfoCardList items={info.items} />
        </div>
        <Aside></Aside>
      </Content>
    </>
  );
};

InfoPage.getLayout = function getLayout(page, pageProps) {
  const currentItem = pageProps.info.entity;

  const breadcrumbs = [
    {
      name: currentItem.name,
      slug: currentItem.slug,
    },
  ];

  return (
    <Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
      {page}
    </Layout>
  );
};

export default InfoPage;

export async function getStaticProps({ params }) {
  const repoMenu = await getData(`/menu`);
  const repoInfo = await getData(`/info`);

  if (!repoInfo?.entity?.name) {
    return {
      notFound: true,
    };
  }

  return {
    props: { menu: repoMenu, info: repoInfo },
    revalidate: 10,
  };
}
