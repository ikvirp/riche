import { Content, Layout } from '@/components/common';
import { SigninForm } from '@/components/ui';
import { getData } from '@/utils/fetcher';
import { getServerSession } from 'next-auth/next';
import { useSession } from 'next-auth/react';
import { NextSeo } from 'next-seo';
import { useRouter } from 'next/router';
import { useEffect } from 'react';
import { authOptions } from './api/auth/[...nextauth]';

const SignIn = ({}) => {
	//console.log(categories);
	const { status: session_status } = useSession();
	const router = useRouter();

	useEffect(() => {
		if (session_status === 'authenticated') {
			//redirect('/me');
			router.push('/me');
		}
	}, [session_status]);

	return (
		<>
			<NextSeo
				title="Авторизация на сайте"
				description="Авторизация на сайте"
			/>
			<Content variant="sm">
				<h1>Авторизация на сайте</h1>
				<SigninForm redirect={false} />
			</Content>
		</>
	);
};

SignIn.getLayout = function getLayout(page, pageProps) {
	const breadcrumbs = [
		{
			name: 'Личный кабинет',
			slug: '/me',
		},
	];
	return (
		<Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
			{page}
		</Layout>
	);
};

export default SignIn;

export async function getServerSideProps({ req, res }) {
	const session = await getServerSession(req, res, authOptions);

	//console.log(session);

	if (session) {
		return { redirect: { destination: '/me' } };
	}

	const repoMenu = await getData(`/menu`);

	return {
		props: { menu: repoMenu },
	};
}
