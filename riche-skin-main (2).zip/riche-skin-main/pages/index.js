import { Content, Layout } from '@/components/common';
import { MainBlock } from '@/components/ui';
import styles from '@/styles/pages/HomePage.module.css';
import { getData } from '@/utils/fetcher';
import { LogoJsonLd } from 'next-seo';

const NEXT_PUBLIC_DOMAIN = process.env.NEXT_PUBLIC_DOMAIN;

const HomePage = ({ menu, blocks }) => {
  const aBlocks = blocks ? blocks.blocks : [];

  return (
    <>
      <LogoJsonLd
        logo={`${NEXT_PUBLIC_DOMAIN}/i/logo.png`}
        url={NEXT_PUBLIC_DOMAIN}
      />
      <Content>
        <div className={styles.root}>
          {aBlocks.length > 0 &&
            aBlocks.map((block, i) => {
              return <MainBlock data={block} key={i} />;
            })}
        </div>
      </Content>
    </>
  );
};

HomePage.getLayout = function getLayout(page, pageProps) {
  return <Layout menu={pageProps.menu}>{page}</Layout>;
};

export default HomePage;

export async function getStaticProps({ params }) {
  const repoMenu = await getData(`/menu`);
  const repoMain = await getData(`/main`);

  return {
    props: { menu: repoMenu, blocks: repoMain },
    revalidate: 10,
  };
}
