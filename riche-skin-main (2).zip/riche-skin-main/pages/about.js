import { Content, Layout } from '@/components/common';
import { getData } from '@/utils/fetcher';
import { prepareText } from '@/utils/prepare';
import { NextSeo } from 'next-seo';

const AboutPage = ({ doc }) => {
  const output = prepareText(doc.text);

  return (
    <>
      <NextSeo
        title='RICHE — натуральная косметика для умного ухода'
        description='RICHE — натуральная косметика для умного ухода'
      />
      <Content variant='xl'>{output}</Content>
    </>
  );
};

AboutPage.getLayout = function getLayout(page, pageProps) {
  const breadcrumbs = [
    {
      name: pageProps.doc.name,
      slug: '/about',
    },
  ];
  return (
    <Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
      {page}
    </Layout>
  );
};

export default AboutPage;

export async function getStaticProps({ params }) {
  const repoMenu = await getData(`/menu`);
  const repoDoc = await getData(`/doc/7`);

  if (repoDoc?.error) {
    return {
      notFound: true,
    };
  }

  return {
    props: { menu: repoMenu, doc: repoDoc },
    revalidate: 10,
  };
}
