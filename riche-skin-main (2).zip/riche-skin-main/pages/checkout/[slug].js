import { Content, Layout } from '@/components/common';
import { Button, Loader } from '@/components/ui';
import { authOptions } from '@/pages/api/auth/[...nextauth]';
import styles from '@/styles/pages/CheckoutPage.module.css';
import { getData } from '@/utils/fetcher';
import { CheckCircleIcon } from '@heroicons/react/24/outline';
import { getServerSession } from 'next-auth';
import { NextSeo } from 'next-seo';
import { useRouter } from 'next/router';
import Script from 'next/script';
import { useState } from 'react';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;
const NEXT_PUBLIC_DATA_METRIKA_ID = process.env.NEXT_PUBLIC_DATA_METRIKA_ID;

const CheckoutItemPage = ({ orderData }) => {
  const currentItem = orderData.order;

  const router = useRouter();
  const { status } = router.query;

  const [loading, setLoading] = useState(true);

  const blocksOptions = orderData.handler.block;
  const configuration = orderData.handler.config;
  const handlerStatus = orderData.handler.status;

  const handleLoad = () => {
    //alert('loaded');

    const blocksApp = new cp.PaymentBlocks(blocksOptions, configuration);

    blocksApp.mount(document.getElementById('element'), setLoading(false));

    // blocksApp.on('destroy', () => {
    //   console.log('destroy');
    // });
    blocksApp.on('success', (result) => {
      if (NEXT_PUBLIC_DATA_METRIKA_ID > 0) {
        ym(NEXT_PUBLIC_DATA_METRIKA_ID, 'reachGoal', 'ORDER_PAID');
      }
      router.push(`/checkout/${currentItem.guid}?status=success`);
    });
    blocksApp.on('fail', (result) => {
      router.push(`/checkout/${currentItem.guid}?status=fail`);
      //console.log('fail', result);
    });
  };

  if (handlerStatus.paid || (status && status == 'success')) {
    return (
      <>
        <NextSeo
          title={`Заказ ${currentItem.invoice} оплачен`}
          description={`Заказ ${currentItem.invoice} оплачен`}
        />
        <Content variant='sm'>
          <div className={styles.cnt2}>
            <CheckCircleIcon className='w-16 h-16 text-primary' />
            <h1
              className={styles.title}
            >{`Заказ ${currentItem.invoice} оплачен`}</h1>
            <div>Информация об оплате была отправлена на вашу почту</div>
            <div className='pt-3'>
              <Button Component='a' href='/me'>
                Перейти в кабинет
              </Button>
            </div>
          </div>
        </Content>
      </>
    );
  }

  return (
    <>
      <Script
        src='https://widget.cloudpayments.ru/bundles/paymentblocks.js'
        strategy='lazyOnload'
        onLoad={handleLoad}
      />
      <NextSeo
        title={`Оплата заказа ${currentItem.invoice}`}
        description={`Оплата заказа ${currentItem.invoice}`}
      />
      <Content variant='sm'>
        {/* <div>{JSON.stringify(status)}</div>
        <div>{JSON.stringify(orderData)}</div> */}
        {loading && <Loader />}
        <div className={styles.cnt}>
          <h1
            className={styles.title}
          >{`Оплата заказа ${currentItem.invoice}`}</h1>
          <div id='element'></div>
        </div>
      </Content>
    </>
  );
};

CheckoutItemPage.getLayout = function getLayout(page, pageProps) {
  const breadcrumbs = [
    {
      name: 'Оформление заказа',
      slug: '/checkout',
    },
  ];
  return (
    <Layout variant='checkout2' breadcrumbs={null} menu={pageProps.menu}>
      {page}
    </Layout>
  );
};

export default CheckoutItemPage;

export async function getServerSideProps({ req, res, params }) {
  const session = await getServerSession(req, res, authOptions);

  if (!session) {
    return { redirect: { destination: '/signin' } };
  }

  const { slug } = params;

  const repoMenu = await getData(`/menu`);

  const repoMeOrderData = await getData(`/me/orders`, 'POST', {
    token: session.token,
    guid: slug,
    paydata: true,
  });

  //console.log(repoMeOrderData);

  if (!repoMeOrderData) {
    return {
      notFound: true,
    };
  }

  return {
    props: { menu: repoMenu, orderData: repoMeOrderData },
  };
}
