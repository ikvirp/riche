import { Content, Layout } from '@/components/common';
import { Button, CityModal, Img, Lnk, Loader, MapModal } from '@/components/ui';
import { city_default, providers } from '@/config/city_default';
import { authOptions } from '@/pages/api/auth/[...nextauth]';
import styles from '@/styles/pages/CheckoutPage.module.css';
import { getData } from '@/utils/fetcher';
import { numberFormat } from '@/utils/prepare';
import { RadioGroup, Tab } from '@headlessui/react';
import { ChevronRightIcon } from '@heroicons/react/24/outline';
import cn from 'classnames';
import { getServerSession } from 'next-auth';
import { NextSeo } from 'next-seo';
import Image from 'next/image';
import { useRouter } from 'next/router';
import { useEffect, useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { useLocalStorage, useReadLocalStorage } from 'usehooks-ts';

import { AddressSuggestions } from 'react-dadata';
import useR46Track from '@/components/r46/useR46Track';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;
const NEXT_PUBLIC_DATA_METRIKA_ID = process.env.NEXT_PUBLIC_DATA_METRIKA_ID;

const deliveryTypes = {
	0: 'point',
	1: 'door',
};

const CheckoutPage = ({ token }) => {
	const dispatch = useDispatch();
	const router = useRouter();

	const { trackPurchase } = useR46Track();

	const [cartList, setCartList] = useLocalStorage('cartList', []);
	const [coupon, setCoupon] = useLocalStorage('coupon', '');

	const [valueIndex, setValueIndex] = useState('');
	const suggestionsRef = useRef(null);

	// проверка и валидация формы
	const {
		register,
		setValue,
		getValues,
		handleSubmit,
		reset,
		formState: { errors, isDirty, isValid },
	} = useForm({
		mode: 'all',
	});

	//const { replace } = useFieldArray({ name: 'address' });

	const valuesForm = getValues();

	// загрузчик
	const [loading, setLoading] = useState(true);
	const [loadingGlobal, setLoadingGlobal] = useState(false);

	// Данные корзины из Redux
	const cartFull = useSelector((state) => state.cart);

	// город из localStorage
	const userCityLocal = useReadLocalStorage('city');

	// город по дефолту
	const [userCity, setUserCity] = useState(city_default);

	// окно выбора города
	const [showModalCity, setShowModalCity] = useState(false);

	// текущий таб доставки
	const [tabIndex, setTabIndex] = useState(0);

	// окно выбора пункта
	const [showModalMap, setShowModalMap] = useState(false);
	const [points, setPoints] = useState([]);
	// текущая выбранная точка на карте
	const [cPoint, setCPoint] = useState(null);
	const [cPointData, setCPointData] = useState(null);
	const [oDelivery, setODelivery] = useState({});

	const [deliveryDate, setDeliveryDate] = useState(null);

	// платёжная система
	const [payVal, setPayVal] = useState(null);

	// окончательные данные цены
	const [orderTotal, setОrderTotal] = useState(cartFull.total);

	// данные первого тач
	const [firstData, setFirstData] = useState(null);

	//
	const [saveProfile, setSaveProfile] = useState(false);

	useEffect(() => {
		const fetchData = async () => {
			const fullFata = {
				token: token,
				city_id: userCity.id,
			};

			const data = await getData(`/checkout`, 'POST', fullFata);

			if (typeof data.total.delivery_date != 'undefined') {
				//alert(`${userCity.id} — ${data.total.delivery_date}`);
				setDeliveryDate(data.total.delivery_date);
			}
		};
		fetchData();
	}, [userCity]);

	// Изменение города
	useEffect(() => {
		// let useCityName = userCity.city_name;
		// if (userCityLocal) {
		//   setUserCity(userCityLocal);
		//   useCityName = userCityLocal.city_name;
		// }

		let useCityId = userCity.id;
		if (userCityLocal) {
			setUserCity(userCityLocal);
			useCityId = userCityLocal.id;
		}

		const fetchData = async () => {
			// const oCart = cartFull.cart.map((el, i) => {
			//   return {
			//     id: el.cart.id,
			//     quantity: el.cart.quantity,
			//     timestamp: el.cart.timestamp,
			//   };
			// });

			const fullFata = {
				token: token,
				city_id: userCity.id,
				// coupon: cartFull.coupon,
				// items: oCart,
			};

			//alert('fullFata: ' + JSON.stringify(fullFata));

			const data = await getData(`/checkout`, 'POST', fullFata);
			setPayVal(data.pay[0]);
			setFirstData(data);
			reset({ ...data.profile, address: '' });
			setValueIndex('');

			setSaveProfile(data.updateprofile);

			resetDadata();
			//setDeliveryDate(null);

			if (typeof data.total.delivery_date != 'undefined') {
				//alert(`${userCity.id} — ${data.total.delivery_date}`);
				setDeliveryDate(data.total.delivery_date);
			}

			const oDelivery = {
				delivery_type: deliveryTypes[tabIndex],
				delivery_provider: null,
				delivery_address: null,
				delivery_index: null,
				apiship_point_id: null,
			};
			setODelivery(oDelivery);
		};
		fetchData();

		// Первичные данные пункты
		const fetchDataPoints = async () => {
			setLoading(true);
			const data = await getData(`/apiship/points`, 'POST', {
				city_id: useCityId,
			});
			if (data) {
				setPoints(data.rows);
			}
			setLoading(false);
		};
		fetchDataPoints();
	}, [userCityLocal]);

	// Изменение типа доставки таб
	useEffect(() => {
		let in_delivery_type = deliveryTypes[tabIndex];
		let in_delivery_provider = null;
		let in_delivery_address = null;
		let in_delivery_index = null;
		let in_apiship_point_id = null;

		//setValue('address', '');
		reset({ address: '' });
		//alert('asdasd');
		resetDadata();
		// if (suggestionsRef.current) {
		//   suggestionsRef.current.setValueData('Тут пример запроса');
		// }

		if (tabIndex == 1) {
			in_delivery_provider = 'courier';
		}

		// const fetchData = async () => {
		//   const fullFata = {
		//     token: token,
		//     city_id: userCity.id,
		//   };
		//   const data = await getData(`/checkout`, 'POST', fullFata);
		//   setDeliveryDate(oDelivery);
		// };
		// fetchData();

		//setDeliveryDate(null);
		setODelivery({
			delivery_type: in_delivery_type,
			delivery_provider: in_delivery_provider,
			delivery_address: in_delivery_address,
			delivery_index: in_delivery_index,
			apiship_point_id: in_apiship_point_id,
		});
	}, [tabIndex]);

	// Изменение текущй точки
	useEffect(() => {
		if (cPoint) {
			const filtred = points.find((el) => el.id == cPoint);

			if (filtred) {
				setCPointData(filtred);

				setODelivery({
					delivery_type: deliveryTypes[tabIndex],
					delivery_provider: filtred.providerKey,
					delivery_index: filtred.postIndex,
					delivery_address: `${filtred.street} ${filtred.streetType}, ${filtred.house}`,
					apiship_point_id: cPoint,
				});

				// setValue(
				//   'address',
				//   `${filtred.street} ${filtred.streetType}, ${filtred.house}`
				// );

				//alert(JSON.stringify(filtred));
				setValueIndex(filtred.postIndex);

				reset({
					address: `${filtred.street} ${filtred.streetType}, ${filtred.house}`,
				});
			}
		}
	}, [cPoint]);

	const onSubmitOrder = async (data) => {
		setLoadingGlobal(true);

		const aCurDelivery = oDelivery;
		aCurDelivery.delivery_address = data.address;
		aCurDelivery.delivery_index = valueIndex;

		const oCart = cartFull.cart.map((el, i) => {
			return {
				id: el.cart.id,
				quantity: el.cart.quantity,
				timestamp: el.cart.timestamp,
			};
		});

		//let saveProfile = firstData && firstData.updateprofile ? true : false;

		const fullFata = {
			token: token,
			coupon: cartFull.coupon,
			city_id: userCity.id,
			delivery: aCurDelivery,
			pay_id: payVal.id,
			profile: {
				email: data.email,
				phone: data.phone,
				surname: data.surname,
				name: data.name,
				save: saveProfile,
			},
			items: oCart,
		};

		//alert(JSON.stringify(fullFata));

		const fetchData = async () => {
			const data = await getData(`/makeorder`, 'POST', fullFata);

			let orderAmount = 0;
			const aProducts = [];
			data.items.forEach((el) => {
				if (el.price > 0) {
					orderAmount += el.price * el.quantity;
					aProducts.push({
						id: el.id,
						price: el.price,
						amount: el.quantity,
					});
				}
			});

			if (aProducts.length > 0) {
				const oObjR46 = {
					email: data.order.email,
					phone: data.order.phone,
					products: aProducts,
					order: data.order.invoice,
					order_price: orderAmount,
				};
				trackPurchase(oObjR46);
			}

			if (data && data.order) {
				if (NEXT_PUBLIC_DATA_METRIKA_ID > 0) {
					// metrika — Покупка
					window.dataLayer = window.dataLayer || [];
					window.dataLayer.push({
						ecommerce: {
							currencyCode: 'RUB',
							purchase: {
								actionField: {
									id: data.order.invoice,
									coupon: data.order.coupon,
								},
								products: data.items,
							},
						},
					});
					ym(NEXT_PUBLIC_DATA_METRIKA_ID, 'reachGoal', 'ORDER_CREATE');
				}

				//router.push(payUrl);
				router.push(`/checkout/${data.order.guid}`);
				setCartList([]);
				setCoupon('');
				//setLoadingGlobal(false);
			}
		};
		fetchData();

		//alert(JSON.stringify(fullFata));
	};

	useEffect(() => {
		if (oDelivery.delivery_provider && oDelivery.delivery_type) {
			const oCart = cartFull.cart.map((el, i) => {
				return {
					id: el.cart.id,
					quantity: el.cart.quantity,
					timestamp: el.cart.timestamp,
				};
			});

			const fullFata = {
				token: token,
				coupon: cartFull.coupon,
				items: oCart,

				city_id: userCity.id,
				delivery: oDelivery,
				pay_id: payVal.id,
			};

			//alert(JSON.stringify(fullFata));

			const fetchData = async () => {
				const data = await getData(`/checkout`, 'POST', fullFata);

				if (data.total) {
					setОrderTotal(data.total);

					if (typeof data.total.delivery_date != 'undefined') {
						setDeliveryDate(data.total.delivery_date);
					}

					//alert(JSON.stringify(data));
				}
			};
			fetchData();
		}
	}, [oDelivery]);

	// useEffect(() => {
	//   if (oDelivery.delivery_provider && oDelivery.delivery_address) {
	//     const oCart = cartFull.cart.map((el, i) => {
	//       return {
	//         id: el.cart.id,
	//         quantity: el.cart.quantity,
	//         timestamp: el.cart.timestamp,
	//       };
	//     });

	//     const fullFata = {
	//       token: token,
	//       coupon: cartFull.coupon,
	//       items: oCart,

	//       city_id: userCity.id,
	//       delivery: oDelivery,
	//       pay_id: payVal.id,
	//     };

	//     alert(JSON.stringify(fullFata));

	//     const fetchData = async () => {
	//       const data = await getData(`/checkout`, 'POST', fullFata);

	//       if (data.total) {
	//         setОrderTotal(data.total);
	//         //alert(JSON.stringify(data.total));
	//       }
	//     };
	//     fetchData();
	//   }
	// }, [valuesForm.address]);

	const resetDadata = () => {
		if (suggestionsRef && suggestionsRef.current) {
			//alert('asds');
			setValueIndex('');
			suggestionsRef.current.setInputValue('');

			//setValueData('');
		}
	};
	const handleInputChange = (event) => {
		// alert(JSON.stringify(event.target.value));

		// console.log(event.target.value);
		// let postalCode = '';
		// if (e.data.postal_code) {
		//   postalCode = e.data.postal_code;
		// }
		// setValueIndex(postalCode);

		reset({
			address: event.target.value,
		});
	};

	const cityName = userCity
		? `${userCity.city_name}, ${userCity.region_name}`
		: 'Выбрать город';

	// const buttonDisabled =
	//   isValid && oDelivery.delivery_provider && oDelivery.delivery_address
	//     ? false
	//     : true;

	const buttonDisabled =
		isValid && valuesForm.address && valuesForm.address != '' ? false : true;

	const addressInputData =
		oDelivery.delivery_type == 'point'
			? { label: 'Адрес пункта выдачи', class: 'hidden', disabled: false }
			: { label: 'Адрес доставки', class: 'block', disabled: false };

	const providerData = providers.find(
		(el) => el.key == oDelivery.delivery_provider,
	);
	const deliveryPointAddress =
		providerData && oDelivery.delivery_address
			? `${providerData.name}: ${oDelivery.delivery_address}`
			: //: 'Укажите пункт выдачи';
			oDelivery.delivery_type == 'point'
			? 'укажите пункт выдачи'
			: 'укажите адрес';

	const sAddress =
		valuesForm.address && valuesForm.address != ''
			? `${numberFormat(orderTotal.total_delivery_price)} ${
					orderTotal.currency
			  }`
			: oDelivery.delivery_type == 'point'
			? 'укажите пункт'
			: 'укажите адрес';

	const sAddress2 =
		valuesForm.address && valuesForm.address != ''
			? `${numberFormat(orderTotal.total_order)} ${orderTotal.currency}`
			: oDelivery.delivery_type == 'point'
			? 'укажите пункт'
			: 'укажите адрес';

	const realAddress = (
		<>
			<div className={styles.subtotal}>
				<span>
					<div>{`Доставка (${deliveryPointAddress})`}</div>
					<div></div>
				</span>
				<span>{sAddress}</span>
			</div>

			{deliveryDate && (
				<div className={styles.subtotal}>
					<span>Доставим</span>
					<span>{deliveryDate}</span>
				</div>
			)}

			<div>
				<hr />
				<div className={styles.subtotal}>
					<span className="font-bold">Итого заказ</span>
					<span className="font-bold">{sAddress2}</span>
				</div>
			</div>
		</>
	);

	if (cartFull.cart.length == 0) {
		return (
			<>
				<NextSeo title="Оформление заказа" description="Оформление заказа" />
				<Content variant="sm">
					<div className={styles.cnt}>
						<h1 className={styles.title}>Оформление заказа</h1>
						<div className="text-xl text-center">
							Добавьте товары из&nbsp;каталога в&nbsp;корзину чтобы перейти
							к&nbsp;оформлению
						</div>
						<div className="text-xl text-center pt-3">
							<Button Component="a" href="/catalog" title="Каталог">
								Перейти в каталог
							</Button>
						</div>
					</div>
				</Content>
			</>
		);
	}

	return (
		<>
			<NextSeo title="Оформление заказа" description="Оформление заказа" />
			<Content variant="sm">
				{/* <div>orderTotal: {JSON.stringify(cartFull.total)}</div>
        <div>{points.length}</div> */}
				{/* <div>{points.length}</div>
        <hr />
        <div className='fle flex-col gap-1.5'>
          <div>oDelivery: {JSON.stringify(oDelivery)}</div>
          <hr />
          <div>city_id: {userCity.id}</div>
          <hr />
          <div>orderTotal: {JSON.stringify(orderTotal)}</div>
        </div> */}

				{/* <div>orderTotal: {JSON.stringify(valuesForm)}</div> */}
				{/* <div>SaveProfile: {JSON.stringify(saveProfile)}</div> */}

				{loadingGlobal && <Loader />}

				<form onSubmit={handleSubmit(onSubmitOrder)}>
					<div className={styles.cnt}>
						{/* {loading && <Loader variant='cart' />} */}
						<h1 className={styles.title}>Оформление заказа</h1>

						<div className={styles.part}>
							<div>
								<div className={styles.ttl}>Город доставки</div>
								<div>
									<span
										className="cursor-pointer hover:opacity-60 inline-flex items-center leading-none"
										onClick={() => {
											setShowModalCity(true);
										}}
									>
										{cityName}
										<ChevronRightIcon className="w-4 h-4" />
										<CityModal
											show={showModalCity}
											onClose={() => {
												setShowModalCity(false);

												//setDeliveryDate(null);
											}}
										/>
									</span>
								</div>
							</div>
						</div>

						<div>
							<Tab.Group
								selectedIndex={tabIndex}
								//onChange={setTabIndex}
								onChange={(index) => {
									setTabIndex(index);
									resetDadata();
									//setDeliveryDate(null);
								}}
							>
								<Tab.List className={styles.tablist}>
									<Tab
										className={({ selected }) =>
											cn(styles.tab, selected ? styles.tabactive : '')
										}
									>
										Пункты выдачи
									</Tab>
									<Tab
										className={({ selected }) =>
											cn(styles.tab, selected ? styles.tabactive : '')
										}
									>
										Курьером
									</Tab>
								</Tab.List>
								<Tab.Panels>
									<Tab.Panel className={styles.tabpanel}>
										<div className="h-24 bg-gray-200 rounded-md flex flex-col items-center justify-center relative overflow-hidden">
											<Image
												src="/i/map.jpg"
												// width='1024'
												// height='180'
												alt="Пункты выдачи"
												title="Пункты выдачи"
												className={styles.mapimage}
												fill={true}
											/>
											<Button
												variant="white"
												className="shadow-md"
												//disabled={loading}
												onClick={() => {
													if (!loading) {
														reset({
															address: '',
														});
														setValueIndex('');
														resetDadata();
														setShowModalMap(true);
													}
												}}
											>
												{loading && <Loader variant="cart" />}
												Выбрать пункт
											</Button>
										</div>
										<MapModal
											points={points}
											show={showModalMap}
											// onClose={() => {
											//   setShowModalMap(false);
											// }}
											onClose={(e) => {
												setShowModalMap(false);
												//const old = checkoutData;

												if (e) {
													setCPoint(e);
												}
											}}
										/>
										<div className="pt-3">{deliveryPointAddress}</div>
									</Tab.Panel>
									<Tab.Panel className={styles.tabpanel}></Tab.Panel>
								</Tab.Panels>
							</Tab.Group>
							<div className={cn(`${addressInputData.class}`)}>
								<input
									type="hidden"
									id="index"
									name="index"
									placeholder="Индекс"
									value={valueIndex}
									onChange={(e) => {
										setValueIndex(e.target.value);
									}}
								/>

								<label
									className="text-gray-500 pb-1 px-2 block text-sm"
									htmlFor="address"
								>
									{addressInputData.label}
								</label>

								<div>
									<AddressSuggestions
										token="64b75257b4ef513c8e21645a38f265759a822470"
										//value={valueData}
										onChange={(e) => {
											let postalCode = '';
											if (e.data.postal_code) {
												postalCode = e.data.postal_code;
											}
											setValueIndex(postalCode);
											reset({
												address: e.value,
											});
										}}
										ref={suggestionsRef}
										filterLocations={[{ city: userCity.city_name }]}
										filterRestrictValue={true}
										inputProps={{
											onChange: handleInputChange,
											placeholder: addressInputData.label,
										}}
										selectOnBlur
									/>

									<input
										className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14  hidden"
										type="text"
										id="address"
										name="address"
										disabled={addressInputData.disabled}
										placeholder={addressInputData.label}
										//onKeyUp={handleKeyUp}
										// onChange={(e) => {
										//   alert(e.target.value);
										//   if (suggestionsRef.current) {
										//     suggestionsRef.current.setInputValue(e.target.value);
										//   }
										// }}
										{...register('address', {
											required: true,
											// onChange: (e) => {
											//   handleKeyUp(e.target.value);
											// },
										})}
									/>
								</div>

								{errors.address?.type === 'required' && (
									<div
										className="text-xs pt-1.5 px-2 text-red-600"
										role="alert"
									>
										Адрес обязателен
									</div>
								)}
							</div>

							{/* <div>{cityName}</div>
              <div>{userCity.city_name}</div> */}
							{/* <div>{JSON.stringify(filterLocation)}</div> */}
						</div>

						<div className={styles.part}>
							<div className={styles.ttl}>Способ оплаты</div>
							{firstData && firstData.pay.length > 0 && (
								<RadioGroup
									value={payVal}
									onChange={(el) => {
										setPayVal(el);
									}}
								>
									<div className={styles.list}>
										{firstData.pay.map((el, i) => (
											<RadioGroup.Option
												key={i}
												value={el}
												className={({ active, checked }) =>
													`${active ? '' : ''}
                          ${checked ? ' ring-black' : ' ring-gray-200'}
                            relative flex cursor-pointer rounded-md ring-2  p-3 focus:outline-none`
												}
											>
												{({ active, checked }) => (
													<>
														<div className="flex w-full items-center justify-between gap-3">
															<div className="shrink-1">
																<span
																	className={`block w-6 h-6 rounded-full relative after:content-[''] after:block after:absolute after:w-3 after:h-3 after:rounded-full after:left-1.5 after:top-1.5 ${
																		checked
																			? ' bg-black after:bg-white'
																			: ' bg-gray-200'
																	}`}
																></span>
															</div>
															<div className="flex flex-col flex-1">
																<RadioGroup.Label as="div">
																	{el.name}
																</RadioGroup.Label>
																<RadioGroup.Description
																	as="div"
																	className="text-sm text-gray-500"
																>
																	{el.description}
																</RadioGroup.Description>
															</div>
															<div className="shrink-1">
																<Img
																	src={`${NEXT_PUBLIC_DATA_DOMAIN}${el.thumb}`}
																	width="40"
																	height="40"
																	alt={el.name}
																	title={el.name}
																/>
															</div>
														</div>
													</>
												)}
											</RadioGroup.Option>
										))}
									</div>
								</RadioGroup>
							)}
						</div>

						<div className={styles.part}>
							<div className={styles.ttl}>Данные покупателя</div>
							<div className={styles.inputlist}>
								<div>
									<label
										className="text-gray-500 pb-1 px-2 block text-sm"
										htmlFor="email"
									>
										Email
									</label>
									<input
										className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14"
										type="email"
										id="email"
										name="email"
										placeholder="ваша@эл.почта"
										{...register('email', {
											required: true,
											pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
										})}
									/>
									{errors.email?.type === 'required' && (
										<div
											className="text-xs pt-1.5 px-2 text-red-600"
											role="alert"
										>
											Email обязателен
										</div>
									)}
									{errors.email?.type === 'pattern' && (
										<div
											className="text-xs pt-1.5 px-2 text-red-600"
											role="alert"
										>
											Не похоже на Email
										</div>
									)}
								</div>
								<div>
									<label
										className="text-gray-500 pb-1 px-2 block text-sm"
										htmlFor="phone"
									>
										Телефон
									</label>
									<input
										className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14"
										type="text"
										id="phone"
										name="phone"
										placeholder="+7XXXXXXXXXX"
										{...register('phone', {
											required: true,
											pattern:
												/(^\+7)((\d{10})|(\s\(\d{3}\)\s\d{3}\s\d{2}\s\d{2}))/i,
										})}
									/>
									{errors.phone?.type === 'required' && (
										<div
											className="text-xs pt-1.5 px-2 text-red-600"
											role="alert"
										>
											Телефон обязателен
										</div>
									)}
									{errors.phone?.type === 'pattern' && (
										<div
											className="text-xs pt-1.5 px-2 text-red-600"
											role="alert"
										>
											Не похоже на телефон
										</div>
									)}
								</div>
								<div>
									<label
										className="text-gray-500 pb-1 px-2 block text-sm"
										htmlFor="surname"
									>
										Фамилия
									</label>
									<input
										className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14"
										type="text"
										id="surname"
										name="surname"
										placeholder="Фамилия"
										{...register('surname', {
											required: true,
										})}
									/>
									{errors.surname?.type === 'required' && (
										<div
											className="text-xs pt-1.5 px-2 text-red-600"
											role="alert"
										>
											Фамилия обязателена
										</div>
									)}
								</div>
								<div>
									<label
										className="text-gray-500 pb-1 px-2 block text-sm"
										htmlFor="name"
									>
										Имя
									</label>
									<input
										className="block w-full rounded-xl bg-white border-gray-200 focus:border-gray-900 focus:bg-white focus:ring-0 h-14"
										type="text"
										id="name"
										name="name"
										placeholder="Имя"
										{...register('name', {
											required: true,
										})}
									/>
									{errors.name?.type === 'required' && (
										<div
											className="text-xs pt-1.5 px-2 text-red-600"
											role="alert"
										>
											Имя обязателено
										</div>
									)}
								</div>
							</div>

							{firstData && firstData.updateprofile && (
								<div className=" text-sm leading-none pt-1 ">
									<label className="inline-flex items-center">
										<input
											type="checkbox"
											class="
                      w-[18px] h-[18px]
                          rounded-md
                          bg-gray-200
                          border-transparent
                          focus:border-transparent focus:bg-gray-200
                          text-black
                          focus:ring-1 focus:ring-offset-2 focus:ring-gray-500
                        "
											checked={saveProfile}
											onChange={() => setSaveProfile(!saveProfile)}
										/>
										<span className="ml-2">Сохранить данные профиля</span>
									</label>
								</div>
							)}

							{/* <div class='flex items-center'>
              <input
                id='link-checkbox'
                type='checkbox'
                value=''
                class='w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600'
              />
              <label
                for='link-checkbox'
                class='ml-2 text-sm font-medium text-gray-900 dark:text-gray-300'
              >
                I agree with the{' '}
                <a
                  href='#'
                  class='text-blue-600 dark:text-blue-500 hover:underline'
                >
                  terms and conditions
                </a>
                .
              </label>
            </div> */}

							<div className={styles.footer}>
								<div className={styles.total}>
									<div className={styles.subtotal}>
										<span>Стоимость заказа</span>
										<span>
											{`${numberFormat(cartFull.total.total_amount)} ${
												cartFull.total.currency
											}`}
										</span>
									</div>
								</div>
								{realAddress}
							</div>
							<div className="pt-3 text-sm">
								Нажимая на кнопку Сделать заказ, я принимаю условия{' '}
								<Lnk
									href="/info/politika-v-otnoshenii-personalnyx-dannyx-3"
									title="Политика в отношении персональных данных"
									className="underline"
									target="_blank"
								>
									политики обработки персональных данных
								</Lnk>{' '}
								и условия{' '}
								<Lnk
									href="/info/publichnaya-oferta-2"
									title="Публичная оферта"
									className="underline"
									target="_blank"
								>
									публичной оферты
								</Lnk>
							</div>

							<div className="pt-6">
								<Button
									variant="black"
									size="normal"
									className="w-full h-14"
									type="submit"
									disabled={buttonDisabled}
								>
									Сделать заказ
								</Button>
							</div>
						</div>
					</div>
				</form>
			</Content>
		</>
	);
};

CheckoutPage.getLayout = function getLayout(page, pageProps) {
	const breadcrumbs = [
		{
			name: 'Оформление заказа',
			slug: '/checkout',
		},
	];
	return (
		<Layout variant="checkout" breadcrumbs={breadcrumbs} menu={pageProps.menu}>
			{page}
		</Layout>
	);
};

export default CheckoutPage;

export async function getServerSideProps({ req, res }) {
	const session = await getServerSession(req, res, authOptions);

	if (!session) {
		return { redirect: { destination: '/signin' } };
	}
	const repoMenu = await getData(`/menu`);

	return {
		props: { menu: repoMenu, token: session.token },
	};
}
