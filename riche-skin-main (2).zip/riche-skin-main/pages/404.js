import { Content, Layout } from '@/components/common';
import { R46Reccomend } from '@/components/r46';
import { Button } from '@/components/ui';
import styles from '@/styles/pages/ErrorPage.module.css';
import { getData } from '@/utils/fetcher';
import { NextSeo } from 'next-seo';

const Custom404 = ({ menu }) => {
	return (
		<>
			<NextSeo
				title="Такой страницы не существует на сайте"
				description="Такой страницы не существует на сайте"
			/>
			<Content variant="sm">
				<div className={styles.cnt}>
					<h1 className={styles.title}>
						Такой страницы не&nbsp;существует на&nbsp;сайте
					</h1>
					<div className={styles.text}>
						Попробуйте вернуться назад или поищите что-нибудь в&nbsp;каталоге.
					</div>
					<div className={styles.action}>
						<Button Component="a" href="/catalog" title="Каталог">
							Перейти в каталог
						</Button>
					</div>
				</div>
			</Content>
			<Content>
				<div className="pt-12">
					<R46Reccomend
						id={`eea54822f12aefb5efa777cd7965d207`}
						title="Вам будет это интересно"
						centertitle={true}
						//variant="same"
					/>

					<R46Reccomend
						id={`93f34c35483730999e2755d3ffd88c6f`}
						title="Прямо сейчас покупают"
						centertitle={true}
						//variant="same"
					/>
				</div>
			</Content>
		</>
	);
};

Custom404.getLayout = function getLayout(page, pageProps) {
	return <Layout menu={pageProps.menu}>{page}</Layout>;
};

export default Custom404;

export async function getStaticProps({ params }) {
	const repoMenu = await getData(`/menu`);

	return {
		props: { menu: repoMenu },
		revalidate: 10,
	};
}
