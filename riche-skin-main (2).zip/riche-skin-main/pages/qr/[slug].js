import { Content } from '@/components/common';
import { Loader, Logo } from '@/components/ui';
import { getData } from '@/utils/fetcher';
// import Script from 'next/script';

// https://github.com/duskload/react-device-detect/blob/master/docs/selectors.md
// https://stackoverflow.com/questions/59494037/how-to-detect-the-device-on-react-ssr-app-with-next-js

const QRItem = ({ link }) => {
  return (
    <>
      {/* <Script id='start' strategy='lazyOnload'>{`alert('asdasd')`}</Script> */}
      <Content variant='md'>
        <div className='py-12 text-center flex flex-col gap-6 justify-center items-center'>
          <Logo />
          <Loader variant='cart' />
        </div>
      </Content>
    </>
  );
};

export default QRItem;

export async function getServerSideProps({ req, res, params }) {
  const { slug } = params;
  const repoRedirect = await getData(`/qr/${slug}`);

  if (!repoRedirect) {
    return {
      notFound: true,
    };
  } else {
    return {
      redirect: {
        destination: repoRedirect.to,
        permanent: true,
      },
    };
  }

  return {
    props: { link: repoRedirect.to },
  };
}
