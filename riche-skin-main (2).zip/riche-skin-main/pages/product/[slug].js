import { Content, Layout } from '@/components/common';
import { R46Reccomend } from '@/components/r46';
import useR46Track from '@/components/r46/useR46Track';
import {
	AccordionGroup,
	Button,
	PayList,
	ProductCardCatalogList,
	ProductCardComments,
	ProductCardFancy,
	ProductCardPromo,
	ProductCardSame,
	ProductCardStick,
	Stars,
} from '@/components/ui';
import config from '@/config/root.json';
import { cart__load } from '@/store/actions/cart';
import styles from '@/styles/pages/ProductPage.module.css';
import { getData } from '@/utils/fetcher';
import { num_word, numberFormat, prepareText } from '@/utils/prepare';
import {
	CheckIcon,
	HeartIcon,
	ShareIcon,
	ShoppingBagIcon,
	TruckIcon,
} from '@heroicons/react/24/outline';
import { HeartIcon as HeartIconSolid } from '@heroicons/react/24/solid';
import { NextSeo, ProductJsonLd } from 'next-seo';
import { useRouter } from 'next/router';
import { useEffect, useRef, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useLocalStorage } from 'usehooks-ts';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;
const NEXT_PUBLIC_DOMAIN = process.env.NEXT_PUBLIC_DOMAIN;
const NEXT_PUBLIC_DATA_METRIKA_ID = process.env.NEXT_PUBLIC_DATA_METRIKA_ID;

const ProductPage = ({ product }) => {
	const itemName = product.entity.name;
	const itemDescription = product.entity.description;
	const seo = product.entity.seo;

	const output = prepareText(product.entity.text);

	const data = product.entity;

	const { trackProduct, trackFavAdd, trackFavRemove, trackCartAdd } =
		useR46Track();

	// return (
	//   <div>
	//     {JSON.stringify(data.media)}
	//     <div>
	//       {data.media.map((el, i) => {
	//         if (typeof el.original !== 'undefined') {
	//           return (
	//             <div key={i}>
	//               {`${NEXT_PUBLIC_DATA_DOMAIN}${el.original.file}`}
	//             </div>
	//           );
	//         }
	//       })}
	//     </div>
	//   </div>
	// );

	const [favList, setFavList] = useLocalStorage('favList', []);
	const [cartList, setCartList] = useLocalStorage('cartList', []);
	const [isFav, setIsFav] = useState(null);
	const dispatch = useDispatch();
	const router = useRouter();

	const boxRef = useRef();
	const [yButtonCart, setYButtonCart] = useState(0);

	useEffect(() => {
		if (favList) {
			const filtred = favList.find((el) => el == data.id);

			if (filtred) {
				setIsFav(data.id);
			}
		}
	}, [favList, data.id]);

	const getPositionButtonCart = () => {
		setYButtonCart(boxRef.current.offsetTop);
	};

	useEffect(() => {
		const minRest =
			typeof data.min_rest_add != 'undefined' ? data.min_rest_add : 0;

		const inStock = data.rest > minRest ? data.rest : 0;

		const oObjR46 = {
			id: data.id,
			stock: inStock > 0,
		};

		trackProduct(oObjR46);

		getPositionButtonCart();
		window.addEventListener('resize', getPositionButtonCart);
		if (NEXT_PUBLIC_DATA_METRIKA_ID > 0) {
			// metrika — Просмотр товара
			window.dataLayer = window.dataLayer || [];
			window.dataLayer.push({
				ecommerce: {
					currencyCode: 'RUB',
					detail: {
						products: [
							{
								id: data.id,
								name: data.name,
								price: data.price.current,
								category: data.group_name,
							},
						],
					},
				},
			});
		}
	}, [router.asPath]);

	const realPrice =
		data.price.current != data.price.old ? (
			<>
				<span className={styles.pcurrent}>{`${numberFormat(
					data.price.current,
				)} ${data.price.currency}`}</span>
				<span className={styles.pold}>{`${numberFormat(data.price.old)} ${
					data.price.currency
				}`}</span>
			</>
		) : (
			<span className={styles.pcurrent}>{`${numberFormat(data.price.current)} ${
				data.price.currency
			}`}</span>
		);

	const handleClickFav = (id) => {
		const aCur = favList ? favList : [];

		const filtred = aCur.find((el) => el == id);

		if (filtred) {
			const aNew = aCur.filter((el) => el != id);
			setFavList(aNew);
			setIsFav(null);
			trackFavRemove(id);
		} else {
			const aNew = [...aCur, id];
			setIsFav(id);
			setFavList(aNew);
			trackFavAdd(id);
		}
	};

	const handleClickShare = async (obj) => {
		const shareData = {
			title: obj.name,
			text: obj.text,
			url: `${NEXT_PUBLIC_DOMAIN}/product/${data.slug}${config.share_product_utm}`,
		};

		//alert(JSON.stringify(shareData));

		try {
			await navigator.share(shareData);
		} catch (error) {
			console.log(error);
		}
	};

	const handleClickCart = (obj) => {
		const aCur = cartList ? cartList : [];

		// metrika — Добавление товара в корзину
		if (NEXT_PUBLIC_DATA_METRIKA_ID > 0) {
			window.dataLayer = window.dataLayer || [];
			window.dataLayer.push({
				ecommerce: {
					currencyCode: 'RUB',
					add: {
						products: [
							{
								id: obj.id,
								name: obj.name,
								price: obj.price,
								quantity: obj.quantity,
								group: obj.group,
							},
						],
					},
				},
			});
		}

		const found = aCur.find((el) => el.id == obj.id);

		const timestamp = Math.floor(Date.now() / 1000);

		let aNew = [];
		if (!found) {
			aNew = [...aCur, { ...obj, timestamp }];
		} else {
			//alert(found.quantity);

			const filtred = aCur.filter((el) => el.id != obj.id);
			found.quantity++;
			found.timestamp = timestamp;

			aNew = [...filtred, found];
		}

		aNew.sort(function (a, b) {
			// Turn your strings into dates, and then subtract them
			// to get a value that is either negative, positive, or zero.
			return b.timestamp - a.timestamp;
		});

		setCartList(aNew);

		dispatch(cart__load('show'));
		//dispatch(sidebar__toggle('cart'));
		//console.log(cartList);
	};

	const heartIcon = isFav ? (
		<HeartIconSolid className="h-6 w-6 fill-red-600" />
	) : (
		<HeartIcon className="w-6 h-6" />
	);

	const labels = data.labels.length > 0 ? data.labels : null;

	const discount =
		data.price.current != data.price.old ? data.price.discount_percent : null;

	let aAfterPlus = [];
	if (data.for != '') {
		aAfterPlus.push({ name: 'Для какой кожи', description: data.for });
	}
	if (data.instruction != '') {
		aAfterPlus.push({
			name: 'Как использовать',
			description: data.instruction,
		});
	}
	if (data.sostav != '') {
		aAfterPlus.push({ name: 'Состав', description: data.sostav });
	}

	const minRest =
		typeof data.min_rest_add != 'undefined' ? data.min_rest_add : 0;

	const addCartButton =
		data.rest > minRest ? (
			<Button
				variant="productpage"
				className="w-full"
				onClick={(e) => {
					const val = {
						id: data.id,
						quantity: 1,
						name: data.name,
						price: data.price.current,
						group: data.group_name,
					};
					handleClickCart(val);

					trackCartAdd(data.id);
				}}
			>
				<ShoppingBagIcon className="w-6 h-6" /> В корзину
			</Button>
		) : (
			<Button
				variant="productpage"
				className="w-full"
				disabled
				// onClick={(e) => {
				//   const val = {
				//     id: data.id,
				//     quantity: 1,
				//   };
				//   handleClickCart(val);
				// }}
			>
				<ShoppingBagIcon className="w-6 h-6" /> Временно недоступно
			</Button>
		);

	const oOg = data?.media[0]?.original
		? {
				images: [
					{
						url: `${NEXT_PUBLIC_DATA_DOMAIN}${data?.media[0]?.original?.file}`,
						alt: itemName,
					},
				],
		  }
		: null;

	const wVolume =
		parseFloat(data.volume.value) > 0 ? (
			<div className={styles.volume}>
				{`Объём: ${numberFormat(data.volume.value)} ${data.volume.measure}`}
			</div>
		) : parseFloat(data.weight.value) > 0 ? (
			<div className={styles.volume}>
				{`Вес: ${numberFormat(data.weight.value)} ${data.weight.measure}`}
			</div>
		) : null;

	const ldImages = data.media.map((el) => {
		if (typeof el.original !== 'undefined') {
			return `${NEXT_PUBLIC_DATA_DOMAIN}${el.original.file}`;
		}
	});
	const strippedString =
		itemDescription && itemDescription.length > 0
			? itemDescription.replace(/(<([^>]+)>)/gi, '')
			: '';

	const dataSticky = {
		id: data.id,
		name: data.name,
		marking: data.marking,
		thumb: data.thumb,
		slug: data.slug,
		rest: data.rest,
		min_rest_add: minRest,
		price: data.price,
		labels: data.labels,
		seo: data.seo,

		rate: data.comments.rate,
	};

	return (
		<>
			<NextSeo
				title={seo.title}
				description={seo.description}
				openGraph={oOg}
			/>

			<ProductJsonLd
				productName={itemName}
				images={ldImages}
				description={strippedString}
				brand="RICHE"
				manufacturerName="RICHE"
				manufacturerLogo={`${NEXT_PUBLIC_DOMAIN}/i/logo.png`}
				aggregateRating={{
					ratingValue: product.entity.comments.rate.comments_average_grade,
					reviewCount: product.entity.comments.rate.comments_count,
				}}
				offers={[
					{
						price: product.entity.price.current,
						priceCurrency: 'RUB',
						priceValidUntil: '2024-01-01',
						itemCondition: 'https://schema.org/UsedCondition',
						availability: 'https://schema.org/InStock',
						url: `{${NEXT_PUBLIC_DOMAIN}/product/${product.entity.slug}}`,
						seller: {
							name: 'RICHE',
						},
					},
				]}
			/>

			<Content>
				<div className={styles.cnt}>
					<div className={styles.gallery}>
						<ProductCardFancy
							data={data.media}
							labels={labels}
							discount={discount}
							name={itemName}
						/>

						{/* <ProductCardMedia
              data={data.media}
              labels={labels}
              discount={discount}
              name={itemName}
            /> */}
					</div>
					<div className={styles.info}>
						<div className={styles.data}>
							<div className={styles.price}>{realPrice}</div>
							<h1 className={styles.name}>{itemName}</h1>
							{wVolume}
							<div className={styles.rate}>
								<Stars rating={data.comments.rate.comments_average_grade} />
								{parseFloat(data.comments.rate.comments_grade_count) > 0 && (
									<>
										<div className={styles.rating}>
											{parseFloat(data.comments.rate.comments_average_grade)}
										</div>
										<div
											className={styles.ratecount}
											onClick={() => {
												const element = document.getElementById(`commets`);
												if (element) {
													// 👇 Will scroll smoothly to the top of the next section
													element.scrollIntoView({
														behavior: 'smooth',
														//block: 'end',
														inline: 'nearest',
													});
												}
											}}
										>
											{`${numberFormat(
												data.comments.rate.comments_grade_count,
											)} ${num_word(data.comments.rate.comments_grade_count, [
												'отзыв',
												'отзыва',
												'отзывов',
											])}`}
										</div>
									</>
								)}
							</div>
							<div className={styles.cartdelivery}>
								<div className={styles.delivery}>
									<TruckIcon className="w-4 h-4" /> Отправим завтра
								</div>
								<div className={styles.cart} ref={boxRef}>
									<div className={styles.add}>
										{addCartButton}
										<div className={styles.pay}>
											<PayList />
										</div>
									</div>

									<Button
										variant="roundbig"
										aria-label="Избранные товары"
										title="Избранные товары"
										onClick={() => {
											handleClickFav(data.id);
										}}
									>
										{heartIcon}
									</Button>
									<Button
										variant="roundbig"
										aria-label="Поделиться"
										title="Поделиться"
										onClick={() => {
											const shareData = {
												name: itemName,
												text: seo.description,
											};

											handleClickShare(shareData);
										}}
									>
										<ShareIcon className="w-6 h-6" />
									</Button>
								</div>
							</div>

							{data.plus.length > 0 && (
								<ul className={styles.fast}>
									{data.plus.map((el, i) => {
										const icon = el.thumb ? (
											<span className="w-6">
												<CheckIcon className="w-6 h-6" />
											</span>
										) : null;

										return (
											<li className={styles.li} key={i}>
												{icon} {el.name}
												{/* <div className={styles.check}>
                          {icon} {el.name}
                        </div> */}
											</li>
										);
									})}
								</ul>
							)}

							{data.text.length > 0 && (
								<div
									className="pt-3"
									dangerouslySetInnerHTML={{ __html: data.text }}
								></div>
							)}

							{aAfterPlus.length > 0 && (
								<div className="pt-3">
									<AccordionGroup variant="small" list={aAfterPlus} />
								</div>
							)}
						</div>
					</div>
				</div>
				<R46Reccomend
					id={`67142187f3cd9db713460d2b6ae5c20b`}
					title="Рекомендуем присмотреться"
					variant="same"
					//centertitle={true}
					obj={{
						item: data.id,
					}}
				/>
				{data.type == 3 && data.set && data.set.length > 0 && (
					<div className={styles.same}>
						<div className={styles.ttl}>
							<i className="font-accent">Состав</i> набора
						</div>
						<div className={styles.list}>
							{data.set.map((el, i) => {
								return <ProductCardSame data={el} key={i} />;
							})}
						</div>
					</div>
				)}
				{data.promo.length > 0 && (
					<div className={styles.promo}>
						{data.promo.map((el, i) => {
							const odd = i % 2 == 0 ? true : false;
							return <ProductCardPromo data={el} key={i} odd={odd} />;
						})}
					</div>
				)}

				<R46Reccomend
					id={`eea54822f12aefb5efa777cd7965d207`}
					title="Вам будет это интересно"
					//variant="same"
					obj={{
						item: data.id,
					}}
				/>

				{data.faq.length > 0 && (
					<div className={styles.faq}>
						<div className={styles.faq_ttl}>Часто задаваемые вопросы</div>
						<div className={styles.faqlist}>
							<AccordionGroup variant="small" list={data.faq} />
						</div>
					</div>
				)}

				{data.same && data?.same.length > 0 && (
					<div className={styles.same}>
						{/* <div className={styles.ttl}>
							<i className="font-accent">Рекомендуем</i> присмотреться
						</div> */}
						<div className={styles.list}>
							{data.same.map((el, i) => {
								return <ProductCardSame data={el} key={i} />;
							})}
						</div>
					</div>
				)}
				{data.type == 0 &&
					data.recommendation &&
					data.recommendation.length > 0 && (
						<div className={styles.same}>
							{/* <div className={styles.ttl}>
								<i className="font-accent">Рекомендуем</i> присмотреться
							</div> */}
							<div className={styles.list}>
								{data.recommendation.map((el, i) => {
									return <ProductCardSame data={el} key={i} />;
								})}
							</div>
						</div>
					)}

				{data.comments.list.length > 0 && (
					<div id="commets">
						<ProductCardComments
							item_id={data.id}
							item_data={dataSticky}
							comments={data.comments.list}
							rate={data.comments.rate}
						/>
					</div>
				)}

				{data.bottom_recommendation.length > 0 && (
					<ProductCardCatalogList
						//title='Вам понравиться'
						items={data.bottom_recommendation}
					/>
				)}
				<ProductCardStick data={dataSticky} yButtonCart={yButtonCart} />
			</Content>
		</>
	);
};

ProductPage.getLayout = function getLayout(page, pageProps) {
	const currentItem = pageProps.product.entity;

	const currentGroup = pageProps.product.entity.group_id;
	const groupCurrent = pageProps.product.groups.find(
		(el) => el.id == currentGroup,
	);

	const groupParent =
		pageProps.product.groups.find((el) => el.id == groupCurrent.group_id) ||
		null;

	const breadcrumbs = [
		{
			name: 'Каталог RICHE',
			slug: '/catalog',
		},
	];

	if (groupParent) {
		breadcrumbs.push({
			name: groupParent.name,
			slug: `/catalog/${groupParent.slug}`,
		});
	}

	breadcrumbs.push({
		name: groupCurrent.name,
		slug: `/catalog/${groupCurrent.slug}`,
	});

	breadcrumbs.push({
		name: currentItem.name,
		slug: currentItem.slug,
	});

	const data = pageProps.product.entity;

	return (
		<Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
			{page}
		</Layout>
	);
};

export default ProductPage;

export async function getStaticPaths() {
	const repoItems = await getData('/catalog?list=1');

	const paths = repoItems.items.map((item, index) => {
		return { params: { slug: item } };
	});

	return { paths, fallback: 'blocking' };
}

export async function getStaticProps({ params }) {
	const { slug } = params;

	const repoProduct = await getData(`/catalog/${slug}`);

	if (!repoProduct?.entity?.name) {
		return {
			notFound: true,
		};
	}

	const repoMenu = await getData(`/menu`);

	return {
		props: { menu: repoMenu, product: repoProduct },
		revalidate: 10,
	};
}
