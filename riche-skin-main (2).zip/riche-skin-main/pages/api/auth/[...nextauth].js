import { getData } from '@/utils/fetcher';
import NextAuth from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';

const NEXT_PUBLIC_API_URL = process.env.NEXT_PUBLIC_API_URL;
// https://generate-secret.vercel.app/32
const NEXTAUTH_SECRET = process.env.NEXTAUTH_SECRET;

export const authOptions = {
	pages: {
		signIn: '/signin',
		error: '/signin',
	},

	// Configure one or more authentication providers
	providers: [
		CredentialsProvider({
			// The name to display on the sign in form (e.g. 'Sign in with...')
			maxAge: 30 * 24 * 60 * 60, // 30 days
			updateAge: 24 * 60 * 60, // 24 hours
			name: 'credentials',
			credentials: {
				username: { label: 'Username', type: 'text' },
				password: { label: 'Password', type: 'password' },
				type: { label: 'Type', type: 'text' },
			},
			async authorize(credentials, req) {
				const url = credentials.type == 'phone' ? '/signinphone/' : '/signin/';
				const obj =
					credentials.type == 'phone'
						? {
								username: credentials.username,
								code: credentials.password,
								type: credentials.type,
						  }
						: {
								username: credentials.username,
								password: credentials.password,
								type: credentials.type,
						  };

				const user = await getData(url, 'POST', obj);

				// console.log(credentials);
				// console.log(url);
				// console.log(obj);
				// console.log(user);

				if (user.error !== undefined) {
					// throw new Error(
					//   JSON.stringify({ errors: user.error.message, status: false })
					// );
					return '/signin';
				} else {
					return user;
				}
			},
		}),
	],

	callbacks: {
		jwt: ({ token, user }) => {
			// first time jwt callback is run, user object is available
			if (user) {
				token.token = user.token;
				//token.profile = user.profile;
			}

			return token;
		},
		session: ({ session, token }) => {
			if (token) {
				session.token = token.token;
				//session.profile = token.profile;
			}

			return session;
		},
	},
	// session: {
	//   strategy: 'jwt',
	// },
	session: {
		jwt: true,
	},
	secret: NEXTAUTH_SECRET,
	// jwt: {
	//   secret: NEXT_PUBLIC_SECRET,
	//   encryption: true,
	// },
};

export default NextAuth(authOptions);
