import { Content, Layout } from '@/components/common';
import { CertCard } from '@/components/ui';
import styles from '@/styles/pages/CertificatesPage.module.css';
import FancyboxWrapper from '@/utils/fancybox';
import { getData } from '@/utils/fetcher';
import { NextSeo } from 'next-seo';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const CertificatesPage = ({ cert }) => {
  const groupName = cert.entity.name;
  const groupDescription = cert.entity.description;
  const seo = cert.entity.seo;

  const aGroups = cert.groups;

  return (
    <>
      <NextSeo title={seo.title} description={seo.description} />
      <Content>
        <h1>{groupName}</h1>
        {groupDescription != '' && (
          <div
            className='lead'
            dangerouslySetInnerHTML={{ __html: groupDescription }}
          ></div>
        )}
        {/* <InfoCardList items={info.items} /> */}
        <FancyboxWrapper
          options={{
            compact: false,
            idle: false,
            animated: true,
            showClass: false,
            hideClass: false,
            dragToClose: false,
            Images: {
              zoom: true,
            },
            Toolbar: {
              display: {
                left: [],
                middle: ['infobar'],
                right: ['close'],
              },
            },
            Thumbs: {
              type: 'modern',
            },
          }}
        >
          <div className={styles.list}>
            {cert.items.map((el, i) => (
              <CertCard data={el} key={i} fancybox='gallery' />
            ))}
          </div>
        </FancyboxWrapper>
      </Content>
    </>
  );
};

CertificatesPage.getLayout = function getLayout(page, pageProps) {
  const currentItem = pageProps.cert.entity;

  const breadcrumbs = [
    {
      name: currentItem.name,
      slug: currentItem.slug,
    },
  ];
  return (
    <Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
      {page}
    </Layout>
  );
};

export default CertificatesPage;

export async function getStaticProps({ params }) {
  const repoMenu = await getData(`/menu`);
  const repoCert = await getData(`/cert`);

  if (!repoCert?.entity?.name) {
    return {
      notFound: true,
    };
  }

  return {
    props: { menu: repoMenu, cert: repoCert },
    revalidate: 10,
  };
}
