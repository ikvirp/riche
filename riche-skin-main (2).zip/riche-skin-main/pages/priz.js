import { Content, Layout } from '@/components/common';
import styles from '@/styles/pages/ErrorPage.module.css';
import { getData } from '@/utils/fetcher';
import { prepareText } from '@/utils/prepare';
import { NextSeo } from 'next-seo';

const PrizPage = ({ doc }) => {
  const output = prepareText(doc.text);

  return (
    <>
      <NextSeo title={doc.name} description={doc.name} />
      <Content variant='sm'>
        <div className={styles.cnt}>{output}</div>
      </Content>
    </>
  );
};

PrizPage.getLayout = function getLayout(page, pageProps) {
  return <Layout menu={pageProps.menu}>{page}</Layout>;
};

export default PrizPage;

export async function getStaticProps({ params }) {
  const repoMenu = await getData(`/menu`);
  const repoDoc = await getData(`/doc/8`);

  if (repoDoc?.error) {
    return {
      notFound: true,
    };
  }

  return {
    props: { menu: repoMenu, doc: repoDoc },
    revalidate: 10,
  };
}
