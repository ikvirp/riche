import { Content, Layout } from '@/components/common';
import { Button } from '@/components/ui';
import { getData } from '@/utils/fetcher';
import Image from 'next/image';
import { useEffect, useState } from 'react';
// import Script from 'next/script';

import { isAndroid, isIOS, isMobile } from 'react-device-detect';
// https://github.com/duskload/react-device-detect/blob/master/docs/selectors.md
// https://stackoverflow.com/questions/59494037/how-to-detect-the-device-on-react-ssr-app-with-next-js

const OzonItem = ({ link }) => {
  // const router = useRouter();
  // const slug = router.query.slug;
  // const handleLoad = () => {
  //   alert('loaded');
  // };

  const [android, setAndroid] = useState(false);
  const [mobile, setMobile] = useState(false);
  const [ios, setIos] = useState(false);

  //const link = `https://www.wildberries.ru/catalog/72068585/detail.aspx`;

  const goLocation = (url) => {
    window.location = url;
    //alert(url);
  };

  useEffect(() => {
    setAndroid(isAndroid);
    setMobile(isMobile);
    setIos(isIOS);
  }, []);

  useEffect(() => {
    if (mobile && !ios) {
      if (android) {
        const arrayInput = link.split('//');
        goLocation(
          `intent://${arrayInput[1]}#Intent;package=ru.ozon.app.android;scheme=https;S.browser_fallback_url=https://${arrayInput[1]};end;`
        );
      } else {
        goLocation(`${link}?utm_campaign=vendor_org_14992_`);
      }

      // let timer = setTimeout(
      //   () => goLocation(`${link}?utm_campaign=vendor_org_14992_`),
      //   100
      // );

      // return () => {
      //   clearTimeout(timer);
      // };
    }
  }, [android, mobile, ios, link]);

  return (
    <>
      {/* <Script id='start' strategy='lazyOnload'>{`alert('asdasd')`}</Script> */}
      <Content variant='md' className='h-full'>
        {/* <div>mobile: {JSON.stringify(mobile)}</div> */}
        {/* <div>android: {JSON.stringify(android)}</div> */}
        {/* <div>link: {link}</div> */}

        <div className='flex flex-col gap-12 text-center h-full justify-center'>
          <div className='flex justify-center'>
            <Image
              src='/i/logos/ozon.svg'
              alt='Ozon'
              width={240}
              height={28}
              priority
            />
          </div>

          <Button Component='a' href={link}>
            Открыть приложение OZON
          </Button>
        </div>
      </Content>
    </>
  );
};

OzonItem.getLayout = function getLayout(page, pageProps) {
  return (
    <Layout
      variant='checkout'
      phone={false}
      breadcrumbs={null}
      menu={pageProps.menu}
      className='h-full'
    >
      {page}
    </Layout>
  );
};

export default OzonItem;

export async function getServerSideProps({ req, res, params }) {
  const { slug } = params;
  const repoMenu = await getData(`/menu`);
  const repoRedirect = await getData(
    `/marketredirects?market=ozon&from=${slug}`
  );

  if (!repoRedirect) {
    return {
      notFound: true,
    };
  }

  return {
    props: { menu: repoMenu, link: repoRedirect.to },
  };
}
