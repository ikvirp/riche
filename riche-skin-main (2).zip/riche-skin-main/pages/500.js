import { Content, Layout } from '@/components/common';
import styles from '@/styles/pages/ErrorPage.module.css';
import { getData } from '@/utils/fetcher';
import { NextSeo } from 'next-seo';

const Custom500 = ({ menu }) => {
  return (
    <>
      <NextSeo
        title='Внутренняя ошибка сервера'
        description='Внутренняя ошибка сервера'
      />
      <Content variant='sm'>
        <div className={styles.cnt}>
          <h1 className={styles.title}>Внутренняя ошибка сервера</h1>
          <div className={styles.text}>Попробуйте позднее.</div>
        </div>
      </Content>
    </>
  );
};

Custom500.getLayout = function getLayout(page, pageProps) {
  return <Layout menu={pageProps.menu}>{page}</Layout>;
};

export default Custom500;

export async function getStaticProps({ params }) {
  const repoMenu = await getData(`/menu`);

  return {
    props: { menu: repoMenu },
    revalidate: 10,
  };
}
