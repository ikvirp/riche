import { R46Init } from '@/components/r46';
import YandexMetrika from '@/utils/metrika';
import { Head, Html, Main, NextScript } from 'next/document';

export default function Document() {
	return (
		<Html lang="ru">
			<Head>
				<link
					rel="preload"
					href="/i/font/TTHoves-Regular.woff2"
					as="font"
					type="font/woff"
					crossOrigin="anonymous"
				/>
				<link
					rel="preload"
					href="/i/font/TTHoves-Medium.woff2"
					as="font"
					type="font/woff2"
					crossOrigin="anonymous"
				/>

				<R46Init />

				<YandexMetrika
					clickmap={true}
					trackLinks={true}
					accurateTrackBounce={true}
					webvisor={true}
					ecommerce="dataLayer"
				/>
			</Head>
			<body>
				<Main />
				<NextScript />
			</body>
		</Html>
	);
}
