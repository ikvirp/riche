import { ContentMe, Layout } from '@/components/common';
import { Button, CatalogProductCardList } from '@/components/ui';
import { authOptions } from '@/pages/api/auth/[...nextauth]';
import { getData } from '@/utils/fetcher';
import { HeartIcon } from '@heroicons/react/24/outline';
import { getServerSession } from 'next-auth/next';
import { NextSeo } from 'next-seo';
import { useEffect, useState } from 'react';
import { useLocalStorage } from 'usehooks-ts';

const Me = ({ orders, token }) => {
	const [favList, setFavList] = useLocalStorage('favList', []);
	const [items, setItems] = useState([]);

	useEffect(() => {
		if (favList.length > 0) {
			const sData = favList.join(',');
			const fetchData = async () => {
				const data = await getData(`/catalog/?fav=${sData}`);
				if (data) {
					setItems(data.items);
				}
			};
			fetchData();
		} else {
			setItems([]);
		}
	}, [favList]);

	if (items.length) {
		return (
			<>
				<NextSeo title="Избранные товары" description="Избранные товары" />
				<ContentMe>
					<div className="flex flex-col gap-6 lg:max-w-1440 lg:m-auto px-3 lg:px-10 pt-6 pb-12 2xl:w-10/12">
						<h1 className="text-2xl  lg:text-3xl">Избранные товары</h1>
						<CatalogProductCardList showAction={true} items={items} />
					</div>
				</ContentMe>
			</>
		);
	}

	return (
		<>
			<NextSeo title="Избранные товары" description="Избранные товары" />
			<ContentMe>
				<div className="flex flex-col gap-6 lg:max-w-1440 lg:m-auto px-3 lg:px-10 pt-6 pb-12 2xl:w-10/12">
					<div className="text-center lg:text-left">
						<h1 className="pt-0 text-2xl lg:text-3xl">
							Здесь будут ваши избранные товары
						</h1>
						<div className="lg:text-xl">
							Нажмите на <HeartIcon className="w-6 h-6 inline" /> чтобы добавить
							продукт в избранное
						</div>
					</div>
					<div className="text-center lg:text-left">
						<Button
							Component="a"
							className="h-14"
							href="/catalog"
							title="Каталог"
						>
							Перейти в каталог
						</Button>
					</div>
				</div>
			</ContentMe>
		</>
	);
};

Me.getLayout = function getLayout(page, pageProps) {
	const breadcrumbs = [
		{
			name: 'Личный кабинет',
			slug: '/me',
		},
		{
			name: 'Избранные товары',
			slug: '/me/fav',
		},
	];
	return (
		<Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
			{page}
		</Layout>
	);
};

export default Me;

export async function getServerSideProps({ req, res }) {
	const session = await getServerSession(req, res, authOptions);

	if (!session) {
		return { redirect: { destination: '/signin' } };
	}

	const repoMenu = await getData(`/menu`);

	const repoOrders = await getData(`/me/orders`, 'POST', {
		token: session.token,
	});

	return {
		props: { menu: repoMenu, token: session.token, orders: repoOrders },
	};
}
