import { ContentMe, Layout } from '@/components/common';
import { Button, Img, Modal } from '@/components/ui';
import { authOptions } from '@/pages/api/auth/[...nextauth]';
import { getData } from '@/utils/fetcher';
import {
	num_word,
	numberFormat,
	numberFormat2,
	prepareDate,
	prepareDate2,
} from '@/utils/prepare';
import {
	CreditCardIcon,
	FaceSmileIcon,
	InformationCircleIcon,
	MapPinIcon,
	ShoppingCartIcon,
} from '@heroicons/react/24/outline';
import { CheckCircleIcon } from '@heroicons/react/24/solid';
import cn from 'classnames';
import { getServerSession } from 'next-auth/next';
import { NextSeo } from 'next-seo';
import { useRouter } from 'next/router';
import { useState } from 'react';
const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const countArr = (arr) => {
	let amount = 0;
	arr.forEach((element) => {
		amount += parseFloat(element.total);
	});
	return amount;
};

const prepareOrdelList = (goods) => {
	const oReturn = {
		items: [],
		items_count: 0,
		items_amount: 0,
		items_amount_before_sale: 0,
		sale_amount: 0,
		delivery_amount: 0,
	};

	const aItemsFilter = goods.filter((el) => el.type == 0);
	const aSalesFilter = goods.filter((el) => el.total < 0);
	const aDeliveryFilter = goods.filter((el) => el.type == 1);

	const aItems = [];
	aItemsFilter.forEach((element) => {
		const saleName = `Скидка на товар ${element.name}`;
		const found = aSalesFilter.find((el) => el.name == saleName);
		let sale = found ? found.total : 0;

		const oNew = element;
		oNew.sale = parseFloat(sale);
		oNew.total_with_sale = parseFloat(element.total) + parseFloat(sale);
		aItems.push(oNew);
	});

	oReturn.items = aItems;
	oReturn.items_count = aItemsFilter.length;

	oReturn.sale_amount = countArr(aSalesFilter);
	oReturn.delivery_amount = countArr(aDeliveryFilter);
	oReturn.items_amount_before_sale = countArr(aItems);

	let amount = 0;
	aItems.forEach((element) => {
		amount += element.total_with_sale;
	});
	oReturn.items_amount = amount;

	return oReturn;
};

const MeOrderItem = ({ orders }) => {
	const [showModal, setShowModal] = useState(false);
	const currentItem = orders.orders[0];
	const date = prepareDate(currentItem.datetime);
	const paid = currentItem.paid ? `Оплачен` : `Ожидает оплаты`;
	const currency = currentItem.currency;

	const router = useRouter();

	const countedGoods = prepareOrdelList(currentItem.goods);

	const trackButton = currentItem.delivery.track ? (
		<Button
			variant="transparentgray"
			Component="a"
			className="text-gray-500"
			target="_blank"
			href={currentItem.delivery.track_url}
			title={currentItem.delivery.track}
		>
			<InformationCircleIcon className="w-6 h-6" /> Отследить заказ
		</Button>
	) : null;

	const aHistory =
		typeof currentItem.delivery.track_history != 'undefined'
			? currentItem.delivery.track_history
			: [];

	const trackHistory =
		aHistory.length > 0 ? (
			<div className="">
				<Button
					variant="transparentgray"
					className="text-gray-500"
					target="_blank"
					onClick={() => setShowModal(true)}
				>
					<InformationCircleIcon className="w-6 h-6" /> Отследить заказ
				</Button>

				{/* <div className="inline-flex items-center gap-3  leading-none rounded-full py-1 px-3 border">
					<span className="font-bold">{`${aHistory[0].name}`} </span>
					<span
						className="flex items-center gap-1 text-sm cursor-pointer hover:opacity-60 text-gray-500"
						onClick={() => setShowModal(true)}
					>
						<InformationCircleIcon className="w-4 h-4" />
						Отследить заказ
					</span>
				</div> */}

				<Modal
					redirect={false}
					onClose={() => setShowModal(false)}
					show={showModal}
					title={`${currentItem.invoice}`}
				>
					<div className="p-0 pb-3 ">
						{aHistory.map((el, i) => {
							const sRealName =
								el.providerName.length > 1 ? el.providerName : el.name;

							const sRealDate =
								el.createdProvider.length > 1 ? el.createdProvider : el.created;

							const dt = prepareDate2(sRealDate);

							const classItem = i == 0 ? 'text-primary' : '';

							const nameApi =
								i == 0 && sRealName != el.name ? `${el.name} — ` : '';

							const classNameDot =
								i == 0
									? 'font-bold relative before:absolute before:block before:content-[""]  before:w-4 before:bg-primary before:h-4 before:-left-2 before:top-[3px] pl-4 before:rounded-full text-primary before:hidden'
									: 'font-bold relative before:absolute before:block before:content-[""]  before:w-4 before:bg-black before:h-4 before:-left-2 before:top-[3px] pl-4 before:rounded-full before:hidden';

							return (
								<div
									key={i}
									className='relative py-3 ml-1.5 before:absolute before:block before:content-[""]  before:w-[1px] before:bg-gray-300 before:h-full before:top-[16px] last:before:hidden'
								>
									<div className={classNameDot}>
										<span className="absolute -left-3 top-0 bg-white rounded-full leading-none">
											<CheckCircleIcon className="w-6 h-6" />
										</span>
										{`${nameApi}${sRealName}`}
									</div>
									{el.description.length > 1 && (
										<div className="text-sm text-gray-500 pl-4 ">
											{el.description}
										</div>
									)}
									<div className="text-xs text-gray-400 pl-4 pt-1">
										{/* {sRealDate} */}
										{dt}
									</div>
								</div>
							);
						})}
					</div>
				</Modal>
			</div>
		) : null;

	// countedGoods.items_count

	const anumClass = cn(
		'text-lg lg:text-xl  font-bold',
		currentItem.paid ? 'text-primary' : 'text-black',
	);

	return (
		<>
			<NextSeo
				title={`Заказ ${currentItem.invoice}`}
				description={`Заказ ${currentItem.invoice}`}
			/>
			<ContentMe bg="gray">
				<div className="flex flex-col gap-6 lg:flex-col lg:flex-1 lg:max-w-1440 lg:m-auto px-3 lg:px-10 pt-6 pb-12 2xl:w-10/12">
					{/* {ordersList} */}
					{/* {token} */}
					{/* {JSON.stringify(countedGoods)} */}
					<div className="grow">
						<h1 className="text-2xl lg:text-3xl pb-0">
							Заказ № {currentItem.invoice}
						</h1>
						<div>{`от ${date}`}</div>
						<div className="pt-1 text-gray-500 text-sm">{paid}</div>
					</div>
					<div className="flex flex-col gap-6 lg:flex-row">
						<div className="Zmax-w-screen-md ">
							<div className="bg-white rounded-xl  p-3 lg:py-4 lg:px-6">
								<div className="flex justify-between items-center pt-1 pb-4">
									<div
										className="text-lg lg:text-xl"
										style={{ color: currentItem.status.color }}
									>
										{currentItem.status.name}
									</div>
									<div>{trackHistory}</div>
								</div>
								<div className="flex justify-between items-center py-4 border-t">
									<div className="text-lg lg:text-xl font-bold">{`${numberFormat(
										countedGoods.items_count,
									)} ${num_word(countedGoods.items_count, [
										'товар',
										'товара',
										'товаров',
									])} на сумму`}</div>
									<div className={anumClass}>{`${numberFormat2(
										countedGoods.items_amount,
									)} ${currency}`}</div>
								</div>

								<div className="flex flex-col">
									{countedGoods.items.map((el, i) => {
										const imageUrl = el.thumb
											? `${NEXT_PUBLIC_DATA_DOMAIN}${el.thumb.file}`
											: null;

										return (
											<div
												key={i}
												className="flex justify-between items-center gap-3 py-4 border-t"
											>
												<div>
													{imageUrl && (
														<Img
															src={imageUrl}
															className="w-24 rounded-xl"
															alt={el.name}
															title={el.name}
															width={350}
															height={350}
														/>
													)}
												</div>
												<div className="pr-3 lg:text-lg leading-tight font-bold grow">
													{el.name}
												</div>
												<div className="text-right">
													{el.sale < 0 && (
														<div className="text-gray-500 text-sm whitespace-nowrap">{`Скидка ${numberFormat2(
															el.sale * -1,
														)} ${currency}`}</div>
													)}

													<div className=" font-bold whitespace-nowrap">{`${numberFormat2(
														el.price,
													)} ${currency}`}</div>
													<div className="text-gray-500 text-sm whitespace-nowrap">{`${numberFormat(
														el.quantity,
													)} шт`}</div>
												</div>
											</div>
										);
									})}
								</div>
							</div>
						</div>

						<div className="bg-white rounded-xl  p-3 lg:py-4 lg:px-6 shrink-0 lg:max-w-sm">
							<div className="flex  gap-3 py-5 pt-3 ">
								<div className="grow-0 pt-0.5">
									<MapPinIcon className="w-6 h-6" />
								</div>
								<div className="flex flex-col gap-1">
									<div className="font-bold text-lg">
										{`${currentItem.delivery.name} ${currentItem.delivery.provider_name}`}
									</div>
									<div>{currentItem.address.address.full}</div>
								</div>
							</div>

							<div className="flex  gap-3 py-5 border-t">
								<div className="grow-0 pt-0.5">
									<FaceSmileIcon className="w-6 h-6" />
								</div>
								<div className="flex flex-col gap-1">
									<div className="font-bold text-lg">Получатель</div>
									<div>
										<div>Email: {currentItem.person.email}</div>
										<div>Телефон: {currentItem.person.phone}</div>
										<div>Фамилия: {currentItem.person.surname}</div>
										<div>Имя: {currentItem.person.name}</div>
									</div>
								</div>
							</div>

							<div className="flex  gap-3 py-5 border-t">
								<div className="grow-0 pt-0.5">
									<CreditCardIcon className="w-6 h-6" />
								</div>
								<div className="flex flex-col gap-1">
									<div className="font-bold text-lg">Способ оплаты</div>
									<div>
										<div>{currentItem.payment.name}</div>
									</div>
								</div>
							</div>

							<div className="flex  gap-3 py-5 border-t">
								<div className="grow-0 pt-0.5">
									<ShoppingCartIcon className="w-6 h-6" />
								</div>
								<div className=" shring-0 font-bold  w-full text-lg">
									<div className=" flex flex-col gap-1">
										<div className=" flex justify-between items-center ">
											<div>Товары</div>
											<div className="text-right ">{`${numberFormat2(
												countedGoods.items_amount_before_sale,
											)} ${currency}`}</div>
										</div>
									</div>

									{countedGoods.sale_amount < 0 && (
										<div className=" flex flex-col gap-1">
											<div className=" flex justify-between items-center ">
												<div>Скидки</div>
												<div className="text-right ">{`${numberFormat2(
													countedGoods.sale_amount,
												)} ${currency}`}</div>
											</div>
										</div>
									)}

									<div className=" flex flex-col gap-1">
										<div className=" flex justify-between items-center ">
											<div>Доставка</div>
											<div className="text-right ">{`${numberFormat2(
												countedGoods.delivery_amount,
											)} ${currency}`}</div>
										</div>
									</div>
									<hr />
									<div className=" flex flex-col gap-1">
										<div className=" flex justify-between items-center ">
											<div>Итого</div>
											<div className="text-right ">{`${numberFormat2(
												currentItem.amount,
											)} ${currency}`}</div>
										</div>
									</div>
								</div>
							</div>

							{!currentItem.paid && !currentItem.canceled && (
								<div className="pt-3 pb-6">
									<Button
										className="w-full"
										onClick={() => router.push(`/checkout/${currentItem.guid}`)}
									>
										Оплатить заказ
									</Button>
								</div>
							)}
						</div>
					</div>
				</div>
			</ContentMe>
		</>
	);
};

MeOrderItem.getLayout = function getLayout(page, pageProps) {
	const currentItem = pageProps.orders.orders[0];

	const breadcrumbs = [
		{
			name: 'Личный кабинет',
			slug: '/me',
		},
		{
			name: 'История заказов',
			slug: '/me/orders',
		},
		{
			name: currentItem.invoice,
			slug: `/me/orders/${currentItem.guid}`,
		},
	];
	return (
		<Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
			{page}
		</Layout>
	);
};

export default MeOrderItem;

export async function getServerSideProps({ req, res, params }) {
	const session = await getServerSession(req, res, authOptions);

	if (!session) {
		return { redirect: { destination: '/signin' } };
	}

	const { slug } = params;

	//console.log(slug);

	const repoMenu = await getData(`/menu`);
	const repoMeOrders = await getData(`/me/orders`, 'POST', {
		token: session.token,
		guid: slug,
	});

	if (repoMeOrders.orders.length == 0) {
		return {
			notFound: true,
		};
	}

	return {
		props: { menu: repoMenu, orders: repoMeOrders },
	};
}
