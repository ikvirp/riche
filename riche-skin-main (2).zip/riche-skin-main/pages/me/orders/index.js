import { ContentMe, Layout } from '@/components/common';
import { MeOrderList } from '@/components/ui';
import { authOptions } from '@/pages/api/auth/[...nextauth]';
import { getData } from '@/utils/fetcher';
import { getServerSession } from 'next-auth/next';
import { NextSeo } from 'next-seo';

const MeOrders = ({ orders, token }) => {
	return (
		<>
			<NextSeo title="Личный кабинет" description="Личный кабинет" />
			<ContentMe bg="gray">
				<div className="flex flex-col gap-6 lg:flex-row lg:flex-1 lg:max-w-1440 lg:m-auto px-3 lg:px-10 pt-6 pb-12 2xl:w-10/12">
					{/* {ordersList} */}
					{/* {token} */}
					<div className="max-w-screen-md grow">
						<MeOrderList data={orders} />
					</div>
					{/* <div>asdas</div> */}
				</div>
			</ContentMe>
		</>
	);
};

MeOrders.getLayout = function getLayout(page, pageProps) {
	const breadcrumbs = [
		{
			name: 'Личный кабинет',
			slug: '/me',
		},
		{
			name: 'История заказов',
			slug: '/me/orders',
		},
	];
	return (
		<Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
			{page}
		</Layout>
	);
};

export default MeOrders;

export async function getServerSideProps({ req, res }) {
	const session = await getServerSession(req, res, authOptions);

	if (!session) {
		return { redirect: { destination: '/signin' } };
	}

	const repoMenu = await getData(`/menu`);

	const repoOrders = await getData(`/me/orders`, 'POST', {
		token: session.token,
	});

	return {
		props: { menu: repoMenu, token: session.token, orders: repoOrders },
	};
}
