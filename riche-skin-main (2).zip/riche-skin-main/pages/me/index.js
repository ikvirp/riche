import { ContentMe, Layout } from '@/components/common';
import { MeOrderList } from '@/components/ui';
import { authOptions } from '@/pages/api/auth/[...nextauth]';
import { getData } from '@/utils/fetcher';
import { getServerSession } from 'next-auth/next';
import { NextSeo } from 'next-seo';

const Me = ({ orders, token }) => {
	//console.log(orders.items);

	// const ordersList =
	// 	me && me.orders.length > 0 ? (
	// 		<>
	// 			<h1>Мои заказы</h1>
	// 			<div className="flex flex-col gap-3">
	// 				{/* <div className={styles.ttl}>Последние заказы</div> */}
	// 				<div className={styles.list}>
	// 					{me.orders.map((el, i) => (
	// 						<OrderCardShort data={el} key={i} />
	// 					))}
	// 				</div>
	// 			</div>
	// 		</>
	// 	) : (
	// 		<div className="flex flex-col gap-6 text-center lg:text-left lg:max-w-xs ">
	// 			<div>
	// 				<h1>Самое время сделать свой первый заказ</h1>
	// 				<div>
	// 					Подробная информация обо всех ваших заказах RICHE будет доступна
	// 					здесь.
	// 				</div>
	// 			</div>
	// 			<div>
	// 				<Button Component="a" href="/catalog" title="Перейти в каталог">
	// 					За покупками
	// 				</Button>
	// 			</div>
	// 		</div>
	// 	);
	return (
		<>
			<NextSeo title="Личный кабинет" description="Личный кабинет" />
			<ContentMe bg="gray">
				<div className="flex flex-col gap-6 lg:flex-row lg:flex-1 lg:max-w-1440 lg:m-auto px-3 lg:px-10 pt-6 pb-12 2xl:w-10/12">
					{/* {ordersList} */}
					{/* {token} */}
					<div className="max-w-screen-md grow">
						<MeOrderList data={orders} />
					</div>
					{/* <div>asdas</div> */}
				</div>
			</ContentMe>
		</>
	);
};

Me.getLayout = function getLayout(page, pageProps) {
	const breadcrumbs = [
		{
			name: 'Личный кабинет',
			slug: '/me',
		},
	];
	return (
		<Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
			{page}
		</Layout>
	);
};

export default Me;

export async function getServerSideProps({ req, res }) {
	const session = await getServerSession(req, res, authOptions);

	if (!session) {
		return { redirect: { destination: '/signin' } };
	}

	const repoMenu = await getData(`/menu`);

	const repoOrders = await getData(`/me/orders`, 'POST', {
		token: session.token,
	});

	return {
		props: { menu: repoMenu, token: session.token, orders: repoOrders },
	};
}
