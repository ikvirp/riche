import { ContentMe, Layout } from '@/components/common';
import { MeComment } from '@/components/ui';
import { authOptions } from '@/pages/api/auth/[...nextauth]';
import { getData } from '@/utils/fetcher';
import { getServerSession } from 'next-auth/next';
import { NextSeo } from 'next-seo';

const Me = ({ commentList, token }) => {
	const item_id = 0;
	return (
		<>
			<NextSeo title="Мои отзывы" description="Мои отзывы" />
			<ContentMe>
				<div className="flex flex-col gap-6 lg:max-w-1440 lg:m-auto px-3 lg:px-10 pt-6 pb-12 2xl:w-10/12">
					<h1 className="text-2xl  lg:text-3xl">Мои отзывы</h1>
					<div className="flex flex-col gap-6">
						{commentList.comments.map((el, i) => (
							<MeComment data={el} key={i} token={token} />
						))}
					</div>
				</div>
			</ContentMe>
		</>
	);
};

Me.getLayout = function getLayout(page, pageProps) {
	const breadcrumbs = [
		{
			name: 'Личный кабинет',
			slug: '/me',
		},
		{
			name: 'Мои отзывы',
			slug: '/me/comments',
		},
	];
	return (
		<Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
			{page}
		</Layout>
	);
};

export default Me;

export async function getServerSideProps({ req, res }) {
	const session = await getServerSession(req, res, authOptions);

	if (!session) {
		return { redirect: { destination: '/signin' } };
	}

	const repoMenu = await getData(`/menu`);

	const repoComments = await getData(`/me/comments`, 'POST', {
		token: session.token,
	});

	//console.log(repoComments);

	// return {
	// 	notFound: true,
	// };

	return {
		props: { menu: repoMenu, token: session.token, commentList: repoComments },
	};
}
