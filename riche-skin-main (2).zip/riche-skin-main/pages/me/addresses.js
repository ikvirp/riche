import { ContentMe, Layout } from '@/components/common';
import { Lnk, MeAddresses } from '@/components/ui';
import { authOptions } from '@/pages/api/auth/[...nextauth]';
import { getData } from '@/utils/fetcher';
import { getServerSession } from 'next-auth/next';
import { NextSeo } from 'next-seo';

const Me = ({ addresses, token }) => {
	// const profileAlert = !addresses.profile ? (
	// 	<div className="lg:text-xl">
	// 		<Lnk href="/me/profile" className="underline">
	// 			Заполнить данные профиля
	// 		</Lnk>{' '}
	// 		чтобы добавлять адреса
	// 	</div>
	// ) : (
	// 	<div className="lg:text-xl">
	// 		Используйте ваш адрес при оформлении заказа
	// 	</div>
	// );

	const profileAlert = !addresses.profile ? (
		<div className="lg:text-xl">
			<Lnk href="/me/profile" className="underline">
				Заполнить данные профиля
			</Lnk>{' '}
			чтобы добавлять адреса
		</div>
	) : null;

	return (
		<>
			<NextSeo title="Мои адреса" description="Мои адреса" />
			<ContentMe>
				<div className="flex flex-col gap-6 lg:max-w-1440 lg:m-auto px-3 lg:px-10 pt-6 pb-12 2xl:w-10/12">
					<div>
						<h1 className="text-2xl  lg:text-3xl">Все адреса</h1>
						<div className="max-w-screen-md grow">{profileAlert}</div>
					</div>
					<div className="max-w-screen-md grow">
						<MeAddresses data={addresses.addresses} token={token} />
					</div>
				</div>
			</ContentMe>
		</>
	);
};

Me.getLayout = function getLayout(page, pageProps) {
	const breadcrumbs = [
		{
			name: 'Личный кабинет',
			slug: '/me',
		},
		{
			name: 'Мои адреса',
			slug: '/me/addresses',
		},
	];
	return (
		<Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
			{page}
		</Layout>
	);
};

export default Me;

export async function getServerSideProps({ req, res }) {
	const session = await getServerSession(req, res, authOptions);

	if (!session) {
		return { redirect: { destination: '/signin' } };
	}

	const repoMenu = await getData(`/menu`);

	const repoAddresses = await getData(`/me/addresses`, 'POST', {
		token: session.token,
	});

	return {
		props: { menu: repoMenu, token: session.token, addresses: repoAddresses },
	};
}
