import { Aside, Content, ContentMe, Layout } from '@/components/common';
import { MeProfileEmail, MeProfilePhone } from '@/components/pages';
import { MeMenu } from '@/components/ui';
import { authOptions } from '@/pages/api/auth/[...nextauth]';
import { getData } from '@/utils/fetcher';
import { getServerSession } from 'next-auth/next';
import { NextSeo } from 'next-seo';

const NEXT_PUBLIC_AUTH_MODE = process.env.NEXT_PUBLIC_AUTH_MODE;

const MeProfile = ({ profile }) => {
	if (NEXT_PUBLIC_AUTH_MODE == 'phone') {
		return (
			<>
				<NextSeo title="Мои данные" description="Мои данные" />
				<ContentMe>
					<div className="flex flex-col gap-6 lg:flex-row lg:flex-1 lg:max-w-1440 lg:m-auto px-3 lg:px-10 pt-6 pb-12 2xl:w-10/12">
						{/* {ordersList} */}
						{/* {token} */}
						<div className="max-w-screen-md grow">
							<MeProfilePhone profile={profile} />
						</div>
						{/* <div>asdas</div> */}
					</div>
				</ContentMe>
			</>
		);
	}

	return (
		<>
			<NextSeo title="Мои данные" description="Мои данные" />
			<Content aside>
				<MeProfileEmail profile={profile} />
				<Aside>
					<MeMenu />
				</Aside>
			</Content>
		</>
	);
};

MeProfile.getLayout = function getLayout(page, pageProps) {
	const breadcrumbs = [
		{
			name: 'Личный кабинет',
			slug: '/me',
		},
		{
			name: 'Мои данные',
			slug: '/me/profile',
		},
	];
	return (
		<Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
			{page}
		</Layout>
	);
};

export default MeProfile;

export async function getServerSideProps({ req, res }) {
	const session = await getServerSession(req, res, authOptions);

	if (!session) {
		return { redirect: { destination: '/signin' } };
	}

	const repoMenu = await getData(`/menu`);
	const repoMeProfile = await getData(`/me`, 'POST', {
		token: session.token,
		orders: false,
		//pass: true,
	});

	return {
		props: { menu: repoMenu, profile: repoMeProfile },
	};
}
