import { Content, Layout } from '@/components/common';
import { BlogCardList } from '@/components/ui';
import { getData } from '@/utils/fetcher';
import { numberFormat } from '@/utils/prepare';
import {
  ChevronLeftIcon,
  ChevronRightIcon,
  EllipsisHorizontalIcon,
} from '@heroicons/react/24/outline';
import { NextSeo } from 'next-seo';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';

import ReactPaginate from 'react-paginate';

const BlogPage = ({ blog }) => {
  const groupName = blog.entity.name;
  const groupDescription = blog.entity.description;

  const aGroups = blog.groups;

  const [seo, setSeo] = useState(blog.entity.seo);
  const [itemsList, setItemsList] = useState(blog.items);
  const [pagination, setPagination] = useState(blog.pagination);
  const router = useRouter();

  const paginationHandler = (page) => {
    const currentPath = router.pathname;
    const currentQuery = router.query;

    currentQuery.page = page.selected + 1;
    // router.push(`/blog/?page=${currentQuery.page}`, undefined, {
    //   shallow: true,
    // });
    // } else {
    //   router.push(`/blog/`, undefined, { shallow: true });
    // }

    // alert(
    //   JSON.stringify({
    //     pathname: currentPath,
    //     query: currentQuery,
    //   })
    // );

    const oPush =
      page.selected !== 0
        ? {
            pathname: currentPath,
            query: currentQuery,
          }
        : {
            pathname: currentPath,
          };

    router.push(oPush, undefined, { shallow: true, scroll: true });
    // currentQuery.page = page.selected + 1;
    // router.push({
    //   pathname: currentPath,
    //   query: currentQuery,
    // });
  };

  useEffect(() => {
    const realPage = router.query?.page ? router.query.page : 1;
    if (realPage) {
      //alert(router.query.page);

      const fetchData = async () => {
        //alert(`${NEXT_PUBLIC_API_URL}/catalog/?fav=${sData}`);
        const repoBlogPage = await getData(`/blog/?page=${realPage}`);

        setItemsList(repoBlogPage.items);
        setPagination(repoBlogPage.pagination);

        const oSeo = {
          title: blog.entity.seo.title,
          description: blog.entity.seo.description,
        };

        if (repoBlogPage.pagination.currentPage !== 1) {
          setSeo({
            ...oSeo,
            title: `${blog.entity.seo.title}, страница ${numberFormat(
              repoBlogPage.pagination.currentPage
            )}`,
          });
        } else {
          setSeo(oSeo);
        }
      };

      fetchData();
    }
  }, [router.query]);

  return (
    <>
      <NextSeo title={seo.title} description={seo.description} />
      <Content>
        <h1>{groupName}</h1>
        {groupDescription != '' && pagination.currentPage == 1 && (
          <div
            className='lead'
            dangerouslySetInnerHTML={{ __html: groupDescription }}
          ></div>
        )}
        {/* {JSON.stringify(pagination)} */}
        <BlogCardList items={itemsList} />

        {pagination.pageCount > 1 && (
          <div className='pt-12'>
            <ReactPaginate
              previousLabel={<ChevronLeftIcon className='w-6 h-6' />}
              nextLabel={<ChevronRightIcon className='w-6 h-6' />}
              breakLabel={<EllipsisHorizontalIcon className='w-6 h-6' />}
              breakClassName='p-0 m-0'
              breakLinkClassName='w-8 h-8 block rounded-md hover:bg-gray-100 hover:opacity-100 flex items-center justify-center'
              nextClassName='p-0 m-0'
              nextLinkClassName='w-8 h-8 block rounded-md hover:bg-gray-100 hover:opacity-100 flex items-center justify-center'
              previousClassName='p-0 m-0'
              previousLinkClassName='w-8 h-8 block rounded-md hover:bg-gray-100 hover:opacity-100 flex items-center justify-center'
              pageClassName='p-0 m-0'
              pageLinkClassName='w-8 h-8 block rounded-md hover:bg-gray-100 hover:opacity-100 flex items-center justify-center'
              activeClassName={'p-0 m-0'}
              activeLinkClassName='w-8 h-8 block rounded-md hover:bg-black bg-black text-white flex items-center justify-center cursor-default'
              disabledClassName='hidden'
              containerClassName={'pagination'}
              subContainerClassName={'pages pagination'}
              initialPage={pagination.currentPage - 1}
              pageCount={pagination.pageCount}
              marginPagesDisplayed={2}
              pageRangeDisplayed={2}
              onPageChange={paginationHandler}
              className='list-none flex justify-center items-center gap-1.5 m-0 p-0'
            />
          </div>
        )}
      </Content>
    </>
  );
};

BlogPage.getLayout = function getLayout(page, pageProps) {
  const currentItem = pageProps.blog.entity;

  const breadcrumbs = [
    {
      name: currentItem.name,
      slug: currentItem.slug,
    },
  ];

  return (
    <Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
      {page}
    </Layout>
  );
};

export default BlogPage;

export async function getStaticProps({ params, query }) {
  const repoMenu = await getData(`/menu`);

  const repoBlog = await getData(`/blog`);

  if (!repoBlog?.entity?.name) {
    return {
      notFound: true,
    };
  }

  return {
    props: { menu: repoMenu, blog: repoBlog },
    revalidate: 10,
  };
}
