import { Content, Layout } from '@/components/common';
import { BlogItemCatalogList, Img } from '@/components/ui';
import { getData } from '@/utils/fetcher';
import { prepareText } from '@/utils/prepare';
import { ArticleJsonLd, NextSeo } from 'next-seo';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;
const NEXT_PUBLIC_DOMAIN = process.env.NEXT_PUBLIC_DOMAIN;

const BlogItemPage = ({ blog }) => {
  const itemName = blog.entity.name;
  const itemDescription = blog.entity.description;
  const seo = blog.entity.seo;

  const output = prepareText(blog.entity.text);

  const media = blog.entity.media[0]?.original
    ? {
        file: `${NEXT_PUBLIC_DATA_DOMAIN}${blog.entity.media[0]?.original.file}`,
        width: blog.entity.media[0]?.original.width,
        height: blog.entity.media[0]?.original.height,
      }
    : null;

  const oOg = media
    ? {
        images: [
          {
            url: `${NEXT_PUBLIC_DATA_DOMAIN}${blog.entity.media[0]?.original.file}`,
            alt: itemName,
          },
        ],
      }
    : null;

  const strippedString =
    itemDescription && itemDescription.length > 0
      ? itemDescription.replace(/(<([^>]+)>)/gi, '')
      : '';

  return (
    <>
      <NextSeo
        title={seo.title}
        description={seo.description}
        openGraph={oOg}
      />

      <ArticleJsonLd
        useAppDir={false}
        url={`${NEXT_PUBLIC_DOMAIN}/blog/${blog.entity.slug}`}
        title={itemName}
        images={[
          `${NEXT_PUBLIC_DATA_DOMAIN}${blog.entity.media[0]?.original.file}`,
        ]}
        author={{ url: `${NEXT_PUBLIC_DATA_DOMAIN}`, name: 'RICHE' }}
        publisherName='RICHE'
        publisherLogo={`${NEXT_PUBLIC_DOMAIN}/i/logo.png`}
        description={strippedString}
        isAccessibleForFree={true}
      />
      <Content variant='md'>
        {media && (
          <div className='pb-6'>
            <Img
              src={media.file}
              className='rounded-xl'
              title={itemName}
              alt={itemName}
              width={media.width}
              height={media.height}
            />
          </div>
        )}
        <h1>{itemName}</h1>
        {output}
        {blog.entity.shop_items.length > 0 && (
          <BlogItemCatalogList items={blog.entity.shop_items} />
        )}
      </Content>
    </>
  );
};

BlogItemPage.getLayout = function getLayout(page, pageProps) {
  const currentItem = pageProps.blog.entity;

  const breadcrumbs = [
    {
      name: 'Блог',
      slug: '/blog',
    },
    {
      name: currentItem.name,
      slug: currentItem.slug,
    },
  ];

  return (
    <Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
      {page}
    </Layout>
  );
};

export default BlogItemPage;

export async function getStaticPaths() {
  const repoItems = await getData('/blog?list=1');

  const paths = repoItems.groups.map((item, index) => {
    return { params: { slug: item } };
  });

  return { paths, fallback: 'blocking' };
}

export async function getStaticProps({ params }) {
  const { slug } = params;

  const repoBlog = await getData(`/blog/${slug}`);

  if (!repoBlog?.entity?.name) {
    return {
      notFound: true,
    };
  }

  const repoMenu = await getData(`/menu`);

  return {
    props: { menu: repoMenu, blog: repoBlog },
    revalidate: 10,
  };
}
