import { Content, Layout } from '@/components/common';
import { R46Reccomend } from '@/components/r46';
import useR46Track from '@/components/r46/useR46Track';
import {
	CatalogGroupHeader,
	CatalogGroupTagList,
	CatalogProductCardList,
} from '@/components/ui';
import { getData } from '@/utils/fetcher';
import { NextSeo } from 'next-seo';
import { useRouter } from 'next/router';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const CatalogGroupPage = ({ catalog }) => {
	const groupName = catalog.entity.name;
	const groupTitle = catalog.entity.title;
	const currentGroup = catalog.entity.current;
	const groupCurrent = catalog.groups.find((el) => el.id == currentGroup);

	const groupParent =
		catalog.groups.find((el) => el.id == groupCurrent.group_id) || null;

	const realGroup = groupParent ? groupParent : groupCurrent;
	realGroup.sorting = -1;

	const aGroups = catalog.groups.filter((el) => el.group_id == realGroup.id);
	const aGroupsFull = aGroups.length > 0 ? [realGroup, ...aGroups] : [];

	const seo = catalog.entity.seo;

	const cartFull = useSelector((state) => state.cart);
	const dispatch = useDispatch();

	const router = useRouter();
	const { trackCategory } = useR46Track();
	useEffect(() => {
		//alert(1);
		trackCategory(currentGroup);
	}, [router]);

	// console.log('groupCurrent', groupCurrent);
	// console.log('groupParent', groupParent);
	// console.log('realGroup', realGroup);

	const headerData = {
		name: groupName,
		title: groupTitle,
		thumb: catalog.entity.thumb,
		media: catalog.entity.media,
		description: catalog.entity.description,
	};

	const oOg = catalog.entity.thumb
		? {
				images: [
					{
						url: `${NEXT_PUBLIC_DATA_DOMAIN}${catalog.entity.thumb.file}`,
						alt: groupTitle,
					},
				],
		  }
		: null;

	return (
		<>
			<NextSeo
				title={seo.title}
				description={seo.description}
				openGraph={oOg}
			/>
			<Content>
				<CatalogGroupHeader data={headerData} />
				<CatalogGroupTagList items={aGroupsFull} current={currentGroup} />

				<R46Reccomend
					id={`2ad048ac3a2c7b994f90abff5737a31f`}
					title={false}
					variant="same"
					//centertitle={true}
					pt0={true}
					listClassName="pt-0"
					obj={{
						category: catalog.entity.id,
					}}
				/>

				<CatalogProductCardList items={catalog.items} />

				<R46Reccomend
					id={`eea54822f12aefb5efa777cd7965d207`}
					title="Вам будет это интересно"
					//variant="same"
					obj={{
						category: catalog.entity.id,
					}}
				/>
			</Content>
		</>
	);
};

CatalogGroupPage.getLayout = function getLayout(page, pageProps) {
	const currentGroup = pageProps.catalog.entity;
	const groupCurrent = pageProps.catalog.groups.find(
		(el) => el.id == currentGroup.id,
	);

	const groupParent =
		pageProps.catalog.groups.find((el) => el.id == groupCurrent.group_id) ||
		null;

	//console.log('groupParent', groupParent);

	const breadcrumbs = [
		{
			name: 'Каталог RICHE',
			slug: '/catalog',
		},
	];

	if (groupParent) {
		breadcrumbs.push({
			name: groupParent.name,
			slug: groupParent.slug,
		});
	}

	breadcrumbs.push({
		name: currentGroup.name,
		slug: currentGroup.slug,
	});

	return (
		<Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
			{page}
		</Layout>
	);
};

export default CatalogGroupPage;

export async function getStaticPaths() {
	const repoGroups = await getData('/catalog?list=1');

	const paths = repoGroups.groups.map((item, index) => {
		return { params: { slug: item } };
	});

	return { paths, fallback: 'blocking' };
}

export async function getStaticProps({ params }) {
	const { slug } = params;

	const repoCatalog = await getData(`/catalog?group=${slug}`);

	if (!repoCatalog?.entity?.name) {
		return {
			notFound: true,
		};
	}

	const repoMenu = await getData(`/menu`);

	return {
		props: { menu: repoMenu, catalog: repoCatalog },
		revalidate: 10,
	};
}
