import { Content, Layout } from '@/components/common';
import useR46Track from '@/components/r46/useR46Track';
import { CatalogGroupTagList, CatalogProductCardList } from '@/components/ui';
import { getData } from '@/utils/fetcher';
import { useRouter } from 'next/router';
import { useEffect } from 'react';

const CatalogPage = ({ catalog }) => {
	const groupName = catalog.entity.name;
	const currentGroup = catalog.entity.current;
	const aGroups = catalog.groups.filter((el) => el.group_id == currentGroup);

	const router = useRouter();
	const { trackCategory } = useR46Track();
	useEffect(() => {
		//alert(1);
		trackCategory('0');
	}, [router]);

	return (
		<>
			<Content>
				<h1>{groupName}</h1>
				<CatalogGroupTagList items={aGroups} current={currentGroup} />
				<CatalogProductCardList items={catalog.items} />
			</Content>
		</>
	);
};

CatalogPage.getLayout = function getLayout(page, pageProps) {
	const currentItem = pageProps.catalog.entity;

	const breadcrumbs = [
		{
			name: currentItem.name,
			slug: currentItem.slug,
		},
	];
	return (
		<Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
			{page}
		</Layout>
	);
};

export default CatalogPage;

export async function getStaticProps({ params }) {
	const repoMenu = await getData(`/menu`);

	const repoCatalog = await getData(`/catalog`);

	if (!repoCatalog?.entity?.name) {
		return {
			notFound: true,
		};
	}

	return {
		props: { menu: repoMenu, catalog: repoCatalog },
		revalidate: 10,
	};
}
