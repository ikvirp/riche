import { Content, Layout } from '@/components/common';
import { Button, CatalogProductCardList } from '@/components/ui';
import { getData } from '@/utils/fetcher';
import { NextSeo } from 'next-seo';
import { useEffect, useState } from 'react';
import { useLocalStorage } from 'usehooks-ts';

const FavPage = ({ menu }) => {
  const [favList, setFavList] = useLocalStorage('favList', []);
  const [items, setItems] = useState([]);

  useEffect(() => {
    if (favList.length > 0) {
      const sData = favList.join(',');
      const fetchData = async () => {
        const data = await getData(`/catalog/?fav=${sData}`);
        if (data) {
          setItems(data.items);
        }
      };
      fetchData();
    } else {
      setItems([]);
    }
  }, [favList]);

  if (items.length) {
    return (
      <>
        <NextSeo title='Избранные товары' description='Избранные товары' />
        <Content>
          <h1>Избранные товары</h1>
          <CatalogProductCardList showAction={true} items={items} />
        </Content>
      </>
    );
  }
  return (
    <>
      <NextSeo title='Избранные товары' description='Избранные товары' />
      <Content>
        <div className='text-center'>
          <div className=' text-xl'>
            Добавляйте товары из каталога в избранное
          </div>
          <div className='text-xl pt-6'>
            <Button
              Component='a'
              href={'/catalog'}
              variant='black'
              title='Каталог'
            >
              Перейти в каталог
            </Button>
          </div>
        </div>
      </Content>
    </>
  );
};

FavPage.getLayout = function getLayout(page, pageProps) {
  const breadcrumbs = [
    {
      name: 'Избранные товары',
      slug: '/fav',
    },
  ];
  return (
    <Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
      {page}
    </Layout>
  );
};

export default FavPage;

export async function getStaticProps({ params }) {
  const repoMenu = await getData(`/menu`);

  return {
    props: { menu: repoMenu },
    revalidate: 10,
  };
}
