#!/usr/bin/env bash


DIR='/home/riche/sites/riche.skin'
APPNAME='riche-skin'

# Переходим в папку
cd $DIR


### STOP APP
##start_spinner 'Stop app...'
pm2 stop $APPNAME
##stop_spinner $?


### BUILD APP
##start_spinner 'Build app...'
npm run build
##stop_spinner $?


### RESTART APP
##start_spinner 'Start app...'
pm2 restart $APPNAME --cron-restart="0 * * * *"
##stop_spinner $?

green="\e[1;32m"
red="\e[1;31m"
nc="\e[0m"

echo "----------------"
echo ""
echo "${green}Готово!${nc}"
echo ""
echo "----------------"





