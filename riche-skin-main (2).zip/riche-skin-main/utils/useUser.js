import { getData } from '@/utils/fetcher';
import { useSession } from 'next-auth/react';
import { useEffect, useState } from 'react';

const useUser = () => {
	const feConf = 'me@riche.skin';
	//const feConf = 'me@riche.skin';
	const { data: session } = useSession();

	useEffect(() => {
		if (session) {
			fetchData();
		}
	}, [session]);

	const [user, setUser] = useState({
		token: null,
		profile: null,
		avatar: null,
	});

	const fetchData = async () => {
		const obj = {
			token: session.token,
			profile: null,
			avatar: user.avatar,
		};
		const data = await getData(`/me`, 'POST', {
			token: session.token,
			orders: false,
			//pass: true,
		});
		if (data) {
			obj.profile = data.profile;
			if (data.profile.avatar) {
				obj.avatar = data.avatar;
			}
		}

		setUser(obj);
	};

	const updateData = () => {
		if (session) {
			console.log('updateData');
			fetchData();
			console.log(user);
		}
	};

	return { ...user, updateData };
};

export default useUser;
