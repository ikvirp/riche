//const API_URL = 'https://dummyjson.com/posts?skip=0&limit=1';

const NEXT_PUBLIC_API_URL = process.env.NEXT_PUBLIC_API_URL;

const fetchData = async (
	url,
	type = 'GET',
	request = null,
	callback = null,
) => {
	// url with trailing slash —— hostCMS
	const aUrl = url.split('?');
	const sPath = aUrl[0].replace(/\/$|$/, '/');
	let sParams = '';
	if (aUrl.length == 2) {
		sParams = `?${aUrl[1]}`;
	}

	const realUrl = `${NEXT_PUBLIC_API_URL}${sPath}${sParams}`;
	let data = null;

	let params = {
		method: type,
		headers: {
			'Access-Control-Allow-Origin': '*',
			Accept: 'application/json',
			'Content-Type': 'application/json',
			//Authorization: 'Bearer XXX',
		},
	};

	if (type == 'POST') {
		params.body = JSON.stringify(request);
	}

	try {
		let response = await fetch(realUrl, params);

		if (response.status === 200) {
			let result = await response.json();

			if (result?.error !== undefined) {
				return null;
			}

			if (callback) {
				const dt = callback(result);
				data = dt;
			} else {
				data = result;
			}
		}
	} catch (error) {
		console.log(error);
	}

	return data;
};

export const getData = async (
	url = null,
	type = 'GET',
	request = null,
	callback = null,
) => {
	try {
		const clearData = await fetchData(url, type, request, callback);

		//console.log(clearData);

		return clearData;
	} catch (error) {
		console.log(error);
	}
};

export const uploadAvatar = async (token, file) => {
	let data = null;
	try {
		// console.log(`token:`, token);
		// console.log(`file:`, file);

		const formdata = new FormData();
		formdata.append('token', token);
		formdata.append('action', 'avatar');
		formdata.append('file', file, file.name);

		// console.log(`formdata:`, formdata);

		const realUrl = `https://data.riche.skin/upl/`;
		let params = {
			method: 'POST',
			redirect: 'follow',
			// headers: {
			// 	// 'Access-Control-Allow-Origin': '*',
			// 	// //Accept: '*/*',
			// 	'Content-Type': 'multipart/form-data',
			// 	//Authorization: 'Bearer XXX',
			// },
			body: formdata,
		};

		// console.log('params:', params);
		// console.log('realUrl:', realUrl);

		try {
			let response = await fetch(realUrl, params);
			data = await response.json();

			//console.log('datadata:', data);
		} catch (error) {
			console.log(error);
		}
	} catch (error) {
		console.log(error);
	}
	return data;
};
