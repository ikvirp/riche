import { Img, Lnk } from '@/components/ui';
import parse, { domToReact } from 'html-react-parser';

const NEXT_PUBLIC_DATA_DOMAIN = process.env.NEXT_PUBLIC_DATA_DOMAIN;

const number_format = (
	number,
	decimals = 0,
	dec_point = '.',
	thousands_sep = ',',
) => {
	const sign = number < 0 ? '-' : '';
	const absNumber = Math.abs(number);
	const absNumberFixed = absNumber.toFixed(decimals);
	let s_number = parseInt(absNumberFixed).toString();
	const len = s_number.length;
	const tchunk = len > 3 ? len % 3 : 0;
	const ch_first = tchunk ? s_number.substr(0, tchunk) + thousands_sep : '';
	const ch_rest = s_number
		.substr(tchunk)
		.replace(/(\d\d\d)(?=\d)/g, '$1' + thousands_sep);
	const ch_last = decimals ? dec_point + absNumberFixed.slice(-decimals) : '';

	return sign + ch_first + ch_rest + ch_last;
};

export const numberFormat = (number, currency = false) => {
	return number_format(number, 0, ',', ' ');
};
export const numberFormat2 = (number, currency = false) => {
	return number_format(number, 2, ',', ' ');
};

export const prepareText = (text) => {
	const htmlOptions = {
		replace: (domNode) => {
			if (domNode.name === 'img') {
				const src = `${NEXT_PUBLIC_DATA_DOMAIN}${domNode.attribs.src}`;
				const alt = domNode.attribs.alt ? domNode.attribs.alt : 'фото';
				const title = domNode.attribs.alt ? domNode.attribs.alt : 'фото';
				const width = domNode.attribs.width ? domNode.attribs.width : 1600;
				const height = domNode.attribs.height ? domNode.attribs.height : 900;

				return (
					<Img
						src={src}
						alt={alt}
						title={title}
						width={width}
						height={height}
						empty={true}
						className="rounded-2xl"
					/>
				);
			}

			if (domNode.name === 'a') {
				//intext;
				return (
					<Lnk
						href={domNode.attribs.href}
						//shallow={true}
						title={domNode.attribs.title}
						className={`intext ${domNode.attribs.class}`}
					>
						{domToReact(domNode.children, htmlOptions)}
					</Lnk>
				);
			}

			// if (domNode.attribs.class === 'accent') {
			//   return (
			//     <span className='font-accent italic'>
			//       {domToReact(domNode.children, htmlOptions)}
			//     </span>
			//   );
			// }
		},
	};

	return parse(text, htmlOptions);
};

export const сalculateDiscountPercent = (current, old) => {
	var oldPrice = eval(old.replace(/,/, '.'));
	var currentPrice = eval(current.replace(/,/, '.'));

	return (100 * (oldPrice - currentPrice)) / oldPrice;
};

export const num_word = (value, words) => {
	value = Math.abs(value) % 100;
	var num = value % 10;
	if (value > 10 && value < 20) return words[2];
	if (num > 1 && num < 5) return words[1];
	if (num == 1) return words[0];
	return words[2];
};

export const prepareDate = (date_text) => {
	const oDate = new Date(date_text);

	const oMonth = {
		0: 'января',
		1: 'февраля',
		2: 'марта',
		3: 'апреля',
		4: 'мая',
		5: 'июня',
		6: 'июля',
		7: 'августа',
		8: 'сентября',
		9: 'октября',
		10: 'ноября',
		11: 'декабря',
	};

	const year = oDate.getFullYear();
	const month = oMonth[oDate.getMonth()];
	const day = oDate.getDate();
	return `${day} ${month}, ${year}`;
};

export const prepareDate2 = (date_text) => {
	const oDate = new Date(date_text);

	const MyDateString =
		('0' + oDate.getDate()).slice(-2) +
		'.' +
		('0' + (oDate.getMonth() + 1)).slice(-2) +
		'.' +
		oDate.getFullYear();

	return MyDateString;
};

export const parseSlug = (slug) => {
	const aLastGroup = slug.split('-');
	const lastGroup = parseInt(aLastGroup.slice(-1)[0]);

	if (aLastGroup.length == 0 || isNaN(lastGroup) || lastGroup == 0) {
		return null;
	}

	return lastGroup;
};

export const validatePassword = (password) => {
	// 1 строчная
	// 1 заглавная
	// 1 цифра
	// 1 символ (#?!@$%^&*-)
	// Функция валидации пароля с входящим параметром password
	const passwordRegEx =
		/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#@$!%?&+\-_]).{6,}$/; // Инициализация регулярного выражения
	return passwordRegEx.test(password); // Возвращает булево значение в зависимости от того, соответствует ли переданный параметр password регулярному выражению
};
