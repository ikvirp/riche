import { useEffect, useRef } from 'react';

// import { Fancybox as NativeFancybox } from '@fancyapps/ui';
// import '@fancyapps/ui/dist/fancybox/fancybox.css';

import { Carousel as NativeFancybox } from '@fancyapps/ui/dist/carousel/carousel.umd';
import '@fancyapps/ui/dist/carousel/carousel.css';

// import { Thumbs as NativeThumbs } from '@fancyapps/ui/dist/carousel/carousel.thumbs.umd';
// import '@fancyapps/ui/dist/carousel/carousel.thumbs.css';

// import { Fancybox as NativeFancybox } from '@fancyapps/ui/dist/fancybox/fancybox.umd';
// import '@fancyapps/ui/dist/fancybox/fancybox.css';

function FancyboxWrapperProduct(props) {
  const containerCarouselRef = useRef(null);

  useEffect(() => {
    // const container = containerRef.current;
    // const delegate = props.delegate || '[data-fancybox]';
    // const options = props.options || {};
    // NativeFancybox.bind(container, delegate, options);
    // return () => {
    //   NativeFancybox.unbind(container);
    //   NativeFancybox.close();
    // };

    const container = containerCarouselRef.current;
    const productCarousel = new Carousel(
      container,
      {
        transition: 'slide',
        preload: 3, // Smoother navigation when using lazy loaded images

        Dots: false,
        Thumbs: {
          type: 'classic',
          Carousel: {
            dragFree: false,
            slidesPerPage: 'auto',
            Navigation: true,

            axis: 'x',
            breakpoints: {
              '(min-width: 768px)': {
                axis: 'y',
              },
            },
          },
        },
      },
      { Thumbs }
    );
  });

  return <div ref={containerCarouselRef}>{props.children}</div>;
}

export default FancyboxWrapperProduct;
