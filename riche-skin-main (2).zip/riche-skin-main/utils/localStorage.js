export const getStorLocal = (item) => {
  if (typeof localStorage !== 'undefined') {
    return localStorage.getItem(item);
  }
  return null;
};
export const setStorLocal = (item, value) => {
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem(item, value);
  }
};
