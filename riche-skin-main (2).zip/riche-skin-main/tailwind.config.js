/** @type {import('tailwindcss').Config} */

// tailwind.config.js
const { fontFamily } = require('tailwindcss/defaultTheme');

//github.com/tailwindlabs/tailwindcss/blob/master/stubs/defaultConfig.stub.js

module.exports = {
	content: [
		'./app/**/*.{js,ts,jsx,tsx}',
		'./pages/**/*.{js,ts,jsx,tsx}',
		'./components/**/*.{js,ts,jsx,tsx}',
		'./layout/**/*.{js,ts,jsx,tsx}',
	],
	future: {
		hoverOnlyWhenSupported: true,
	},
	theme: {
		extend: {
			colors: { primary: '#58B151', primarygray: '#F8F8FA' },
			maxWidth: {
				1440: '1440px',
			},
			fontFamily: {
				//sans: ['var(--font-raleway)', ...fontFamily.sans],
				sans: ['var(--font-hoves)', ...fontFamily.sans],
				// accent: ['var(--font-livret)', ...fontFamily.serif],
			},
			// fontSize: {
			// 	// xs: '0.75rem',
			// 	// sm: '0.875rem',
			// 	// base: '1rem',
			// 	// lg: '1.125rem',
			// 	// xl: '1.25rem',
			// 	// '2xl': '1.5rem',
			// 	// '3xl': '1.875rem',
			// 	// '4xl': '2.25rem',
			// 	// '5xl': '3rem',
			// 	// '6xl': '3.75rem',
			// 	// '7xl': '4.5rem',
			// 	// '8xl': '6rem',
			// 	// '9xl': '8rem',

			// 	// '0.75rem',
			// 	// xs: '0.875rem',
			// 	// sm: '1rem',
			// 	// base: '1.125rem',
			// 	// lg: '1.25rem',
			// 	// xl: '1.5rem',
			// 	// '2xl': '1.875rem',
			// 	// '3xl': '2.25rem',
			// 	// '4xl': '3rem',
			// 	// '5xl': '3.75rem',
			// 	// '6xl': '4.5rem',
			// 	// '7xl': '6rem',
			// 	// '8xl': '8rem',
			// 	// '9xl': '8rem',
			// },
			fontWeight: {
				thin: '100',
				hairline: '100',
				extralight: '200',
				light: '300',
				normal: '400', // 400
				medium: '500',
				semibold: '600',
				bold: '500', //700
				extrabold: '800',
				'extra-bold': '800',
				black: '900',
			},
		},
	},
	plugins: [require('@tailwindcss/forms')],
};
