import { Aside, Content, Layout } from '@/components/common';
import { Button, Lnk, MeMenu, Modal } from '@/components/ui';
import { authOptions } from '@/pages/api/auth/[...nextauth]';
import { getData } from '@/utils/fetcher';
import {
	numberFormat,
	numberFormat2,
	prepareDate,
	prepareDate2,
} from '@/utils/prepare';
import { InformationCircleIcon } from '@heroicons/react/24/outline';
import { CheckCircleIcon } from '@heroicons/react/24/solid';
import { getServerSession } from 'next-auth/next';
import { NextSeo } from 'next-seo';
import { useRouter } from 'next/router';
import { useState } from 'react';

const MeOrderItem = ({ orders }) => {
	const [showModal, setShowModal] = useState(false);
	const [commentData, setCommentData] = useState({
		order_id: null,
		item_id: null,
		item_name: null,
	});

	const currentItem = orders.orders[0];

	const router = useRouter();

	const date = prepareDate(currentItem.datetime);
	const paid = currentItem.paid ? (
		<span className="bg-green-600 text-white text-sm px-1 py-0.5 rounded-md block">
			Оплачен
		</span>
	) : (
		<span className="bg-red-600 text-white text-sm px-1 py-0.5  rounded-md block">
			Неоплачен
		</span>
	);

	const status = currentItem.status.name ? (
		<span
			className=" text-white px-1 py-0.5  rounded-md block"
			style={{ background: currentItem.status.color, color: '#fff' }}
		>
			{currentItem.status.name}
		</span>
	) : null;

	const showStatuses = currentItem.canceled ? (
		<div className="px-1 py-0.5  bg-black text-white rounded-md block">
			Отменён
		</div>
	) : (
		<>
			{paid} {status}
		</>
	);

	const deliveryProvider = currentItem.delivery.provider_name
		? ` (${currentItem.delivery.provider_name})`
		: null;
	const trackButton = currentItem.delivery.track ? (
		<div className="pt-1">
			<Button
				Component="a"
				target="_blank"
				href={currentItem.delivery.track_url}
				title={currentItem.delivery.track}
			>
				Отследить
			</Button>
		</div>
	) : null;

	const aHistory =
		typeof currentItem.delivery.track_history != 'undefined'
			? currentItem.delivery.track_history
			: [];
	const aHistoryTest = [
		{
			key: 'onWay',
			name: 'В пути',
			description: '',
			errorCode: '',
			providerCode: 'ACCEPTED_IN_TRANSIT_CITY',
			providerName: 'Встречен в г. транзите',
			providerDescription: '',
			createdProvider: '2023-08-17T03:22:06+03:00',
			created: '2023-08-17T08:40:52+03:00',
		},
		{
			key: 'onWay',
			name: 'В пути',
			description: '',
			errorCode: '',
			providerCode: 'SENT_TO_TRANSIT_CITY',
			providerName: 'Отправлен в г. транзит',
			providerDescription: '',
			createdProvider: '2023-08-16T22:15:20+03:00',
			created: '2023-08-16T23:45:50+03:00',
		},
		{
			key: 'onWay',
			name: 'В пути',
			description: '',
			errorCode: '',
			providerCode: 'TAKEN_BY_TRANSPORTER_FROM_SENDER_CITY',
			providerName: 'Сдан перевозчику в г. отправителе',
			providerDescription: '',
			createdProvider: '2023-08-16T22:15:10+03:00',
			created: '2023-08-16T23:45:50+03:00',
		},
		{
			key: 'onWay',
			name: 'В пути',
			description: '',
			errorCode: '',
			providerCode: 'READY_FOR_SHIPMENT_IN_SENDER_CITY',
			providerName: 'Выдан на отправку в г. отправителе',
			providerDescription: '',
			createdProvider: '2023-08-16T17:40:29+03:00',
			created: '2023-08-16T23:45:50+03:00',
		},
		{
			key: 'onPointIn',
			name: 'Принят на склад в пункте отправления',
			description: 'Заказ физически принят на складе службы доставки',
			errorCode: '',
			providerCode: 'RETURNED_TO_SENDER_CITY_WAREHOUSE',
			providerName: 'Возвращен на склад отправителя',
			providerDescription: '',
			createdProvider: '2023-08-16T17:40:17+03:00',
			created: '2023-08-16T23:45:50+03:00',
		},
		{
			key: 'onWay',
			name: 'В пути',
			description: '',
			errorCode: '',
			providerCode: 'READY_FOR_SHIPMENT_IN_SENDER_CITY',
			providerName: 'Выдан на отправку в г. отправителе',
			providerDescription: '',
			createdProvider: '2023-08-16T17:40:14+03:00',
			created: '2023-08-16T23:45:50+03:00',
		},
		{
			key: 'onPointIn',
			name: 'Принят на склад в пункте отправления',
			description: 'Заказ физически принят на складе службы доставки',
			errorCode: '',
			providerCode: 'RECEIVED_AT_SHIPMENT_WAREHOUSE',
			providerName: 'Принят на склад отправителя',
			providerDescription: '',
			createdProvider: '2023-08-16T17:40:09+03:00',
			created: '2023-08-16T23:45:50+03:00',
		},
		{
			key: 'uploaded',
			name: 'Информация успешно загружена в систему перевозчика',
			description: '',
			errorCode: '',
			providerCode: 'CREATED',
			providerName: 'Создан',
			providerDescription: '',
			createdProvider: '2023-08-15T10:18:52+03:00',
			created: '2023-08-15T10:18:54+03:00',
		},
		{
			key: 'uploading',
			name: 'Загрузка информации в систему перевозчика',
			description: '',
			errorCode: '',
			providerCode: '',
			providerName: '',
			providerDescription: '',
			createdProvider: '',
			created: '2023-08-15T10:18:46+03:00',
		},
	];

	const trackHistory =
		aHistory.length > 0 ? (
			<div className="pb-6">
				<div className="inline-flex items-center gap-3  leading-none rounded-full py-1 px-3 border">
					<span className="font-bold">{`${aHistory[0].name}`} </span>
					<span
						className="flex items-center gap-1 text-sm cursor-pointer hover:opacity-60 text-gray-500"
						onClick={() => setShowModal(true)}
					>
						<InformationCircleIcon className="w-4 h-4" />
						Показать историю
					</span>
				</div>

				<Modal
					redirect={false}
					onClose={() => setShowModal(false)}
					show={showModal}
					title={`${currentItem.invoice}`}
				>
					<div className="p-0 pb-3 ">
						{aHistory.map((el, i) => {
							const sRealName =
								el.providerName.length > 1 ? el.providerName : el.name;

							const sRealDate =
								el.createdProvider.length > 1 ? el.createdProvider : el.created;

							const dt = prepareDate2(sRealDate);

							const classItem = i == 0 ? 'text-primary' : '';

							const nameApi =
								i == 0 && sRealName != el.name ? `${el.name} — ` : '';

							const classNameDot =
								i == 0
									? 'font-bold relative before:absolute before:block before:content-[""]  before:w-4 before:bg-primary before:h-4 before:-left-2 before:top-[3px] pl-4 before:rounded-full text-primary before:hidden'
									: 'font-bold relative before:absolute before:block before:content-[""]  before:w-4 before:bg-black before:h-4 before:-left-2 before:top-[3px] pl-4 before:rounded-full before:hidden';

							return (
								<div
									key={i}
									className='relative py-3 ml-1.5 before:absolute before:block before:content-[""]  before:w-[1px] before:bg-gray-300 before:h-full before:top-[16px] last:before:hidden'
								>
									<div className={classNameDot}>
										<span className="absolute -left-3 top-0 bg-white rounded-full leading-none">
											<CheckCircleIcon className="w-6 h-6" />
										</span>
										{`${nameApi}${sRealName}`}
									</div>
									{el.description.length > 1 && (
										<div className="text-sm text-gray-500 pl-4 ">
											{el.description}
										</div>
									)}
									<div className="text-xs text-gray-400 pl-4 pt-1">
										{/* {sRealDate} */}
										{dt}
									</div>
								</div>
							);
						})}
					</div>
				</Modal>
			</div>
		) : null;

	return (
		<>
			<NextSeo
				title={`Заказ ${currentItem.invoice}`}
				description={`Заказ ${currentItem.invoice}`}
			/>
			<Content aside>
				<div className="flex-1 order-2 max-w-2xl">
					<h1>{currentItem.invoice}</h1>

					{trackHistory}

					<div className="flex flex-col gap-3">
						<div className="text-sm text-gray-500">{date}</div>
						<div className="flex gap-1.5 text-sm">{showStatuses}</div>
						<div className="flex flex-col gap-0.5">
							<div>Email: {currentItem.person.email}</div>
							<div>Телефон: {currentItem.person.phone}</div>
							<div>Фамилия: {currentItem.person.surname}</div>
							<div>Имя: {currentItem.person.name}</div>
						</div>
						<hr />
						<div className="flex flex-col gap-1.5">
							<div className="flex gap-1.5">
								Способ оплаты: {currentItem.payment.name} {paid}
							</div>

							{!currentItem.paid && !currentItem.canceled && (
								<div>
									<Button
										onClick={() => router.push(`/checkout/${currentItem.guid}`)}
									>
										Оплатить
									</Button>
								</div>
							)}
						</div>
						<hr />
						<div className="flex flex-col gap-0.5">
							<div>Адрес: {currentItem.address.address.full}</div>
							<div>
								{currentItem.delivery.name}
								{deliveryProvider}
							</div>
							{/* {trackButton} */}
						</div>
						<hr />
						<div>
							<div className="font-bold text-xl">Состав заказа</div>

							<div className="flex flex-col gap-1.5">
								{currentItem.goods.map((el, i) => {
									let cl = el.price >= 0 ? 'pt-6 pl-0' : 'pt-0 pl-3';
									if (i == 0) {
										cl = 'pt-0';
									}

									return (
										<div key={i} className={cl}>
											<hr />
											<div className="flex justify-between" key={i}>
												<div className="flex-1">
													<div>
														<Lnk href={`/product/${el.slug}`} title={el.name}>
															{el.name}
														</Lnk>
													</div>
													<div className="text-sm text-gray-500">
														{el.marking}
													</div>
												</div>
												<div className="text-right">
													<div className="text-gray-500 text-sm">
														{numberFormat(el.quantity)} &times;{' '}
														{`${numberFormat2(el.price)} ${el.currency}`}
													</div>
													<div className=" ">{`${numberFormat2(el.total)} ${
														el.currency
													}`}</div>
												</div>
											</div>
										</div>
									);
								})}

								<hr />
								<div className="flex justify-between font-bold">
									<div className="flex-1">
										<div>Итого</div>
									</div>
									<div className="text-right">
										<div className=" ">{`${numberFormat2(currentItem.amount)} ${
											currentItem.currency
										}`}</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<Aside>
					<MeMenu />
				</Aside>
			</Content>
		</>
	);
};

MeOrderItem.getLayout = function getLayout(page, pageProps) {
	const currentItem = pageProps.orders.orders[0];

	const breadcrumbs = [
		{
			name: 'Личный кабинет',
			slug: '/me',
		},
		{
			name: 'История заказов',
			slug: '/me/orders',
		},
		{
			name: currentItem.invoice,
			slug: `/me/orders/${currentItem.guid}`,
		},
	];
	return (
		<Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
			{page}
		</Layout>
	);
};

export default MeOrderItem;

export async function getServerSideProps({ req, res, params }) {
	const session = await getServerSession(req, res, authOptions);

	if (!session) {
		return { redirect: { destination: '/signin' } };
	}

	const { slug } = params;

	//console.log(slug);

	const repoMenu = await getData(`/menu`);
	const repoMeOrders = await getData(`/me/orders`, 'POST', {
		token: session.token,
		guid: slug,
	});

	if (repoMeOrders.orders.length == 0) {
		return {
			notFound: true,
		};
	}

	return {
		props: { menu: repoMenu, orders: repoMeOrders },
	};
}
