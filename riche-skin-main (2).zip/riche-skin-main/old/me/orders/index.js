import { Aside, Content, Layout } from '@/components/common';
import { MeMenu, OrderCardShort } from '@/components/ui';
import { authOptions } from '@/pages/api/auth/[...nextauth]';
import styles from '@/styles/pages/OrdersPage.module.css';
import { getData } from '@/utils/fetcher';
import { getServerSession } from 'next-auth/next';
import { NextSeo } from 'next-seo';
import { useEffect, useState } from 'react';

const MeOrders = ({ token }) => {
  //console.log(orders.items);

  const [orders, setOrders] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const data = await getData(`/me/orders`, 'POST', {
        token: token,
      });
      if (data) {
        setOrders(data.orders);
      }
    };
    fetchData();
  }, []);

  return (
    <>
      <NextSeo title='История заказов' description='История заказов' />
      <Content aside>
        <div className='flex-1 order-2 max-w-2xl'>
          <h1>История заказов</h1>
          <div className='flex flex-col gap-3'>
            <div className={styles.list}>
              {orders.map((el, i) => (
                <OrderCardShort data={el} key={i} />
              ))}
            </div>
          </div>
        </div>
        <Aside>
          <MeMenu />
        </Aside>
      </Content>
    </>
  );
};

MeOrders.getLayout = function getLayout(page, pageProps) {
  const breadcrumbs = [
    {
      name: 'Личный кабинет',
      slug: '/me',
    },
    {
      name: 'История заказов',
      slug: '/me/orders',
    },
  ];
  return (
    <Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
      {page}
    </Layout>
  );
};

export default MeOrders;

export async function getServerSideProps({ req, res }) {
  const session = await getServerSession(req, res, authOptions);

  if (!session) {
    return { redirect: { destination: '/signin' } };
  }

  const repoMenu = await getData(`/menu`);

  return {
    props: { menu: repoMenu, token: session.token },
  };
}
