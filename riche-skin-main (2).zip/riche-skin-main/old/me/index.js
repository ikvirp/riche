import { Aside, Content, Layout } from '@/components/common';
import { Alert, Button, Lnk, MeMenu, OrderCardShort } from '@/components/ui';
import { authOptions } from '@/pages/api/auth/[...nextauth]';
import styles from '@/styles/pages/MePage.module.css';
import { getData } from '@/utils/fetcher';
import { getServerSession } from 'next-auth/next';
import { NextSeo } from 'next-seo';
import { useEffect, useState } from 'react';

const Me = ({ token }) => {
	//console.log(orders.items);

	const [me, setMe] = useState(null);

	useEffect(() => {
		const fetchData = async () => {
			const data = await getData(`/me`, 'POST', {
				token: token,
				orders: true,
			});
			if (data) {
				setMe(data);
			}
		};
		fetchData();
	}, []);

	const profileAlert =
		(me && me.profile.email.length == 0) ||
		(me && me.profile.phone.length == 0) ||
		(me && me.profile.name.length == 0) ||
		(me && me.profile.surname.length == 0) ? (
			<Alert variant="info" active close>
				<Lnk href="/me/profile">Заполнить данные профиля</Lnk>
			</Alert>
		) : null;

	const ordersList =
		me && me.orders.length > 0 ? (
			<div className="flex flex-col gap-3">
				<div className={styles.ttl}>Последние заказы</div>
				<div className={styles.list}>
					{me.orders.map((el, i) => (
						<OrderCardShort data={el} key={i} />
					))}
				</div>
			</div>
		) : (
			<div>
				<Button
					className="w-full"
					Component="a"
					href="/catalog"
					title="Перейти в каталог"
				>
					Перейти в каталог
				</Button>
			</div>
		);
	return (
		<>
			<NextSeo title="Личный кабинет" description="Личный кабинет" />
			<Content aside>
				<div className="flex-1 order-2 max-w-2xl">
					<h1>Личный кабинет</h1>
					{profileAlert}
					<div className="lead">
						<p>👋 Добро пожаловать в личный кабинет!</p>
					</div>

					{ordersList}
				</div>
				<Aside>
					<MeMenu />
				</Aside>
			</Content>
		</>
	);
};

Me.getLayout = function getLayout(page, pageProps) {
	const breadcrumbs = [
		{
			name: 'Личный кабинет',
			slug: '/me',
		},
	];
	return (
		<Layout breadcrumbs={breadcrumbs} menu={pageProps.menu}>
			{page}
		</Layout>
	);
};

export default Me;

export async function getServerSideProps({ req, res }) {
	const session = await getServerSession(req, res, authOptions);

	if (!session) {
		return { redirect: { destination: '/signin' } };
	}

	const repoMenu = await getData(`/menu`);

	return {
		props: { menu: repoMenu, token: session.token },
	};
}
